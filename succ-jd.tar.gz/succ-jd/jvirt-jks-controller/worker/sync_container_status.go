package worker

import (
	"encoding/json"
	"sync"
	"time"

	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/redis"
	"jd.com/jvirt/jvirt-jks-controller/bean"
	"jd.com/jvirt/jvirt-jks-controller/cfg"
	"jd.com/jvirt/jvirt-jks-controller/dao"
	"jd.com/jvirt/jvirt-jks-controller/util"
)

const (
	JvirtJksContainerStatusSyncTimeKey = "jvirt:jks:containerstatus:sync" // 记录时间点,作为下次查询数据库的条件.
)

func init() {
	RegisterCollector("SyncContainerStatusToCache", func(args *FactoryArgs) (Worker, error) {
		return &SyncContainerStatusInfo{
			tableDao:     dao.NewContainerStatusDao(args.Logger, args.DBCli),
			redisCli:     args.RedisCli,
			syncInterval: time.Duration(cfg.WorkerIntervalCfg.SyncInstanceInterval) * time.Second,
			logger:       args.Logger,
			isRunFull:    true,
		}, nil
	})
}

type SyncContainerStatusInfo struct {
	tableDao     *dao.ContainerStatusDao
	redisCli     redis.Redis
	logger       log.Logger
	syncInterval time.Duration
	isRunFull    bool
}

func (p *SyncContainerStatusInfo) Interval() time.Duration {
	return p.syncInterval
}

func (p *SyncContainerStatusInfo) Name() string {
	return "SyncContainerStatusToCache"
}

func (p *SyncContainerStatusInfo) Work() error {
	isFullSync, lastSyncTime, err := isFullSync(p.redisCli, p.logger, JvirtJksContainerStatusSyncTimeKey)
	if err != nil {
		return err
	}

	p.logger.Info("Redis Key: %s, Value: %s, FullSync: %s", JvirtJksContainerStatusSyncTimeKey, lastSyncTime, isFullSync)

	if isFullSync {
		if err := p.fullSync(); err != nil {
			p.logger.Error("Invoke fullSync failed. Error: %s.", err.Error())
			return err
		}
		return nil
	}
	// 执行增量同步数据到Redis.
	if err := p.incrementSync(lastSyncTime.UTC()); err != nil {
		p.logger.Error("Invoke incrementSync failed. Error: %s.", err.Error())
		return err
	}

	return nil
}

// 全量更新
func (p *SyncContainerStatusInfo) fullSync() error {
	var innerErr error

	p.logger.Info("fullSync ContainerStatus start.")

	// 全量备份前需要将redis中的数据清除,否则会出现脏数据.
	keys, err := p.redisCli.GetKeys(common.JksCacheContainerStatusPrefix + "*")
	if err != nil {
		p.logger.Error("Invoke Redis KEYS failed. Error: %s.", err.Error())
		return err
	}

	// 信号量,并发的数量.
	wg := &sync.WaitGroup{}
	concurrence := make(chan int, 20)
	defer close(concurrence)

	for _, redisKey := range keys {
		wg.Add(1)
		concurrence <- 1

		go func(rKey string) {
			defer wg.Done()

			_, err := p.redisCli.Del(rKey)
			if err != nil {
				p.logger.Error("Invoke Redis DEL [%s] key failed. Error: %s.", rKey, err.Error())
				innerErr = err
			}
			<-concurrence
		}(redisKey)
	}

	wg.Wait()

	if innerErr != nil {
		return innerErr
	}

	nextUpdateTime, err := p.tableDao.NextUpdateTime()
	if err != nil {
		return err
	}

	totalNum, err := p.tableDao.QueryCanSyncCount()
	if err != nil {
		p.logger.Warn("Invoke DB QueryCanSyncCount failed. Error: %s.", err.Error())
		return err
	}
	p.logger.Info("Total ContainerStatus count: %d.", totalNum)

	if totalNum == 0 {
		if err := p.redisCli.StrSet(JvirtJksContainerStatusSyncTimeKey, nextUpdateTime); err != nil {
			p.logger.Error("Update redisCli key %s failed.", JvirtJksContainerStatusSyncTimeKey)
			return err
		}
		p.logger.Info("fullSync ContainerStatus finished, no update.")

		return nil
	}

	for i := 0; i < util.Page(totalNum, defaultPageSize); i++ {
		query := &dao.QueryCondition{
			Page:     i * defaultPageSize,
			PageSize: defaultPageSize,
		}

		containerStatuses, err := p.tableDao.QueryByPage(query)
		if err != nil {
			// 如果查询失败，导致缓存的数据有问题。
			return err
		}
		if containerStatuses == nil || len(containerStatuses) == 0 {
			break
		}

		for _, containerStatus := range containerStatuses {
			wg.Add(1)
			concurrence <- 1

			go func(inst *bean.ContainerStatus) {
				hashKey := common.JksCacheContainerStatusPrefix + inst.HostIp
				hashField := inst.ContainerName

				data, err := json.Marshal(inst.ConvertCacheModel())
				if err != nil {
					innerErr = err
				}

				if err := p.redisCli.HashFieldSet(hashKey, hashField, string(data)); err != nil {
					innerErr = err
				}

				<-concurrence
				wg.Done()
			}(containerStatus)
		}

		wg.Wait()

		if innerErr != nil {
			return innerErr
		}
	}

	// 需要更新同步状态为增量
	if err := p.redisCli.StrSet(JvirtJksContainerStatusSyncTimeKey, nextUpdateTime); err != nil {
		p.logger.Error("Update redisCli key %s failed.", JvirtJksContainerStatusSyncTimeKey)
		return err
	}

	p.logger.Info("fullSync ContainerStatus finished.")

	return nil
}

func (p *SyncContainerStatusInfo) incrementSync(beforeUpdateTime time.Time) error {
	p.logger.Info("Increment sync ContainerStatus start. BeforeUpdateTime: %s.", beforeUpdateTime)

	nextUpdateTime, err := p.tableDao.NextUpdateTime()
	if err != nil {
		return err
	}

	cond := &dao.QueryCondition{
		UpdateTime: beforeUpdateTime,
	}
	objects, err := p.tableDao.QueryIncrementSync(cond)
	if err != nil {
		p.logger.Error("Invoke QueryTaskAfterUpdateTime failed. Error: %#v.", err)
		return err
	}
	if objects == nil || len(objects) == 0 {
		p.logger.Info("no objects found")
		return nil
	}

	for _, object := range objects {
		hashKey := common.JksCacheContainerStatusPrefix + object.HostIp
		hashField := object.ContainerName
		// TODO: 需要清理迁移完的原计算节点上的ContainerStatus.

		// 清理由于Pod删除，redis中产生ContainerStatus脏数据.
		if object.Status == common.DBStatusDelete {
			if _, err := p.redisCli.HashFieldDel(hashKey, hashField); err != nil {
				p.logger.Warn("Delete hash field failed, generate dirty data. Key: %s, Filed: %s, Error: %s.", hashKey, hashField, err.Error())
			}
		} else {
			data, err := json.Marshal(object.ConvertCacheModel())
			if err != nil {
				p.logger.Error("Json marshal content failed. ContainerId: %s, Error: %s.", hashField, err.Error())
				return err
			}
			if err := p.redisCli.HashFieldSet(hashKey, hashField, string(data)); err != nil {
				p.logger.Error("Set hash field failed. Key: %s, Filed: %s, Error: %s.", hashKey, hashField, err.Error())
				return err
			}
		}
	}

	if err := p.redisCli.StrSet(JvirtJksContainerStatusSyncTimeKey, nextUpdateTime); err != nil {
		p.logger.Warn("Update %s key failed. Error: %#v.", JvirtJksContainerStatusSyncTimeKey, err)
	}

	p.logger.Info("Increment update ContainerStatus end.")

	return nil
}
