package worker

import (
	"time"
)

type Worker interface {
	Name() string            // 采集器名称
	Work() error             // 采集信息
	Interval() time.Duration // 间隔时间
}
