package worker

import (
	"sync"
	"time"

	"jd.com/jvirt/jvirt-common/inner/jks/api"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jks-controller/bean"
	"jd.com/jvirt/jvirt-jks-controller/cfg"
	"jd.com/jvirt/jvirt-jks-controller/dao"
)

func init() {
	RegisterCollector("CompensateTask", func(args *FactoryArgs) (Worker, error) {
		return &CompensateTask{
			taskDao:      dao.NewTaskDao(args.Logger, args.DBCli),
			logger:       args.Logger,
			jksApiClient: args.JksApiClient,
			interval:     time.Duration(cfg.WorkerIntervalCfg.CompensateTaskInterval) * time.Second,
			delay:        cfg.DefaultCfg.DelayCompensate,
		}, nil
	})
}

type CompensateTask struct {
	taskDao      *dao.TaskDao
	logger       log.Logger
	jksApiClient api.InnerApi
	interval     time.Duration
	delay        int
}

// 间隔时间
func (p *CompensateTask) Interval() time.Duration {
	return p.interval
}

// 采集器名称
func (p *CompensateTask) Name() string {
	return "CompensateTask"
}

/*
需要补偿的任务:
1. (task_before=1 and task_state="pending") 调用rms申请资源失败的任务.
2. (task_after=1 and task_state in ("failed","finished") 任务处理完成或者失败后,但是资源释放失败的任务.
*/
func (p *CompensateTask) Work() error {
	queryTask := &dao.QueryTaskCondition{
		Delay: p.delay,
	}
	p.logger.Info("[CompensateTaskWorker] delay in queryTask: [%d].", queryTask.Delay)
	tasks, err := p.taskDao.QueryCompensateTasks(queryTask)
	if err != nil {
		p.logger.Error("[CompensateTaskWorker] Invoke QueryCompensateTasks failed. Error: %$v.", err)
		return err
	}

	if len(tasks) == 0 {
		p.logger.Info("[CompensateTaskWorker] There is no task to compensate.")
		return nil
	}

	// 同时最多补偿20个任务.
	tokens := make(chan struct{}, 20)

	wg := &sync.WaitGroup{}
	for _, item := range tasks {
		p.logger.Info("[CompensateTaskWorker] Compensate TaskId: %v.", item.Id)
		wg.Add(1)
		tokens <- struct{}{}
		go func(task *bean.Task) {
			defer func() {
				<-tokens
				wg.Done()
			}()

			taskRequest := &api.CompenstateTaskRequest{
				RequestId: task.RequestId + "-Compensate",
				TaskId:    task.Id,
			}

			if jErr := p.jksApiClient.CompensateTask(taskRequest); jErr != nil {
				p.logger.Error("[CompensateTaskWorker] Invoke api CompensateTask failed. TaskId: %v, Err: %s, Detail: %s.",
					task.Id, jErr.Error(), jErr.Detail())
			}
		}(item)
	}
	wg.Wait()

	return nil
}
