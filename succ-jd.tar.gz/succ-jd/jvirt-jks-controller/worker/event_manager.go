package worker

import (
	"time"

	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	"jd.com/jvirt/jvirt-common/integration/billing"
	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jks-controller/bean"
	"jd.com/jvirt/jvirt-jks-controller/cfg"
	"jd.com/jvirt/jvirt-jks-controller/dao"
)

const (
	pendingString  = "pending"
	finishedString = "finished"
	Hyper          = "hyper"
	Pod            = "pod"
)

const (
	StartBilling  = 1
	StopBilling   = 2
	FinishBilling = 4
)

type EventManager struct {
	logger        log.Logger
	tableDao      *dao.EventDao
	podDao        *dao.PodDao
	dbOperator    *db.ExtendDB
	jksApiClient  api.InnerApi
	billingClient *billing.BillingClient
	syncInterval  time.Duration
}

func init() {
	RegisterCollector("EventManager", func(args *FactoryArgs) (Worker, error) {
		return &EventManager{
			tableDao:      dao.NewEventDao(args.Logger, args.DBCli),
			podDao:        dao.NewPodDao(args.Logger, args.DBCli),
			jksApiClient:  args.JksApiClient,
			billingClient: args.BillingApiCli,
			syncInterval:  time.Duration(cfg.WorkerIntervalCfg.SyncEventInterval) * time.Second,
			logger:        args.Logger,
		}, nil
	})
}

func needByBilling(event *bean.Event) int {
	eventType := event.EventType

	if eventType == "task" && event.TaskState == jks.TaskFinished {
		switch event.TaskType {
		case jks.PodStartTask, jks.PodCreateTask:
			return StartBilling
		case jks.PodStopTask:
			return StopBilling
		case jks.PodDeleteTask:
			return FinishBilling
		default:
			return -1
		}
	}

	if eventType == "agent" {
		oldResState := event.OldResourceState
		newResState := event.NewResourceState

		// POD状态Error，Stopped，会停止计费
		if newResState == jks.PodPhaseError || newResState == jks.PodPhaseStopped {
			return StopBilling
		}
		// POD状态Running，Failed，Succeeded，会开始计费
		if newResState == jks.PodPhaseRunning || newResState == jks.PodPhaseFailed || newResState == jks.PodPhaseSucceeded {
			if oldResState == jks.PodPhaseRunning || oldResState == jks.PodPhaseFailed || oldResState == jks.PodPhaseSucceeded {
				return -1
			}
			return StartBilling
		}
	}

	return -1
}

func (p *EventManager) toBillingEvent(opType int, event *bean.Event) (*billing.OpRecordParam, error) {
	billingEvent := &billing.OpRecordParam{
		Site:       0,
		AppCode:    "jcloud",
		OpType:     opType,
		ResourceId: event.ResourceId,
		OpTime:     event.CreatedTime.UTC().Add(8 * time.Hour).Format("2006-01-02 15:04:05"),
	}

	instId := event.ResourceId
	if instanceType, err := p.podDao.QueryInstanceTypeByPodId(instId); err != nil {
		return nil, err
	} else {
		billingEvent.InstanceType = instanceType
	}
	return billingEvent, nil
}

func (p *EventManager) Interval() time.Duration {
	return p.syncInterval
}

func (p *EventManager) Name() string {
	return "EventManager"
}

func (p *EventManager) Work() error {
	p.logger.Debug("EventManager start")

	cond := &dao.QueryEventCondition{
		EventState: pendingString,
	}
	events, err := p.tableDao.QueryEvent(cond)
	if err != nil {
		p.logger.Error("QueryEvent failed. Error : %s", err.Error())
		return nil
	}

	for _, event := range events {
		eventId := event.Id
		opType := needByBilling(event)

		if opType < 0 {
			// 如果没有消耗event，也会把event_state置成finished
			p.logger.Info("get opType from event failed. Event: %+v", *event)
			req := &api.UpdateEventRequest{
				Id:         eventId,
				EventState: finishedString,
			}
			if err := p.jksApiClient.UpdateEvent(req); err != nil {
				p.logger.Error("jksApiClient.UpdateEvent failed. EventId: %v, Error: %s.", eventId, err.Error())
			}
			continue
		}

		billingEvent, err := p.toBillingEvent(opType, event)
		if err != nil {
			p.logger.Error("toBillingEvent failed. EventId: %v, Error: %s.", eventId, err.Error())
			continue
		}
		if err := p.billingClient.SendOpRecord(billingEvent); err != nil {
			p.logger.Error("send billing event failed. EventId: %+v, billingEvent: %+v, Error: %s", event, billingEvent, err.Error())
			continue
		}

		p.logger.Debug("send success to billing system. EventId: %v, OpType: %v.", event, opType)

		req := &api.UpdateEventRequest{
			Id:         eventId,
			EventState: finishedString,
		}
		if err := p.jksApiClient.UpdateEvent(req); err != nil {
			p.logger.Error("jksApiClient.UpdateEvent failed. EventId: %v, Error: %s.", eventId, err.Error())
			continue
		}
	}

	p.logger.Debug("EventManager finished")

	return nil
}
