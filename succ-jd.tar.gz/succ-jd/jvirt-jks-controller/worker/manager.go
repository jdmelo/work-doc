package worker

import (
	"errors"
	"sync"
	"time"

	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/runtime"
	"jd.com/jvirt/jvirt-common/utils/wait"
)

// 数据库表迁移周期.
const (
	moveTime = time.Hour * -7 * 24 // 一周
	delTime  = time.Hour * -9 * 24
)

type WorkerManager struct {
	logger    log.Logger
	workers   []Worker
	stop      chan struct{}
	mut       *sync.Mutex
	isStarted bool
	waitGroup *sync.WaitGroup
}

func NewWorkerManager(logger log.Logger) *WorkerManager {
	return &WorkerManager{
		workers:   make([]Worker, 0),
		stop:      make(chan struct{}),
		mut:       &sync.Mutex{},
		isStarted: false,
		waitGroup: &sync.WaitGroup{},
		logger:    logger,
	}
}

func (p *WorkerManager) AddWorker(worker Worker) {
	p.mut.Lock()
	defer p.mut.Unlock()

	p.workers = append(p.workers, worker)
}

func (p *WorkerManager) Start() error {
	p.logger.Info("WorkerManager Start lock")
	p.mut.Lock()
	defer p.mut.Unlock()
	p.logger.Info("WorkerManager Start lock success")

	p.stop = make(chan struct{})

	if p.isStarted {
		return errors.New("manager is started")
	}
	p.isStarted = true
	if len(p.workers) == 0 {
		return nil
	}
	for _, worker := range p.workers {
		p.waitGroup.Add(1)
		go func(worker Worker) {
			defer p.waitGroup.Done()
			wait.Until(p.trigger(worker), worker.Interval(), p.stop)
		}(worker)
	}
	return nil

}

func (p *WorkerManager) Stop() {
	p.logger.Info("WorkerManager Stop lock")
	p.mut.Lock()
	defer p.mut.Unlock()
	p.logger.Info("WorkerManager Stop lock success")
	if p.isStarted {
		close(p.stop)
		p.waitGroup.Wait()
	}
	p.isStarted = false
}

func (p *WorkerManager) trigger(worker Worker) func() {
	return func() {
		defer runtime.HandleCrash(func(err interface{}) {
			p.logger.Error("worker run panic. Detail: %v.", err)
		})
		workerName := worker.Name()
		p.logger.Info("Worker [%s] begins to start.", workerName)
		if err := worker.Work(); err != nil {
			p.logger.Error("Worker [%s] runs failed. Error: %#v.", workerName, err)
		}
		p.logger.Info("Worker [%s] end of the run.", workerName)
	}
}
