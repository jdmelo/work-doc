package worker

import (
	"time"

	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jks-controller/cfg"
	"jd.com/jvirt/jvirt-jks-controller/dao"
)

func init() {
	RegisterCollector("BackupEvent", func(args *FactoryArgs) (Worker, error) {
		return &BackupEvent{
			logger:          args.Logger,
			tableDao:        dao.NewEventDao(args.Logger, args.DBCli),
			dbOperator:      args.DBCli,
			syncInterval:    time.Duration(cfg.WorkerIntervalCfg.BackupEventInterval) * time.Second,
			backupTimePoint: cfg.BackupTimePointCfg.BackupEventTimePoint,
		}, nil
	})
}

type BackupEvent struct {
	logger          log.Logger
	tableDao        *dao.EventDao
	dbOperator      *db.ExtendDB
	syncInterval    time.Duration
	backupTimePoint int
}

func (p *BackupEvent) Interval() time.Duration {
	return p.syncInterval
}

func (p *BackupEvent) Name() string {
	return "BackupEvent"
}

func (p *BackupEvent) backup() error {
	p.logger.Info("Backup jvirt_jks.event table start.")

	cond := &dao.QueryEventCondition{
		UpdateTime: time.Now().Add(moveTime),
	}
	condDel := &dao.QueryEventCondition{
		UpdateTime: time.Now().Add(delTime),
	}
	if err := p.tableDao.InsertToBackupTable(cond); err != nil {
		p.logger.Error("Invoke InsertToBackupTable failed. Error: %#v.", err)
		return err
	}

	if err := p.tableDao.DeleteFromSrcTable(condDel); err != nil {
		p.logger.Error("Invoke DeleteFromSrcTable failed. Error: %#v.", err)
		return err
	}
	p.logger.Info("Backup jvirt_jks.event table end.")

	return nil
}

func (p *BackupEvent) Work() error {
	if time.Now().Hour() == p.backupTimePoint {
		if err := p.backup(); err != nil {
			p.logger.Error("Backup jvirt_jks.event table failed. Error: %#v.", err)
			return err
		}
	}

	return nil
}
