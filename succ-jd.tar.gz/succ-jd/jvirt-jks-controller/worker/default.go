package worker

import (
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	"jd.com/jvirt/jvirt-common/integration/billing"
	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/redis"
)

var WorkerFactorys = make(map[string]Factory)

type FactoryArgs struct {
	Logger        log.Logger
	DBCli         *db.ExtendDB
	RedisCli      redis.Redis
	JksApiClient  api.InnerApi
	BillingApiCli *billing.BillingClient
}

type Factory func(factoryArgs *FactoryArgs) (Worker, error)

func RegisterCollector(name string, factory Factory) {
	WorkerFactorys[name] = factory
}
