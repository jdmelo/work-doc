package worker

import (
	"time"

	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jks-controller/cfg"
	"jd.com/jvirt/jvirt-jks-controller/dao"
)

func init() {
	RegisterCollector("BackupTask", func(args *FactoryArgs) (Worker, error) {
		return &BackupTask{
			logger:          args.Logger,
			tableDao:        dao.NewTaskDao(args.Logger, args.DBCli),
			dbOperator:      args.DBCli,
			syncInterval:    time.Duration(cfg.WorkerIntervalCfg.BackupTaskInterval) * time.Second,
			backupTimePoint: cfg.BackupTimePointCfg.BackupTaskTimePoint,
		}, nil
	})
}

type BackupTask struct {
	logger          log.Logger
	tableDao        *dao.TaskDao
	dbOperator      *db.ExtendDB
	syncInterval    time.Duration
	backupTimePoint int
}

func (p *BackupTask) Interval() time.Duration {
	return p.syncInterval
}

func (p *BackupTask) Name() string {
	return "BackupTask"
}

func (p *BackupTask) backup() error {
	p.logger.Info("Backup jvirt_jks.task table start.")

	cond := &dao.QueryTaskCondition{
		UpdateTime: time.Now().Add(moveTime),
	}
	condDel := &dao.QueryTaskCondition{
		UpdateTime: time.Now().Add(delTime),
	}
	if err := p.tableDao.InsertToBackupTable(cond); err != nil {
		p.logger.Error("Invoke InsertToBackupTable failed. Error: %#v.", err)
		return err
	}

	if err := p.tableDao.DeleteFromSrcTable(condDel); err != nil {
		p.logger.Error("Invoke DeleteFromSrcTable failed. Error: %#v.", err)
		return err
	}

	p.logger.Info("Backup jvirt_jks.task table end.")

	return nil
}

func (p *BackupTask) Work() error {

	if time.Now().Hour() == p.backupTimePoint {
		if err := p.backup(); err != nil {
			p.logger.Error("Backup jvirt_jks.task table failed. Error: %#v.", err)
			return err
		}
	}

	return nil
}
