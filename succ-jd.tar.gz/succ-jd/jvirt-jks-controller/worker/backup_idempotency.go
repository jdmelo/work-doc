package worker

import (
	"time"

	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jks-controller/cfg"
	"jd.com/jvirt/jvirt-jks-controller/dao"
)

// 数据库表迁移周期.
const (
	IdempotencyMoveTime = time.Hour * -30 * 24 // 一个月
	IdempotencyDelTime  = time.Hour * -32 * 24
)

type BackupIdempotency struct {
	logger          log.Logger
	dbOperator      *db.ExtendDB
	tableDao        *dao.IdempotencyDao
	syncInterval    time.Duration
	backupTimePoint int
}

func init() {
	RegisterCollector("BackupIdempotency", func(args *FactoryArgs) (Worker, error) {
		return &BackupIdempotency{
			logger:          args.Logger,
			backupTimePoint: cfg.BackupTimePointCfg.BackupIdempotencyTimePoint,
			syncInterval:    time.Duration(cfg.WorkerIntervalCfg.BackupIdempotencyInterval) * time.Second,
			dbOperator:      args.DBCli,
			tableDao:        dao.NewIdempotencyDao(args.Logger, args.DBCli),
		}, nil
	})
}

func (p *BackupIdempotency) Interval() time.Duration {
	return p.syncInterval
}

func (p *BackupIdempotency) Name() string {
	return "BackupIdempotency"
}

func (p *BackupIdempotency) backup() error {
	p.logger.Info("Backup jvirt_jks.idempotency table start.")
	cond := &dao.QueryIdempotencyCondition{
		UpdateTime: time.Now().Add(IdempotencyMoveTime),
	}
	condDel := &dao.QueryIdempotencyCondition{
		UpdateTime: time.Now().Add(IdempotencyDelTime),
	}
	if err := p.tableDao.InsertToBackupTable(cond); err != nil {
		p.logger.Error("Invoke InsertToBackupTable failed. Error: %#v.", err)
		return err
	}

	if err := p.tableDao.DeleteFromSrcTable(condDel); err != nil {
		p.logger.Error("Invoke DeleteFromSrcTable failed. Error: %#v.", err)
		return err
	}
	p.logger.Info("Backup jvirt_jks.idempotency table end.")

	return nil
}

func (p *BackupIdempotency) Work() error {

	if time.Now().Hour() == p.backupTimePoint {
		if err := p.backup(); err != nil {
			p.logger.Error("Backup jvirt_jks.idempotency table failed. Error: %#v.", err)
			return err
		}
	}

	return nil
}
