package worker

import (
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/redis"
	"time"
)

func isFullSync(redis redis.Redis, log log.Logger, key string) (bool, time.Time, error) {
	var lastSyncTime time.Time
	exist, err := redis.Exist(key)
	if err != nil {
		log.Error("Invoke redis Exist failed, key: %s, err: %s", key, err.Error())
		return true, lastSyncTime, err
	}
	if !exist {
		log.Info("LastSyncTime not exist, key: %s", key)
		return true, lastSyncTime, nil
	}

	value, err := redis.StrGet(key)
	if err != nil {
		log.Error("Invoke redis StrGet failed, key: %s, err: %s", key, err.Error())
		return true, lastSyncTime, err
	}

	lastSyncTime, err = time.Parse("2006-01-02 15:04:05", value)
	if err != nil {
		log.Error("LastSyncTime is invalid, key: %s, value: %s, err: %s", key, value, err.Error())
		return true, lastSyncTime, nil
	}

	log.Info("Query lastSyncTime succeed, key: %s, value: %s", key, value)
	return false, lastSyncTime, nil
}
