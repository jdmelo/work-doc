package worker

import (
	"encoding/json"
	"strconv"
	"sync"
	"time"

	"jd.com/jvirt/jvirt-common/inner/jks"
	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/redis"
	"jd.com/jvirt/jvirt-jks-controller/bean"
	"jd.com/jvirt/jvirt-jks-controller/cfg"
	"jd.com/jvirt/jvirt-jks-controller/dao"
)

/* Sync task data from mysql to redis. */

const (
	JvirtJksTaskSyncTimeKey = "jvirt:jks:task:sync" // 记录时间点,作为下次查询数据库的条件.
)

func init() {
	RegisterCollector("SyncTaskToCache", func(args *FactoryArgs) (Worker, error) {
		return &SyncTaskInfo{
			tableDao:     dao.NewTaskDao(args.Logger, args.DBCli),
			redisCli:     args.RedisCli,
			syncInterval: time.Duration(cfg.WorkerIntervalCfg.SyncTaskInterval) * time.Second,
			logger:       args.Logger,
			isRunFull:    true,
		}, nil
	})
}

type Extends struct {
	AllocId      string   `json:"alloc_id"`
	RetryHosts   []string `json:"retry_hosts"`
	ExcludeHosts []string `json:"exclude_hosts"`
	IncludeHosts []string `json:"include_hosts"`
	InstanceType string   `json:"instance_type"`
}

type SyncTaskInfo struct {
	tableDao     *dao.TaskDao
	redisCli     redis.Redis
	syncInterval time.Duration
	logger       log.Logger
	isRunFull    bool
}

func (p *SyncTaskInfo) Interval() time.Duration {
	return p.syncInterval
}

func (p *SyncTaskInfo) Name() string {
	return "SyncTaskToCache"
}

// 全量更新
func (p *SyncTaskInfo) full() error {
	var innerErr error

	p.logger.Info("Full update tasks start.")

	// 全量备份前需要将redis中的数据清除,否则会出现脏数据.
	keys, err := p.redisCli.GetKeys(common.JksCacheTaskPrefix + "*")
	if err != nil {
		p.logger.Error("Invoke Redis KEYS failed. Error: %#v.", err)
		return err
	}

	// 信号量,并发的数量.
	wg := &sync.WaitGroup{}
	concurrence := make(chan int, 20)
	defer close(concurrence)

	for _, redisKey := range keys {
		wg.Add(1)
		concurrence <- 1

		go func(rKey string) {
			defer wg.Done()

			_, err := p.redisCli.Del(rKey)
			if err != nil {
				p.logger.Error("Invoke Redis DEL [%s] key failed. Error: %#v.", rKey, err)
				innerErr = err
			}
			<-concurrence
		}(redisKey)
	}

	wg.Wait()
	if innerErr != nil {
		return innerErr
	}

	nextUpdateTime, err := p.tableDao.NextUpdateTime()
	if err != nil {
		return err
	}

	tasks, err := p.tableDao.QueryRunningTasks()
	if err != nil {
		// 如果查询失败，导致缓存的数据有问题。
		p.logger.Error("Invoke QueryRunningTasks failed. Error: %#v.", err)
		return err
	}
	if tasks == nil || len(tasks) == 0 {
		if err := p.redisCli.StrSet(JvirtJksTaskSyncTimeKey, nextUpdateTime); err != nil {
			p.logger.Error("Update redisCli key jvirt:jks:task:sync failed.")
			return err
		}
		p.logger.Info("Full update tasks end, no tasks found.")
		return nil
	}

	for _, task := range tasks {
		wg.Add(1)
		concurrence <- 1

		go func(task *bean.Task) {
			defer wg.Done()

			key := common.JksCacheTaskPrefix + task.HostIp
			content, err := json.Marshal(task.ConvertCacheModel())
			if err != nil {
				p.logger.Error("Invoke json Marshal failed. TaskId: %s, Error: %#v.", task.Id, err)
				innerErr = err
			}
			if err := p.redisCli.HashFieldSet(key, strconv.Itoa(int(task.Id)), string(content)); err != nil {
				p.logger.Error("Invoke HashFieldSet failed. TaskId: %s, Error: %#v.", task.Id, err)
				innerErr = err
			}

			<-concurrence
		}(task)
	}

	wg.Wait()
	if innerErr != nil {
		return innerErr
	}

	if err := p.redisCli.StrSet(JvirtJksTaskSyncTimeKey, nextUpdateTime); err != nil {
		p.logger.Error("Update redisCli key `jvirt:jks:task:sync` failed.")
		return err
	}

	p.logger.Info("Full update tasks end.")

	return nil
}

func (p *SyncTaskInfo) increment(beforeUpdateTime time.Time) error {
	p.logger.Info("Increment update task start. Before UpdateTime: %s.", beforeUpdateTime)

	nextUpdateTime, err := p.tableDao.NextUpdateTime()
	if err != nil {
		return err
	}

	query := &dao.QueryTaskCondition{
		UpdateTime: beforeUpdateTime,
	}
	tasks, err := p.tableDao.QueryTaskAfterUpdateTime(query)
	if err != nil {
		p.logger.Error("Invoke QueryTaskAfterUpdateTime failed. Error: %#v.", err)
		return err
	}
	if tasks == nil || len(tasks) == 0 {
		p.logger.Info("no tasks found")
		return nil
	}

	for _, task := range tasks {
		var retryHosts []string
		key := common.JksCacheTaskPrefix + task.HostIp
		taskId := strconv.Itoa(int(task.Id))

		if task.TaskType == jks.PodCreateTask {
			extends := new(Extends)
			if err := json.Unmarshal([]byte(task.Extends), extends); err != nil {
				p.logger.Error("Unmarshal Task.Extends content failed. TaskId: %v, Error: %#v.", taskId, err)
				return err
			}
			retryHosts = extends.RetryHosts
		}
		p.logger.Debug("CreateTask RetryHosts: %v, TaskId: %v.", retryHosts, taskId)
		for _, host := range retryHosts {
			key := common.JksCacheTaskPrefix + host
			if _, err := p.redisCli.HashFieldDel(key, taskId); err != nil {
				// 任务删除失败,running状态的task,会一直存在,成为脏数据.
				p.logger.Error("Delete hash filed failed. key: %s, filed: %s, Error: %#v.", key, taskId, err)
				return err
			}
		}

		if task.TaskState == jks.TaskFinished || task.TaskState == jks.TaskFailed {
			// 任务删除失败,running状态的task,会一直存在,成为脏数据.
			_, err := p.redisCli.HashFieldDel(key, taskId)
			if err != nil {
				p.logger.Error("Delete hash filed failed. key: %s, filed: %s, Error: %#v.", key, taskId, err)
				return err
			}
		} else {
			data, err := json.Marshal(task.ConvertCacheModel())
			if err != nil {
				p.logger.Error("Invoke json Marshal failed. TaskId: %s, Error: %#v.", taskId, err)
				return err
			}
			if err := p.redisCli.HashFieldSet(key, taskId, string(data)); err != nil {
				// 任务没有添加到Cache中需要报警,否则会出现任务丢失.
				p.logger.Error("Set hash filed failed. key: %s, filed: %s, Error: %#v.", key, taskId, err)
				return err
			}
		}
	}

	if err := p.redisCli.StrSet(JvirtJksTaskSyncTimeKey, nextUpdateTime); err != nil {
		p.logger.Warn("Update jvirt:jks:task:sync key failed. Error: %#v.", err)
	}

	p.logger.Info("Increment update task end.")

	return nil
}

/*
数据库时间窗口过期导致的问题:
1. redis中脏数据问题,数据库中处于finished或者failed状态的任务,在redis中一直处于running状态.
2. running的任务不能同步到redis中,导致任务丢失现象.

为了解决以上问题,需要定期调用全量同步.
*/
func (p *SyncTaskInfo) Work() error {
	isFullSync, lastSyncTime, err := isFullSync(p.redisCli, p.logger, JvirtJksTaskSyncTimeKey)
	if err != nil {
		return err
	}

	p.logger.Info("Redis Key: %s, Value: %s, FullSync: %s", JvirtJksTaskSyncTimeKey, lastSyncTime, isFullSync)

	if isFullSync {
		if err := p.full(); err != nil {
			p.logger.Error("Invoke fullSync failed. Error: %s.", err.Error())
			return err
		}
		return nil
	}

	// 执行增量同步数据到Redis.
	if err := p.increment(lastSyncTime.UTC()); err != nil {
		p.logger.Error("Invoke increment update failed. Error: %#v.", err)
		return err
	}

	return nil
}
