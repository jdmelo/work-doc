package bean

import (
	"time"

	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/model"
)

type PodStatus struct {
	PodId   string `db:"pod_id" json:"pod_id"`
	HostIp  string `db:"host_ip" json:"host_ip"`
	Phase   string `db:"phase" json:"phase"`
	Reason  string `db:"reason" json:"reason"`
	Message string `db:"message" json:"message"`
	Status  int    `db:"status" json:"status"`
}

func (p *PodStatus) ConvertCacheModel() *model.CachePodStatus {
	obj := &model.CachePodStatus{
		Phase:   p.Phase,
		Reason:  p.Reason,
		Message: p.Message,
	}

	return obj
}

type PodCondition struct {
	PodId              string `db:"pod_id" json:"pod_id"`
	HostIp             string `db:"host_ip" json:"host_ip"`
	ConditionType      string `db:"condition_type" json:"condition_type"`
	ConditionStatus    string `db:"condition_status" json:"condition_status"`
	Reason             string `db:"reason" json:"reason"`
	Message            string `db:"message" json:"message"`
	LastProbeTime      string `db:"last_probe_time" json:"last_probe_time"`
	LastTransitionTime string `db:"last_transition_time" json:"last_transition_time"`
	Status             int    `db:"status" json:"status"`
}

func (p *PodCondition) ConvertCacheModel() *model.CachePodCondition {
	obj := &model.CachePodCondition{
		Reason:             p.Reason,
		Message:            p.Message,
		Status:             p.ConditionStatus,
		LastProbeTime:      p.LastProbeTime,
		LastTransitionTime: p.LastTransitionTime,
	}

	return obj
}

type ContainerStatus struct {
	PodId               string `db:"pod_id" json:"pod_id"`
	Phase               string `db:"phase" json:"phase"`
	HostIp              string `db:"host_ip" json:"host_ip"`
	ContainerName       string `db:"container_name" json:"container_name"`
	RestartCount        int    `db:"restart_count" json:"restart_count"`
	Ready               bool   `db:"ready" json:"ready"`
	CurrentState        string `db:"current_state" json:"current_state"`
	CurrentStateContent string `db:"current_state_content" json:"current_state_content"`
	Status              int    `db:"status" json:"status"`
}

func (p *ContainerStatus) ConvertCacheModel() *model.CacheContainerStatus {
	obj := &model.CacheContainerStatus{
		Phase:               p.Phase,
		RestartCount:        p.RestartCount,
		Ready:               p.Ready,
		CurrentState:        p.CurrentState,
		CurrentStateContent: p.CurrentStateContent,
	}

	return obj
}

type Task struct {
	Id          int64     `db:"id" json:"id"`
	UserId      string    `db:"user_id" json:"user_id"`
	RequestId   string    `db:"request_id" json:"request_id"`
	TaskType    string    `db:"task_type" json:"task_type"`
	ReferId     string    `db:"refer_id" json:"refer_id"`
	HostIp      string    `db:"host_ip" json:"host_ip"`
	Content     string    `db:"content" json:"content"`
	Extends     string    `db:"extends" json:"extends"`
	Timeout     int       `db:"timeout" json:"timeout"`
	RetryTime   int       `db:"retry_time" json:"retry_time"`
	TaskAfter   int       `db:"task_after" json:"task_after"`
	TaskBefore  int       `db:"task_before" json:"task_before"`
	Fault       string    `db:"fault" json:"fault"`
	TaskState   string    `db:"task_state" json:"task_state"`
	CreatedTime time.Time `db:"created_time" json:"created_time"`
	UpdateTime  time.Time `db:"update_time" json:"update_time"`
	Status      int       `db:"status" json:"status"`
}

func (p *Task) ConvertCacheModel() *jks.Task {
	obj := &jks.Task{
		TaskId:     p.Id,
		TaskType:   p.TaskType,
		Content:    p.Content,
		HostIp:     p.HostIp,
		TaskState:  p.TaskState,
		UserId:     p.UserId,
		Timeout:    p.Timeout,
		ReferId:    p.ReferId,
		TaskBefore: p.TaskBefore,
		TaskAfter:  p.TaskAfter,
		RequestId:  p.RequestId,
	}

	return obj
}

type Idempotency struct {
	Id          int64     `db:"id" json:"id"`
	UserId      string    `db:"user_id" json:"user_id"`
	ClientToken string    `db:"client_token" json:"client_token"`
	Action      string    `db:"action" json:"action"`
	State       string    `db:"state" json:"state"`
	Chost       string    `db:"chost" json:"chost"`
	Shost       string    `db:"shost" json:"shost"`
	Output      string    `db:"output" json:"output"`
	Input       string    `db:"input" json:"input"`
	ExecuteTime int       `db:"execute_time" json:"execute_time"`
	CreatedTime time.Time `db:"created_time" json:"created_time"`
	UpdateTime  time.Time `db:"update_time" json:"update_time"`
	Status      int       `db:"status" json:"status"`
}

type Event struct {
	Id               int64     `db:"id" json:"id"`
	ResourceId       string    `db:"resource_id" json:"resource_id"`
	ResourceType     string    `db:"resource_type" json:"resource_type"`
	NewResourceState string    `db:"new_resource_state" json:"new_resource_state"`
	OldResourceState string    `db:"old_resource_state" json:"old_resource_state"`
	TaskId           int64     `db:"task_id" json:"task_id"`
	TaskType         string    `db:"task_type" json:"task_type"`
	TaskState        string    `db:"task_state" json:"task_state"`
	EventType        string    `db:"event_type" json:"event_type"`
	EventState       string    `db:"event_state" json:"event_state"`
	CreatedTime      time.Time `db:"created_time" json:"created_time"`
	UpdateTime       time.Time `db:"update_time" json:"update_time"`
	Status           int       `db:"status" json:"status"`
}

type InstanceType struct {
	InstanceType string `db:"instance_type" json:"instance_type"`
}
