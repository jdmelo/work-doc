package dao

import (
	"errors"
	"time"

	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/log"
)

var (
	queryNow = db.NewSql(`select now() as now`)
)

var ErrGetDBTime = errors.New("get the now time of DB failed")

type QueryNow struct {
	Now time.Time `db:"now"`
}

type BaseDao struct {
	Operator db.DBOperator
	Logger   log.Logger
}

type QueryCondition struct {
	Page       int       `db:"page"`
	PageSize   int       `db:"page_size"`
	UpdateTime time.Time `db:"update_time"`
}

func (p *BaseDao) QueryUTCTime() (time.Time, error) {
	t := time.Time{}
	result, err := p.Operator.Query(queryNow, nil, func() interface{} { return &QueryNow{} })
	if err != nil {
		return t, err
	}
	if result == nil {
		return t, ErrGetDBTime
	}
	dbNowTime := result.(*QueryNow)
	if dbNowTime == nil {
		return t, ErrGetDBTime
	}

	t = dbNowTime.Now.UTC()

	return t, nil
}

func (p *BaseDao) NextUpdateTime() (string, error) {
	dbTime, err := p.QueryUTCTime()
	if err != nil {
		p.Logger.Error("Invoke select dbTime() failed. Error: %s.", err.Error())
		return "", err
	}

	next := dbTime.Add(-10 * time.Second).Format("2006-01-02 15:04:05")
	p.Logger.Info("CurrentDBUTCTime: %s, NextQueryUpdateTime: %s.", dbTime, next)

	return next, nil
}
