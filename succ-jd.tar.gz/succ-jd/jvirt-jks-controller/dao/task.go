package dao

import (
	"time"

	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jks-controller/bean"
)

var (
	queryRunningTask         = db.NewSql(`select id,user_id,request_id,task_type,refer_id,host_ip,content,extends,timeout,retry_time,task_after,task_before,fault,task_state,created_time,update_time,status from task where task_state="running"`)
	queryTaskAfterUpdateTime = db.NewSql(`select id,user_id,request_id,task_type,refer_id,host_ip,content,extends,timeout,retry_time,task_after,task_before,fault,task_state,created_time,update_time,status from task where update_time>:update_time and task_state in ("running", "failed", "finished")`)
	queryCompensateTask      = db.NewSql(`select id,user_id,request_id,task_type,refer_id,host_ip,content,extends,timeout,retry_time,task_after,task_before,fault,task_state,created_time,update_time,status from task where (update_time<date_sub(now(),interval :delay second)) and ((task_before=1 and task_state="pending") or (task_after=1 and task_state in ("failed","finished")))`)
)

type QueryTaskCondition struct {
	UpdateTime time.Time `db:"update_time"`
	Delay      int       `db:"delay"`
}

type TaskDao struct {
	BaseDao
}

func NewTaskDao(l log.Logger, operator db.DBOperator) *TaskDao {
	b := BaseDao{
		Logger:   l,
		Operator: operator,
	}
	return &TaskDao{
		BaseDao: b,
	}
}

func (td *TaskDao) QueryRunningTasks() ([]*bean.Task, error) {
	result, err := td.Operator.List(queryRunningTask, nil, func() interface{} { return &bean.Task{} })
	if err != nil {
		return nil, err
	}

	if result == nil {
		return nil, nil
	}

	tasks := make([]*bean.Task, 0, len(result))
	for _, value := range result {
		tasks = append(tasks, value.(*bean.Task))
	}

	return tasks, nil
}

func (td *TaskDao) QueryTaskAfterUpdateTime(queryTask *QueryTaskCondition) ([]*bean.Task, error) {
	result, err := td.Operator.List(queryTaskAfterUpdateTime, queryTask, func() interface{} { return &bean.Task{} })
	if err != nil {
		return nil, err
	}
	if result == nil || len(result) == 0 {
		return nil, nil
	}
	tasks := make([]*bean.Task, 0, len(result))
	for _, value := range result {
		tasks = append(tasks, value.(*bean.Task))
	}
	return tasks, nil
}

func (td *TaskDao) QueryCompensateTasks(delay *QueryTaskCondition) ([]*bean.Task, error) {
	result, err := td.Operator.List(queryCompensateTask, delay, func() interface{} { return &bean.Task{} })
	if err != nil {
		return nil, err
	}
	if len(result) == 0 {
		return nil, nil
	}
	tasks := make([]*bean.Task, 0, len(result))
	for _, value := range result {
		tasks = append(tasks, value.(*bean.Task))
	}
	return tasks, nil
}

func (td *TaskDao) InsertToBackupTable(cond *QueryTaskCondition) error {
	insertSql := db.NewSql(`INSERT IGNORE INTO task_bak SELECT * FROM task WHERE update_time<:update_time and task_state in ("failed", "finished") and task_after in (2, 3)`)
	td.Logger.Debug("InsertIntoBackupFromTask SQL: %s", insertSql.Generate(cond))

	_, err := td.Operator.Update(insertSql, cond)
	if err != nil {
		return err
	}

	return nil
}

func (td *TaskDao) DeleteFromSrcTable(cond *QueryTaskCondition) error {
	delSql := db.NewSql(`DELETE task FROM task INNER JOIN task_bak ON task.id = task_bak.id`)
	td.Logger.Debug("DeleteTaskByIds SQL: %s", delSql.Generate(cond))

	_, err := td.Operator.Update(delSql, cond)
	if err != nil {
		return err
	}

	return nil
}
