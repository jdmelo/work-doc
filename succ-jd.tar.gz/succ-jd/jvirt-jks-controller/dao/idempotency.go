package dao

import (
	"time"

	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/log"
)

type QueryIdempotencyCondition struct {
	UpdateTime time.Time `db:"update_time"`
}

type IdempotencyDao struct {
	BaseDao
}

func NewIdempotencyDao(l log.Logger, operator db.DBOperator) *IdempotencyDao {
	b := BaseDao{
		Logger:   l,
		Operator: operator,
	}
	return &IdempotencyDao{
		BaseDao: b,
	}
}

func (id *IdempotencyDao) InsertToBackupTable(cond *QueryIdempotencyCondition) error {
	insertSql := db.NewSql(`INSERT IGNORE INTO idempotency_bak SELECT * FROM idempotency WHERE update_time<:update_time`)
	id.Logger.Debug("InsertIntoIdempotencyBakFromIdempotency SQL: %s", insertSql.Generate(cond))

	_, err := id.Operator.Update(insertSql, cond)
	if err != nil {
		return err
	}

	return nil
}

func (id *IdempotencyDao) DeleteFromSrcTable(cond *QueryIdempotencyCondition) error {
	delSql := db.NewSql(`DELETE idempotency FROM idempotency INNER JOIN idempotency_bak ON idempotency.id = idempotency_bak.id`)
	id.Logger.Debug("DeleteIdempotencyByIds SQL: %s", delSql.Generate(cond))

	_, err := id.Operator.Update(delSql, cond)
	if err != nil {
		return err
	}

	return nil
}
