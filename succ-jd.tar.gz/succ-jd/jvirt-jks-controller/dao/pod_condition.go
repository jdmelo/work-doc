package dao

import (
	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jks-controller/bean"
)

var (
	// condition: p.task_id=0 and p.status=1 and p.host_ip!=""
	queryCanSyncPodConditionCount = db.NewSql(`select count(pc.id) from pod_condition pc join pod p on pc.pod_id=p.pod_id where p.task_id=0 and p.status=1 and p.host_ip!=""`)
	// condition: p.task_id=0 and p.status=1 and p.host_ip!=""
	queryFullSyncPodConditionSQL = db.NewSql(`select p.pod_id, p.host_ip, pc.condition_type, pc.condition_status, pc.reason, pc.message, pc.last_probe_time, pc.last_transition_time, pc.status from pod_condition pc join pod p on pc.pod_id=p.pod_id where p.task_id=0 and p.status=1 and p.host_ip!="" order by p.created_time limit {{.Page}}, {{.PageSize}}`)
	// condition: p.task_id=0 and p.host_ip!="" and ps.update_time>:update_time
	queryIncSyncPodConditionSQL = db.NewSql(`select p.pod_id, p.host_ip, pc.condition_type, pc.condition_status, pc.reason, pc.message, pc.last_probe_time, pc.last_transition_time, pc.status from pod_condition pc join pod p on pc.pod_id=p.pod_id where p.task_id=0 and p.host_ip!="" and p.update_time>:update_time`)
)

type PodConditionDao struct {
	BaseDao
}

func NewPodConditionDao(l log.Logger, operator db.DBOperator) *PodConditionDao {
	b := BaseDao{
		Logger:   l,
		Operator: operator,
	}
	return &PodConditionDao{
		BaseDao: b,
	}
}

func (p *PodConditionDao) QueryCanSyncCount() (int, error) {
	c := 1
	result, err := p.Operator.Query(queryCanSyncPodConditionCount, nil, func() interface{} { return &c })
	if err != nil {
		return 0, err
	}
	count := *(result.(*int))

	return count, nil
}

func (p *PodConditionDao) QueryIncrementSync(cond *QueryCondition) ([]*bean.PodCondition, error) {
	result, err := p.Operator.List(queryIncSyncPodConditionSQL, cond, func() interface{} { return &bean.PodCondition{} })
	if err != nil {
		return nil, err
	}

	if result == nil {
		return nil, nil
	}

	podConditions := make([]*bean.PodCondition, 0, len(result))
	for _, value := range result {
		podConditions = append(podConditions, value.(*bean.PodCondition))
	}

	return podConditions, nil
}

func (p *PodConditionDao) QueryByPage(cond *QueryCondition) ([]*bean.PodCondition, error) {
	result, err := p.Operator.List(queryFullSyncPodConditionSQL, cond, func() interface{} { return &bean.PodCondition{} })
	if err != nil {
		return nil, err
	}

	if result == nil {
		return nil, nil
	}

	podConditions := make([]*bean.PodCondition, 0, len(result))
	for _, value := range result {
		podConditions = append(podConditions, value.(*bean.PodCondition))
	}

	return podConditions, nil
}
