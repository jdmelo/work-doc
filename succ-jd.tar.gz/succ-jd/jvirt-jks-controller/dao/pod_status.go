package dao

import (
	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jks-controller/bean"
)

var (
	// condition: p.task_id=0 and p.status=1 and p.host_ip!=""
	queryCanSyncPodCount = db.NewSql(`select count(ps.id) from pod_status ps join pod p on ps.pod_id=p.pod_id where p.task_id=0 and p.status=1 and p.host_ip!=""`)
	// condition: p.task_id=0 and p.status=1 and p.host_ip!=""
	queryFullSyncPodStatusSQL = db.NewSql(`select p.pod_id, p.host_ip, ps.phase, ps.reason, ps.message, ps.status from pod_status ps join pod p on ps.pod_id=p.pod_id where p.task_id=0 and p.status=1 and p.host_ip!="" order by ps.created_time limit {{.Page}}, {{.PageSize}}`)
	// condition: p.task_id=0 and p.host_ip!="" and ps.update_time>:update_time
	queryIncSyncPodStatusSQL = db.NewSql(`select p.pod_id, p.host_ip, ps.phase, ps.reason, ps.message, ps.status from pod_status ps join pod p on ps.pod_id=p.pod_id where p.task_id=0 and p.host_ip!="" and p.update_time>:update_time`)
)

type PodStatusDao struct {
	BaseDao
}

func NewPodStatusDao(l log.Logger, operator db.DBOperator) *PodStatusDao {
	b := BaseDao{
		Logger:   l,
		Operator: operator,
	}
	return &PodStatusDao{
		BaseDao: b,
	}
}

func (p *PodStatusDao) QueryCanSyncCount() (int, error) {
	c := 1
	result, err := p.Operator.Query(queryCanSyncPodCount, nil, func() interface{} { return &c })
	if err != nil {
		return 0, err
	}
	count := *(result.(*int))

	return count, nil
}

func (p *PodStatusDao) QueryIncrementSync(cond *QueryCondition) ([]*bean.PodStatus, error) {
	result, err := p.Operator.List(queryIncSyncPodStatusSQL, cond, func() interface{} { return &bean.PodStatus{} })
	if err != nil {
		return nil, err
	}

	if result == nil {
		return nil, nil
	}

	ret := make([]*bean.PodStatus, 0, len(result))
	for _, value := range result {
		ret = append(ret, value.(*bean.PodStatus))
	}

	return ret, nil
}

func (p *PodStatusDao) QueryByPage(cond *QueryCondition) ([]*bean.PodStatus, error) {
	result, err := p.Operator.List(queryFullSyncPodStatusSQL, cond, func() interface{} { return &bean.PodStatus{} })
	if err != nil {
		return nil, err
	}

	if result == nil {
		return nil, nil
	}

	instances := make([]*bean.PodStatus, 0, len(result))
	for _, value := range result {
		instances = append(instances, value.(*bean.PodStatus))
	}

	return instances, nil
}
