package dao

import (
	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jks-controller/bean"
)

var (
	// condition: p.task_id=0 and p.status=1 and p.host_ip!=""
	queryCanSyncContainerStatusCount = db.NewSql(`select count(cs.id) from container_status cs join pod p on cs.pod_id=p.pod_id where p.task_id=0 and p.status=1 and p.host_ip!=""`)
	// condition: p.task_id=0 and p.status=1 and p.host_ip!=""
	queryFullSyncContainerStatusSQL = db.NewSql(`select p.pod_id, cs.phase, p.host_ip, cs.container_name, cs.restart_count, cs.ready, cs.current_state, cs.current_state_content, cs.status from container_status cs join pod p on cs.pod_id=p.pod_id where p.task_id=0 and p.status=1 and p.host_ip!="" order by cs.created_time limit {{.Page}}, {{.PageSize}}`)
	// condition: p.task_id=0 and p.host_ip!="" and ps.update_time>:update_time
	queryIncSyncContainerStatusSQL = db.NewSql(`select p.pod_id, cs.phase, p.host_ip, cs.container_name, cs.restart_count, cs.ready, cs.current_state, cs.current_state_content, cs.status from container_status cs join pod p on cs.pod_id=p.pod_id where p.task_id=0 and p.host_ip!="" and p.update_time>:update_time`)
)

type ContainerStatusDao struct {
	BaseDao
}

func NewContainerStatusDao(l log.Logger, operator db.DBOperator) *ContainerStatusDao {
	b := BaseDao{
		Logger:   l,
		Operator: operator,
	}
	return &ContainerStatusDao{
		BaseDao: b,
	}
}

func (p *ContainerStatusDao) QueryCanSyncCount() (int, error) {
	c := 1
	result, err := p.Operator.Query(queryCanSyncContainerStatusCount, nil, func() interface{} { return &c })
	if err != nil {
		return 0, err
	}
	count := *(result.(*int))

	return count, nil
}

func (p *ContainerStatusDao) QueryIncrementSync(cond *QueryCondition) ([]*bean.ContainerStatus, error) {
	result, err := p.Operator.List(queryIncSyncContainerStatusSQL, cond, func() interface{} { return &bean.ContainerStatus{} })
	if err != nil {
		return nil, err
	}

	if result == nil {
		return nil, nil
	}

	ret := make([]*bean.ContainerStatus, 0, len(result))
	for _, value := range result {
		ret = append(ret, value.(*bean.ContainerStatus))
	}

	return ret, nil
}

func (p *ContainerStatusDao) QueryByPage(cond *QueryCondition) ([]*bean.ContainerStatus, error) {
	result, err := p.Operator.List(queryFullSyncContainerStatusSQL, cond, func() interface{} { return &bean.ContainerStatus{} })
	if err != nil {
		return nil, err
	}

	if result == nil {
		return nil, nil
	}

	containerStatuses := make([]*bean.ContainerStatus, 0, len(result))
	for _, value := range result {
		containerStatuses = append(containerStatuses, value.(*bean.ContainerStatus))
	}

	return containerStatuses, nil
}
