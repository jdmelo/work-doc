package dao

import (
	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jks-controller/bean"
)

var (
	QueryInstanceTypeByPodIdSQL = db.NewSql(`select instance_type from pod where pod_id=:pod_id`)
)

type PodDao struct {
	BaseDao
}

func NewPodDao(l log.Logger, operator db.DBOperator) *PodDao {
	b := BaseDao{
		Logger:   l,
		Operator: operator,
	}
	return &PodDao{
		BaseDao: b,
	}
}

func (p *PodDao) QueryInstanceTypeByPodId(podId string) (string, error) {
	result, err := p.Operator.Query(QueryInstanceTypeByPodIdSQL, map[string]interface{}{"pod_id": podId}, func() interface{} { return &bean.InstanceType{} })
	if err != nil {
		return "", err
	}
	count := result.(*bean.InstanceType)

	return count.InstanceType, nil
}
