package dao

import (
	"time"

	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jks-controller/bean"
)

var (
	queryEvent = db.NewSql(`select id,resource_id,resource_type,new_resource_state,old_resource_state,task_id,task_type,task_state,event_type,event_state,created_time,update_time,status
		from event where
		{{if ne .EventState ""}} event_state=:event_state AND {{end}}
        {{if ne .EventType ""}}event_type=:event_type AND {{end}}
        status=1`)
)

type QueryEventCondition struct {
	UpdateTime time.Time `db:"update_time" json:"update_time"`
	EventState string    `db:"event_state" json:"event_state"`
	EventType  string    `db:"event_type" json:"event_type"`
}

type EventDao struct {
	BaseDao
}

func NewEventDao(l log.Logger, operator db.DBOperator) *EventDao {
	b := BaseDao{
		Logger:   l,
		Operator: operator,
	}

	return &EventDao{
		BaseDao: b,
	}
}

func (p *EventDao) QueryEvent(param *QueryEventCondition) ([]*bean.Event, error) {
	result, err := p.Operator.List(queryEvent, param, func() interface{} { return &bean.Event{} })
	if err != nil {
		return nil, err
	}
	if result == nil {
		return nil, nil
	}
	events := make([]*bean.Event, 0, len(result))
	for _, value := range result {
		events = append(events, value.(*bean.Event))
	}
	return events, nil
}

func (p *EventDao) InsertToBackupTable(cond *QueryEventCondition) error {
	insertSql := db.NewSql(`INSERT IGNORE INTO event_bak SELECT * FROM event WHERE update_time<:update_time AND event_state="finished"`)
	p.Logger.Debug("InsertIntoBackupFromEvent SQL: %s", insertSql.Generate(cond))

	_, err := p.Operator.Update(insertSql, cond)
	if err != nil {
		return err
	}

	return nil
}

func (p *EventDao) DeleteFromSrcTable(cond *QueryEventCondition) error {
	delSql := db.NewSql(`DELETE event FROM event INNER JOIN event_bak ON event.id = event_bak.id`)
	p.Logger.Debug("DeleteEventByIds SQL: %s", delSql.Generate(cond))

	_, err := p.Operator.Update(delSql, cond)
	if err != nil {
		return err
	}

	return nil
}
