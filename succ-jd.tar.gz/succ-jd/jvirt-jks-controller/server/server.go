package server

import (
	"time"

	"jd.com/jvirt/jvirt-common/inner/jks/api"
	"jd.com/jvirt/jvirt-common/integration/billing"
	"jd.com/jvirt/jvirt-common/utils/config"
	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/leader"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/redis"
	"jd.com/jvirt/jvirt-jks-controller/cfg"
	"jd.com/jvirt/jvirt-jks-controller/model"
	"jd.com/jvirt/jvirt-jks-controller/worker"
)

type jksControllerServer struct {
	logger        log.Logger
	stop          chan struct{}
	workerManager *worker.WorkerManager
}

func (s *jksControllerServer) Master() {
	err := s.Start()
	if err != nil {
		panic(err.Error())
	}
}

func (s *jksControllerServer) Slave() {
	s.Stop()
}

func (s *jksControllerServer) Start() error {
	s.logger.Info("jksControllerServer Start")
	if err := s.workerManager.Start(); err != nil {
		return err
	}

	return nil
}

func (s *jksControllerServer) Stop() {
	s.logger.Info("jksControllerServer Stop")
	close(s.stop)
	s.workerManager.Stop()

}

func createDBClient(c *model.DatabaseConfig) (*db.ExtendDB, error) {
	conf := &config.Database{
		Ip:            c.Ip,
		Port:          c.Port,
		User:          c.User,
		Password:      c.Password,
		DB:            c.DB,
		Timeout:       c.Timeout,
		MaxConnection: c.MaxConnection,
		MaxLifetime:   c.MaxLifetime,
	}
	instance := &db.MysqlInstance{Conf: conf}
	databaseInstance, err := instance.NewMysqlInstance()
	if err != nil {
		return nil, err
	}
	database := db.NewExtendDB(databaseInstance)
	return database, nil
}

func createRedisClient(c *model.RedisConfig) (redis.Redis, error) {
	// 修改为单机模式, 有redis proxy做ha
	redisClient, err := redis.New(c.Addr[0], c.IdleMax, c.ActiveMax, time.Duration(c.IdleTimeout)*time.Second, c.Password, true)
	if err != nil {
		return nil, err
	}

	return redisClient, nil
}

func createJksApiClient(c *config.JksApiConfig, logger log.Logger) api.InnerApi {
	return api.NewJksInnerApiClient(c, logger)
}

func createBillingApiClient(c *config.BillingConfig, l log.Logger) *billing.BillingClient {
	return billing.NewBillingClient(l, c)
}

func CreateVote(l log.Logger) (leader.Vote, error) {
	selectModel := cfg.VoteCfg.Model
	localId := cfg.VoteCfg.LocalID
	masterId := cfg.VoteCfg.MasterID
	voteKeyName := cfg.VoteCfg.VoteKeyName
	voteKeyLease := time.Duration(cfg.VoteCfg.VoteKeyLease) * time.Second

	dbCli, err := createDBClient(cfg.DatabaseCfg)
	if err != nil {
		return nil, err
	}

	redisCli, err := createRedisClient(cfg.RedisCfg)
	if err != nil {
		return nil, err
	}

	vote, err := leader.NewRedisVote(l, redisCli, selectModel, masterId, localId, voteKeyName, voteKeyLease)
	if err != nil {
		return nil, err
	}

	workerManager := worker.NewWorkerManager(l)
	factoryArgs := &worker.FactoryArgs{
		Logger:        l,
		DBCli:         dbCli,
		RedisCli:      redisCli,
		JksApiClient:  createJksApiClient(cfg.JksApiCfg, l),
		BillingApiCli: createBillingApiClient(cfg.BillingApiCfg, l),
	}
	workerMap := make(map[string]int)
	for _, item := range cfg.DefaultCfg.Workers {
		workerMap[item] = 1
	}
	for _, factory := range worker.WorkerFactorys {
		w, err := factory(factoryArgs)
		if err != nil {
			return nil, err
		}
		workerName := w.Name()
		if _, ok := workerMap[workerName]; ok {
			workerManager.AddWorker(w)
		}
	}
	ser := &jksControllerServer{
		workerManager: workerManager,
		logger:        l,
		stop:          make(chan struct{}),
	}

	vote.RegisterWorker(ser)

	return vote, nil
}
