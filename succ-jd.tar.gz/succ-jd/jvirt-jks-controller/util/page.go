package util

// page 从1开始
func Page(count, pageSize int) (pageCount int) {
	if count == 0 {
		return 0
	}
	return (count / pageSize) + 1
}
