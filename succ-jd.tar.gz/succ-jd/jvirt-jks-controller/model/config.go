package model

type DefaultConfig struct {
	Region          string   `ini:"region" validate:"nonzero"`
	HostIp          string   `ini:"host_ip" validate:"nonzero"`
	RuntimeCores    int      `ini:"runtime_cores"`
	DelayCompensate int      `ini:"delay_compensate"`
	DebugModel      bool     `ini:"debug_model"`                // 服务是否在debug模式，服务在debug模式下，一些问题会直接crash掉进程，便于调试问题。
	Workers         []string `ini:"workers" validate:"nonzero"` // 需要加载的 workers,以逗号分隔
}

type LogConfig struct {
	Level    string `ini:"level"`
	FilePath string `ini:"file_path" validate:"nonzero"`
}

type DatabaseConfig struct {
	Ip            string `ini:"ip" validate:"nonzero"`
	Port          int    `ini:"port" validate:"nonzero"`
	User          string `ini:"user" validate:"nonzero"`
	Password      string `ini:"password" validate:"nonzero"`
	DB            string `ini:"db" validate:"nonzero"`
	Timeout       int    `ini:"timeout"`
	MaxConnection int    `ini:"max_connection"`
	MaxLifetime   int    `ini:"max_life_time"`
}

type RedisConfig struct {
	Addr        []string `ini:"addr" validate:"nonzero"`
	Password    string   `ini:"password"`
	IdleMax     int      `ini:"idle_max"`
	ActiveMax   int      `ini:"active_max"`
	IdleTimeout int      `ini:"idle_timeout"`
}

type VoteConfig struct {
	Model        string `ini:"model"` // vote | fixed
	LocalID      string `ini:"local_id" validate:"nonzero"`
	MasterID     string `ini:"master_id"`
	VoteKeyName  string `ini:"vote_key_name"`
	VoteKeyLease int    `ini:"vote_key_lease"`
}

type WorkerIntervalConfig struct {
	CompensateTaskInterval    int `ini:"compensate_task_interval"`
	SyncInstanceInterval      int `ini:"sync_instance_interval"`
	SyncTaskInterval          int `ini:"sync_task_interval"`
	SyncEventInterval         int `ini:"sync_event_interval"`
	BackupTaskInterval        int `ini:"backup_task_interval"`
	BackupEventInterval       int `ini:"backup_event_interval"`
	BackupIdempotencyInterval int `ini:"backup_idempotency_interval"`
}

type BackupTimePointConfig struct {
	BackupTaskTimePoint        int `ini:"backup_task_time_point"`
	BackupEventTimePoint       int `ini:"backup_event_time_point"`
	BackupIdempotencyTimePoint int `ini:"backup_idempotency_time_point"`
}
