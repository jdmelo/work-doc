package cfg

import (
	"errors"
	"fmt"
	"os"

	"jd.com/jvirt/jvirt-common/utils/config"
	"jd.com/jvirt/jvirt-common/utils/validate"
	"jd.com/jvirt/jvirt-jks-controller/model"
)

const (
	DefaultSession         = "default"
	LogSession             = "log"
	JksApiSession          = "jks_api"
	BillingApiSession      = "billing_api"
	DatabaseSession        = "database"
	RedisSession           = "redis"
	VoteSession            = "vote"
	WorkerIntervalSession  = "worker_interval"
	BackupTimePointSession = "backup_time_point"
)

var (
	DefaultCfg         *model.DefaultConfig
	LogCfg             *model.LogConfig
	JksApiCfg          *config.JksApiConfig
	BillingApiCfg      *config.BillingConfig
	DatabaseCfg        *model.DatabaseConfig
	RedisCfg           *model.RedisConfig
	VoteCfg            *model.VoteConfig
	WorkerIntervalCfg  *model.WorkerIntervalConfig
	BackupTimePointCfg *model.BackupTimePointConfig
)

func init() {
	DefaultCfg = &model.DefaultConfig{
		RuntimeCores:    4,
		DebugModel:      true,
		DelayCompensate: 10,
	}
	LogCfg = &model.LogConfig{
		Level: "debug",
	}
	JksApiCfg = &config.JksApiConfig{
		MaxIdleConns:          100,
		TimerInterval:         60,
		ConnectTimeout:        500,
		ResponseHeaderTimeout: 5000,
		RequestTotalTimeout:   10000,
	}
	BillingApiCfg = &config.BillingConfig{
		MaxIdleConns:          100,
		TimerInterval:         60,
		ConnectTimeout:        500,
		ResponseHeaderTimeout: 5000,
		RequestTotalTimeout:   10000,
	}
	DatabaseCfg = &model.DatabaseConfig{
		Timeout:       1000,
		MaxConnection: 300,
		MaxLifetime:   60000,
	}
	VoteCfg = &model.VoteConfig{
		Model:        "vote",
		VoteKeyName:  "jvirt_jks_controller_master",
		VoteKeyLease: 10,
	}
	RedisCfg = &model.RedisConfig{
		IdleMax:     80,
		ActiveMax:   100,
		IdleTimeout: 100,
	}
	WorkerIntervalCfg = &model.WorkerIntervalConfig{
		CompensateTaskInterval:    10,
		SyncInstanceInterval:      10,
		SyncTaskInterval:          10,
		SyncEventInterval:         10,
		BackupTaskInterval:        1800,
		BackupEventInterval:       1800,
		BackupIdempotencyInterval: 1800,
	}
	BackupTimePointCfg = &model.BackupTimePointConfig{
		BackupTaskTimePoint:        1,
		BackupEventTimePoint:       2,
		BackupIdempotencyTimePoint: 3,
	}
}

func ParseConfig(configPath *string) error {
	if configPath == nil {
		return errors.New("config path is nil")
	}

	parser, err := config.NewConfigParser(*configPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "NewConfigParser failed. Error: %v.\n", err.Error())
		return err
	}

	// default session config.
	if err := parser.ParserAppointSection(DefaultSession, DefaultCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Parser DefaultSession failed. Error: %v.\n", err.Error())
		return err
	}
	if err := validate.Validate(DefaultCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate DefaultSession failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("DefaultSession: %#v.\n", DefaultCfg)

	// log session config.
	if err := parser.ParserAppointSection(LogSession, LogCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Parser LogSession failed. Error: %v.\n", err.Error())
		return err
	}
	if err := validate.Validate(LogCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate LogSession failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("LogSession: %#v.\n", LogCfg)

	// jvirt_jks_api session config.
	if err := parser.ParserAppointSection(JksApiSession, JksApiCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Parser JksApiSession failed. Error: %v.\n", err.Error())
		return err
	}
	if err := validate.Validate(JksApiCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate JksApiSession failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("JksApiSession: %#v.\n", JksApiCfg)

	// billing_api session config.
	if err := parser.ParserAppointSection(BillingApiSession, BillingApiCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Parser BillingApiSession failed. Error: %v.\n", err.Error())
		return err
	}
	if err := validate.Validate(BillingApiCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate BillingApiSession failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("BillingApiSession: %#v.\n", BillingApiCfg)

	// database session config.
	if err := parser.ParserAppointSection(DatabaseSession, DatabaseCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Parser DatabaseSession failed. Error: %v.\n", err.Error())
		return err
	}
	if err := validate.Validate(DatabaseCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate DatabaseSession failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("DatabaseSession: %#v.\n", DatabaseCfg)

	// redis session config.
	if err := parser.ParserAppointSection(RedisSession, RedisCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Parser RedisSession failed. Error: %v.\n", err.Error())
		return err
	}
	if err := validate.Validate(RedisCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate RedisSession failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("RedisSession: %#v.\n", RedisCfg)

	// vote session config.
	if err := parser.ParserAppointSection(VoteSession, VoteCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Parser VoteSession failed. Error: %v.\n", err.Error())
		return err
	}
	if err := validate.Validate(VoteCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate VoteSession failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("VoteSession: %#v.\n", VoteCfg)

	// worker_interval session config.
	if err := parser.ParserAppointSection(WorkerIntervalSession, WorkerIntervalCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Parser WorkerIntervalSession failed. Error: %v.\n", err.Error())
		return err
	}
	if err := validate.Validate(WorkerIntervalCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate WorkerIntervalSession failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("WorkerIntervalSession: %#v.\n", WorkerIntervalCfg)

	// backup_time_point session config.
	if err := parser.ParserAppointSection(BackupTimePointSession, BackupTimePointCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Parser BackupTimePointSession failed. Error: %v.\n", err.Error())
		return err
	}
	if err := validate.Validate(BackupTimePointCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate BackupTimePointSession failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("BackupTimePointSession: %#v.\n", BackupTimePointCfg)

	return nil
}
