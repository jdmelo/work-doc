package cfg

import "testing"

func TestParseConfig(t *testing.T) {
	cfgFile := "C:/gopath/src/jd.com/jvirt/jvirt-jks-controller/cfg/config.conf"
	if err := ParseConfig(&cfgFile); err != nil {
		t.Error("ParseConfig failed. Error:", err.Error())
	}
}
