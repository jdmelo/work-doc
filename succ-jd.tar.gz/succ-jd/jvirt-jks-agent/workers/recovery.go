package workers

import (
	"path"
	"sync"
	"time"

	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/utils/golocal"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/retry"
	"jd.com/jvirt/jvirt-jks-agent/adapter"
	"jd.com/jvirt/jvirt-jks-agent/cfg"
	"jd.com/jvirt/jvirt-jks-agent/constant"
	"jd.com/jvirt/jvirt-jks-agent/httpclient"
	"jd.com/jvirt/jvirt-jks-agent/service"
	"jd.com/jvirt/jvirt-jks-agent/utils"
)

// 恢复服务
type ServerRecovery struct {
	Logger         log.Logger               `inject:""`
	ComputeCfg     *cfg.ComputeConfig       `inject:""`
	ServiceManager *service.PodService      `inject:""`
	JksApiClient   *httpclient.JksApiClient `inject:""`
	VolumeClient   *httpclient.VolumeClient `inject:""`
	Adapter        *adapter.ModelAdapter    `inject:""`
}

/*
恢复服务

1. agent重启，恢复任务
2. host重启，恢复实例状态，running状态
3. 处理孤儿虚拟机
4. 重新挂在共享存储.
*/

func (p *ServerRecovery) Recover() error {
	var (
		apiErr error
		result error
		pods   []*jks.Pod
	)

	f := func() error {
		if pods, apiErr = p.JksApiClient.ListPodsByHostIp(p.ComputeCfg.HostIp); apiErr != nil {
			p.Logger.Error("[Recover] ListPodsByHostIp failed. Error: %s", apiErr.Error())
			return apiErr
		}

		return nil
	}
	if err := retry.Retry(f, 3, time.Second); err != nil {
		p.Logger.Error("Invoke JvirtJksApi ListPods with retry failed. Error: %#v.", err)
		return err
	}

	wait := &sync.WaitGroup{}
	for _, item := range pods {
		wait.Add(1)
		go func(pod *jks.Pod) {
			defer func() {
				wait.Done()
				golocal.GoContext.Remove()
			}()
			golocal.GoContext.Put(&golocal.GoValue{RequestId: "jks-agent-recover", TaskType: jks.PodStartTask})

			if err := p.recoverPod(pod); err != nil {
				p.Logger.Error("[Recover] recoverPod failed. PodId: %s, Error: %s", pod.PodId, err.Error())
				result = err
			}

		}(item)
	}
	wait.Wait()

	if p.ComputeCfg.IgnoreRecoveryError {
		if result != nil {
			p.Logger.Warn("Ignore jks-agent Recovery Error: %s.", result.Error())
		}

		result = nil
	}

	return result
}

func (p *ServerRecovery) recoverPod(pod *jks.Pod) error {
	podId := pod.PodId
	taskId := pod.TaskId
	userId := pod.UserId
	hostIp := p.ComputeCfg.HostIp
	phase := ""
	if pod.PodStatus != nil {
		phase = pod.PodStatus.Phase
	}
	p.Logger.Info("[recoverPod] PodId: %s, TaskId: %d, PodPhase: %s.", podId, taskId, phase)

	cloudDisks := make([]*jks.CloudDisk, 0)
	for _, container := range pod.Containers {
		if container.SystemDisk != nil {
			cloudDisks = append(cloudDisks, container.SystemDisk)
		}
	}
	for _, volume := range pod.Volumes {
		if volume.JDCloudDisk != nil {
			disk := &jks.CloudDisk{
				VolumeId:            volume.JDCloudDisk.VolumeId,
				Type:                volume.JDCloudDisk.Type,
				FsType:              volume.JDCloudDisk.FsType,
				DeleteOnTermination: volume.JDCloudDisk.DeleteOnTermination,
			}
			cloudDisks = append(cloudDisks, disk)
		}
	}

	for _, d := range cloudDisks {
		devName := utils.ZbsSoftLinkName(d.VolumeId, podId)
		zbsSoftPath := path.Join(p.ComputeCfg.ZbsLinkFileDir, devName)
		if utils.FileExist(zbsSoftPath) {
			p.Logger.Info("[recoverPod] ZbsSoftLinkFile %s exist. Don't need to invoke AttachVolume.", zbsSoftPath)
			continue
		}

		p.Logger.Info("ZbsSoftLinkFile %s not exist. Invoke idempotent AttachVolume.", zbsSoftPath)
		_, err := p.VolumeClient.AttachVolume(userId, hostIp, d.VolumeId, podId, pod.ResourceType, false)
		if err != nil {
			p.Logger.Error("[recoverPod] AttachVolume failed. UserId: %s, PodId: %s, VolId: %s, Error: %s.",
				userId, podId, d.VolumeId, err.Error())
			return err
		}
	}

	if taskId == 0 && phase == jks.PodPhaseRunning {
		var podPhase string

		f := func() error {
			resp, err := p.ServiceManager.GetPodStatus(pod.RuntimeType, podId)
			if err != nil {
				p.Logger.Error("[recoverPod] GetPodStatus failed. PodId: %s, Error: %s", podId, err.Error())
				return err
			}
			podPhase = resp.Phase
			return nil
		}
		if err := retry.Retry(f, 3, time.Second); err != nil {
			p.Logger.Error("Invoke GetPodStatus with retry failed. PodId: %s, Error: %s", podId, err.Error())
			return err
		}

		p.Logger.Debug("PodId: %s, Pod DBPhase: %s, Pod RealPhase: %s.", podId, phase, podPhase)
		if podPhase == jks.PodPhaseRunning {
			return nil
		}
		startArgs, err := p.Adapter.ConvertPodCommon2Agent(constant.StartPodAction, pod)
		if err != nil {
			p.Logger.Error("[recoverPod] ConvertPodCommon2Agent failed. TaskId: %d, PodId: %s, Error: %s.", taskId, podId, err.Error())
			return err
		}

		if err := p.ServiceManager.StartPod(startArgs); err != nil {
			p.Logger.Error("Invoke StartPod failed. PodId: %s, Error: %#v.", podId, err)
			return err
		}
	}

	return nil
}
