package workers

import (
	"time"

	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/inner/jks/gw"
	"jd.com/jvirt/jvirt-common/inner/rms"
	"jd.com/jvirt/jvirt-common/inner/rms/state"
	"jd.com/jvirt/jvirt-common/utils/golocal"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/server"
	"jd.com/jvirt/jvirt-common/utils/wait"
	"jd.com/jvirt/jvirt-jks-agent/cfg"
	"jd.com/jvirt/jvirt-jks-agent/handler/async"
	"jd.com/jvirt/jvirt-jks-agent/httpclient"
	"jd.com/jvirt/jvirt-jks-agent/service"
)

type Heartbeat struct {
	*server.Server
	Logger         log.Logger              `inject:""`
	ComputeCfg     *cfg.ComputeConfig      `inject:""`
	ServiceManager *service.PodService     `inject:""`
	TaskDispatcher *async.TaskDispatcher   `inject:""`
	JksGwClient    *httpclient.JksGwClient `inject:""`
	RmsGwClient    *httpclient.RmsGwClient `inject:""`
}

func NewHeartbeat() *Heartbeat {
	resp := &Heartbeat{}
	resp.Server = server.NewServer(resp.doStart, resp.doStop)

	return resp
}

func (p *Heartbeat) doStart() error {
	p.Logger.Debug("Invoke Heartbeat doStart ......")

	// 启动后立即拉取任务
	p.JksGwHeartbeat()

	// 启动与jks-gw服务的心跳
	goValue := &golocal.GoValue{RequestId: p.ComputeCfg.HostIp}
	go func() {
		defer func() {
			golocal.GoContext.Remove()
		}()
		golocal.GoContext.Put(goValue)

		wait.Until(p.JksGwHeartbeat, p.ComputeCfg.JksGWHeartbeatPeriod*time.Second, p.Close())
	}()

	// 启动与RMS-gw服务的心跳
	go func() {
		defer func() {
			golocal.GoContext.Remove()
		}()
		golocal.GoContext.Put(goValue)

		wait.Until(p.RmsGwHeartbeat, p.ComputeCfg.RmsGWHeartbeatPeriod*time.Second, p.Close())
	}()

	p.Logger.Debug("Invoke Heartbeat doStart finished.")

	return nil
}

func (p *Heartbeat) doStop() {
	p.Logger.Debug("Invoke Heartbeat doStop.")
}

func (p *Heartbeat) RmsGwHeartbeat() {
	// 获取底层instances电源状态
	hyperAlive := rms.PropertiesDriverAlive

	if alive := p.ServiceManager.RuntimeIsAlive(); !alive {
		p.Logger.Warn("Runtime is dead")
		hyperAlive = rms.PropertiesDriverDead
	}

	properties := make(map[string]string)
	properties[rms.PropertiesHyperDriver] = hyperAlive
	// todo 以后增加镜像信息
	//properties["local_docker_image"] = dockerImages

	args := &state.HeartBeatRequest{
		Host:       p.ComputeCfg.HostIp,
		AppId:      jks.AppIdJks,
		Properties: properties,
	}
	if err := p.RmsGwClient.RmsGwHeartbeat(args); err != nil {
		p.Logger.Warn("RmsGwHeartbeat failed. Error: %s.", err.Error())
	}
}

func (p *Heartbeat) JksGwHeartbeat() {
	var err error

	podStatuses := make(map[string]*jks.PodStatus)
	uploadPodIds := make([]string, 0)
	for _, dType := range p.ComputeCfg.SupportDrivers {
		resp, err := p.ServiceManager.ListPodStatuses(dType)
		if err != nil {
			p.Logger.Error("[JksGwHeartbeat] ListPods failed. DriverType: %s, Error: %s", dType, err.Error())
			continue
		}
		for podId, status := range resp {
			podStatuses[podId] = status
			uploadPodIds = append(uploadPodIds, podId)
		}
	}

	p.Logger.Info("Send heartbeat PodIds: %v.", uploadPodIds)

	// 上报Instance状态，并且拉取Running状态的任务.
	args := &gw.HeartbeatRequest{
		DescribeTasks: &gw.DescribeTasksRequest{
			HostIp:    p.ComputeCfg.HostIp,
			TaskState: jks.TaskRunning,
		},
		UpdatePodStatus: &gw.UpdatePodStatusRequest{
			HostIp:      p.ComputeCfg.HostIp,
			PodStatuses: podStatuses,
		},
	}
	pullTasks, err := p.JksGwClient.JksGwHeartbeat(args)
	if err != nil {
		p.Logger.Warn("Send heartbeat to jks-gw server failed. Error: %#v.", err)
		return
	}

	// 调用task dispatcher处理任务
	for _, item := range pullTasks {
		err := p.TaskDispatcher.Dispatcher(item)
		if err != nil {
			p.Logger.Warn("Task executes failed. Error: %#v.", err)
		}
	}
}
