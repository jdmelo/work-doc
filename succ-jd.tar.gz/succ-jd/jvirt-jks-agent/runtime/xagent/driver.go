package xagent

import (
	"encoding/json"
	"fmt"
	"strings"
	"time"

	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/inner/jks/agent"
	"jd.com/jvirt/jvirt-common/integration/xagent"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/retry"
	"jd.com/jvirt/jvirt-jks-agent/adapter"
	"jd.com/jvirt/jvirt-jks-agent/cfg"
	"jd.com/jvirt/jvirt-jks-agent/constant"
	"jd.com/jvirt/jvirt-jks-agent/em"
	"jd.com/jvirt/jvirt-jks-agent/httpclient"
	"jd.com/jvirt/jvirt-jks-agent/model"
	"jd.com/jvirt/jvirt-jks-agent/utils"
)

type XAgentDriver struct {
	Logger       log.Logger                      `inject:""`
	ImageRegCli  *httpclient.ImageRegistryClient `inject:""`
	NetworkCli   *httpclient.NetworkClient       `inject:""`
	VolumeCli    *httpclient.VolumeClient        `inject:""`
	EventHandler *em.EventManagerService         `inject:""`
	ComputeCfg   *cfg.ComputeConfig              `inject:""`
	XAgentClient *xagent.XAgentClient            `inject:""`
	Adapter      *adapter.ModelAdapter           `inject:""`
}

func (p *XAgentDriver) Initialization() error {
	p.Logger.Info("Initialization XAgentDriver ......")
	instancesDir := p.ComputeCfg.InstancesDir
	if err := utils.CreateDir(instancesDir, 0755); err != nil {
		return err
	}
	return nil
}

func (p *XAgentDriver) Cleanup() error {
	p.Logger.Info("Cleanup XAgentDriver ......")
	return nil
}

func (p *XAgentDriver) DriverIsAlive() bool {
	ok, err := p.XAgentClient.Ping()
	if err != nil {
		p.Logger.Error("[DriverIsAlive] xagent.Ping failed. Error: %s", err.Error())
		return false
	}

	return ok
}

func (p *XAgentDriver) checkPodStatus(podId string, retryTimes int, interval time.Duration, targetStatuses ...string) error {
	targetStatusMap := make(map[string]bool)
	for _, item := range targetStatuses {
		targetStatusMap[item] = true
	}

	f := func() error {
		state, err := p.XAgentClient.GetPodStatus(podId)
		if err != nil {
			p.Logger.Error("[checkPodStatus] GetPodStatus error : %s", err.Error())
			return err
		}
		if state == nil {
			return fmt.Errorf("pod %s not found in the xagent", podId)
		}

		podPhase := state.Phase
		p.Logger.Info("[checkPodStatus] PodId: %s, TargetStatuses: %+v, CurrentStatus: %s", podId, targetStatuses, podPhase)

		if _, ok := targetStatusMap[podPhase]; ok {
			return nil
		}

		return fmt.Errorf("check pod status failed, curret status is %s, not expect status", podPhase)
	}

	if err := retry.Retry(f, retryTimes, interval); err != nil {
		p.Logger.Error("[checkPodStatus] CheckPodStatus failed. PodId: %s, Error: %s.", podId, err.Error())
		return err
	}

	return nil
}

func (p *XAgentDriver) checkContainerStatus(ctnName string, retryTimes int, interval time.Duration, targetStatuses ...string) error {
	targetStatusMap := make(map[string]bool)
	for _, item := range targetStatuses {
		targetStatusMap[item] = true
	}

	f := func() error {
		containerView, err := p.XAgentClient.GetContainer(ctnName)
		if err != nil {
			p.Logger.Error("[checkContainerStatus] GetContainer failed. ContainerName: %s, Error: %s", ctnName, err.Error())
			return err
		}
		if containerView == nil || containerView.Status == nil {
			p.Logger.Error("[checkContainerStatus] GetContainer not found in the xagent. ContainerName: %s", ctnName)
			return fmt.Errorf("container %s not found in the xagent", ctnName)
		}

		ctnPhase := containerView.Status.Phase
		p.Logger.Info("[checkContainerStatus] ContainerName: %s, TargetStatuses: %+v, CurrentStatus: %s", ctnName, targetStatuses, ctnPhase)

		if _, ok := targetStatusMap[ctnPhase]; ok {
			return nil
		}

		return fmt.Errorf("check container status failed, curret status is %s, not expect status", ctnPhase)
	}

	if err := retry.Retry(f, retryTimes, interval); err != nil {
		p.Logger.Error("[checkContainerStatus] CheckContainerStatus failed. ContainerName: %s, Error: %s.", ctnName, err.Error())
		return err
	}

	return nil
}

func (p *XAgentDriver) deleteLocalFiles(path string) error {
	var delErr error

	if path != "" && utils.DirExist(path) {
		p.Logger.Debug("[deleteLocalFiles] Deleting pod local files %s start.", path)

		err := utils.RemoveAll(path)
		if err != nil {
			p.Logger.Error("[deleteLocalFiles] Remove directory %s failed. Error: %s.", path, err.Error())
			delErr = err
		}

		p.Logger.Debug("[deleteLocalFiles] Deleting pod local files %s success.", path)

	}

	return delErr
}

func (p *XAgentDriver) GetContainerLogs(args *agent.GetContainerLogsRequest) (string, error) {
	logInfo, err := p.XAgentClient.GetLogs(args.ContainerName, args.StartTime, args.EndTime, args.TailLines, args.LimitBytes, args.SinceSeconds)
	if err != nil {
		p.Logger.Error("GetContainerLogs failed. ContainerName: %s, Error: %s.", args.ContainerName, err.Error())
		return "", err
	}

	return logInfo, nil
}

func (p *XAgentDriver) ListPodStatuses() (map[string]*jks.PodStatus, error) {
	results := make(map[string]*jks.PodStatus)

	resp, err := p.XAgentClient.ListPods()
	if err != nil {
		p.Logger.Error("[ListPodStatuses] Invoke xagent.ListPods failed. Error: %s.", err.Error())
		return nil, err
	}
	if resp == nil {
		p.Logger.Debug("[ListPodStatuses] ListPods result is nil")
		return nil, nil
	}

	for _, item := range resp.PodList {
		// 如果podlabels包含create_by_jks，且值为true，则将这个pod的状态加入的返回值
		if value, ok := item.Labels[constant.CreateByJks]; ok && value == "true" {
			results[item.PodID] = adapter.ConvertPodStatusXagent2Service(item.Status)
			continue
		}
		// 如果podid以"c-"开头，则将这个pod的状态加入的返回值
		if strings.HasPrefix(item.PodID, "c-") {
			results[item.PodID] = adapter.ConvertPodStatusXagent2Service(item.Status)
		}
	}

	return results, nil
}

func (p *XAgentDriver) GetPodStatus(podId string) (*jks.PodStatus, error) {
	p.Logger.Debug("[GetPodStatus] PodId: %s", podId)

	podStatus, err := p.XAgentClient.GetPodStatus(podId)
	if err != nil {
		p.Logger.Error("[GetPodStatus] Invoke xagent.GetPodStatus failed. PodId: %s, Error: %s.", podId, err.Error())
		return nil, err
	}
	if podStatus == nil {
		return nil, fmt.Errorf("pod %s not found in the xagent", podId)
	}

	return adapter.ConvertPodStatusXagent2Service(podStatus), nil
}

func (p *XAgentDriver) doCreatePod(pod *model.Pod) error {
	podId := pod.PodId
	p.EventHandler.EmitExecuteTimeEvent(podId, "XAgentDriver.doCreatePod", constant.StartStage, false)
	defer p.EventHandler.EmitExecuteTimeEvent(podId, "XAgentDriver.doCreatePod", constant.FinishedStage, true)

	if err := p.NetworkCli.CheckPortsReady(pod.UserId, podId, pod.NetworkType); err != nil {
		p.Logger.Error("[doCreatePod] CheckPortsReady failed. PodId: %s, Error: %s", podId, err.Error())
		return err
	}

	// create pod
	createPodParams, err := p.Adapter.ConvertPodJks2Xagent(pod)
	if err != nil {
		p.Logger.Error("[doCreatePod] Convert jks-agent.model to xagent.model failed. PodId: %s, Error: %s", podId, err.Error())
		return err
	}

	if err := p.XAgentClient.CreatePod(createPodParams); err != nil {
		errMsg := err.Error()
		p.Logger.Error("[doCreatePod] xagent.CreatePod failed. PodId: %s, Error: %s", podId, errMsg)

		if !strings.Contains(errMsg, xagent.ErrRequestTimeout) {
			return err
		}
	}
	p.EventHandler.EmitExecuteTimeEvent(podId, "XAgentDriver.doCreatePod", "XAgentClient.CreatePod", false)

	if err := p.checkPodStatus(podId, 1200, time.Millisecond*500, jks.PodPhaseCreated); err != nil {
		p.Logger.Error("[doCreatePod] checkPodStatus failed. PodId: %s, Error: %s.", podId, err.Error())
		return err
	}
	p.EventHandler.EmitExecuteTimeEvent(podId, "XAgentDriver.doCreatePod", "checkPodStatus", false)

	return nil
}

func (p *XAgentDriver) CreatePod(pod *model.Pod) error {
	argsJson, err := json.Marshal(pod)
	if err == nil {
		p.Logger.Debug("[CreatePod] Params: %s", argsJson)
	}
	podId := pod.PodId
	p.EventHandler.EmitExecuteTimeEvent(podId, "XAgentDriver.CreatePod", constant.StartStage, false)
	defer p.EventHandler.EmitExecuteTimeEvent(podId, "XAgentDriver.CreatePod", constant.FinishedStage, true)

	// create dir
	if err := utils.CreateDir(pod.PodPath, 0755); err != nil {
		p.Logger.Error("[CreatePod] Create %s directory failed. Error: %v.", pod.PodPath, err.Error())
		return err
	}
	p.EventHandler.EmitExecuteTimeEvent(podId, "XAgentDriver.CreatePod", "CreateDir", false)

	// download pod images.
	if err := p.ImageRegCli.DownloadImages(podId, pod.Containers); err != nil {
		p.Logger.Error("[CreatePod] Invoke DownloadImages failed. Error: %s.", err.Error())
		return err
	}

	// load image to system disk
	if err := p.ImageRegCli.LoadImagesToPod(pod.PodPath, pod.Containers); err != nil {
		p.Logger.Error("[CreatePod] Invoke LoadImagesToPod failed. Error: %s.", err.Error())
		return err
	}
	p.EventHandler.EmitExecuteTimeEvent(podId, "XAgentDriver.CreatePod", "ImageRegCli.LoadImagesToPod", false)

	if err := p.doCreatePod(pod); err != nil {
		p.Logger.Error("[CreatePod] doCreatePod failed. Error: %s", err.Error())
		return err
	}

	if err := p.doStartPod(pod); err != nil {
		p.Logger.Error("[CreatePod] doStartPod failed. Error: %s", err.Error())
		return err
	}

	p.Logger.Debug("[CreatePod] finished PodId: %s", pod.PodId)

	return nil
}

func (p *XAgentDriver) RebuildPod(pod *model.Pod) error {
	argsJson, err := json.Marshal(pod)
	if err == nil {
		p.Logger.Debug("[RebuildPod] Params: %s", argsJson)
	}
	podId := pod.PodId
	p.EventHandler.EmitExecuteTimeEvent(podId, "XAgentDriver.RebuildPod", constant.StartStage, false)
	defer p.EventHandler.EmitExecuteTimeEvent(podId, "XAgentDriver.RebuildPod", constant.FinishedStage, true)

	// create dir
	if err := utils.CreateDir(pod.PodPath, 0755); err != nil {
		p.Logger.Error("[RebuildPod] Create %s directory failed. Error: %v.", pod.PodPath, err.Error())
		return err
	}
	p.EventHandler.EmitExecuteTimeEvent(podId, "XAgentDriver.RebuildPod", "CreateDir", false)

	rebuildContainers := make([]*model.Container, 0)
	for _, container := range pod.Containers {
		if container.IsRebuild {
			p.Logger.Debug("[RebuildPod] ContainerName: %s", container.Name)
			rebuildContainers = append(rebuildContainers, container)
		}
	}

	if err := p.ImageRegCli.DownloadImages(podId, rebuildContainers); err != nil {
		p.Logger.Error("[RebuildPod] Invoke DownloadImages failed. Error: %s.", err.Error())
		return err
	}

	if err := p.ImageRegCli.LoadImagesToPod(pod.PodPath, rebuildContainers); err != nil {
		p.Logger.Error("[RebuildPod] Invoke LoadImagesToPod failed. Error: %s.", err.Error())
		return err
	}
	p.EventHandler.EmitExecuteTimeEvent(podId, "XAgentDriver.RebuildPod", "ImageRegCli.LoadImagesToPod", false)

	if err := p.doCreatePod(pod); err != nil {
		p.Logger.Error("[RebuildPod] doCreatePod failed. Error: %s", err.Error())
		return err
	}

	p.Logger.Debug("[RebuildPod] finished PodId: %s", pod.PodId)

	return nil
}

func (p *XAgentDriver) doStartPod(pod *model.Pod) error {
	// start pod
	podId := pod.PodId
	p.EventHandler.EmitExecuteTimeEvent(podId, "XAgentDriver.doStartPod", constant.StartStage, false)
	defer p.EventHandler.EmitExecuteTimeEvent(podId, "XAgentDriver.doStartPod", constant.FinishedStage, true)

	if err := p.XAgentClient.StartPod(podId); err != nil {
		errMsg := err.Error()
		p.Logger.Error("[doStartPod] xagent.StartPod failed. PodId: %s, Error: %s", podId, errMsg)
		if !strings.Contains(errMsg, xagent.ErrRequestTimeout) {
			return err
		}
	}
	p.EventHandler.EmitExecuteTimeEvent(podId, "XAgentDriver.doStartPod", "XAgentClient.StartPod", false)

	targetStatuses := []string{jks.PodPhaseRunning, jks.PodPhaseSucceeded, jks.PodPhaseFailed}
	if err := p.checkPodStatus(podId, 240, 500*time.Millisecond, targetStatuses...); err != nil {
		p.Logger.Error("[doStartPod] checkPodState failed. PoId: %s, Error: %s", podId, err.Error())
		return err
	}
	p.EventHandler.EmitExecuteTimeEvent(podId, "XAgentDriver.doStartPod", "checkPodStatus", false)

	if pod.ResourceType == jks.ResourceTypeNativeContainer {
		targetStatuses := []string{jks.ContainerPhaseRunning, jks.ContainerPhaseStopped}
		if err := p.checkContainerStatus(podId, 60, 500*time.Millisecond, targetStatuses...); err != nil {
			p.Logger.Error("[doStartPod] checkContainerStatus failed. ContainerName: %s, Error: %s", podId, err.Error())
			return err
		}
	}
	p.EventHandler.EmitExecuteTimeEvent(podId, "XAgentDriver.doStartPod", "checkContainerStatus", false)

	return nil
}

func (p *XAgentDriver) StartPod(pod *model.Pod) error {
	podId := pod.PodId

	p.Logger.Debug("[StartPod] PodId: %s", podId)

	if err := p.NetworkCli.CheckPortsReady(pod.UserId, podId, pod.NetworkType); err != nil {
		p.Logger.Error("[StartPod] CheckPortsReady failed. PodId: %s, Error: %s", podId, err.Error())
		return err
	}

	if err := p.doStartPod(pod); err != nil {
		p.Logger.Error("[StartPod] doStartPod failed. PodId: %s, Error: %s", podId, err.Error())
		return err
	}

	p.Logger.Debug("[StartPod] finished PodId: %s", podId)

	return nil
}

func (p *XAgentDriver) doStopPod(pod *model.Pod) error {
	podId := pod.PodId

	if err := p.XAgentClient.StopPod(pod.PodId); err != nil {
		errMsg := err.Error()
		p.Logger.Error("[doStopPod] xagent.StopPod failed. PodId: %s, Error: %s", podId, errMsg)
		if !strings.Contains(errMsg, xagent.ErrRequestTimeout) {
			return err
		}
	}

	if err := p.checkPodStatus(podId, 120, 500*time.Millisecond, jks.PodPhaseStopped); err != nil {
		p.Logger.Error("[doStopPod] checkPodStatus failed. PodId: %s, Error: %s", podId, err.Error())
		return err
	}

	return nil
}

func (p *XAgentDriver) StopPod(pod *model.Pod) error {
	podId := pod.PodId

	p.Logger.Debug("[StopPod] PodId: %s.", podId)

	if err := p.doStopPod(pod); err != nil {
		p.Logger.Error("[StopPod] doStopPod failed. PodId: %s, Error: %s", podId, err.Error())
		return err
	}

	p.Logger.Debug("[StopPod] finished PodId: %s.", podId)

	return nil
}

func (p *XAgentDriver) MigratePod(pod *model.Pod) error {
	podId := pod.PodId

	argsJson, err := json.Marshal(pod)
	if err == nil {
		p.Logger.Debug("[MigratePod] Params: %s", argsJson)
	}

	// create dir
	if err := utils.CreateDir(pod.PodPath, 0755); err != nil {
		p.Logger.Error("[MigratePod] Create %s directory failed. Error: %v.", pod.PodPath, err.Error())
		return err
	}

	if err := p.doCreatePod(pod); err != nil {
		p.Logger.Error("[MigratePod] doCreatePod failed. PodId: %s, Error: %s", podId, err.Error())
		return err
	}

	p.Logger.Debug("[MigratePod] finished PodId: %s.", podId)

	return nil
}

func (p *XAgentDriver) UpdatePod(pod *model.Pod) error {
	podId := pod.PodId
	argsJson, err := json.Marshal(pod)
	if err == nil {
		p.Logger.Debug("[UpdatePod] Params: %s", argsJson)
	}

	resource := p.Adapter.ConvertResourceJks2Xagent(pod.PhysicalResource)
	if err != nil {
		p.Logger.Error("[UpdatePod] Convert jks-agent.model to xagent.model failed. PodId: %s, Error: %s", podId, err.Error())
		return err
	}

	containers := p.Adapter.ConvertContainerResourceJks2Xagent(podId, pod.Containers)
	if err != nil {
		p.Logger.Error("[UpdatePod] Convert jks-agent.model to xagent.model failed. PodId: %s, Error: %s", podId, err.Error())
		return err
	}

	if err := p.checkPodStatus(podId, 3, 500*time.Millisecond, jks.PodPhaseStopped); err != nil {
		p.Logger.Error("[UpdatePod] checkPodStatus failed. PodId: %s, Error: %s", podId, err.Error())
		return err
	}

	var containerResources []*xagent.ContainersResource
	for _, container := range containers {
		containerResource := &xagent.ContainersResource{
			Name:      container.Name,
			Resources: container.Resources,
		}
		containerResources = append(containerResources, containerResource)
	}

	params := &xagent.UserResizeResource{
		Vcpu:                resource.Vcpu,
		Memory:              resource.Memory,
		Cputune:             resource.Cputune,
		ContainersResources: containerResources,
	}
	if err := p.XAgentClient.UpdatePod(podId, params); err != nil {
		errMsg := err.Error()
		p.Logger.Error("[UpdatePod] xagent.CreatePod failed. PodId: %s, Error: %s", podId, errMsg)

		if !strings.Contains(errMsg, xagent.ErrRequestTimeout) {
			return err
		}
	}
	p.EventHandler.EmitExecuteTimeEvent(podId, "XAgentDriver.ResizePod", "XAgentClient.UpdatePod", false)

	// rsizePod success stop pod
	if err := p.doStopPod(pod); err != nil {
		p.Logger.Error("[UpdatePod] doStopPod failed. PodId: %s, Error: %s", podId, err.Error())
		return err
	}

	p.Logger.Debug("[UpdatePod] finished PodId: %s.", podId)

	return nil
}

func (p *XAgentDriver) PodExist(podId, podPath string) (bool, error) {
	// 判断pod路径是否存在
	if utils.DirExist(podPath) {
		p.Logger.Debug("[PodExist] PodId %s dir [%s] is exist in the host", podId, podPath)
		return true, nil
	}
	p.Logger.Warn("[PodExist] PodId %s dir [%s] not found in the host", podId, podPath)

	// 判断pod在xagent中是否存在
	resp, err := p.XAgentClient.GetPod(podId)
	if err != nil {
		p.Logger.Error("[PodExist] GetPod failed. PodId: %s, Error: %s", podId, err.Error())
		return true, err
	}

	if resp == nil {
		p.Logger.Warn("[PodExist] PodId %s not found in the host", podId)
		return false, nil
	}

	return true, nil
}

func (p *XAgentDriver) DeletePod(pod *model.Pod) error {
	podId := pod.PodId
	p.Logger.Debug("[DeletePod] PodId: %s.", podId)
	p.EventHandler.EmitExecuteTimeEvent(podId, "XAgentDriver.DeletePod", constant.StartStage, false)
	defer p.EventHandler.EmitExecuteTimeEvent(podId, "XAgentDriver.DeletePod", constant.FinishedStage, true)
	// 如果pod不存在，不会调用xagent删除pod
	resp, err := p.XAgentClient.GetPod(podId)
	if err != nil {
		p.Logger.Error("[DeletePod] GetPod failed. PodId: %s, Error: %s", podId, err.Error())
		return err
	}
	if resp != nil {
		if err := p.XAgentClient.DeletePod(podId); err != nil {
			errMsg := err.Error()
			p.Logger.Error("[DeletePod] xagent.DeletePod failed. PodId: %s, Error: %s", podId, errMsg)

			if !strings.Contains(errMsg, xagent.ErrRequestTimeout) {
				return err
			}
		}
		p.EventHandler.EmitExecuteTimeEvent(podId, "XAgentDriver.DeletePod", "XAgentClient.DeletePod", false)

		// check pod deleted
		f := func() error {
			resp, err := p.XAgentClient.GetPod(podId)
			if err != nil {
				p.Logger.Error("[checkDeletePod] GetPod failed. PodId: %s, Error: %s", podId, err.Error())
				return err
			}
			if resp == nil {
				p.Logger.Debug("[checkDeletePod] delete pod success. PodId: %s", podId)
				return nil
			}

			return fmt.Errorf("pod %s is exist in the xagent, delete pod failed", podId)
		}

		if err := retry.Retry(f, 1000, time.Millisecond*500); err != nil {
			p.Logger.Error("[DeletePod] checkDeletePod failed. PodId: %s, Error: %s.", podId, err.Error())
			return err
		}
		p.EventHandler.EmitExecuteTimeEvent(podId, "XAgentDriver.DeletePod", "check pod deleted", false)
	}

	// 最后清理目录
	if err := p.deleteLocalFiles(pod.PodPath); err != nil {
		p.Logger.Error("[DeletePod] deleteLocalFiles failed. PodId: %s, Error: %s", podId, err.Error())
		return err
	}
	p.EventHandler.EmitExecuteTimeEvent(podId, "XAgentDriver.DeletePod", "deleteLocalFiles", false)

	p.Logger.Debug("[DeletePod] finished PodId: %s", podId)
	return nil
}
