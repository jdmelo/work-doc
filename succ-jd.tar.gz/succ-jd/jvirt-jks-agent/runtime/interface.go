package runtime

import (
	"sync"

	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/inner/jks/agent"
	. "jd.com/jvirt/jvirt-jks-agent/model"
)

/*
底层hypervisor使用方式：
1: 创建DriverManager对象。
2: 初始化DriverManager对象，事件回调。
*/

type RuntimeManager struct {
	drivers map[string]IRuntime
	mu      sync.Mutex
}

func NewRuntimeManager() *RuntimeManager {
	ret := &RuntimeManager{
		drivers: make(map[string]IRuntime),
	}

	return ret
}

func (p *RuntimeManager) AddDriver(driverType string, driver IRuntime) {
	p.mu.Lock()
	defer p.mu.Unlock()

	p.drivers[driverType] = driver
}

func (p *RuntimeManager) GetDriver(driverType string) IRuntime {
	p.mu.Lock()
	defer p.mu.Unlock()

	if ret, ok := p.drivers[driverType]; ok {
		return ret
	}

	return nil
}

func (p *RuntimeManager) ListDriver() map[string]IRuntime {
	p.mu.Lock()
	defer p.mu.Unlock()
	return p.drivers
}

type IRuntime interface {
	DriverIsAlive() bool // 判断是否存活
	CreatePod(args *Pod) error
	RebuildPod(args *Pod) error
	UpdatePod(args *Pod) error
	StartPod(args *Pod) error
	StopPod(args *Pod) error
	DeletePod(args *Pod) error
	MigratePod(args *Pod) error
	PodExist(podId, podPath string) (bool, error)
	ListPodStatuses() (map[string]*jks.PodStatus, error)                  // key 是 podId
	GetPodStatus(podId string) (*jks.PodStatus, error)                    // key 是 podId
	GetContainerLogs(args *agent.GetContainerLogsRequest) (string, error) // /v0.8.1/container/logs?container=pod5&follow=false&since=&size=&stderr=true&stdout=true&tail=&timestamps=false
	Initialization() error
	Cleanup() error
}
