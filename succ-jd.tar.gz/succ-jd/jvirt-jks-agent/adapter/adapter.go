package adapter

/*
adapter jks model to jks-agent model.
*/

import (
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jks-agent/cfg"
	"jd.com/jvirt/jvirt-jks-agent/httpclient"
)

type ModelAdapter struct {
	Logger     log.Logger                `inject:""`
	ComputeCfg *cfg.ComputeConfig        `inject:""`
	JksApiCli  *httpclient.JksApiClient  `inject:""`
	VolCli     *httpclient.VolumeClient  `inject:""`
	NetCli     *httpclient.NetworkClient `inject:""`
}
