package adapter

import (
	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/integration/xagent"
)

func ConvertPodStatusXagent2Service(xagentStatus *xagent.PodStatus) *jks.PodStatus {
	if xagentStatus == nil {
		return nil
	}
	result := &jks.PodStatus{
		Phase:     xagentStatus.Phase,
		Reason:    xagentStatus.Reason,
		Message:   xagentStatus.Message,
		StartTime: xagentStatus.StartTime,
	}
	if len(xagentStatus.PodIP) != 0 {
		result.PodIP = xagentStatus.PodIP[0]
	}
	result.Conditions = ConvertPodConditionXagent2Service(xagentStatus.Conditions)
	result.ContainerStatuses = ConvertContainerStatusXagent2Service(xagentStatus.ContainerStatus)
	return result
}

func ConvertPodConditionXagent2Service(xagentCondition []*xagent.PodCondition) []*jks.PodCondition {
	results := make([]*jks.PodCondition, 0)
	for _, item := range xagentCondition {
		result := &jks.PodCondition{
			LastProbeTime:      item.LastProbeTime,
			LastTransitionTime: item.LastTransitionTime,
			Reason:             item.Reason,
			Message:            item.Message,
			Status:             item.Status,
			Type:               item.Type,
		}
		results = append(results, result)
	}
	return results
}

func ConvertContainerStatusXagent2Service(xagentContainerStatus []*xagent.ContainerStatus) []*jks.ContainerStatus {
	results := make([]*jks.ContainerStatus, 0)
	for _, item := range xagentContainerStatus {
		result := &jks.ContainerStatus{
			Name:         item.Name,
			Phase:        item.Phase,
			Ready:        item.Ready,
			RestartCount: int(item.RestartCount),
		}
		result.State = ConvertContainerStateXagent2Service(item.Waiting, item.Running, item.Terminated)
		if item.LastState != nil {
			result.LastState = ConvertContainerStateXagent2Service(item.LastState.Waiting, item.LastState.Running, item.LastState.Terminated)
		}
		results = append(results, result)
	}
	return results
}

func ConvertContainerStateXagent2Service(waiting *xagent.WaitingStatus, running *xagent.RunningStatus, terminated *xagent.TermStatus) *jks.ContainerState {
	if waiting != nil || terminated != nil || running != nil {
		state := &jks.ContainerState{}
		if running != nil {
			state.Running = &jks.ContainerStateRunning{
				StartedAt: running.StartedAt,
			}
		}
		if waiting != nil {
			state.Waiting = &jks.ContainerStateWaiting{
				Reason:  waiting.Reason,
				Message: waiting.Message,
			}
		}
		if terminated != nil {
			state.Terminated = &jks.ContainerStateTerminated{
				Signal:     int(terminated.Signal),
				ExitCode:   int(terminated.ExitCode),
				Reason:     terminated.Reason,
				Message:    terminated.Message,
				FinishedAt: terminated.FinishedAt,
				StartedAt:  terminated.StartedAt,
			}
		}
		return state
	} else {
		return nil
	}
}

func ConvertPodXagent2Service(xagentPod []*xagent.PodListResult) []*jks.Pod {
	results := make([]*jks.Pod, 0)
	for _, item := range xagentPod {
		result := &jks.Pod{
			PodId:      item.PodID,
			Name:       item.PodName,
			CreateTime: item.CreatedAt,
			PodStatus:  ConvertPodStatusXagent2Service(item.Status),
		}
		results = append(results, result)
	}
	return results
}
