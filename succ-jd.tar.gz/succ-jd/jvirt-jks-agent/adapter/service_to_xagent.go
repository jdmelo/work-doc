package adapter

import (
	"errors"
	"fmt"
	"strings"

	"jd.com/jvirt/jvirt-jks-agent/constant"

	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/integration/xagent"
	"jd.com/jvirt/jvirt-jks-agent/model"
)

var DefaultLogConfig = map[string]string{"max-file": "10", "max-size": "10M"}

const (
	KeyDiskType     = "disktype"
	KeyFsType       = "fstype"
	KeySource       = "source"
	DiskTypeBlock   = "block"
	LogTypeJsonFile = "json-file"
	BPS_READ        = "bps-read"
	IOPS_READ       = "iops-read"
	BPS_WRITE       = "bps-write"
	IOPS_WRITE      = "iops-write"
	CpuPeriod       = 100
	DiskFormatRaw   = "raw"
)

const (
	NetworkTypeTap       = "tap"
	NetworkTypeVhostUser = "vhost-user"
)

func ConvertEnv(params *model.Container) []*xagent.EnvironmentVar {

	// merge env
	resp := make([]*xagent.EnvironmentVar, 0)

	keyMap := make(map[string]bool)

	for _, item := range params.Env {
		env := &xagent.EnvironmentVar{
			Env:   item.Name,
			Value: item.Value,
		}
		keyMap[item.Name] = true
		resp = append(resp, env)
	}

	for _, item := range params.ImageInfo.Env {
		envSlice := strings.SplitN(item, "=", 2)
		if len(envSlice) != 2 {
			continue
		}

		key := envSlice[0]
		value := envSlice[1]

		if _, ok := keyMap[key]; ok {
			continue
		}

		env := &xagent.EnvironmentVar{
			Env:   key,
			Value: value,
		}
		resp = append(resp, env)
	}

	return resp
}

/*
参考文档:
https://kubernetes.io/docs/tasks/inject-data-application/define-command-argument-container/
*/
func ConvertCommand(params *model.Container) []string {
	var commandRun []string

	imageInfo := params.ImageInfo
	imageEntrypoint := imageInfo.Entrypoint
	imageCmd := imageInfo.Cmd

	containerCommand := params.Command
	containerArgs := params.Args

	if len(containerCommand) == 0 && len(containerArgs) == 0 {
		commandRun = imageEntrypoint
		for _, cmd := range imageCmd {
			commandRun = append(commandRun, cmd)
		}
	}
	if len(containerCommand) > 0 && len(containerArgs) == 0 {
		commandRun = containerCommand
	}
	if len(containerCommand) == 0 && len(containerArgs) > 0 {
		commandRun = imageEntrypoint
		for _, cmd := range containerArgs {
			commandRun = append(commandRun, cmd)
		}
	}
	if len(containerCommand) > 0 && len(containerArgs) > 0 {
		commandRun = containerCommand
		for _, cmd := range containerArgs {
			commandRun = append(commandRun, cmd)
		}
	}
	return commandRun
}

func ConvertProbe(probe *jks.Probe) *xagent.Probe {
	if probe == nil {
		return nil
	}

	var result *xagent.Probe

	result = &xagent.Probe{
		InitialDelaySeconds: int32(probe.InitialDelaySeconds),
		TimeoutSeconds:      int32(probe.TimeoutSeconds),
		PeriodSeconds:       int32(probe.PeriodSeconds),
		SuccessThreshold:    int32(probe.SuccessThreshold),
		FailureThreshold:    int32(probe.FailureThreshold),
	}

	execAction := probe.Exec
	httpAction := probe.HTTPGet
	tcpAction := probe.TCPSocket

	if execAction != nil {
		result.Exec = &xagent.ExecAction{
			Command: execAction.Command,
		}
	}
	if httpAction != nil {
		headers := make([]*xagent.HTTPHeader, 0)
		for _, item := range httpAction.HTTPHeaders {
			header := &xagent.HTTPHeader{
				Name:  item.Name,
				Value: item.Value,
			}
			headers = append(headers, header)
		}
		result.HttpGet = &xagent.HTTPGetAction{
			Path:        httpAction.Path,
			Port:        int32(httpAction.Port),
			Host:        httpAction.Host,
			Scheme:      httpAction.Scheme,
			HttpHeaders: headers,
		}
	}
	if tcpAction != nil {
		result.TcpSocket = &xagent.TCPSocketAction{
			Port: int32(tcpAction.Port),
		}
	}

	return result
}

func arraryInt64ToInt(int64Arrary []int64) []int {
	result := make([]int, 0)
	for _, item := range int64Arrary {
		result = append(result, int(item))
	}
	return result
}

func (p *ModelAdapter) ConvertPodJks2Xagent(pod *model.Pod) (*xagent.UserPod, error) {
	hostname := pod.Hostname
	reqParams := &xagent.UserPod{
		Id:                            pod.PodId,
		Hostname:                      hostname,
		RestartPolicy:                 pod.RestartPolicy,
		TerminationGracePeriodSeconds: fmt.Sprintf("%v", pod.TerminationGracePeriodSeconds),
		Labels:                        map[string]string{"create_by_jks": "true", "zone": pod.Az, "user_id": pod.UserId, "resource_type": pod.ResourceType},
	}
	if pod.PhysicalResource == nil {
		return nil, errors.New("Pod.PhysicalResource is nil ")
	}
	reqParams.Resource = &xagent.UserResource{
		Vcpu:   int32(pod.PhysicalResource.CpuTotal),
		Memory: int32(pod.PhysicalResource.MemTotal),
		Cputune: &xagent.PodCputune{
			CpuSetCpus: arraryInt64ToInt(pod.PhysicalResource.CpuSet),
			CpuSetMems: arraryInt64ToInt(pod.PhysicalResource.NodeSet),
		},
	}

	reqParams.Log = &xagent.PodLogConfig{
		Type:   LogTypeJsonFile,
		Config: DefaultLogConfig,
	}

	if pod.DNSConfig != nil {
		reqParams.Dns = pod.DNSConfig.Nameservers
		options := make([]string, 0)
		for _, item := range pod.DNSConfig.Options {
			option := item.Name
			if item.Value != "" {
				option = option + ":" + item.Value
			}

			options = append(options, option)
		}
		reqParams.DnsOptions = options
		reqParams.DnsSearch = pod.DNSConfig.Searches
	}

	extraHosts := make([]string, 0)
	for _, item := range pod.HostAliases {
		ip := item.IP
		for _, hn := range item.Hostnames {
			extraHosts = append(extraHosts, hn+":"+ip)
		}
	}

	for _, item := range pod.PrimaryInterface.IPAddresses {
		ip := item.Ip
		extraHosts = append(extraHosts, hostname+":"+ip)
	}
	reqParams.ExtraHosts = extraHosts

	reqParams.Interfaces = p.ConvertNetJks2Xagent(pod)
	reqParams.Containers = p.ConvertContainerJks2Xagent(pod)
	reqParams.Volumes = p.ConvertVolumesJks2Xagent(pod)

	return reqParams, nil
}

func (p *ModelAdapter) ConvertNetJks2Xagent(pod *model.Pod) []*xagent.UserInterface {
	priInterface := pod.PrimaryInterface

	resp := &xagent.UserInterface{
		Mac:    priInterface.Mac,
		PortId: priInterface.PortId,
		Mtu:    priInterface.Mtu,
	}

	switch pod.NetworkType {
	case constant.OVSKernel:
		resp.NetworkType = NetworkTypeTap
	case constant.OVSDpdk:
		resp.NetworkType = NetworkTypeVhostUser
	}

	ipAddrs := make([]*xagent.IPAddress, 0)
	for _, item := range priInterface.IPAddresses {
		ipAddr := &xagent.IPAddress{
			Ip:      item.Ip,
			Subnet:  item.Subnet,
			Gateway: item.Gateway,
		}
		ipAddrs = append(ipAddrs, ipAddr)
	}
	resp.IPAddresses = ipAddrs

	return []*xagent.UserInterface{resp}
}

func (p *ModelAdapter) ConvertContainerJks2Xagent(pod *model.Pod) []*xagent.UserContainer {
	containers := pod.Containers

	result := make([]*xagent.UserContainer, 0)
	for _, item := range containers {
		name := jks.JoinPodContainerUQ(pod.PodId, item.Name)
		container := &xagent.UserContainer{
			Name:           name,
			Tty:            item.TTY,
			Image:          item.ImageInfo.ImageName,
			Command:        ConvertCommand(item),
			Envs:           ConvertEnv(item),
			LivenessProbe:  ConvertProbe(item.LivenessProbe),
			ReadinessProbe: ConvertProbe(item.ReadinessProbe),
		}

		// 判断用户是否传了workingDir，如果没传，则会去取镜像中的workingDir，如果镜像中也没有，则会传"/"。
		if item.WorkingDir == "" {
			if item.ImageInfo.WorkingDir == "" {
				container.Workdir = "/"
			} else {
				container.Workdir = item.ImageInfo.WorkingDir
			}
		} else {
			container.Workdir = item.WorkingDir
		}

		sysDisk := item.SystemDisk
		if sysDisk != nil {
			container.StorageOpt = map[string]string{
				KeyDiskType: DiskTypeBlock,
				KeyFsType:   sysDisk.FsType,
				KeySource:   sysDisk.DevicePath,
			}
			if sysDisk.IoTune != nil {
				container.StorageOpt[BPS_READ] = fmt.Sprintf("%v", sysDisk.IoTune.ReadBytes)
				container.StorageOpt[BPS_WRITE] = fmt.Sprintf("%v", sysDisk.IoTune.WriteBytes)
				container.StorageOpt[IOPS_READ] = fmt.Sprintf("%v", sysDisk.IoTune.ReadIops)
				container.StorageOpt[IOPS_WRITE] = fmt.Sprintf("%v", sysDisk.IoTune.WriteIops)
			}
		}

		volumeMounts := make([]*xagent.UserVolumeReference, 0)
		for _, dataDisk := range item.VolumeMounts {
			volume := &xagent.UserVolumeReference{
				Path:     dataDisk.MountPath,
				ReadOnly: dataDisk.ReadOnly,
				Volume:   dataDisk.Name,
			}
			volumeMounts = append(volumeMounts, volume)
		}
		container.Volumes = volumeMounts

		if item.Resources != nil { //todo 独立包装一个
			cpu := &xagent.Cputune{}
			mem := &xagent.Memtune{}

			limits := item.Resources.Limits
			requests := item.Resources.Requests

			if limits != nil {
				cpu.CpuPeriod = CpuPeriod * 1000
				if limits.CPU != 0 {
					cpu.CpuQuota = int64(CpuPeriod * limits.CPU)
				}
				if limits.MemoryMB != 0 {
					mem.MemoryLimitInByte = int64(limits.MemoryMB * 1024 * 1024)
				}
			}

			if requests != nil {
				if requests.CPU != 0 {
					cpu.CpuShares = int64(requests.CPU * 1024 / 1000)
				}
				if requests.MemoryMB != 0 {
					mem.MemorySoftLimitInByte = int64(requests.MemoryMB * 1024 * 1024)
				}
			}

			container.Resources = &xagent.ContainerResource{
				Cputune: cpu,
				Memtune: mem,
			}
		}

		result = append(result, container)
	}
	return result
}

func (p *ModelAdapter) ConvertVolumesJks2Xagent(pod *model.Pod) []*xagent.UserVolume {
	dataDisks := pod.Volumes
	volumes := make([]*xagent.UserVolume, 0)

	for _, dataDisk := range dataDisks {
		if dataDisk.JDCloudDisk == nil {
			break
		}
		cloudDisk := dataDisk.JDCloudDisk
		item := &xagent.UserVolume{}
		if cloudDisk.IoTune != nil {
			option := &xagent.UserVolumeOption{
				BpsRead:   cloudDisk.IoTune.ReadBytes,
				IOpsRead:  cloudDisk.IoTune.ReadIops,
				BpsWrite:  cloudDisk.IoTune.WriteBytes,
				IOpsWrite: cloudDisk.IoTune.WriteIops,
			}
			item.Option = option
		}
		item.Name = dataDisk.Name
		item.Format = DiskFormatRaw
		item.Source = cloudDisk.DevicePath
		item.Fstype = cloudDisk.FsType
		item.Formatfs = cloudDisk.FormatFs
		volumes = append(volumes, item)
	}

	return volumes
}

func (p *ModelAdapter) ConvertResourceJks2Xagent(PhysicalResource *model.PhysicalResource) *xagent.UserResource {
	return &xagent.UserResource{
		Vcpu:   int32(PhysicalResource.CpuTotal),
		Memory: int32(PhysicalResource.MemTotal),
		Cputune: &xagent.PodCputune{
			CpuSetCpus: arraryInt64ToInt(PhysicalResource.CpuSet),
			CpuSetMems: arraryInt64ToInt(PhysicalResource.NodeSet),
		},
	}
}

func (p *ModelAdapter) ConvertContainerResourceJks2Xagent(podId string, containers []*model.Container) []*xagent.UserContainer {
	result := make([]*xagent.UserContainer, 0)
	for _, item := range containers {
		name := jks.JoinPodContainerUQ(podId, item.Name)
		container := &xagent.UserContainer{
			Name: name,
		}

		if item.Resources != nil {
			cpu := &xagent.Cputune{}
			mem := &xagent.Memtune{}

			limits := item.Resources.Limits
			requests := item.Resources.Requests

			if limits != nil {
				cpu.CpuPeriod = CpuPeriod * 1000
				if limits.CPU != 0 {
					cpu.CpuQuota = int64(CpuPeriod * limits.CPU)
				}
				if limits.MemoryMB != 0 {
					mem.MemoryLimitInByte = int64(limits.MemoryMB * 1024 * 1024)
				}
			}

			if requests != nil {
				if requests.CPU != 0 {
					cpu.CpuShares = int64(requests.CPU * 1024 / 1000)
				}
				if requests.MemoryMB != 0 {
					mem.MemorySoftLimitInByte = int64(requests.MemoryMB * 1024 * 1024)
				}
			}

			container.Resources = &xagent.ContainerResource{
				Cputune: cpu,
				Memtune: mem,
			}
		}

		result = append(result, container)
	}
	return result
}
