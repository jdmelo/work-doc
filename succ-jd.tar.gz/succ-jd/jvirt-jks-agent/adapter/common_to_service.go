package adapter

import (
	"errors"
	"fmt"
	"path"
	"strings"

	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-jks-agent/constant"
	"jd.com/jvirt/jvirt-jks-agent/model"
	"jd.com/jvirt/jvirt-jks-agent/utils"
)

func (p *ModelAdapter) ConvertPodCommon2Agent(action string, params *jks.Pod) (*model.Pod, error) {
	podId := params.PodId
	userId := params.UserId

	result := &model.Pod{
		InstanceType:                  params.InstanceType,
		ResourceType:                  params.ResourceType,
		RuntimeType:                   params.RuntimeType,
		PodPath:                       path.Join(p.ComputeCfg.InstancesDir, params.PodId),
		PodId:                         params.PodId,
		UserId:                        params.UserId,
		UserPin:                       params.UserPin,
		Description:                   params.Description,
		Az:                            params.Az,
		Hostname:                      params.Hostname,
		HostIP:                        params.HostIP,
		RestartPolicy:                 params.RestartPolicy,
		TerminationGracePeriodSeconds: params.TerminationGracePeriodSeconds,
		DNSConfig:                     params.DNSConfig,
		HostAliases:                   params.HostAliases,
		LogConfig:                     params.LogConfig,
		NetworkType:                   p.ComputeCfg.OVSType,
	}

	containers, err := p.ConvertContainerCommon2Agent(action, userId, podId, params.Containers)
	if err != nil {
		p.Logger.Error("[ConvertPodCommon2Agent] convert containers failed. Error: %s", err.Error())
		return nil, err
	}
	result.Containers = containers

	volumes, err := p.ConvertDateDiskCommon2Agent(action, userId, podId, params.Volumes)
	if err != nil {
		p.Logger.Error("[ConvertPodCommon2Agent] convert volumes failed. Error: %s", err.Error())
		return nil, err
	}
	result.Volumes = volumes

	net, err := p.ConvertNetworkCommon2Agent(action, userId, params.PrimaryInterface)
	if err != nil {
		p.Logger.Error("[ConvertPodCommon2Agent] convert network failed. Error: %s", err.Error())
		return nil, err
	}
	result.PrimaryInterface = net

	return result, nil
}

func (p *ModelAdapter) ConvertContainerCommon2Agent(action, userId, podId string, params []*jks.Container) ([]*model.Container, error) {
	result := make([]*model.Container, 0)
	for _, container := range params {
		item := &model.Container{
			Name:           container.Name,
			Command:        container.Command,
			Args:           container.Args,
			Env:            container.Env,
			WorkingDir:     container.WorkingDir,
			TTY:            container.TTY,
			LivenessProbe:  container.LivenessProbe,
			ReadinessProbe: container.ReadinessProbe,
			Resources:      container.Resources,
			VolumeMounts:   container.VolumeMounts,
		}

		// 只有创建迁移pod才会去查镜像信息
		switch action {
		case constant.CreatePodAction, constant.MigratePodAction, constant.RebuildPodAction:
			respImage, err := p.JksApiCli.GetContainerImage(podId, container.Name)
			if err != nil {
				return nil, err
			}
			imageInfo := &model.ImageInfo{
				RegistryType:     respImage.RegistryType,
				RegistryUrl:      respImage.RegistryUrl,
				RegistryUsername: respImage.RegistryUsername,
				RegistryPassword: respImage.RegistryPassword,
				HttpProxy:        respImage.HttpProxy,
				Env:              respImage.Env,
				Cmd:              respImage.Command,
				WorkingDir:       respImage.WorkingDir,
				Entrypoint:       respImage.Entrypoint,
				ImageDigest:      respImage.ImageDigest,
				ImageName:        respImage.ImageName,
			}
			imageInfo.DownloadPath = path.Join(p.ComputeCfg.InstancesDir, podId, respImage.ImageDigest)

			item.ImageInfo = imageInfo
		}

		sysDisk, err := p.ConvertSysDiskCommon2Agent(action, userId, podId, container.SystemDisk)
		if err != nil {
			p.Logger.Error("[ConvertContainerCommon2Agent] convert sysDisk failed. Error: %s", err.Error())
			return nil, err
		}
		item.SystemDisk = sysDisk

		result = append(result, item)
	}

	return result, nil
}

func (p *ModelAdapter) ConvertSysDiskCommon2Agent(action, userId, podId string, params *jks.CloudDisk) (*model.CloudDisk, error) {
	if params == nil {
		p.Logger.Error("[ConvertSysDiskCommon2Agent] Params is nil")
		return nil, errors.New("container system disk is nil")
	}

	volId := params.VolumeId
	disk := &model.CloudDisk{
		VolumeId:            volId,
		FsType:              params.FsType,
		DeleteOnTermination: params.DeleteOnTermination,
		FormatFs:            true,
	}

	devName := utils.ZbsSoftLinkName(volId, podId)
	disk.DevicePath = path.Join(p.ComputeCfg.ZbsLinkFileDir, devName)

	switch action {
	// 只有创建迁移pod需要去查限速信息
	case constant.CreatePodAction, constant.MigratePodAction, constant.RebuildPodAction:
		volView, err := p.VolCli.DescribeVolume(userId, volId)
		if err != nil {
			p.Logger.Error("[ConvertSysDiskCommon2Agent] DescribeVolume failed. VolId: %s, Error: %v.", volId, err.Error())
			return nil, err
		}
		if volView.Data == nil {
			p.Logger.Error("[ConvertSysDiskCommon2Agent] DescribeVolume result is nil. VolId: %s.", volId)
			return nil, errors.New("DescribeVolume result is nil. ")
		}

		volIoLimit := volView.Data.IoLimit
		disk.IoTune = &model.IOLimit{
			ReadBytes:  uint64(volIoLimit.ReadBytes) * constant.SIZE_MB,
			WriteBytes: uint64(volIoLimit.WriteBytes) * constant.SIZE_MB,
			ReadIops:   uint64(volIoLimit.ReadIops),
			WriteIops:  uint64(volIoLimit.WriteIops),
		}
	}

	return disk, nil
}

func (p *ModelAdapter) ConvertDateDiskCommon2Agent(action, userId, podId string, params []*jks.Volume) ([]*model.Volume, error) {
	result := make([]*model.Volume, 0)
	for _, vol := range params {
		jdcloudDisk := vol.JDCloudDisk
		if jdcloudDisk != nil {
			var ioTune *model.IOLimit
			volId := jdcloudDisk.VolumeId
			devName := utils.ZbsSoftLinkName(volId, podId)
			devPath := path.Join(p.ComputeCfg.ZbsLinkFileDir, devName)

			switch action {
			// 只有创建迁移pod需要去查限速信息
			case constant.CreatePodAction, constant.MigratePodAction, constant.RebuildPodAction, constant.ExtendVolumeAction:
				volView, err := p.VolCli.DescribeVolume(userId, volId)
				if err != nil {
					p.Logger.Error("[ConvertDateDiskCommon2Agent] DescribeVolume failed. VolId: %s, Error: %v.", volId, err.Error())
					return nil, err
				}
				if volView.Data == nil {
					if action == constant.DeletePodAction {
						p.Logger.Warn("[ConvertDateDiskCommon2Agent] DescribeVolume result is nil. VolId: %s. Action: %s", volId, action)
						continue
					}
					p.Logger.Error("[ConvertDateDiskCommon2Agent] DescribeVolume result is nil. VolId: %s.", volId)
					return nil, errors.New("DescribeVolume result is nil. ")
				}

				volIoLimit := volView.Data.IoLimit
				ioTune = &model.IOLimit{
					ReadBytes:  uint64(volIoLimit.ReadBytes) * constant.SIZE_MB,
					WriteBytes: uint64(volIoLimit.WriteBytes) * constant.SIZE_MB,
					ReadIops:   uint64(volIoLimit.ReadIops),
					WriteIops:  uint64(volIoLimit.WriteIops),
				}
			}

			item := &model.Volume{
				Name: vol.Name,
				JDCloudDisk: &model.CloudDisk{
					VolumeId:            volId,
					FsType:              jdcloudDisk.FsType,
					DevicePath:          devPath,
					FormatFs:            false,
					IoTune:              ioTune,
					DeleteOnTermination: jdcloudDisk.DeleteOnTermination,
				},
			}
			if action == constant.CreatePodAction {
				item.JDCloudDisk.FormatFs = jdcloudDisk.FormatVolume
			}

			result = append(result, item)
		}
	}
	return result, nil
}

func (p *ModelAdapter) ConvertNetworkCommon2Agent(action, userId string, params *jks.NetworkPort) (*model.Network, error) {
	portId := params.PortId
	subnetId := params.SubnetId

	ret := &model.Network{
		DeviceIndex:         params.DeviceIndex,
		VpcId:               params.VpcId,
		PortId:              portId,
		DeleteOnTermination: params.DeleteOnTermination,
	}

	switch action {
	// 删除，停止，清理资源不需要其他参数
	case constant.CleanPodAction, constant.DeletePodAction, constant.StopPodAction:
		return ret, nil
	}

	portView, err := p.NetCli.DescribePortById(userId, portId)
	if err != nil {
		p.Logger.Error("[ConvertNetworkCommon2Agent] DescribePort failed. PortId: %s; Error: %s.", portId, err.Error())
		return nil, err
	}
	subnetView, err := p.NetCli.DescribeSubnetById(userId, subnetId)
	if err != nil {
		p.Logger.Error("[ConvertNetworkCommon2Agent] DescribeSubnetById failed. SubnetId: %s; Error: %s.", subnetId, err.Error())
		return nil, err
	}

	ipv4Cidrs := strings.Split(subnetView.Cidr, "/")
	if len(ipv4Cidrs) != 2 {
		msg := fmt.Sprintf("subnet cidr [%s] Invalid format", subnetView.Cidr)
		p.Logger.Error(msg)
		return nil, errors.New(msg)
	}
	subnetIpv4Cidr := ipv4Cidrs[1]

	ipAddresses := make([]*model.IPAddress, 0)
	ipAddress := &model.IPAddress{
		Ip:      params.FixedIP,
		Subnet:  subnetIpv4Cidr,
		Gateway: subnetView.GatewayIpAddress,
	}
	ipAddresses = append(ipAddresses, ipAddress)

	// 如果查到的ipv6的cidr为空字符串，则不会处理ipv6地址
	if subnetView.Ipv6Cidr != "" {
		ipv6Cidrs := strings.Split(subnetView.Ipv6Cidr, "/")
		if len(ipv6Cidrs) != 2 {
			msg := fmt.Sprintf("subnet cidr [%s] Invalid format", subnetView.Ipv6Cidr)
			p.Logger.Error(msg)
			return nil, errors.New(msg)
		}
		subnetIpv6Cidr := ipv6Cidrs[1]
		for _, item := range params.Ipv6Addresses {
			ipAddress := &model.IPAddress{
				Ip:      item,
				Subnet:  subnetIpv6Cidr,
				Gateway: subnetView.Ipv6GateWayIp,
			}
			ipAddresses = append(ipAddresses, ipAddress)
		}
	}

	ret.Mac = portView.MacAddress
	ret.Mtu = uint64(subnetView.Mtu)
	ret.IPAddresses = ipAddresses

	return ret, nil
}
