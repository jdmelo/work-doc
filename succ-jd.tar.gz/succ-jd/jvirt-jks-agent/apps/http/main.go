package main

import (
	"flag"
	"fmt"
	"os"
	"runtime"
	"time"

	commonRuntime "jd.com/jvirt/jvirt-common/utils/runtime"
	"jd.com/jvirt/jvirt-common/utils/termination"
	"jd.com/jvirt/jvirt-jks-agent/apps/http/server"
	"jd.com/jvirt/jvirt-jks-agent/cfg"
)

const (
	defaultConfig = "/etc/jks/jks-agent.conf"
)

func InitJksAgentServer() (*server.JksAgentServer, error) {
	// 1: 参数解析
	var configPath string
	flag.StringVar(&configPath, "config", defaultConfig, "configure file!")
	flag.Usage = func() {
		fmt.Fprintf(os.Stderr, "Usage: %s [-config <file_path>] \n", os.Args[0])
		flag.PrintDefaults()
	}
	flag.Parse()

	// 2：配置文件解析
	if err := cfg.ParseConfig(&configPath); err != nil {
		return nil, err
	}

	// 3. 根据配置文件，设置程序并发.
	runtime.GOMAXPROCS(cfg.DefaultCfg.RuntimeCores)

	// 4: start jvirt-jks-agent http server.
	return server.NewJksAgentServer()
}

func main() {
	jksServer, err := InitJksAgentServer()
	if err != nil {
		fmt.Fprintf(os.Stderr, "%s Init jvirt-jks-agent error: %v.\n", time.Now(), err.Error())
		os.Exit(1)
	}

	commonRuntime.ReallyCrash = cfg.DefaultCfg.ReallyCrash

	startNotify := func() error {
		fmt.Fprintf(os.Stdout, "%s Start jvirt-jks-agent ......\n", time.Now())
		err := jksServer.Start()
		if err != nil {
			fmt.Fprintf(os.Stderr, "%s Start jvirt-jks-agent failed. Error: %v\n", time.Now(), err.Error())
			return err
		}
		return nil
	}

	stopNotify := func() {
		fmt.Fprintf(os.Stderr, "%s jvirt-jks-agent stopped.\n", time.Now())
	}

	interrupt := termination.New(nil, jksServer.Stop, stopNotify)

	interrupt.Run(startNotify)
}
