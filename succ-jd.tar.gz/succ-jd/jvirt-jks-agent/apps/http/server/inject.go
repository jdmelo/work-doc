package server

import (
	"errors"
	"reflect"

	"github.com/facebookgo/inject"
)

var g *inject.Graph

func init() {
	g = &inject.Graph{}
}

func InjectObject(obj interface{}) {
	if obj == nil {
		panic(errors.New("service is null"))
	}
	if reflect.TypeOf(obj).Kind() != reflect.Ptr {
		panic(errors.New("service is not point type"))
	}
	g.Provide(
		&inject.Object{Value: obj},
	)
}

func PopulateInject() {
	g.Populate()
}
