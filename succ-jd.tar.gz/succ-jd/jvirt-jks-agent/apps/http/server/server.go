package server

import (
	"context"
	"fmt"
	"net/http"
	"os"
	"time"

	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/integration/xagent"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/server"
	"jd.com/jvirt/jvirt-common/utils/url"
	"jd.com/jvirt/jvirt-jks-agent/adapter"
	"jd.com/jvirt/jvirt-jks-agent/cfg"
	"jd.com/jvirt/jvirt-jks-agent/em"
	"jd.com/jvirt/jvirt-jks-agent/em/loglistener"
	"jd.com/jvirt/jvirt-jks-agent/handler/async"
	"jd.com/jvirt/jvirt-jks-agent/handler/sync"
	"jd.com/jvirt/jvirt-jks-agent/handler/test"
	"jd.com/jvirt/jvirt-jks-agent/httpclient"
	"jd.com/jvirt/jvirt-jks-agent/runtime"
	jksXagent "jd.com/jvirt/jvirt-jks-agent/runtime/xagent"
	"jd.com/jvirt/jvirt-jks-agent/service"
	"jd.com/jvirt/jvirt-jks-agent/workers"
)

// 初始化log
func initLogger(c *cfg.LogConfig) (log.Logger, error) {
	logger := log.New()
	file, err := os.OpenFile(c.FilePath, os.O_WRONLY|os.O_APPEND|os.O_CREATE, 0755)
	if err != nil {
		return nil, err
	}
	logger.SetOutput(file)
	log.SetOutput(file)
	logger.SetLevel(c.Level)
	log.SetLevelString(c.Level)
	return logger, nil
}

func initEventManger(l log.Logger) *em.EventManagerService {
	emService := em.NewEventManager(l)

	//添加Event的Listener
	emService.AddListener(loglistener.NewActionLogger(l))
	emService.AddListener(loglistener.NewExecuteTimer(l))

	return emService
}

func initRuntimeManager(l log.Logger, computeCfg *cfg.ComputeConfig) (*runtime.RuntimeManager, error) {
	rt := runtime.NewRuntimeManager()

	for _, d := range computeCfg.SupportDrivers {
		switch d {
		case jks.RuntimeXagent:
			xd := &jksXagent.XAgentDriver{}
			rt.AddDriver(jks.RuntimeXagent, xd)
			InjectObject(xd)
		default:
			return nil, fmt.Errorf("the driver [%s] of runtime not support", d)
		}
	}

	return rt, nil
}

type JksAgentServer struct {
	*server.Server
	logger         log.Logger
	httpUrl        string // 对外提供的url
	httpRouter     *url.Router
	httpServer     *http.Server
	heartbeat      *workers.Heartbeat // 心跳work
	serverRecovery *workers.ServerRecovery
	taskDispatcher *async.TaskDispatcher
	serviceManager *service.PodService
	eventManager   *em.EventManagerService
}

func NewJksAgentServer() (*JksAgentServer, error) {
	// init logger
	logger, err := initLogger(cfg.LogCfg)
	if err != nil {
		fmt.Println("initLogger failed. Error:", err.Error())
		return nil, err
	}
	InjectObject(logger)

	InjectObject(cfg.ComputeCfg)

	// 实例化image registry客户端
	imageCli, err := httpclient.NewImageRegistryClient(logger)
	if err != nil {
		fmt.Println("NewImageRegistryClient failed. Error:", err.Error())
		return nil, err
	}
	InjectObject(imageCli)

	// 实例化Network客户端
	networkCli, err := httpclient.NewNetworkClient(logger, cfg.NetworkCfg)
	if err != nil {
		fmt.Println("NewNetworkClient failed. Error:", err.Error())
		return nil, err
	}
	InjectObject(networkCli)

	// 实例化Volume客户端
	volumeCli, err := httpclient.NewVolumeClient(logger, cfg.VolumeCfg)
	if err != nil {
		fmt.Println("NewVolumeClient failed. Error:", err.Error())
		return nil, err
	}
	InjectObject(volumeCli)

	// 实例jvirt-jks-api-server客户端
	jksInnerApiCli, err := httpclient.NewJksApiClient(logger, cfg.JksApiCfg)
	if err != nil {
		fmt.Println("NewJksApiClient failed. Error:", err.Error())
		return nil, err
	}
	InjectObject(jksInnerApiCli)

	// 实例jvirt-jks-gw客户端
	jksGwCli, err := httpclient.NewJksGwClient(logger, cfg.JksGwCfg)
	if err != nil {
		fmt.Println("NewJksGwClient failed. Error:", err.Error())
		return nil, err
	}
	InjectObject(jksGwCli)

	// 实例jvirt-jks-agent客户端
	jksAgentCli, err := httpclient.NewJksAgentClient(logger, cfg.JksAgentCfg)
	if err != nil {
		fmt.Println("NewJksAgentClient failed. Error:", err.Error())
		return nil, err
	}
	InjectObject(jksAgentCli)

	// 实例jvirt-rms-api客户端
	rmsApiCli, err := httpclient.NewRmsApiClient(logger, cfg.RmsApiCfg)
	if err != nil {
		fmt.Println("NewRmsApiClient failed. Error:", err.Error())
		return nil, err
	}
	InjectObject(rmsApiCli)

	// 实例jvirt-rms-gw客户端
	rmsGwCli, err := httpclient.NewRmsGwClient(logger, cfg.RmsGwCfg)
	if err != nil {
		fmt.Println("NewRmsGwClient failed. Error:", err.Error())
		return nil, err
	}
	InjectObject(rmsGwCli)

	// 实例化xcgroup客户端
	xcgroupCli, err := httpclient.NewXcgroupClient(logger, cfg.XCgroupCfg, cfg.ComputeCfg.UseXcgroup)
	if err != nil {
		fmt.Println("NewXcgroupClient failed. Error:", err.Error())
		return nil, err
	}
	InjectObject(xcgroupCli)

	// 实例化xagent客户端
	xagentClient := xagent.NewXAgentClient(logger, cfg.XAgentCfg)
	InjectObject(xagentClient)

	// 实例RuntimeManager
	runtimeManager, err := initRuntimeManager(logger, cfg.ComputeCfg)
	if err != nil {
		fmt.Println("initRuntimeManager failed. Error:", err.Error())
		return nil, err
	}
	InjectObject(runtimeManager)

	// 实例EventManger
	eventManager := initEventManger(logger)
	InjectObject(eventManager)

	// 实例化workers
	heartbeat := workers.NewHeartbeat()
	InjectObject(heartbeat)
	recoverServer := &workers.ServerRecovery{}
	InjectObject(recoverServer)

	// 实例化model适配器
	modelAdapter := &adapter.ModelAdapter{}
	InjectObject(modelAdapter)

	// 实例化PodService
	podService := service.NewPodService()
	InjectObject(podService)

	// 实例化任务分发器
	taskDispatcher := async.NewTaskDispatcher()
	InjectObject(taskDispatcher)

	// init httpRouter
	httpRouter := url.NewRouter()
	httpRouter.Logger = logger
	httpRouter.RegisterFilters(httpRouter.InvokerFilter)

	// 实例化http handler
	testHandler := &test.TestHandler{}
	testHandler.RegisterHandler(httpRouter)
	InjectObject(testHandler)
	asyncHandler := &async.TaskHandler{}
	asyncHandler.RegisterHandler(httpRouter)
	InjectObject(asyncHandler)
	syncHandler := &sync.PodHandler{}
	syncHandler.RegisterHandler(httpRouter)
	InjectObject(syncHandler)

	jksAgentServer := &JksAgentServer{
		logger:         logger,
		httpUrl:        "/" + cfg.JksAgentCfg.BasePath,
		httpRouter:     httpRouter,
		heartbeat:      heartbeat,
		serverRecovery: recoverServer,
		taskDispatcher: taskDispatcher,
		serviceManager: podService,
		eventManager:   eventManager,
	}

	jksAgentServer.Server = server.NewServer(jksAgentServer.doStart, jksAgentServer.doStop)
	jksAgentServer.httpServer = &http.Server{
		Addr:         fmt.Sprintf(":%s", cfg.JksAgentCfg.Port),
		ReadTimeout:  30 * time.Second,
		WriteTimeout: 120 * time.Second,
	}

	PopulateInject()

	return jksAgentServer, nil
}

func (s *JksAgentServer) doStart() error {
	s.logger.Debug("Invoke JksAgentServer doStart ......")

	if err := s.serviceManager.Start(); err != nil {
		s.logger.Error("Invoke serviceManager Initialization failed. Error: %+v.", err)
		return err
	}

	if err := s.taskDispatcher.Start(); err != nil {
		s.logger.Error("Start async dispatcher failed. Error: %+v.", err)
		return err
	}

	if err := s.eventManager.Start(); err != nil {
		s.logger.Error("Start async eventManager failed. Error: %+v.", err)
		return err
	}

	if err := s.serverRecovery.Recover(); err != nil {
		// 环境初始化失败,不影响服务启动.
		s.logger.Error("Invoke RecoverPod failed. Error: %+v.", err)
		return err
	}

	// 启动heartbeat子服务,立即拉取任务,执行任务.
	if err := s.heartbeat.Start(); err != nil {
		s.logger.Error("The heartbeat service start failed. Error: %+v.", err)
		return err
	}

	// 启动http服务,接受请求.
	http.Handle(s.httpUrl, s.httpRouter)
	if err := s.httpServer.ListenAndServe(); err != nil {
		s.logger.Error("The HttpServer service start failed. Error: %+v.", err)
		return err
	}

	return nil
}

func (s *JksAgentServer) doStop() {
	s.logger.Debug("Invoke JksAgentServer doStop ......")

	if s.heartbeat != nil {
		s.heartbeat.Stop()
	}

	if s.eventManager != nil {
		s.eventManager.Stop()
	}

	if s.taskDispatcher != nil {
		s.taskDispatcher.Stop()
	}

	if s.serviceManager != nil {
		s.serviceManager.Stop()
	}

	if s.httpServer != nil {
		ctx, cancel := context.WithCancel(context.Background())
		s.httpServer.Shutdown(ctx)
		ctx.Done()
		cancel()
	}

	s.logger.Debug("Invoke JksAgentServer doStop finished.")
}
