package httpclient

import (
	"fmt"
	"os"
	"path"
	"testing"

	"jd.com/jvirt/jvirt-common/integration/registry/tarexport"
	"jd.com/jvirt/jvirt-common/utils/config"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jks-agent/model"
)

func initLoggers(logFile string) (log.Logger, error) {
	c := &config.Default{
		Debug:    true,
		Verbose:  true,
		LogFile:  logFile,
		LogLevel: "debug",
	}
	f, err := os.OpenFile(c.LogFile, os.O_WRONLY|os.O_APPEND|os.O_CREATE, 0755)
	if err != nil {
		return nil, err
	}
	l := log.New()
	l.SetOutput(f)
	l.SetLevel(c.LogLevel)

	return l, nil
}

func getImageClient() *ImageRegistryClient {
	logger, err := initLoggers("/tmp/image_test.log")
	if err != nil {
		panic("initLoggers")
	}
	client, err := NewImageRegistryClient(logger)
	if err != nil {
		panic("NewImageRegistryClient")
	}

	return client
}

func TestDownloadImages(t *testing.T) {
	var (
		imageDownloadDir = "/export/succ/images"
	)

	var (
		// 构造pod参数
		imageInfo1 = &model.ImageInfo{
			RegistryType: "DockerHub",
			RegistryUrl:  "https://registry.docker-cn.com",
			ImageName:    "library/nginx",
			ImageDigest:  "sha256:d98b66402922eccdbee49ef093edb2d2c5001637bd291ae0a8cd21bb4c36bebe",
			DownloadPath: path.Join(imageDownloadDir, "sha256:d98b66402922eccdbee49ef093edb2d2c5001637bd291ae0a8cd21bb4c36bebe"),
		}
		container1 = &model.Container{
			ImageInfo: imageInfo1,
		}
		imageInfo2 = &model.ImageInfo{
			RegistryType: "DockerHub",
			RegistryUrl:  "https://registry.docker-cn.com",
			ImageName:    "library/busybox",
			ImageDigest:  "sha256:915f390a8912e16d4beb8689720a17348f3f6d1a7b659697df850ab625ea29d5",
			DownloadPath: path.Join(imageDownloadDir, "sha256:915f390a8912e16d4beb8689720a17348f3f6d1a7b659697df850ab625ea29d5"),
		}
		container2 = &model.Container{
			ImageInfo: imageInfo2,
		}
		imageInfo3 = &model.ImageInfo{
			RegistryType: "DockerHub",
			RegistryUrl:  "https://registry.docker-cn.com",
			ImageName:    "library/busybox",
			ImageDigest:  "sha256:915f390a8912e16d4beb8689720a17348f3f6d1a7b659697df850ab625ea29d5",
			DownloadPath: path.Join(imageDownloadDir, "sha256:915f390a8912e16d4beb8689720a17348f3f6d1a7b659697df850ab625ea29d5"),
		}
		container3 = &model.Container{
			ImageInfo: imageInfo3,
		}
		pod = &model.Pod{
			Containers: []*model.Container{container1, container2, container3},
		}
	)

	fmt.Println("TestDownloadImages Start")

	if err := getImageClient().DownloadImages(pod); err != nil {
		t.Errorf("[TestDownloadImages] DownloadImages faild. Error: %s", err.Error())
		return
	}

	fmt.Println("Success")
}

func TestLoadTar(t *testing.T) {
	fmt.Println("TestLoadTar Start")
	tarExporter := tarexport.NewTarExporter()
	_, err := tarExporter.LoadTar("/export/succ/images/sha256:915f390a8912e16d4beb8689720a17348f3f6d1a7b659697df850ab625ea29d5", "/mnt/succ/rootfs")
	if err != nil {
		t.Errorf("[TestLoadTar] tarExporter LoadTar failed. Error:%s", err.Error())
		return
	}
	fmt.Println("TestLoadTar Success")
}

func TestLoadImagesToPod(t *testing.T) {

}
