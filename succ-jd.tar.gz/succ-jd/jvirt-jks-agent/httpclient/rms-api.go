package httpclient

import (
	"errors"
	"fmt"

	rmsApi "jd.com/jvirt/jvirt-common/inner/rms/api-server"
	"jd.com/jvirt/jvirt-common/utils/config"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/url"
)

type RmsApiClient struct {
	Logger log.Logger
	Client rmsApi.ResourceManager
}

func NewRmsApiClient(log log.Logger, c *config.Rms) (*RmsApiClient, error) {
	httpCfg := &config.HttpClient{
		ConnectTimeout:        c.ConnectTimeout,
		MaxIdleConns:          c.MaxIdleConns,
		TimerInterval:         c.TimerInterval,
		ResponseHeaderTimeout: c.ResponseHeaderTimeout,
		RequestTotalTimeout:   c.RequestTotalTimeout,
	}

	hc := url.NewClient(httpCfg, log)

	client, err := rmsApi.NewRmsClient(hc, log, c)
	if err != nil {
		return nil, err
	}

	return &RmsApiClient{
		Client: client,
		Logger: log,
	}, nil
}

func (p *RmsApiClient) DescribeFlavor(flavorId string) (*rmsApi.FlavorDescription, error) {
	if flavorId == "" {
		msg := fmt.Sprintf("flavorId must be set")
		p.Logger.Error(msg)
		return nil, errors.New(msg)
	}

	params := rmsApi.DescribeFlavorRequest{
		FlavorIds:    []string{flavorId},
		OnLineStatus: rmsApi.FlavorAllStatus,
	}
	flavors, jErr := p.Client.DescribeFlavorByFlavorId(params)
	if jErr != nil {
		msg := fmt.Sprintf("DescribeFlavorByFlavorId failed. Params: %+v, Error: %s, Detail: %s", params, jErr.Error(), jErr.Detail())
		p.Logger.Error(msg)
		return nil, jErr
	}
	if len(flavors) == 0 {
		msg := fmt.Sprintf("flavor not found. FlavorId: %s.", flavorId)
		p.Logger.Error(msg)
		return nil, errors.New(msg)
	}
	if len(flavors) > 1 {
		msg := fmt.Sprintf("flavor repeat. FlavorId: %s.", flavorId)
		p.Logger.Error(msg)
		return nil, errors.New(msg)
	}
	flavor := flavors[0]

	return flavor, nil
}
