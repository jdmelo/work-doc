package httpclient

import (
	"errors"
	"fmt"
	"sync"

	"jd.com/jvirt/jvirt-common/integration/xcgroup"
	outer "jd.com/jvirt/jvirt-common/integration/xcgroup/model"
	"jd.com/jvirt/jvirt-common/utils"
	"jd.com/jvirt/jvirt-common/utils/config"
	"jd.com/jvirt/jvirt-common/utils/golocal"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/url"
	"jd.com/jvirt/jvirt-jks-agent/model"
)

type XcgroupClient struct {
	mu         sync.Mutex
	client     xcgroup.IXcGroupManager
	logger     log.Logger
	useXcgroup bool
	RmsApiCli  *RmsApiClient `inject:""`
}

func convertView(params *outer.XCGroupView) *model.PhysicalResource {
	return &model.PhysicalResource{
		CpuTotal: params.CpuTotal,
		CpuSet:   params.CpuSet,
		VCPUPin:  params.VCPUPin,
		MemTotal: params.MemTotal,
		NodeSet:  params.NodeSet,
		GpuSet:   params.GpuSet,
		EphSet:   params.EphSet,
	}
}

func NewXcgroupClient(log log.Logger, c *config.XcGroup, useXcgroup bool) (*XcgroupClient, error) {
	httpCfg := &config.HttpClient{
		ConnectTimeout:        c.ConnectTimeout,
		MaxIdleConns:          c.MaxIdleConns,
		TimerInterval:         c.TimerInterval,
		ResponseHeaderTimeout: c.ResponseHeaderTimeout,
		RequestTotalTimeout:   c.RequestTotalTimeout,
	}

	hc := url.NewClient(httpCfg, log)

	client := xcgroup.NewDefaultXcGroupManager(hc, c, log)

	return &XcgroupClient{
		client:     client,
		logger:     log,
		useXcgroup: useXcgroup,
	}, nil
}

// 分配实例请求的资源配置
func (p *XcgroupClient) Alloc(runtimeType, podId, flavorId string) (*model.PhysicalResource, error) {
	p.mu.Lock()
	defer p.mu.Unlock()

	flavorView, err := p.RmsApiCli.DescribeFlavor(flavorId)
	if err != nil {
		p.logger.Error("[Alloc] DescribeFlavor failed. PodId: %s, FlavorId: %s, Error: %s",
			podId, flavorId, err.Error())

		return nil, err
	}

	resView := &outer.XCGroupView{}
	if p.useXcgroup {
		reqId := utils.GenerateUuid("jks-agent")
		if goValue := golocal.GoContext.Get(); goValue != nil {
			reqId = goValue.RequestId
		}

		resView, err = p.Query(podId)
		if err != nil {
			p.logger.Error("[Alloc] query resource failed. PodId: %s, Error: %s", podId, err.Error())
			return nil, err
		}
		if resView == nil {
			params := &outer.AllocateReq{
				InstanceId:   podId,
				InstanceType: runtimeType,
				Cpu:          int64(flavorView.Cpu),
				MicroCpu:     0,
				Memory:       int64(flavorView.Memory * 1024),
			}
			resView, err = p.client.Alloc(reqId, params)
			if err != nil {
				p.logger.Error("[Alloc] alloc resource failed. PodId: %s, FlavorId: %s, Error: %s",
					podId, flavorId, err.Error())
				return nil, err
			}
			if resView == nil {
				msg := fmt.Sprintf("Invoke xcgroup alloc resource is nil, PodId: %s, FlavorId: %s", podId, flavorId)
				p.logger.Error(msg)
				return nil, errors.New(msg)
			}
		}
	}

	// xagent需要我们传入的参数，例如cpu:2, memory:4096
	resView.CpuTotal = int64(flavorView.Cpu)
	resView.MemTotal = int64(flavorView.Memory)

	p.logger.Debug("[Alloc] alloc resource success. PodId: %s, FlavorId: %s, Resp: %+v", podId, flavorId, *resView)

	return convertView(resView), nil
}

// 重新分配实例请求的资源配置
func (p *XcgroupClient) ReAlloc(runtimeType, podId, flavorId string) (*model.PhysicalResource, error) {
	p.mu.Lock()
	defer p.mu.Unlock()

	flavorView, err := p.RmsApiCli.DescribeFlavor(flavorId)
	if err != nil {
		p.logger.Error("[ReAlloc] DescribeFlavor failed. PodId: %s, FlavorId: %s, Error: %s",
			podId, flavorId, err.Error())

		return nil, err
	}

	resView := &outer.XCGroupView{}
	reqId := utils.GenerateUuid("jks-agent")
	if goValue := golocal.GoContext.Get(); goValue != nil {
		reqId = goValue.RequestId
	}

	params := &outer.AllocateReq{
		InstanceId:   podId,
		InstanceType: runtimeType,
		Cpu:          int64(flavorView.Cpu),
		MicroCpu:     0,
		Memory:       int64(flavorView.Memory * 1024),
	}

	resView, err = p.client.ReAlloc(reqId, params)
	if err != nil {
		p.logger.Error("[Alloc] alloc resource failed. PodId: %s, FlavorId: %s, Error: %s",
			podId, flavorId, err.Error())
		return nil, err
	}
	if resView == nil {
		msg := fmt.Sprintf("Invoke xcgroup alloc resource is nil, PodId: %s, FlavorId: %s", podId, flavorId)
		p.logger.Error(msg)
		return nil, errors.New(msg)
	}

	// xagent需要我们传入的参数，例如cpu:2, memory:4096
	resView.CpuTotal = int64(flavorView.Cpu)
	resView.MemTotal = int64(flavorView.Memory)
	p.logger.Debug("[ReAlloc] alloc resource success. PodId: %s, FlavorId: %s, Resp: %+v", podId, flavorId, *resView)
	return convertView(resView), nil
}

func (p *XcgroupClient) Free(podId string) error {
	// 如果不使用xcgroup，直接返回
	if !p.useXcgroup {
		return nil
	}
	p.logger.Debug("[Free] Free resource start. PodId: %v", podId)

	reqId := utils.GenerateUuid("jks-agent")
	if goValue := golocal.GoContext.Get(); goValue != nil {
		reqId = goValue.RequestId
	}

	state, err := p.client.Free(reqId, podId)
	if err != nil {
		p.logger.Error("[Free] Free resource failed. PodId: %v, Error: %v", podId, err.Error())

		return err
	}

	if state == xcgroup.FreeStateFail {
		p.logger.Error("[Free] Free resource failed. State: %v.", state)
		return errors.New("free resource failed, free state is 0")
	}
	p.logger.Debug("[Free] Free resource success. PodId: %v", podId)

	return nil
}

func (p *XcgroupClient) Query(podId string) (*outer.XCGroupView, error) {
	p.logger.Debug("[Query] Query resource start. PodId: %v", podId)

	reqId := utils.GenerateUuid("jks-agent")
	if goValue := golocal.GoContext.Get(); goValue != nil {
		reqId = goValue.RequestId
	}

	resView, err := p.client.Query(reqId, podId)
	if err != nil {
		p.logger.Error("[Query] Query resource failed. PodId: %v, Error: %s", podId, err.Error())

		return nil, err
	}

	return resView, nil
}
