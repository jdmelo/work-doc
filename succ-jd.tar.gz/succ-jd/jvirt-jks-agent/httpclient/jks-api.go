package httpclient

import (
	"errors"
	"fmt"

	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	"jd.com/jvirt/jvirt-common/utils/config"
	"jd.com/jvirt/jvirt-common/utils/log"
)

type JksApiClient struct {
	Logger log.Logger
	Client api.InnerApi
}

func NewJksApiClient(log log.Logger, c *config.JksApiConfig) (*JksApiClient, error) {
	client := api.NewJksInnerApiClient(c, log)

	return &JksApiClient{
		Client: client,
		Logger: log,
	}, nil
}

func (p *JksApiClient) UpdateTask(task *api.UpdateTaskRequest, retry int) error {
	i := 0
	taskId := task.TaskId

	for ; i < retry; i++ {
		if jErr := p.Client.UpdateTask(task); jErr != nil {
			p.Logger.Warn("Invoke jks-api.UpdateTask failed. TaskId: %d, Error: %s, Detail: %s.",
				taskId, jErr.Error(), jErr.Detail())
		} else {
			p.Logger.Info("Invoke jks-api.UpdateTask success. TaskId: %d.", taskId)
			break
		}
	}

	if i >= retry {
		p.Logger.Error("Invoke jks-api.UpdateTask failed. TaskId: %d.", taskId)
		return errors.New("invoke jks-api UpdateTask failed")
	}

	return nil
}

func (p *JksApiClient) ListPodsByHostIp(hostIp string) ([]*jks.Pod, error) {
	request := &api.GetPodsRequest{
		HostIP: hostIp,
	}

	resp, jErr := p.Client.GetPods(request)
	if jErr != nil {
		p.Logger.Error("Invoke jks-api.GetPods failed. Error: %s, Detail: %s.", jErr.Error(), jErr.Detail())
		return nil, jErr
	}

	if resp == nil {
		return nil, nil
	}

	return resp.Items, nil
}

func (p *JksApiClient) GetPodById(podId, hostIp string) (*jks.Pod, error) {
	request := &api.GetPodsRequest{
		PodId:  podId,
		HostIP: hostIp,
	}
	resp, jErr := p.Client.GetPods(request)
	if jErr != nil {
		p.Logger.Error("Invoke jks-api.GetPods failed. PodId: %s, Error: %s, Detail: %s.",
			podId, jErr.Error(), jErr.Detail())
		return nil, jErr
	}
	if resp == nil || len(resp.Items) == 0 {
		p.Logger.Error("The pod [%s] is not exist.", podId)
		return nil, errors.New("pod not found")
	}

	return resp.Items[0], nil
}

// 获取已经删除的Pod详细信息
func (p *JksApiClient) GetRecordPodById(podId string) (*jks.Pod, error) {
	request := &api.GetRecordPodRequest{
		PodId:  podId,
	}
	resp, jErr := p.Client.GetRecordPod(request)
	if jErr != nil {
		p.Logger.Error("Invoke jks-api.GetRecordPodById failed. PodId: %s, Error: %s, Detail: %s.",
			podId, jErr.Error(), jErr.Detail())
		return nil, jErr
	}
	if resp == nil {
		p.Logger.Error("The pod [%s] is not exist.", podId)
		return nil, errors.New("pod not found")
	}
	
	return resp, nil
}

func (p *JksApiClient) GetContainerImage(podId, containerName string) (*api.GetContainerImageResp, error) {
	request := &api.GetContainerImageRequest{
		PodId:         podId,
		ContainerName: containerName,
	}

	resp, jErr := p.Client.GetContainerImage(request)
	if jErr != nil {
		p.Logger.Error("Invoke jks-api.GetContainerImage failed. PodId: %s, ContainerName: %s, Error: %s, Detail: %s.",
			podId, containerName, jErr.Error(), jErr.Detail())
		return nil, jErr
	}
	if resp == nil {
		msg := fmt.Sprintf("image is not found. PodId: %s, ContainerName: %s", podId, containerName)
		p.Logger.Error(msg)
		return nil, errors.New(msg)
	}

	return resp, nil
}
