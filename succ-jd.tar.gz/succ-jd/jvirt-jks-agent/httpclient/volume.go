package httpclient

import (
	"errors"
	"fmt"
	"strings"
	"time"

	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/integration/volume"
	outer "jd.com/jvirt/jvirt-common/integration/volume/model"
	"jd.com/jvirt/jvirt-common/utils/config"
	"jd.com/jvirt/jvirt-common/utils/golocal"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/retry"
	"jd.com/jvirt/jvirt-common/utils/url"
	"jd.com/jvirt/jvirt-jks-agent/model"
	"jd.com/jvirt/jvirt-jks-agent/utils"
)

const (
	InstanceUUID     = "instance_uuid"
	VolumeId         = "volume_id"
	HostIP           = "host_ip"
	AttachmentStatus = "status"
	AttachModeRW     = "rw"
)

type VolumeClient struct {
	Client volume.IVolumeManager
	Logger log.Logger
}

func NewVolumeClient(log log.Logger, c *config.Volume) (*VolumeClient, error) {

	httpCfg := &config.HttpClient{
		ConnectTimeout:        c.ConnectTimeout,
		MaxIdleConns:          c.MaxIdleConns,
		TimerInterval:         c.TimerInterval,
		ResponseHeaderTimeout: c.ResponseHeaderTimeout,
		RequestTotalTimeout:   c.RequestTotalTimeout,
	}

	hc := url.NewClient(httpCfg, log)

	client := volume.NewDefaultVolumeManager(hc, c, log)

	return &VolumeClient{
		Client: client,
		Logger: log,
	}, nil
}

func (p *VolumeClient) detachVolume(tenantId, volumeId, attachId string) (*outer.AttachmentView, error) {
	params := &outer.DetachVolumeParams{
		TenantId:     tenantId,
		VolumeId:     volumeId,
		AttachmentId: attachId,
	}

	volumeView, err := p.Client.DetachVolume(params)
	if err != nil {
		p.Logger.Error("[detachVolume] failed. Params: %s, Error: %s.", *params, err.Error())
		return nil, err
	}

	return volumeView, nil
}

func (p *VolumeClient) describeAttachment(tenantId, attachId string) (*outer.AttachmentView, error) {
	params := &outer.DescribeAttachmentParams{
		Id:       attachId,
		TenantId: tenantId,
	}

	attachView, err := p.Client.DescribeAttachment(params)
	if err != nil {
		p.Logger.Error("[DescribeVolume] failed. Params: %s, Error: %s.", *params, err.Error())
		return nil, err
	}
	if attachView == nil {
		msg := fmt.Sprintf("attachment %s not found", attachId)
		p.Logger.Error(msg)
		return nil, errors.New(msg)
	}

	return attachView, nil
}

func (p *VolumeClient) listAttachments(tenantId string, filters map[string]interface{}) (*outer.ListAttachmentsView, error) {
	params := &outer.ListAttachmentsParams{
		TenantId:  tenantId,
		DescLimit: -1,
		Filter:    make([]*outer.FilterItem, 0),
	}

	for k, v := range filters {
		filterP := &outer.FilterItem{Field: k, Value: v}
		params.Filter = append(params.Filter, filterP)
	}

	attachViews, err := p.Client.ListAttachments(params)
	if err != nil {
		p.Logger.Error("[listAttachments] failed. Params: %s, Error: %s.", *params, err.Error())
		return nil, err
	}

	if attachViews == nil || attachViews.Data == nil {
		p.Logger.Error("listAttachments failed. Result is nil")
		return nil, errors.New("list attachments failed. response is nil")
	}

	return attachViews, nil
}

func (p *VolumeClient) AttachVolume(tenantId, hostIp, volumeId, instanceId, instanceType string, failOver bool) (string, error) {

	params := &outer.AttachVolumeParams{
		TenantId:        tenantId,
		VolumeId:        volumeId,
		InstanceUuid:    instanceId,
		HostIp:          hostIp,
		MultiAttachment: true,
		AttachMode:      AttachModeRW,
		InstanceType:    instanceType,
		FailOver:        failOver,
	}

	volumeView, err := p.Client.AttachVolume(params)
	if err != nil {
		p.Logger.Error("[AttachVolume] failed. Params: %s, Error: %s.", *params, err.Error())
		return "", err
	}
	if volumeView == nil || volumeView.Data == nil {
		p.Logger.Error("[AttachVolume] failed. Params: %s, Result is nil", *params)
		return "", errors.New("Result is nil ")
	}

	return volumeView.Data.Id, nil
}

func (p *VolumeClient) DescribeVolume(tenantId, volumeId string) (*outer.VolumeView, error) {
	params := &outer.DescribeVolumeParams{
		Id:       volumeId,
		TenantId: tenantId,
	}

	volumeView, err := p.Client.DescribeVolume(params)
	if err != nil {
		p.Logger.Error("[DescribeVolume] failed. Params: %s, Error: %s.", *params, err.Error())
		return nil, err
	}
	if volumeView == nil {
		msg := fmt.Sprintf("DescribeVolume return nil, volumeId %s", volumeId)
		p.Logger.Error(msg)
		return nil, errors.New(msg)
	}

	return volumeView, nil
}

func (p *VolumeClient) detachVolumeByConditions(tenantId string, filters map[string]interface{}) error {
	var detachErr error

	filters[AttachmentStatus] = volume.ATTACHMENT_ATTACHED + "|" + volume.ATTACHMENT_ERROR_DETACH + "|" + volume.ATTACHMENT_ATTACHING

	attachments, err := p.listAttachments(tenantId, filters)
	if err != nil {
		p.Logger.Error("[detachVolumeByConditions] listAttachments failed. Error: %s.", err.Error())
		return err
	}

	for _, attach := range attachments.Data.Elements {
		attachId := attach.Id
		volId := attach.VolumeId
		_, err := p.detachVolume(tenantId, volId, attachId)
		if err != nil {
			p.Logger.Error("[detachVolumeByConditions] Detach volume [%s] failed. AttachId: %s, Error: %s.",
				volId, attachId, err.Error())
			detachErr = err
		}

		if err := p.waitVolumeDetached(tenantId, attachId, 300); err != nil {
			p.Logger.Error("[detachVolumeByConditions] waitVolumeDetached [%s] failed. AttachId: %s, Error: %s.",
				volId, attachId, err.Error())
			detachErr = err
		}
	}

	return detachErr
}

func (p *VolumeClient) waitVolumeActionNone(tenantId, volId string, timeout int) (string, error) {
	volStatus := ""
	f := func() error {
		volumeView, err := p.DescribeVolume(tenantId, volId)
		if err != nil {
			p.Logger.Error("[waitVolumeActionNone] DescribeVolume [%s] failed. Error: %s", volId, err.Error())
			return err
		}

		volStatus = volumeView.Data.Status
		action := volumeView.Data.Action
		msg := fmt.Sprintf("waitVolumeActionNone volume.Id is %s, volume.Status is %s, volume.Action is %s", volId, volStatus, action)
		p.Logger.Info(msg)
		if action == "" {
			return nil
		}

		return errors.New(msg)
	}

	if err := retry.Retry(f, timeout, 2*time.Second); err != nil {
		return "", err
	}

	return volStatus, nil
}

func (p *VolumeClient) waitVolumeExtended(tenantId, volId string, timeout int) (string, error) {
	volStatus := ""
	f := func() error {
		volumeView, err := p.DescribeVolume(tenantId, volId)
		if err != nil {
			p.Logger.Error("[waitVolumeExtended] DescribeVolume [%s] failed. Error: %s", volId, err.Error())
			return err
		}

		volStatus = volumeView.Data.Status
		action := volumeView.Data.Action
		msg := fmt.Sprintf("waitVolumeExtended volume.Id is %s, volume.Status is %s, volume.Action is %s", volId, volStatus, action)
		p.Logger.Info(msg)
		if action == "" && volStatus == volume.VOLUME_AVAILABLE{
			return nil
		}

		return errors.New(msg)
	}

	if err := retry.Retry(f, timeout, 2*time.Second); err != nil {
		return "", err
	}

	return volStatus, nil
}

func (p *VolumeClient) waitVolumeAttached(tenantId, instId, hostIp, volId string, retryTimes int) error {

	f := func() error {
		filters := make(map[string]interface{})
		filters[VolumeId] = volId
		filters[HostIP] = hostIp
		filters[InstanceUUID] = instId
		filters[AttachmentStatus] = volume.ATTACHMENT_ATTACHED

		ret, err := p.listAttachments(tenantId, filters)
		if err != nil {
			p.Logger.Warn("[waitVolumeAttached] listAttachments failed. Error: %s.", err.Error())
			return err
		}
		n := len(ret.Data.Elements)
		if n < 1 {
			p.Logger.Warn("Volume [%s] doesn't attach with the pod [%s] of host [%s].", volId, instId, hostIp)
			return errors.New("volume doesn't attach with the pod")
		} else if n > 1 {
			p.Logger.Warn("Volume [%s] repeats attachment to the pod [%s] of host [%s].", volId, instId, hostIp)
			return errors.New("volume repeats attachment to the pod")
		}

		return nil
	}

	if err := retry.Retry(f, retryTimes, 2*time.Second); err != nil {
		p.Logger.Error("[waitVolumeAttached] failed. PodId: %s, VolumeId: %s, Error: %s.",
			instId, volId, err.Error())
		return err
	}

	return nil
}

/**
检查云盘是否卸载成功
*/
func (p *VolumeClient) waitVolumeDetached(tenantId, attachId string, timeout int) error {

	f := func() error {
		ret, err := p.describeAttachment(tenantId, attachId)
		if err != nil {
			p.Logger.Warn("[waitVolumeDetached] listAttachments failed. AttachId: %s, Error: %s.", attachId, err.Error())
			return err
		}

		status := ret.Data.Status
		msg := fmt.Sprintf("waitVolumeDetached attachId: %s, attachStatus: %s", attachId, status)
		p.Logger.Info(msg)
		if status == volume.ATTACHMENT_DETACHED {
			return nil
		}

		return errors.New(msg)
	}

	if err := retry.Retry(f, timeout, 1*time.Second); err != nil {
		p.Logger.Error("[waitVolumeDetached] failed. AttachId: %s, Error: %s.", attachId, err.Error())
		return err
	}

	return nil
}

func (p *VolumeClient) detachVolumeByVolId(tenantId, instId, hostIp, volId string) error {
	p.Logger.Debug("Detach volume %s for pod %s on the host %s.", volId, instId, hostIp)

	// 检查volume是否有action 如果有等action结束
	_, err := p.waitVolumeActionNone(tenantId, volId, 60)
	if err != nil {
		return err
	}

	filters := make(map[string]interface{})
	filters[VolumeId] = volId
	filters[InstanceUUID] = instId
	filters[HostIP] = hostIp
	if err := p.detachVolumeByConditions(tenantId, filters); err != nil {
		return err
	}

	return nil
}

func (p *VolumeClient) checkVolumeStatus(tenantId, volId string, targetStatus []string, retryTimes int) (string, error) {

	var (
		volStatus string
		volAction string
	)

	volumeView, err := p.DescribeVolume(tenantId, volId)
	if err != nil {
		p.Logger.Error("[checkVolumeStatus] DescribeVolume [%s] failed. Error: %s", volId, err.Error())
		return "", err
	}
	volStatus = volumeView.Data.Status
	volAction = volumeView.Data.Action
	p.Logger.Info("[checkVolumeStatus] The [%s] volume.Status is %s, volume.Action is %s", volId, volStatus, volAction)
	if strings.Contains(volStatus, "error_") || volStatus == volume.VOLUME_DELETED {
		errMsg := "volume is " + volStatus + ", no support attach"
		return "", errors.New(errMsg)
	}

	f := func() error {
		volumeView, err := p.DescribeVolume(tenantId, volId)
		if err != nil {
			p.Logger.Error("[checkVolumeStatus] DescribeVolume [%s] failed. Error: %s", volId, err.Error())
			return err
		}

		volStatus = volumeView.Data.Status
		volAction = volumeView.Data.Action
		msg := fmt.Sprintf("checkVolumeStatus volume.Id is %s, volume.Status is %s, volume.Action is %s", volId, volStatus, volAction)
		p.Logger.Info(msg)

		if volAction != "" {
			return errors.New(msg)
		}

		for _, item := range targetStatus {
			if volStatus == item {
				return nil
			}
		}

		return errors.New(msg)
	}

	if err := retry.Retry(f, retryTimes, 2*time.Second); err != nil {
		return "", err
	}

	return volStatus, nil
}

/*
1. 首先清理这个盘和此实例在其他计算节点上的挂载记录;
2. 然后将盘在当前计算节点上建立绑定关系.
*/
func (p *VolumeClient) createPodAttach(tenantId, instId, hostIp, volId, resourceType string) error {
	targetStatus := []string{volume.VOLUME_AVAILABLE, volume.VOLUME_IN_USE}
	volStatus, err := p.checkVolumeStatus(tenantId, volId, targetStatus, 60)
	if err != nil {
		p.Logger.Error("[createPodAttach] checkVolumeStatus failed. PodId: %s, VodId: %s, Error: %s", instId, volId, err.Error())
		return err
	}

	if volStatus == volume.VOLUME_IN_USE {
		// 将云盘-主机错误的挂载记录卸载
		conditions := make(map[string]interface{})
		conditions[InstanceUUID] = instId
		conditions[VolumeId] = volId
		if err := p.detachVolumeByConditions(tenantId, conditions); err != nil {
			p.Logger.Error("Invoke detachVolumeByConditions failed. Error: %#v.", err)
			return err
		}

		if _, err := p.checkVolumeStatus(tenantId, volId, targetStatus, 60); err != nil {
			p.Logger.Error("Invoke waitVolumeAvailable failed. Error: %#v.", err)
			return err
		}
	}

	if _, err := p.AttachVolume(tenantId, hostIp, volId, instId, resourceType, false); err != nil {
		p.Logger.Error("Invoke AttachVolume failed. Error: %#v.", err)
		return err
	}

	return nil
}

func (p *VolumeClient) startPodAttach(tenantId, instId, hostIp, volId, resourceType string) error {
	targetStatus := []string{volume.VOLUME_AVAILABLE, volume.VOLUME_IN_USE}
	volStatus, err := p.checkVolumeStatus(tenantId, volId, targetStatus, 60)
	if err != nil {
		p.Logger.Error("[startPodAttach] checkVolumeStatus failed. PodId: %s, VodId: %s, Error: %s", instId, volId, err.Error())
		return err
	}

	if volStatus == volume.VOLUME_IN_USE {
		filters := make(map[string]interface{})
		filters[InstanceUUID] = instId
		filters[VolumeId] = volId
		filters[HostIP] = hostIp
		filters[AttachmentStatus] = volume.ATTACHMENT_ATTACHED + "|" + volume.ATTACHMENT_ATTACHING

		ret, err := p.listAttachments(tenantId, filters)
		if err != nil {
			p.Logger.Warn("listAttachments failed. Error: %s.", err.Error())
			return err
		}
		if ret.Data.TotalCount == 1 {
			p.Logger.Debug("Volume %s has attached to sync %s of host %s.", volId, instId, hostIp)
			return nil
		}
	}

	if _, err := p.AttachVolume(tenantId, hostIp, volId, instId, resourceType, false); err != nil {
		p.Logger.Error("Invoke AttachVolume failed. Error: %#v.", err)
		return err
	}

	return nil
}

/*
1. 不需要卸载source host挂载记录.
2. 挂载时, 已failover的方式挂载.
*/
func (p *VolumeClient) migratePodAttach(tenantId, instId, hostIp, volId, resourceType string) error {
	targetStatus := []string{volume.VOLUME_AVAILABLE, volume.VOLUME_IN_USE}
	volStatus, err := p.checkVolumeStatus(tenantId, volId, targetStatus, 60)
	if err != nil {
		p.Logger.Error("[migratePodAttach] checkVolumeStatus failed. PodId: %s, VodId: %s, Error: %s", instId, volId, err.Error())
		return err
	}

	if volStatus == volume.VOLUME_IN_USE {
		filters := make(map[string]interface{})
		filters[InstanceUUID] = instId
		filters[VolumeId] = volId
		filters[HostIP] = hostIp
		filters[AttachmentStatus] = volume.ATTACHMENT_ATTACHED + "|" + volume.ATTACHMENT_ATTACHING

		ret, err := p.listAttachments(tenantId, filters)
		if err != nil {
			p.Logger.Warn("listAttachments failed. Error: %s.", err.Error())
			return err
		}
		if ret.Data.TotalCount == 1 {
			p.Logger.Debug("Volume %s has attached to sync %s of host %s.", volId, instId, hostIp)
			return nil
		}
	}

	if _, err := p.AttachVolume(tenantId, hostIp, volId, instId, resourceType, true); err != nil {
		p.Logger.Error("Invoke AttachVolume failed. Error: %#v.", err)
		return err
	}

	return nil
}

func (p *VolumeClient) AttachVolumesToPod(taskType string, pod *model.Pod) error {
	hostIp := pod.HostIP
	userId := pod.UserId
	podId := pod.PodId
	resType := pod.ResourceType

	var f func(tenantId, instId, hostIp, volId, resourceType string) error

	switch taskType {
	case jks.PodCreateTask:
		f = p.createPodAttach
	case jks.PodMigrateTask:
		f = p.migratePodAttach
	case jks.PodStartTask, jks.PodRebuildTask, jks.PodExtendVolumeTask:
		f = p.startPodAttach
	default:
		return errors.New("task type not support")
	}

	for _, item := range pod.GetAllVolume() {
		volId := item.VolumeId
		p.Logger.Debug("[AttachVolumesToPod] PodId: %s, VolumeId: %s", podId, volId)
		if err := f(userId, podId, hostIp, volId, resType); err != nil {
			p.Logger.Error("[AttachVolumesToPod] volumeAttach failed. VolumeId: %s, Error: %s.", volId, err.Error())
			return err
		}
	}

	return nil
}

func (p *VolumeClient) DetachVolumesFromPod(pod *model.Pod) error {
	hostIp := pod.HostIP
	userId := pod.UserId
	podId := pod.PodId

	funcs := make([]func() (interface{}, error), 0)
	goValue := golocal.GoContext.Get()

	for _, item := range pod.GetAllVolume() {
		volId := item.VolumeId
		p.Logger.Debug("[DetachVolumeFromPod] PodId: %s, VolumeId: %s", podId, volId)

		funcs = append(funcs, func() (interface{}, error) {
			defer func() {
				golocal.GoContext.Remove()
			}()
			golocal.GoContext.Put(goValue)

			if err := p.detachVolumeByVolId(userId, podId, hostIp, volId); err != nil {
				p.Logger.Error("[DetachVolumeFromPod] detachVolumeByVolId failed. VolumeId: %s, Error: %s.", volId, err.Error())
				return err, nil
			}
			return nil, nil
		})
	}

	if err := utils.PromiseWhenAll(funcs...); err != nil {
		p.Logger.Error("[DetachVolumeFromPod] utils.PromiseWhenAll failed. Error: %s.", err.Error())
		return err
	}

	return nil
}

func (p *VolumeClient) CheckPodVolumesAttached(pod *model.Pod) error {
	userId := pod.UserId
	podId := pod.PodId
	hostIp := pod.HostIP

	funcs := make([]func() (interface{}, error), 0)
	goValue := golocal.GoContext.Get()

	for _, item := range pod.GetAllVolume() {
		volId := item.VolumeId
		p.Logger.Debug("[CheckPodVolumesAttached] PodId: %s, VolumeId: %s", podId, volId)

		funcs = append(funcs, func() (interface{}, error) {
			defer func() {
				golocal.GoContext.Remove()
			}()
			golocal.GoContext.Put(goValue)

			if err := p.waitVolumeAttached(userId, podId, hostIp, volId, 20); err != nil {
				p.Logger.Error("[CheckPodVolumesAttached] waitVolumeAttached failed. VolumeId: %s, Error: %s", volId, err.Error())
				return err, nil
			}

			return nil, nil
		})
	}

	if err := utils.PromiseWhenAll(funcs...); err != nil {
		p.Logger.Error("[CheckPodVolumesAttached] utils.PromiseWhenAll failed. Error: %s.", err.Error())
		return err
	}

	return nil
}

func (p *VolumeClient) DetachVolumesFromPodById(volId string, pod *model.Pod) error {
	hostIp := pod.HostIP
	userId := pod.UserId
	podId := pod.PodId
	if err := p.detachVolumeByVolId(userId, podId, hostIp, volId); err != nil {
		p.Logger.Error("[DetachVolumeFromPod] detachVolumeByVolId failed. VolumeId: %s, Error: %s.", volId, err.Error())
		return err
	}
	return nil
}

func (p *VolumeClient) ExtendVolume(volumeId string, size int, pod *model.Pod) error {
	// 检查volume是否有action 如果有等action结束
	_, err := p.waitVolumeActionNone(pod.UserId, volumeId, 60)
	if err != nil {
		return err
	}

	params := &outer.ResizeVolumeParams{
		TenantId: pod.UserId,
		Id:       volumeId,
		Size:     size,
	}
	vol, err := p.Client.ResizeVolume(params)
	if err != nil {
		p.Logger.Error("[ExtendVolumeFromPodById] failed. Params: %s, Error: %s.", *params, err.Error())
		return err
	}
	NewVolId := vol.Data.Id
	if _, err := p.waitVolumeExtended(pod.UserId, NewVolId, 300); err != nil {
		p.Logger.Error("[ExtendVolume] waitVolumeExtended [%s] failed. NewVolId: %s, Error: %s.",
			pod.PodId, NewVolId, err.Error())
		return err
	}
	return nil
}
func (p *VolumeClient) AttachExtendVolume(volumeId string, pod *model.Pod) error {
	_, err := p.AttachVolume(pod.UserId, pod.HostIP, volumeId, pod.PodId, pod.InstanceType, false)
	if err != nil {
		p.Logger.Error("[AttachExtendVolume] Invoke VolClient AttachVolume [%v] failed.  Error: %s.", pod.PodId, err.Error())
		return err
	}
	if err := p.waitVolumeAttached(pod.UserId, pod.PodId, pod.HostIP, volumeId, 300); err != nil {
		p.Logger.Error("[AttachExtendVolume] waitVolumeAttached [%s] failed. NewVolId: %s, Error: %s.",
			pod.PodId, volumeId, err.Error())
		return err
	}
	return nil
}
