package httpclient

import (
	"path"
	"strings"

	"jd.com/jvirt/jvirt-common/integration/registry"
	"jd.com/jvirt/jvirt-common/integration/registry/tarexport"
	v2 "jd.com/jvirt/jvirt-common/integration/registry/v2"
	"jd.com/jvirt/jvirt-common/utils/golocal"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jks-agent/constant"
	"jd.com/jvirt/jvirt-jks-agent/em"
	"jd.com/jvirt/jvirt-jks-agent/model"
	"jd.com/jvirt/jvirt-jks-agent/utils"
)

type ImageRegistryClient struct {
	Logger       log.Logger
	Client       *v2.RegClientV2
	EventHandler *em.EventManagerService `inject:""`
}

func NewImageRegistryClient(l log.Logger) (*ImageRegistryClient, error) {
	v2Client := v2.New(l)

	return &ImageRegistryClient{
		Client: v2Client,
		Logger: l,
	}, nil
}

func (p *ImageRegistryClient) DownloadImages(podId string, containers []*model.Container) error {
	funcs := make([]func() (interface{}, error), 0)
	digestMap := make(map[string]bool)
	goValue := golocal.GoContext.Get()

	for _, item := range containers {
		imageInfo := item.ImageInfo
		imageName := imageInfo.ImageName
		imageDigest := imageInfo.ImageDigest

		if _, ok := digestMap[imageDigest]; ok {
			continue
		}
		digestMap[imageDigest] = true

		reqParams := &registry.RegistryConfig{
			Server:    imageInfo.RegistryUrl,
			User:      imageInfo.RegistryUsername,
			Password:  imageInfo.RegistryPassword,
			HttpProxy: imageInfo.HttpProxy,
		}
		downloadPath := imageInfo.DownloadPath

		p.Logger.Debug("[image.Download] params: %+v.", *reqParams)

		if err := utils.CreateDir(downloadPath, 0775); err != nil && !strings.Contains(err.Error(), "file exists") {
			p.Logger.Error("[image.Download] mkdir failed. Error: %s", err.Error())
			return err
		}

		funcs = append(funcs, func() (interface{}, error) {
			defer func() {
				p.EventHandler.EmitExecuteTimeEvent(podId, "ImageRegistryClient.DownloadImages", constant.FinishedStage, true)
				golocal.GoContext.Remove()
			}()
			golocal.GoContext.Put(goValue)
			p.EventHandler.EmitExecuteTimeEvent(podId, "ImageRegistryClient.DownloadImages", constant.StartStage, false)
			if err := p.Client.Download(imageName, imageDigest, downloadPath, reqParams); err != nil {
				p.Logger.Error("[image.Download] Download image failed. Error: %s", err.Error())
				return err, nil
			}
			return nil, nil
		})
	}

	if err := utils.PromiseWhenAll(funcs...); err != nil {
		p.Logger.Error("[image.Download] utils.PromiseWhenAll failed. Error: %s.", err.Error())
		return err
	}

	return nil
}

func (p *ImageRegistryClient) loadImageToSystemDisk(podPath string, sysDisk *model.CloudDisk, imageInfo *model.ImageInfo) error {
	// 系统盘必须格式化
	devicePath := sysDisk.DevicePath
	fsType := sysDisk.FsType
	imagePath := imageInfo.DownloadPath

	p.EventHandler.EmitExecuteTimeEvent(podPath, "ImageRegistryClient.loadImageToSystemDisk", constant.StartStage, false)
	defer p.EventHandler.EmitExecuteTimeEvent(podPath, "ImageRegistryClient.loadImageToSystemDisk", constant.FinishedStage, true)

	if out, err := utils.MakeFileSystem(devicePath, fsType); err != nil {
		p.Logger.Error("[loadImageToSystemDisk] MakeFileSystem %s %s failed. Output: %s, Error: %s", devicePath, fsType, out, err.Error())
		return err
	}
	p.EventHandler.EmitExecuteTimeEvent(podPath, "ImageRegistryClient.loadImageToSystemDisk", "MakeFileSystem", false)

	// 创建临时目录
	mntDir := path.Join(podPath, sysDisk.VolumeId)
	if err := utils.CreateDir(mntDir, 0755); err != nil {
		p.Logger.Error("[loadImageToSystemDisk] Create %s directory failed. Error: %s.", mntDir, err.Error())
		return err
	}
	p.EventHandler.EmitExecuteTimeEvent(podPath, "ImageRegistryClient.loadImageToSystemDisk", "CreateDir.mntDir", false)
	defer utils.RemoveDir(mntDir)

	// 挂载volume
	if err := utils.MountFS(devicePath, mntDir, fsType); err != nil {
		p.Logger.Error("[loadImageToSystemDisk] MountFS -t %s %s %s error %s", fsType, devicePath, mntDir, err.Error())
		return err
	}
	p.EventHandler.EmitExecuteTimeEvent(podPath, "ImageRegistryClient.loadImageToSystemDisk", "MountFS", false)
	defer utils.UMountFS(mntDir)

	// 创建RootFs目录
	rootFsDir := path.Join(mntDir, "rootfs")
	if err := utils.CreateDir(rootFsDir, 0755); err != nil {
		p.Logger.Error("[loadImageToSystemDisk] Create %s directory failed. Error: %s.", rootFsDir, err.Error())
		return err
	}
	p.EventHandler.EmitExecuteTimeEvent(podPath, "ImageRegistryClient.loadImageToSystemDisk", "CreateDir.rootFsDir", false)

	// 解压镜像到volume
	log.Debug("[loadImageToSystemDisk] from %s load image data to %s", imagePath, rootFsDir)

	tarExporter := tarexport.NewTarExporter()
	_, err := tarExporter.LoadTar(imagePath, rootFsDir)
	if err != nil {
		p.Logger.Error("[CheckImage] tarExporter LoadTar failed. Error: %+v.", err)
		return err
	}
	p.EventHandler.EmitExecuteTimeEvent(podPath, "ImageRegistryClient.loadImageToSystemDisk", "tarExporter.LoadTar", false)

	return nil
}

func (p *ImageRegistryClient) LoadImagesToPod(podPath string, containers []*model.Container) error {

	funcs := make([]func() (interface{}, error), 0)
	goValue := golocal.GoContext.Get()

	for _, item := range containers {
		imageInfo := item.ImageInfo
		sysDisk := item.SystemDisk
		funcs = append(funcs, func() (interface{}, error) {
			defer func() {
				golocal.GoContext.Remove()
			}()
			golocal.GoContext.Put(goValue)

			if err := p.loadImageToSystemDisk(podPath, sysDisk, imageInfo); err != nil {
				p.Logger.Error("[image.LoadImagesToPod] loadImageToSystemDisk failed. Error: %s", err.Error())
				return err, nil
			}

			return nil, nil
		})
	}

	if err := utils.PromiseWhenAll(funcs...); err != nil {
		p.Logger.Error("[image.LoadImagesToPod] utils.PromiseWhenAll failed. Error: %s.", err.Error())
		return err
	}

	return nil

}
