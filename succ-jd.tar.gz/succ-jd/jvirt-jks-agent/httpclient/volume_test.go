package httpclient

import (
	"encoding/json"
	"fmt"
	"testing"

	"jd.com/jvirt/jvirt-common/utils/config"
	"jd.com/jvirt/jvirt-jks-agent/model"
)

func getVolumeClient() (*VolumeClient, error) {
	volumeConfig := &config.Volume{
		Url: "http://10.226.134.2:80",
	}
	logger, err := initLoggers("./tmp/network_test.log")
	if err != nil {
		return nil, err
	}
	client, err := NewVolumeClient(logger, volumeConfig)
	if err != nil {
		return nil, err
	}
	return client, nil
}

func TestVolumeClient_AttachVolume(t *testing.T) {
	fmt.Println("TestVolumeClient_AttachVolume Start")

	client, err := getVolumeClient()
	if err != nil {
		fmt.Println("[TestVolumeClient_AttachVolume] getVolumeClient faild. Error:", err.Error())
		t.Errorf("[TestVolumeClient_AttachVolume] getVolumeClient faild. Error:%s", err.Error())
		return
	}
	if res, err := client.AttachVolume("", "", "", "", "", false); err != nil {
		fmt.Println("[TestVolumeClient_AttachVolume] AttachVolume faild. Error:", err.Error())
		t.Errorf("[TestVolumeClient_AttachVolume] AttachVolume faild. Error:%s", err.Error())
		return
	} else {
		fmt.Println("[TestVolumeClient_AttachVolume] Result is ", res)
		fmt.Println("Success")
	}
}

func TestVolumeClient_CheckPodVolumesAttached(t *testing.T) {
	fmt.Println("TestVolumeClient_CheckPodVolumesAttached Start")

	client, err := getVolumeClient()
	if err != nil {
		fmt.Println("[TestVolumeClient_CheckPodVolumesAttached] getVolumeClient faild. Error:", err.Error())
		t.Errorf("[TestVolumeClient_CheckPodVolumesAttached] getVolumeClient faild. Error:%s", err.Error())
		return
	}
	pod := &model.Pod{
		PodId:  "",
		UserId: "",
		HostIP: "",
		Volumes: []*model.Volume{
			&model.Volume{
				Name: "",
				JDCloudDisk: &model.CloudDisk{
					VolumeId: "",
				},
			},
		},
	}
	if err := client.CheckPodVolumesAttached(pod); err != nil {
		fmt.Println("[TestVolumeClient_CheckPodVolumesAttached] CheckPodVolumesAttached faild. Error:", err.Error())
		t.Errorf("[TestVolumeClient_CheckPodVolumesAttached] CheckPodVolumesAttached faild. Error:%s", err.Error())
		return
	} else {
		fmt.Println("Success")
	}
}

// case1: 查询不存在的云盘
// result1: volume.notfound:the volume is not exist
func TestVolumeClient_DescribeVolume(t *testing.T) {
	fmt.Println("TestVolumeClient_DescribeVolume Start")

	client, err := getVolumeClient()
	if err != nil {
		fmt.Println("[TestVolumeClient_DescribeVolume] getVolumeClient faild. Error:", err.Error())
		t.Errorf("[TestVolumeClient_DescribeVolume] getVolumeClient faild. Error:%s", err.Error())
		return
	}
	if res, err := client.DescribeVolume("3js9d203jdkalf3df32", "vol-wjy"); err != nil {
		fmt.Println("[TestVolumeClient_DescribeVolume] DescribeVolume faild. Error:", err.Error())
		t.Errorf("[TestVolumeClient_DescribeVolume] DescribeVolume faild. Error:%s", err.Error())
		return
	} else {
		result, err := json.Marshal(res)
		if err != nil {
			fmt.Println("[TestVolumeClient_DescribeVolume] DescribeVolume faild. Error:", err.Error())
			return
		}
		fmt.Println("[TestVolumeClient_DescribeVolume] Result is ", result)
		fmt.Println("Success")
	}
}

func TestVolumeClient_DetachVolumesFromPod(t *testing.T) {
	fmt.Println("TestVolumeClient_DetachVolumesFromPod Start")

	client, err := getVolumeClient()
	if err != nil {
		fmt.Println("[TestVolumeClient_DetachVolumesFromPod] getVolumeClient faild. Error:", err.Error())
		t.Errorf("[TestVolumeClient_DetachVolumesFromPod] getVolumeClient faild. Error:%s", err.Error())
		return
	}
	pod := &model.Pod{
		PodId:  "",
		UserId: "",
		HostIP: "",
		Volumes: []*model.Volume{
			&model.Volume{
				Name: "",
				JDCloudDisk: &model.CloudDisk{
					VolumeId: "",
				},
			},
		},
	}
	if err := client.DetachVolumesFromPod(pod); err != nil {
		fmt.Println("[TestVolumeClient_DetachVolumesFromPod] DetachVolumesFromPod faild. Error:", err.Error())
		t.Errorf("[TestVolumeClient_DetachVolumesFromPod] DetachVolumesFromPod faild. Error:%s", err.Error())
		return
	} else {
		fmt.Println("Success")
	}
}

func TestVolumeClient_AttachVolumesToPod(t *testing.T) {
	fmt.Println("TestVolumeClient_AttachVolumesToPod Start")

	client, err := getVolumeClient()
	if err != nil {
		fmt.Println("[TestVolumeClient_AttachVolumesToPod] getVolumeClient faild. Error:", err.Error())
		t.Errorf("[TestVolumeClient_AttachVolumesToPod] getVolumeClient faild. Error:%s", err.Error())
		return
	}
	pod := &model.Pod{
		PodId:  "",
		UserId: "",
		HostIP: "",
		Volumes: []*model.Volume{
			&model.Volume{
				Name: "",
				JDCloudDisk: &model.CloudDisk{
					VolumeId: "",
				},
			},
		},
	}
	if err := client.DetachVolumesFromPod(pod); err != nil {
		fmt.Println("[TestVolumeClient_AttachVolumesToPod] DetachVolumesFromPod faild. Error:", err.Error())
		t.Errorf("[TestVolumeClient_AttachVolumesToPod] DetachVolumesFromPod faild. Error:%s", err.Error())
		return
	} else {
		fmt.Println("Success")
	}
}

func TestVolumeClient_MigrateAttach(t *testing.T) {
	fmt.Println("TestVolumeClient_AttachVolumesToPod Start")

	client, err := getVolumeClient()
	if err != nil {
		fmt.Println("[TestVolumeClient_AttachVolumesToPod] getVolumeClient faild. Error:", err.Error())
		t.Errorf("[TestVolumeClient_AttachVolumesToPod] getVolumeClient faild. Error:%s", err.Error())
		return
	}

	if err := client.MigrateAttach("", "", "", ""); err != nil {
		fmt.Println("[TestVolumeClient_AttachVolumesToPod] DetachVolumesFromPod faild. Error:", err.Error())
		t.Errorf("[TestVolumeClient_AttachVolumesToPod] DetachVolumesFromPod faild. Error:%s", err.Error())
		return
	} else {
		fmt.Println("Success")
	}
}

// TODO:没用到
func TestVolumeClient_ResizeVolume(t *testing.T) {

}
