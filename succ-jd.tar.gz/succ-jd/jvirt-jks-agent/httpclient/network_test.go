package httpclient

import (
	"encoding/json"
	"fmt"
	"testing"

	"jd.com/jvirt/jvirt-common/utils/config"
	"jd.com/jvirt/jvirt-jks-agent/model"
)

func getNetworkClient() (*NetworkClient, error) {
	ccConfig := &config.Cc{
		Url: "http://10.226.137.197:9698/cc-server",
	}
	logger, err := initLoggers("./tmp/network_test.log")
	if err != nil {
		return nil, err
	}
	client, err := NewNetworkClient(logger, ccConfig)
	if err != nil {
		return nil, err
	}
	return client, nil
}

// case1：删除不存在的port
// result1: 不返回错误
// case2: 重复删除port
func TestNetworkClient_DeletePort(t *testing.T) {
	fmt.Println("TestNetworkClient_DeletePort Start")

	client, err := getNetworkClient()
	if err != nil {
		fmt.Println("[TestNetworkClient_DeletePort] getNetworkClient faild. Error:", err.Error())
		t.Errorf("[TestNetworkClient_DeletePort] getNetworkClient faild. Error:%s", err.Error())
		return
	}
	if err := client.DeletePort("79fhe1982374hd82374", "port-wjy"); err != nil {
		fmt.Println("[TestNetworkClient_DeletePort] DeletePort faild. Error:", err.Error())
		t.Errorf("[TestNetworkClient_DeletePort] DeletePort faild. Error:%s", err.Error())
		return
	} else {
		fmt.Println("Success")
	}
}

// case1: 查询不存在的subnet
// result1:subnet.notfound
// case2: 查询已删除的subnet
func TestNetworkClient_DescribeSubnetById(t *testing.T) {
	fmt.Println("TestNetworkClient_DescribeSubnetById Start")

	client, err := getNetworkClient()
	if err != nil {
		fmt.Println("[TestNetworkClient_DescribeSubnetById] getNetworkClient faild. Error:", err.Error())
		t.Errorf("[TestNetworkClient_DescribeSubnetById] getNetworkClient faild. Error:%s", err.Error())
		return
	}
	if subnetView, err := client.DescribeSubnetById("x2dja93k23jfa39f", "subnet-wjy"); err != nil {
		fmt.Println("[TestNetworkClient_DescribeSubnetById] DescribeSubnetById faild. Error:", err.Error())
		t.Errorf("[TestNetworkClient_DescribeSubnetById] DescribeSubnetById faild. Error:%s", err.Error())
		return
	} else {
		result, err := json.Marshal(subnetView)
		if err != nil {
			fmt.Println("[TestNetworkClient_DescribeSubnetById] DescribeSubnetById faild. Error:", err.Error())
			return
		}
		fmt.Println("[TestNetworkClient_DescribeSubnetById] Result is ", result)
		fmt.Println("Success")
	}
}

// case1: 查询不存在的port
// result: port.notfound
// case2: 查询已删除的port
func TestNetworkClient_DescribePortById(t *testing.T) {
	fmt.Println("TestDescribePortById Start")

	client, err := getNetworkClient()
	if err != nil {
		fmt.Println("[TestNetworkClient_DescribePortById] getNetworkClient faild. Error:", err.Error())
		t.Errorf("[TestNetworkClient_DescribePortById] getNetworkClient faild. Error:%s", err.Error())
		return
	}
	if portView, err := client.DescribePortById("ex2039s9df3hjkde", "port-wjy"); err != nil {
		fmt.Println("[TestNetworkClient_DescribePortById] DescribePortById faild. Error:", err.Error())
		t.Errorf("[TestNetworkClient_DescribePortById] DescribePortById faild. Error:%s", err.Error())
		return
	} else {
		result, err := json.Marshal(portView)
		if err != nil {
			fmt.Println("[TestNetworkClient_DescribePortById] DescribePortById faild. Error:", err.Error())
			return
		}
		fmt.Println("[TestNetworkClient_DescribePortById] Result is ", result)
		fmt.Println("Success")
	}
}

// case1: 正常功能
// TODO: 是否需要测其他异常场景
func TestNetworkClient_AllocPorts(t *testing.T) {
	fmt.Println("TestNetworkClient_AllocPorts Start")

	client, err := getNetworkClient()
	if err != nil {
		fmt.Println("[TestNetworkClient_AllocPorts] getNetworkClient faild. Error:", err.Error())
		t.Errorf("[TestNetworkClient_AllocPorts] getNetworkClient faild. Error:%s", err.Error())
		return
	}
	pod := &model.Pod{
		PodId:  "",
		UserId: "",
		PrimaryInterface: &model.Network{
			PortId: "",
		},
	}
	if err := client.AllocPorts("", pod); err != nil {
		fmt.Println("[TestNetworkClient_AllocPorts] AllocPorts faild. Error:", err.Error())
		t.Errorf("[TestNetworkClient_AllocPorts] AllocPorts faild. Error:%s", err.Error())
		return
	} else {
		fmt.Println("Success")
	}
}

// case1: 删除不存在的pod的port
// result1: 不报错
// case2: 重复删除一台pod的port
func TestNetworkClient_DeletePorts(t *testing.T) {
	fmt.Println("TestNetworkClient_DeletePorts Start")

	client, err := getNetworkClient()
	if err != nil {
		fmt.Println("[TestNetworkClient_DeletePorts] getNetworkClient faild. Error:", err.Error())
		t.Errorf("[TestNetworkClient_DeletePorts] getNetworkClient faild. Error:%s", err.Error())
		return
	}

	if err := client.DeletePorts("e29jdakj3e9f2k39d", "pod-wjy"); err != nil {
		fmt.Println("[TestNetworkClient_DeletePorts] DeletePorts faild. Error:", err.Error())
		t.Errorf("[TestNetworkClient_DeletePorts] DeletePorts faild. Error:%s", err.Error())
		return
	} else {
		fmt.Println("Success")
	}
}

// case1: 停止不存在的port
// result: 不返回错误
// case2: 重复停止port
func TestNetworkClient_PortDown(t *testing.T) {
	fmt.Println("TestNetworkClient_PortDown Start")

	client, err := getNetworkClient()
	if err != nil {
		fmt.Println("[TestNetworkClient_PortDown] getNetworkClient faild. Error:", err.Error())
		t.Errorf("[TestNetworkClient_PortDown] getNetworkClient faild. Error:%s", err.Error())
		return
	}

	if _, err := client.PortDown("2fjiad20oajf39jdkfadfe3d3", "pod-wjy"); err != nil {
		fmt.Println("[TestNetworkClient_PortDown] PortDown faild. Error:", err.Error())
		t.Errorf("[TestNetworkClient_PortDown] PortDown faild. Error:%s", err.Error())
		return
	} else {
		fmt.Println("Success")
	}
}

// case1: up状态的port
// case2: down状态的port
// case3: 不存在的port
// result3: port.notfound
func TestNetworkClient_PortUpAndCheckStatus(t *testing.T) {
	fmt.Println("TestNetworkClient_PortUpAndCheckStatus Start")

	client, err := getNetworkClient()
	if err != nil {
		fmt.Println("[TestNetworkClient_PortUpAndCheckStatus] getNetworkClient faild. Error:", err.Error())
		t.Errorf("[TestNetworkClient_PortUpAndCheckStatus] getNetworkClient faild. Error:%s", err.Error())
		return
	}
	_, err = client.PortUp("2jdafij3023jfkj9edf39d", "pod-wjy", "ovs-dppdk")
	if err != nil {
		fmt.Println("[TestNetworkClient_PortDown] PortUp faild. Error:", err.Error())
		t.Errorf("[TestNetworkClient_PortDown] PortUp faild. Error:%s", err.Error())
		return
	} else {
		fmt.Println("Success")
	}
}
