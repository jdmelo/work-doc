package httpclient

import (
	"jd.com/jvirt/jvirt-common/inner/rms/state"
	"jd.com/jvirt/jvirt-common/utils/config"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/url"
)

type RmsGwClient struct {
	Logger log.Logger
	Client state.StateService
}

func NewRmsGwClient(log log.Logger, c *config.Rms) (*RmsGwClient, error) {
	httpCfg := &config.HttpClient{
		ConnectTimeout:        c.ConnectTimeout,
		MaxIdleConns:          c.MaxIdleConns,
		TimerInterval:         c.TimerInterval,
		ResponseHeaderTimeout: c.ResponseHeaderTimeout,
		RequestTotalTimeout:   c.RequestTotalTimeout,
	}

	hc := url.NewClient(httpCfg, log)

	client, err := state.NewStateServiceClient(hc, log, c.Url)
	if err != nil {
		return nil, err
	}

	return &RmsGwClient{
		Client: client,
		Logger: log,
	}, nil
}

func (r *RmsGwClient) RmsGwHeartbeat(args *state.HeartBeatRequest) error {
	if err := r.Client.Heartbeat(args); err != nil {
		r.Logger.Error("Heartbeat from jvirt-rms-gw failed. Params: +v, Error: %s.", *args, err.Error())
		return err
	}

	return nil
}
