package httpclient

import (
	"errors"
	"fmt"
	"strings"
	"time"

	"jd.com/jvirt/jvirt-common/integration/network"
	outer "jd.com/jvirt/jvirt-common/integration/network/model"
	"jd.com/jvirt/jvirt-common/utils/config"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/retry"
	"jd.com/jvirt/jvirt-common/utils/url"
	"jd.com/jvirt/jvirt-jks-agent/constant"
	"jd.com/jvirt/jvirt-jks-agent/model"
	"jd.com/jvirt/jvirt-jks-agent/utils"
)

const (
	DeviceID = "device_id"
	PortIDs  = "ids"
)

type NetworkClient struct {
	Client network.INetWorkClient
	Logger log.Logger
}

func NewNetworkClient(l log.Logger, c *config.Cc) (*NetworkClient, error) {
	httpCfg := &config.HttpClient{
		ConnectTimeout:        c.ConnectTimeout,
		MaxIdleConns:          c.MaxIdleConns,
		TimerInterval:         c.TimerInterval,
		ResponseHeaderTimeout: c.ResponseHeaderTimeout,
		RequestTotalTimeout:   c.RequestTotalTimeout,
	}

	hc := url.NewClient(httpCfg, l)

	client := network.NewNetworManager(hc, c, l)

	return &NetworkClient{
		Client: client,
		Logger: l,
	}, nil
}

func (p *NetworkClient) describePortByFilter(tenantId string, filters map[string]interface{}) ([]*outer.PortView, error) {
	params := &outer.ListOptions{
		TenantId: tenantId,
		Filter:   filters,
		Limit:    -1,
	}
	_, resp, err := p.Client.DescribePortByFilter(params)
	if err != nil {
		p.Logger.Error("Invoke describePortByFilter failed. Params: %s, Error: %s", *params, err.Error())
		return nil, err
	}

	return resp, nil
}

func (p *NetworkClient) DeletePort(tenantId string, portId string) error {
	params := &outer.BaseOptions{
		TenantId: tenantId,
		Id:       portId,
	}

	if err := p.Client.DeletePort(params); err != nil {
		errMsg := err.Error()
		if strings.Contains(errMsg, "port.notfound") {
			p.Logger.Info("Port has deleted, PortId: %s", portId)
			return nil
		}

		p.Logger.Error("Invoke DeletePort failed. Params: %s, Error: %s", *params, errMsg)
		return err
	}

	return nil
}

func (p *NetworkClient) checkPortStatus(tenantId string, portIds []string) ([]*outer.PortStatusView, error) {
	params := &outer.CheckPortStatusOptions{
		TenantId: &tenantId,
		Ids:      portIds,
	}

	portStatus, err := p.Client.CheckPortStatus(params)
	if err != nil {
		p.Logger.Error("Invoke checkPortStatus failed. Params: %s, Error: %s", *params, err.Error())

		return nil, err
	}

	return portStatus, nil
}

func (p *NetworkClient) changePortBinding(tenantId, portId, hostId string) error {
	// ChangePortBinding幂等,同一个hostId上不报错.
	portView, err := p.DescribePortById(tenantId, portId)
	if err != nil {
		p.Logger.Error("[changePortBinding] DescribePortById failed. PortId: %sm Error: %s.", portId, err.Error())
		return err
	}
	hostIds := portView.HostIds
	if len(hostIds) > 1 {
		p.Logger.Error("[changePortBinding] Port [%s] bind not only one nodes [%v].", portId, hostIds)
		return err
	}
	if len(hostIds) == 1 {
		portHostId := portView.HostIds[0]
		if hostId == portHostId {
			return nil
		}
	}

	params := &outer.ChangePortBindingOptions{
		TenantId: tenantId,
		Id:       portId,
		HostId:   hostId,
	}
	if err := p.Client.ChangePortBinding(params); err != nil {
		p.Logger.Error("Invoke changePortBinding failed. Params: %s, Error: %s", *params, err.Error())
		return err
	}

	return nil
}

func (p *NetworkClient) getHostId(hostname string) (string, error) {
	filter := make(map[string]interface{})
	filter["name"] = hostname
	params := &outer.ListOptions{
		Limit:  -1,
		Filter: filter,
	}
	_, hosts, err := p.Client.DescribeHostByFilter(params)
	if err != nil {
		p.Logger.Error("Invoke DescribeHostByFilter failed. Error: %s", err.Error())
		return "", err
	}
	if len(hosts) > 1 {
		msg := fmt.Sprintf("The hostname of %s compute nodes is repeat init by cc", hostname)
		p.Logger.Error(msg)
		return "", errors.New(msg)
	}
	if len(hosts) == 0 {
		msg := fmt.Sprintf("The hostname of %s compute nodes is not init by cc", hostname)
		p.Logger.Error(msg)
		return "", errors.New(msg)
	}

	return hosts[0].Id, nil
}

func (p *NetworkClient) checkPortBinding(userId, resourceId, hostId string, portIds []string) error {
	filters := make(map[string]interface{})
	filters[DeviceID] = resourceId
	filters[PortIDs] = portIds

	f := func() error {
		ports, err := p.describePortByFilter(userId, filters)
		if err != nil {
			p.Logger.Error("[checkPortBinding] describePortByFilter failed. Error: %v.", err.Error())
			return err
		}
		for _, port := range ports {
			if len(port.HostIds) != 1 || port.HostIds[0] != hostId {
				p.Logger.Error("The port [%s] is not bound with %s.", port.Id, hostId)
				return errors.New("some ports not bound with this compute node")
			}
		}

		p.Logger.Info("[checkPortBinding] All ports are bound with this compute node.")

		return nil

	}

	err := retry.ExponentialRetry(f, 5)

	return err
}

func (p *NetworkClient) DescribeSubnetById(tenantId string, subnetId string) (*outer.SubnetView, error) {
	params := &outer.DescribeSubnetOptions{
		TenantId: tenantId,
		Id:       subnetId,
	}

	resp, err := p.Client.DescribeSubnetById(params)
	if err != nil {
		p.Logger.Error("Invoke DescribeSubnetById failed. Params: %s, Error: %s", *params, err.Error())
		return nil, err
	}
	if resp == nil {
		msg := fmt.Sprintf("DescribeSubnetById return nil, SubnetId %s", subnetId)
		p.Logger.Error(msg)
		return nil, errors.New(msg)
	}

	return resp, nil
}

func (p *NetworkClient) DescribePortById(tenantId string, portId string) (*outer.PortView, error) {
	params := &outer.BaseOptions{
		TenantId: tenantId,
		Id:       portId,
	}

	resp, err := p.Client.DescribePortById(params)
	if err != nil {
		p.Logger.Error("Invoke DescribePortById failed. Params: %s, Error: %s", *params, err.Error())
		return nil, err
	}
	if resp == nil {
		msg := fmt.Sprintf("DescribePortById return nil, PortId %s", portId)
		p.Logger.Error(msg)
		return nil, errors.New(msg)
	}

	return resp, nil
}

func (p *NetworkClient) getPortsByResourceId(userId, resourceId string) ([]string, error) {
	//get port ids from cc
	filters := make(map[string]interface{})
	filters[DeviceID] = resourceId

	portViews, err := p.describePortByFilter(userId, filters)
	if err != nil {
		return nil, err
	}
	portIds := make([]string, 0)

	for _, portView := range portViews {
		portIds = append(portIds, portView.Id)
	}

	return portIds, nil
}

func (p *NetworkClient) PortDown(userId, podId string) ([]string, error) {
	portIds, err := p.getPortsByResourceId(userId, podId)
	if err != nil {
		p.Logger.Error("[PortDown] getPortsByResourceId failed. UserId: %s, PodId: %s, Error: %s",
			userId, podId, err.Error())
		return nil, err
	}

	params := &outer.ChangePortStateOptions{
		TenantId: userId,
		Ids:      portIds,
	}
	if err := p.Client.PortDown(params); err != nil {
		p.Logger.Error("Invoke PortDown failed. Params: %s, Error: %s", *params, err.Error())
		return nil, err
	}

	return portIds, nil
}

func (p *NetworkClient) PortUp(tenantId, podId, netType string) ([]string, error) {
	// 网络建议: up前先执行down操作
	portIds, err := p.PortDown(tenantId, podId)
	if err != nil {
		p.Logger.Error("[PortUp] Invoke cc.PortDown failed. PodId: %s, Error: %s.", podId, err.Error())
		return nil, err
	}
	if len(portIds) == 0 {
		p.Logger.Warn("[PortUp] PortIds is empty")
		return portIds, nil
	}

	p.Logger.Debug("[PortUp] start. TenantId: %s, PodId: %s, NetType: %s, PortIds: %v", tenantId, podId, netType, portIds)

	if netType == constant.OVSDpdk {
		f := func() error {
			for _, portId := range portIds {
				if utils.CheckOvsPortExist(portId) {
					p.Logger.Warn("[PortUp] After PortDown, port [%s] exist in the ovs-dpdk", portId)
					return errors.New("ovs-vsctl get interface returned successfully, port still exist, after PortDown")
				}
			}

			return nil
		}

		if err := retry.Retry(f, 300, 1*time.Second); err != nil {
			p.Logger.Error("[PortUp] After PortDown, ports is not removed from ovs after 60 seconds.")
			return nil, err
		}
	}

	// 1: port_up 下流表。
	params := &outer.ChangePortStateOptions{
		TenantId: tenantId,
		Ids:      portIds,
	}
	if err := p.Client.PortUp(params); err != nil {
		p.Logger.Error("[PortUp] Invoke cc.PortUp failed. Params: %+v, Error: %s", *params, err.Error())
		return nil, err
	}
	p.Logger.Debug("[PortUp] finished. TenantId: %s, PodId: %s, NetType: %s, PortIds: %v", tenantId, podId, netType, portIds)

	return portIds, nil
}

func (p *NetworkClient) CheckPortsReady(userId, podId, netType string) error {

	var checkF func() error

	portIds, err := p.getPortsByResourceId(userId, podId)
	if err != nil {
		p.Logger.Error("[CheckPortsReady] getPortsByResourceId failed. UserId: %s, PodId: %s, Error: %s",
			userId, podId, err.Error())
		return err
	}

	p.Logger.Debug("[CheckPortsReady] start. TenantId: %s, NetType: %s, PortIds: %v", userId, netType, portIds)

	if netType == constant.OVSDpdk {
		checkF = func() error {
			for _, portId := range portIds {
				if !utils.CheckOvsPortExist(portId) {
					p.Logger.Warn("[CheckPortsReady] port [%s] not found in the ovs-dpdk, after PortUp", portId)
					return errors.New("ovs-vsctl get interface returned failed, port not found, after PortUp")
				}
			}

			return nil
		}
	} else {
		checkF = func() error {
			isUp := true

			status, err := p.checkPortStatus(userId, portIds)
			if err != nil {
				p.Logger.Error("[CheckPortsReady] Check port status failed. Error: %s", err.Error())
				return err
			}
			if status == nil || len(status) == 0 {
				p.Logger.Error("[CheckPortsReady] Check port status failed. return status is nil.")
				return err
			}

			portIds = make([]string, 0)
			for _, value := range status {
				if value.Status == 0 {
					isUp = false
					portIds = append(portIds, value.Id)
					p.Logger.Warn("[CheckPortsReady] The port [%s] is down, after PortUp.", value.Id)
					continue
				}
			}
			if !isUp {
				p.Logger.Debug("[CheckPortsReady] some ports status is not up.")
				return errors.New("the status of ports is not available")
			}

			return nil
		}
	}

	if err := retry.Retry(checkF, 300, 1*time.Second); err != nil {
		p.Logger.Error("[CheckPortsReady] checkPortStatus failed. TenantId: %s, PortIds: %v", userId, portIds)
		return err
	}

	p.Logger.Debug("[CheckPortsReady] finished. TenantId: %s, NetType: %s, PortIds: %v", userId, netType, portIds)

	return nil
}

func (p *NetworkClient) DeletePorts(userId, resourceId string) error {
	var delPortErr error

	filters := make(map[string]interface{})
	filters[DeviceID] = resourceId
	ports, err := p.describePortByFilter(userId, filters)
	if err != nil {
		p.Logger.Error("Invoke describePortByFilter failed. Error: %#v.", err)
		return err
	}

	for _, port := range ports {
		portId := port.Id
		if err := p.DeletePort(userId, portId); err != nil {
			p.Logger.Warn("DeletePort failed. ResourceId: %s, PortId: %s, Error: %s.", resourceId, portId, err.Error())
			delPortErr = err
		}
	}

	return delPortErr
}

func (p *NetworkClient) AllocPorts(hostname string, pod *model.Pod) error {
	podId := pod.PodId
	userId := pod.UserId
	networks := []*model.Network{pod.PrimaryInterface}

	p.Logger.Debug("Allocate network resource start. PodId: %s", podId)

	localHostId, err := p.getHostId(hostname)
	if err != nil {
		p.Logger.Error("[prepareNetwork] getHostId failed. PodId: %s, Hostname: %s, Error: %s",
			podId, hostname, err.Error())
		return err
	}

	portIds := make([]string, 0)
	for _, net := range networks {
		if err := p.changePortBinding(userId, net.PortId, localHostId); err != nil {
			p.Logger.Error("[prepareNetwork] changePortBinding failed. PortId: %s, Error: %s.", net.PortId, err.Error())
			return err
		}

		portIds = append(portIds, net.PortId)
	}

	if err := p.checkPortBinding(userId, podId, localHostId, portIds); err != nil {
		p.Logger.Error("[prepareNetwork] checkPortBinding failed. PodId: %s, Error: %s", podId, err.Error())
		return err
	}

	return nil
}
