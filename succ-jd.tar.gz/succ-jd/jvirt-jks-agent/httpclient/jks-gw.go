package httpclient

import (
	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/inner/jks/gw"
	"jd.com/jvirt/jvirt-common/utils/config"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/url"
)

type JksGwClient struct {
	Logger log.Logger
	Client gw.GwServer
}

func NewJksGwClient(l log.Logger, c *config.GateWayConfig) (*JksGwClient, error) {
	httpCfg := &config.HttpClient{
		ConnectTimeout:        c.ConnectTimeout,
		MaxIdleConns:          c.MaxIdleConns,
		TimerInterval:         c.TimerInterval,
		ResponseHeaderTimeout: c.ResponseHeaderTimeout,
		RequestTotalTimeout:   c.RequestTotalTimeout,
	}

	hc := url.NewClient(httpCfg, l)

	client, err := gw.NewGwServerClient(hc, l, c.Url)
	if err != nil {
		return nil, err
	}

	return &JksGwClient{
		Client: client,
		Logger: l,
	}, nil
}

func (p *JksGwClient) JksGwHeartbeat(params *gw.HeartbeatRequest) ([]*jks.Task, error) {
	tasks, jErr := p.Client.Heartbeat(params)
	if jErr != nil {
		p.Logger.Error("Invoke jks-gw.Heartbeat failed. Error: %s, Detail: %s", jErr.Error(), jErr.Detail())
		return nil, jErr
	}

	return tasks, nil
}
