package httpclient

import (
	"encoding/json"
	"fmt"
	"testing"

	"jd.com/jvirt/jvirt-common/utils/config"
)

func getXcgroupClient() (*XcgroupClient, error) {
	xcgroupConfig := &config.XcGroup{
		Url:     "http://10.226.137.207:8080",
		Version: "1.0.0",
	}
	logger, err := initLoggers("./tmp/xcgroup_test.log")
	if err != nil {
		return nil, err
	}
	client, err := NewXcgroupClient(logger, xcgroupConfig, true)
	if err != nil {
		return nil, err
	}
	xrmsApiConfig := &config.Rms{
		Url: "http://10.226.137.205:8790/rms-api-server",
	}
	rmsApiClient, err := NewRmsApiClient(logger, xrmsApiConfig)
	if err != nil {
		return nil, err
	}
	client.RmsApiCli = rmsApiClient
	return client, nil
}

// case1: 使用podId正常申请
// result1: [123 34 67 112 117 84 111 116 97 108 34 58 54 48 44 34 67 112 117 83 101 116 34 58 91 51 57 44 54 48 44 53
// 54 44 50 51 44 50 55 44 49 55 44 50 56 44 49 51 44 49 52 44 49 50 44 49 49 44 53 55 44 53 56 44 51 48 44 52 53 44 49
// 56 44 52 49 44 51 50 44 52 50 44 49 48 44 50 48 44 50 54 44 54 51 44 49 53 44 55 44 50 50 44 51 56 44 52 51 44 50 52
// 44 50 49 44 53 52 44 49 57 44 50 57 44 49 54 44 51 49 44 52 54 44 52 48 44 51 51 44 50 53 44 54 50 44 51 54 44 52 44
// 52 56 44 53 57 44 54 44 51 52 44 51 53 44 53 53 44 56 44 52 55 44 51 55 44 52 52 44 57 44 54 49 44 53 48 44 52 57 44
// 53 49 44 53 44 53 50 44 53 51 93 44 34 86 67 80 85 80 105 110 34 58 123 34 49 48 34 58 48 44 34 49 49 34 58 48 44 34
// 49 50 34 58 48 44 34 49 51 34 58 48 44 34 49 52 34 58 48 44 34 49 53 34 58 48 44 34 49 54 34 58 49 44 34 49 55 34 58
// 49 44 34 49 56 34 58 49 44 34 49 57 34 58 49 44 34 50 48 34 58 49 44 34 50 49 34 58 49 44 34 50 50 34 58 49 44 34 50
// 51 34 58 49 44 34 50 52 34 58 49 44 34 50 53 34 58 49 44 34 50 54 34 58 49 44 34 50 55 34 58 49 44 34 50 56 34 58 49
// 44 34 50 57 34 58 49 44 34 51 48 34 58 49 44 34 51 49 34 58 49 44 34 51 50 34 58 48 44 34 51 51 34 58 48 44 34 51 52
// 34 58 48 44 34 51 53 34 58 48 44 34 51 54 34 58 48 44 34 51 55 34 58 48 44 34 51 56 34 58 48 44 34 51 57 34 58 48 44
// 34 52 34 58 48 44 34 52 48 34 58 48 44 34 52 49 34 58 48 44 34 52 50 34 58 48 44 34 52 51 34 58 48 44 34 52 52 34 58
// 48 44 34 52 53 34 58 48 44 34 52 54 34 58 48 44 34 52 55 34 58 48 44 34 52 56 34 58 49 44 34 52 57 34 58 49 44 34 53
// 34 58 48 44 34 53 48 34 58 49 44 34 53 49 34 58 49 44 34 53 50 34 58 49 44 34 53 51 34 58 49 44 34 53 52 34 58 49 44
// 34 53 53 34 58 49 44 34 53 54 34 58 49 44 34 53 55 34 58 49 44 34 53 56 34 58 49 44 34 53 57 34 58 49 44 34 54 34 58
// 48 44 34 54 48 34 58 49 44 34 54 49 34 58 49 44 34 54 50 34 58 49 44 34 54 51 34 58 49 44 34 55 34 58 48 44 34 56 34
// 58 48 44 34 57 34 58 48 125 44 34 77 101 109 84 111 116 97 108 34 58 49 48 52 56 53 55 54 44 34 78 111 100 101 83 101
// 116 34 58 91 48 44 49 93 44 34 71 112 117 83 101 116 34 58 110 117 108 108 44 34 69 112 104 83 101 116 34 58 110 117
// 108 108 125]
// case2: 使用podId重复申请
func TestXcgroupClient_Alloc(t *testing.T) {
	fmt.Println("TestXcgroupClient_Alloc Start")

	client, err := getXcgroupClient()
	if err != nil {
		fmt.Println("[TestXcgroupClient_Alloc] getXcgroupClient faild. Error:", err.Error())
		t.Errorf("[TestXcgroupClient_Alloc] getXcgroupClient faild. Error:%s", err.Error())
		return
	}
	if res, err := client.Alloc("xagent", "pod-wjytest", "g.s1.micro"); err != nil {
		fmt.Println("[TestXcgroupClient_Alloc] Alloc faild. Error:", err.Error())
		t.Errorf("[TestXcgroupClient_Alloc] Alloc faild. Error:%s", err.Error())
		return
	} else {
		result, err := json.Marshal(res)
		if err != nil {
			fmt.Println("[TestXcgroupClient_Alloc] Alloc faild. Error:", err.Error())
			return
		}
		fmt.Println("[TestXcgroupClient_Alloc] Result is ", result)
		fmt.Println("Success")
	}
}

// case1: 查询正常的podId
// case2: 查询不存在的podId
// result2: Invoke xcgroup query resource is nil, PodId: pod-wjytest
func TestXcgroupClient_Query(t *testing.T) {
	fmt.Println("TestXcgroupClient_Query Start")

	client, err := getXcgroupClient()
	if err != nil {
		fmt.Println("[TestXcgroupClient_Query] getXcgroupClient faild. Error:", err.Error())
		t.Errorf("[TestXcgroupClient_Query] getXcgroupClient faild. Error:%s", err.Error())
		return
	}
	if view, err := client.Query("pod-wjytest"); err != nil {
		fmt.Println("[TestXcgroupClient_Query] Query faild. Error:", err.Error())
		t.Errorf("[TestXcgroupClient_Query] Query faild. Error:%s", err.Error())
		return
	} else {
		result, err := json.Marshal(view)
		if err != nil {
			fmt.Println("[TestXcgroupClient_Query] Query faild. Error:", err.Error())
			return
		}
		fmt.Println("[TestXcgroupClient_Query] Result is ", result)
		fmt.Println("Success")
	}
}

// case1: 释放不存在的资源
// result1: 不返回错误
// case2: 正常释放资源
func TestXcgroupClient_Free(t *testing.T) {
	fmt.Println("TestXcgroupClient_Free Start")

	client, err := getXcgroupClient()
	if err != nil {
		fmt.Println("[TestXcgroupClient_Free] getXcgroupClient faild. Error:", err.Error())
		t.Errorf("[TestXcgroupClient_Free] getXcgroupClient faild. Error:%s", err.Error())
		return
	}
	if err := client.Free("pod-wjytest"); err != nil {
		fmt.Println("[TestXcgroupClient_Query] Query faild. Error:", err.Error())
		t.Errorf("[TestXcgroupClient_Query] Query faild. Error:%s", err.Error())
		return
	} else {
		fmt.Println("Success")
	}
}

// case1: 正常podId重新申请资源
// case2: 不存在的podId重新申请资源
// case1: ReAlloc resource not found
func TestXcgroupClient_ReAlloc(t *testing.T) {
	fmt.Println("TestXcgroupClient_ReAlloc Start")

	client, err := getXcgroupClient()
	if err != nil {
		fmt.Println("[TestXcgroupClient_ReAlloc] getXcgroupClient faild. Error:", err.Error())
		t.Errorf("[TestXcgroupClient_ReAlloc] getXcgroupClient faild. Error:%s", err.Error())
		return
	}
	if res, err := client.ReAlloc("xagent", "pod-wjytest", "g.s1.micro"); err != nil {
		fmt.Println("[TestXcgroupClient_ReAlloc] ReAlloc faild. Error:", err.Error())
		t.Errorf("[TestXcgroupClient_ReAlloc] ReAlloc faild. Error:%s", err.Error())
		return
	} else {
		result, err := json.Marshal(res)
		if err != nil {
			fmt.Println("[TestXcgroupClient_ReAlloc] ReAlloc faild. Error:", err.Error())
			return
		}
		fmt.Println("[TestXcgroupClient_ReAlloc] Result is ", result)
		fmt.Println("Success")
	}
}
