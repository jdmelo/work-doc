package httpclient

import (
	"jd.com/jvirt/jvirt-common/inner/jks/agent"
	"jd.com/jvirt/jvirt-common/utils/config"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/url"
)

type JksAgentClient struct {
	Logger log.Logger
	Client agent.IAgentHttpClient
}

func NewJksAgentClient(l log.Logger, c *config.Agent) (*JksAgentClient, error) {
	httpCfg := &config.HttpClient{
		ConnectTimeout:        c.ConnectTimeout,
		MaxIdleConns:          c.MaxIdleConns,
		TimerInterval:         c.TimerInterval,
		ResponseHeaderTimeout: c.ResponseHeaderTimeout,
		RequestTotalTimeout:   c.RequestTotalTimeout,
	}

	hc := url.NewClient(httpCfg, l)

	client, err := agent.NewAgentHTTPClient(l, hc, c.Port, c.BasePath)
	if err != nil {
		return nil, err
	}

	return &JksAgentClient{
		Client: client,
		Logger: l,
	}, nil
}
