package httpclient

import "testing"

func TestHelloWorld(t *testing.T) {
	t.Log("Hello world")
}
