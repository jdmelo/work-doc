package cfg

import (
	"time"
)

type DefaultConfig struct {
	RuntimeCores int  `ini:"runtime_cores"`
	ReallyCrash  bool `ini:"really_crash"`
}

type LogConfig struct {
	Level    string `ini:"level"`
	FilePath string `ini:"file_path" validate:"nonzero"`
}

type ComputeConfig struct {
	HostIp               string        `ini:"host_ip" validate:"nonzero"`
	Hostname             string        `ini:"hostname" validate:"nonzero"`
	OVSType              string        `ini:"ovs_type" validate:"nonzero"`   // ovs-kernel | ovs-dpdk
	OVSBridge            string        `ini:"ovs_bridge" validate:"nonzero"` // br0
	ZbsLinkFileDir       string        `ini:"zbs_link_file_dir" validate:"nonzero"`
	InstancesDir         string        `ini:"instances_dir" validate:"nonzero"`
	ImagesDir            string        `ini:"images_dir"`      // 暂时没有使用.
	SupportDrivers       []string      `ini:"support_drivers"` //xagent,docker 逗号分隔
	IgnoreRecoveryError  bool          `ini:"ignore_recovery_error"`
	UseXcgroup           bool          `ini:"use_xcgroup"` // 是否启用xcgroup开关
	JksGWHeartbeatPeriod time.Duration `ini:"jks_gw_heartbeat_period"`
	RmsGWHeartbeatPeriod time.Duration `ini:"rms_gw_heartbeat_period"`
}
