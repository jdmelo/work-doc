package cfg

import "testing"

func TestParseConfig(t *testing.T) {
	cfgFile := "/home/succ/Gopath/src/jd.com/jvirt/jvirt-jks-agent/cfg/jks-agent.conf"
	if err := ParseConfig(&cfgFile); err != nil {
		t.Error("ParseConfig failed. Error:", err.Error())
	}
}
