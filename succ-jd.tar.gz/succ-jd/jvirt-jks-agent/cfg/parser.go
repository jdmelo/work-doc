package cfg

import (
	"errors"
	"fmt"
	"os"

	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/utils/config"
	"jd.com/jvirt/jvirt-common/utils/validate"
)

const (
	DefaultSession       = "default"
	LogSession           = "log"
	JvirtJksAgentSession = "jvirt_jks_agent"
	JvirtJksApiSession   = "jvirt_jks_api"
	JvirtJksGWSession    = "jvirt_jks_gw"
	JvirtRmsApiSession   = "jvirt_rms_api"
	JvirtRmsGWSession    = "jvirt_rms_gw"
	NetworkSession       = "network"
	VolumeSession        = "volume"
	XCgroupSession       = "xcgroup"
	ComputeSession       = "compute"
	XAgentSession        = "xagent"
)

var (
	DefaultCfg  *DefaultConfig
	LogCfg      *LogConfig
	JksApiCfg   *config.JksApiConfig
	JksGwCfg    *config.GateWayConfig
	JksAgentCfg *config.Agent
	RmsGwCfg    *config.Rms
	RmsApiCfg   *config.Rms
	NetworkCfg  *config.Cc
	VolumeCfg   *config.Volume
	XCgroupCfg  *config.XcGroup
	ComputeCfg  *ComputeConfig
	XAgentCfg   *config.XAgentConfig
)

func init() {
	DefaultCfg = &DefaultConfig{
		RuntimeCores: 4,
		ReallyCrash:  true,
	}
	LogCfg = &LogConfig{
		Level: "debug",
	}
	ComputeCfg = &ComputeConfig{
		IgnoreRecoveryError:  true,
		SupportDrivers:       []string{jks.RuntimeXagent},
		JksGWHeartbeatPeriod: 10,
		RmsGWHeartbeatPeriod: 10,
		UseXcgroup:           false,
	}
	XAgentCfg = &config.XAgentConfig{}
	JksApiCfg = &config.JksApiConfig{
		MaxIdleConns:          100,
		TimerInterval:         60,
		ConnectTimeout:        500,
		ResponseHeaderTimeout: 10000,
		RequestTotalTimeout:   20000,
	}
	JksGwCfg = &config.GateWayConfig{}
	RmsGwCfg = &config.Rms{
		MaxIdleConns:          100,
		TimerInterval:         60,
		ConnectTimeout:        500,
		ResponseHeaderTimeout: 10000,
		RequestTotalTimeout:   20000,
	}
	RmsApiCfg = &config.Rms{
		MaxIdleConns:          100,
		TimerInterval:         60,
		ConnectTimeout:        500,
		ResponseHeaderTimeout: 10000,
		RequestTotalTimeout:   20000,
	}
	JksAgentCfg = &config.Agent{
		Port:                  "6779",
		BasePath:              "jvirt-jks-agent",
		MaxIdleConns:          100,
		TimerInterval:         60,
		ConnectTimeout:        500,
		ResponseHeaderTimeout: 5000,
		RequestTotalTimeout:   10000,
	}
	NetworkCfg = &config.Cc{
		MaxIdleConns:          100,
		TimerInterval:         60,
		ConnectTimeout:        500,
		ResponseHeaderTimeout: 10000,
		RequestTotalTimeout:   20000,
	}
	VolumeCfg = &config.Volume{
		MaxIdleConns:          100,
		TimerInterval:         60,
		ConnectTimeout:        500,
		ResponseHeaderTimeout: 5000,
		RequestTotalTimeout:   10000,
	}
	XCgroupCfg = &config.XcGroup{
		MaxIdleConns:          100,
		TimerInterval:         60,
		ConnectTimeout:        500,
		ResponseHeaderTimeout: 10000,
		RequestTotalTimeout:   20000,
	}
}

func ParseConfig(configPath *string) error {
	if configPath == nil {
		return errors.New("The config path is nil.")
	}

	parser, err := config.NewConfigParser(*configPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "NewConfigParser failed. Error: %v.\n", err.Error())
		return err
	}

	// default session config.
	if err := parser.ParserAppointSection(DefaultSession, DefaultCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Parser DefaultSession failed. Error: %v.\n", err.Error())
		return err
	}
	if err := validate.Validate(DefaultCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate DefaultSession failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("DefaultSession: %#v.\n", DefaultCfg)

	// log session config.
	if err := parser.ParserAppointSection(LogSession, LogCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Parser LogSession failed. Error: %v.\n", err.Error())
		return err
	}
	if err := validate.Validate(LogCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate LogSession failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("LogSession: %#v.\n", LogCfg)

	// jvirt_jks_api session config.
	if err := parser.ParserAppointSection(JvirtJksApiSession, JksApiCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Parser JvirtJksApiSession failed. Error: %v.\n", err.Error())
		return err
	}
	if err := validate.Validate(JksApiCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate JvirtJksApiSession failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("JvirtJksApiSession: %#v.\n", JksApiCfg)

	// jvirt_jks_gw session config.
	if err := parser.ParserAppointSection(JvirtJksGWSession, JksGwCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Parser JvirtJksGWSession failed. Error: %v.\n", err.Error())
		return err
	}
	if err := validate.Validate(JksGwCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate JvirtJksGWSession failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("JvirtJksGWSession: %#v.\n", JksGwCfg)

	// jvirt_rms_api session config.
	if err := parser.ParserAppointSection(JvirtRmsApiSession, RmsApiCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Parser JvirtRmsApiSession failed. Error: %v.\n", err.Error())
		return err
	}
	if err := validate.Validate(RmsApiCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate JvirtRmsApiSession failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("JvirtRmsApiSession: %#v.\n", RmsApiCfg)

	// jvirt_rms_gw session config.
	if err := parser.ParserAppointSection(JvirtRmsGWSession, RmsGwCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Parser JvirtRmsGWSession failed. Error: %v.\n", err.Error())
		return err
	}
	if err := validate.Validate(RmsGwCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate JvirtRmsGWSession failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("JvirtRmsGWSession: %#v.\n", RmsGwCfg)

	// jvirt-jks-agent session config.
	if err := parser.ParserAppointSection(JvirtJksAgentSession, JksAgentCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Parser JvirtJksAgentSession failed. Error: %v.\n", err.Error())
		return err
	}
	if err := validate.Validate(JksAgentCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate JvirtJksAgentSession failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("JvirtJksAgentSession: %#v.\n", JksAgentCfg)

	// network session config.
	if err := parser.ParserAppointSection(NetworkSession, NetworkCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Parser NetworkSession failed. Error: %v.\n", err.Error())
		return err
	}
	if err := validate.Validate(NetworkCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate NetworkSession failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("NetworkSession: %#v.\n", NetworkCfg)

	// volume session config.
	if err := parser.ParserAppointSection(VolumeSession, VolumeCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Parser VolumeSession failed. Error: %v.\n", err.Error())
		return err
	}
	if err := validate.Validate(VolumeCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate VolumeSession failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("VolumeSession: %#v.\n", VolumeCfg)

	// xcgroup session config.
	if err := parser.ParserAppointSection(XCgroupSession, XCgroupCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Parser XCgroupSession failed. Error: %v.\n", err.Error())
		return err
	}
	if err := validate.Validate(VolumeCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate XCgroupSession failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("XCgroupSession: %#v.\n", XCgroupCfg)

	// compute session config.
	if err := parser.ParserAppointSection(ComputeSession, ComputeCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Parser ComputeSession failed. Error: %v.\n", err.Error())
		return err
	}
	if err := validate.Validate(ComputeCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate ComputeSession failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("ComputeSession: %#v.\n", ComputeCfg)

	// xagent config.
	if err := parser.ParserAppointSection(XAgentSession, XAgentCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Parser XAgentSession failed. Error: %v.\n", err.Error())
		return err
	}
	if err := validate.Validate(XAgentCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate XAgentSession failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("XAgentSession: %#v.\n", XAgentCfg)

	return nil
}
