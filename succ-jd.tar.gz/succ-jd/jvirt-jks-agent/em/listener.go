package em

import (
	"jd.com/jvirt/jvirt-common/utils/event"
)

type BaseListener struct {
	listenerModel event.ListenerModel
	listenerName  string
	listenerTopic string
}

func NewBaseListener(name, model, topic string) BaseListener {
	return BaseListener{
		listenerName:  name,
		listenerModel: event.ListenerModel(model),
		listenerTopic: topic,
	}
}

// 监听器模式
func (p *BaseListener) Model() event.ListenerModel {
	return p.listenerModel
}

// 监听器名称
func (p *BaseListener) Name() string {
	return p.listenerName
}

// 监听的topic
func (p *BaseListener) ListenTopic() string {
	return p.listenerTopic
}

func (p *BaseListener) Listen(event *event.Event) {

}
