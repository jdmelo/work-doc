package em

import (
	"time"

	"jd.com/jvirt/jvirt-common/utils/event"
	"jd.com/jvirt/jvirt-common/utils/golocal"
	"jd.com/jvirt/jvirt-common/utils/log"
)

type EventManagerService struct {
	EventManager event.EventManager `inject:""`
	Logger       log.Logger         `inject:""`
}

func NewEventManager(l log.Logger) *EventManagerService {
	return &EventManagerService{
		EventManager: event.NewEventManager(200, l, 1),
		Logger:       l,
	}
}

func (p *EventManagerService) Start() error {
	p.Logger.Debug("Invoke EventManagerService doStart......")
	if err := p.EventManager.Start(); err != nil {
		p.Logger.Error("Start async eventManager failed. Error: %s", err.Error())
		return err
	}

	p.Logger.Debug("Invoke EventManagerService doStart finished.")

	return nil
}

func (p *EventManagerService) Stop() error {
	p.Logger.Debug("Invoke EventManagerService doStop......")
	if err := p.EventManager.Stop(); err != nil {
		p.Logger.Error("Start async eventManager failed. Error: %s", err.Error())
		return err
	}

	p.Logger.Debug("Invoke EventManagerService doStop finished.")

	return nil
}

func (p *EventManagerService) AddListener(l event.Listener) {
	p.EventManager.AddListener(l)
}

func (p *EventManagerService) EmitOperationEvent(instId, action, stage, detail string) error {
	item := &event.Event{
		Topic:     InstanceActionTopic,
		Timestamp: time.Now().Unix(),
		Data: &InstanceActionEvent{
			InstanceId: instId,
			RequestId:  golocal.GoContext.Get().RequestId,
			TaskType:   golocal.GoContext.Get().TaskType,
			Action:     action,
			Stage:      stage,
			Detail:     detail,
		},
	}

	if err := p.EventManager.Notify(item); err != nil {
		p.Logger.Error("Send [%s] failed. Error: %+v.", item.Topic, err)
		return err
	}

	return nil
}

func (p *EventManagerService) EmitExecuteTimeEvent(podId, action, stage string, isFinished bool) error {
	item := &event.Event{
		Topic:     ExecuteTimeTopic,
		Timestamp: time.Now().Unix(),
		Data: &ExecuteTimeEvent{
			PodId:      podId,
			RequestId:  golocal.GoContext.Get().RequestId,
			Action:     action,
			Stage:      stage,
			IsFinished: isFinished,
		},
	}

	if err := p.EventManager.Notify(item); err != nil {
		p.Logger.Error("Send [%s] failed. Error: %+v.", item.Topic, err)
		return err
	}

	return nil
}
