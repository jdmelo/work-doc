package loglistener

import (
	"jd.com/jvirt/jvirt-common/utils/event"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jks-agent/em"
)

type ActionLogger struct {
	logger log.Logger
}

func NewActionLogger(logger log.Logger) *ActionLogger {
	return &ActionLogger{
		logger: logger,
	}
}

func (al *ActionLogger) Listener() event.Listener {
	return al
}

func (al *ActionLogger) Model() event.ListenerModel {
	return event.ModelSync
}

func (al *ActionLogger) Name() string {
	return "ActionListener"
}

func (al *ActionLogger) Listen(event *event.Event) {
	if event.Topic != em.InstanceActionTopic {
		return
	}
	instanceOperationData, ok := event.Data.(*em.InstanceActionEvent)
	if !ok {
		al.logger.Error("[ActionLogger] event.Data is not an object of InstanceOperation .")
		return
	}
	instId := instanceOperationData.InstanceId
	action := instanceOperationData.Action
	stage := instanceOperationData.Stage
	detail := instanceOperationData.Detail
	taskType := instanceOperationData.TaskType
	al.logger.Info("[InstanceOperation] [%s] executed %s in %s; Stage: %s; Detail: %s .",
		instId, action, taskType, stage, detail)
}

func (al *ActionLogger) ListenTopic() string {
	return em.InstanceActionTopic
}
