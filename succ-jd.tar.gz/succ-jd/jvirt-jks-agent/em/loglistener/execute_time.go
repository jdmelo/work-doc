package loglistener

import (
	"sync"

	"jd.com/jvirt/jvirt-common/utils/event"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jks-agent/em"
)

type ExecuteTimer struct {
	logger   log.Logger
	timeMap  sync.Map //存储一个模块的所有时间点
	startMap sync.Map //存储一个模块的开始时间点
}

func NewExecuteTimer(logger log.Logger) *ExecuteTimer {
	return &ExecuteTimer{
		logger: logger,
	}
}

func (et *ExecuteTimer) Listener() event.Listener {
	return et
}

func (et *ExecuteTimer) Model() event.ListenerModel {
	return event.ModelSync
}

func (et *ExecuteTimer) Name() string {
	return "ExecuteTimerListener"
}

func (et *ExecuteTimer) Listen(event *event.Event) {
	if event.Topic != em.ExecuteTimeTopic {
		return
	}
	executeTimeEvent, ok := event.Data.(*em.ExecuteTimeEvent)
	if !ok {
		et.logger.Error("[ActionLogger] event.Data is not an object of InstanceOperation .")
		return
	}

	podId := executeTimeEvent.PodId
	requestId := executeTimeEvent.RequestId
	action := executeTimeEvent.Action
	stage := executeTimeEvent.Stage
	isFinished := executeTimeEvent.IsFinished
	key := requestId + action
	now := event.Timestamp
	if lastTime, ok := et.timeMap.Load(key); ok {
		if isFinished {
			//取出开始时间点，计算整个模块耗时
			if startTime, ok := et.startMap.Load(key); ok {
				interval := now - startTime.(int64)
				et.logger.Info("RequestId: %s[ExecuteTimeListener] %s: %s finished, take time is %ds", requestId, podId, action, interval)
				et.startMap.Delete(key)
			} else {
				et.logger.Info("RequestId: %s[ExecuteTimeListener] %s: function is %s, stage is %s", requestId, podId, action, stage)
			}
			et.timeMap.Delete(key)
		} else {
			//计算上一个时间点到此次上报的时间点的耗时
			interval := now - lastTime.(int64)
			et.logger.Info("RequestId: %s[ExecuteTimeListener] %s: function is %s, stage is %s, take time is %ds", requestId, podId, action, stage, interval)
			et.timeMap.Store(key, now)
		}
	} else {
		if isFinished {
			return
		}
		et.timeMap.Store(key, now)
		et.startMap.Store(key, now)
		et.logger.Info("RequestId: %s[ExecuteTimeListener] %s: %s start, stage is %s.", requestId, podId, action, stage)
	}
}

func (et *ExecuteTimer) ListenTopic() string {
	return em.ExecuteTimeTopic
}
