package em

const (
	InstanceActionTopic = "instance.action"
	ExecuteTimeTopic    = "execute.time"
)

type InstanceActionEvent struct {
	InstanceId string `json:"instance_id"`
	RequestId  string `json:"request_id"`
	TaskType   string `json:"task_type"`
	Action     string `json:"action"`
	Stage      string `json:"stage"`
	Detail     string `json:"detail"`
}

type ExecuteTimeEvent struct {
	RequestId  string `json:"request_id"`
	PodId      string `json:"pod_id"`
	Action     string `json:"action"`
	Stage      string `json:"stage"`
	IsFinished bool   `json:"is_finished"`
}
