package model

type IOLimit struct {
	ReadBytes  uint64
	ReadIops   uint64
	WriteBytes uint64
	WriteIops  uint64
}

type CloudDisk struct {
	VolumeId            string
	FsType              string // xfs | ext4
	DevicePath          string // /dev/nbd* | /export/Data/jvirt/instances/${uuid}/disk
	FormatFs            bool   // 是否格式化磁盘
	IoTune              *IOLimit
	DeleteOnTermination bool
}

type Volume struct {
	Name        string
	JDCloudDisk *CloudDisk
}
