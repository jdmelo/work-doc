package model

type IPAddress struct {
	Version string // ipv4 | ipv6
	Ip      string
	Subnet  string
	Gateway string
}

// virtual interface info. Inject interface info to guest system according to the template and generate XML.
type Network struct {
	DeviceIndex         int
	VpcId               string
	PortId              string
	Mac                 string
	Mtu                 uint64
	DeleteOnTermination bool
	IPAddresses         []*IPAddress
}
