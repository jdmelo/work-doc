package model

type InError interface {
	Error() string
	Rollback() bool // assert rollback
	SetRollback(bool)
	SetMsg(error)
}

type AgentError struct {
	rollback bool   // assert rollback
	msg      string // error msg
}

func (e *AgentError) Error() string {
	return e.msg
}

func (e *AgentError) Rollback() bool {
	return e.rollback
}

func (e *AgentError) SetRollback(flag bool) {
	e.rollback = flag
}

func (e *AgentError) SetMsg(err error) {
	if err != nil {
		e.msg = err.Error()
	} else {
		e.msg = ""
	}
}

func NewAgentError(rollback bool, msg string) *AgentError {
	e := &AgentError{
		rollback: rollback,
		msg:      msg,
	}

	return e
}
