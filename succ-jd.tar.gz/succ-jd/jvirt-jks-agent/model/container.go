package model

import (
	"jd.com/jvirt/jvirt-common/inner/jks"
)

type Container struct {
	Name           string
	IsRebuild      bool
	Command        []string
	Args           []string
	Env            []*jks.Env
	WorkingDir     string
	TTY            bool
	LivenessProbe  *jks.Probe
	ReadinessProbe *jks.Probe
	Resources      *jks.ResourceRequests
	SystemDisk     *CloudDisk
	VolumeMounts   []*jks.VolumeMount
	ImageInfo      *ImageInfo
}
