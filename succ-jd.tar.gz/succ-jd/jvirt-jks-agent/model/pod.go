package model

import (
	"jd.com/jvirt/jvirt-common/inner/jks"
)

type Pod struct {
	ResourceType                  string // nc | pod
	RuntimeType                   string // docker | hyper
	InstanceType                  string
	PodId                         string
	PodPath                       string
	UserId                        string
	UserPin                       string
	Description                   string
	Az                            string
	Hostname                      string
	HostIP                        string
	RestartPolicy                 string
	TerminationGracePeriodSeconds int
	DNSConfig                     *jks.PodDNSConfig
	HostAliases                   []*jks.HostAlias
	LogConfig                     *jks.LogConfig
	Containers                    []*Container
	NetworkType                   string
	PrimaryInterface              *Network
	PhysicalResource              *PhysicalResource
	Volumes                       []*Volume
}

type PhysicalResource struct {
	CpuTotal int64
	CpuSet   []int64
	VCPUPin  map[int64]int64
	MemTotal int64
	NodeSet  []int64
	GpuSet   []string
	EphSet   []string
}

func (pod *Pod) GetAllVolume() []*CloudDisk {
	if pod == nil {
		return nil
	}
	disks := make([]*CloudDisk, 0)
	for _, container := range pod.Containers {
		if container.SystemDisk != nil {
			disks = append(disks, container.SystemDisk)
		}
	}
	for _, disk := range pod.Volumes {
		if disk.JDCloudDisk != nil {
			disks = append(disks, disk.JDCloudDisk)
		}
	}
	return disks
}
