package model

type ImageInfo struct {
	RegistryType     string // DockerHub, JcrHub, SelfHub
	RegistryUrl      string
	RegistryUsername string
	RegistryPassword string
	ImageName        string
	ImageDigest      string // 根据这个信息来区分镜像是否相同和存在.
	HttpProxy        string
	Env              []string // List of environment variable to set in the container
	Cmd              []string // Command to run when starting the container
	WorkingDir       string   // Current directory (PWD) in the command will be launched
	Entrypoint       []string // Entrypoint to run when starting the container
	DownloadPath     string
}
