package utils

type Set struct {
	set map[string]interface{}
}

func NewSet() *Set {
	return &Set{set: make(map[string]interface{})}
}

func (s *Set) AddSubSet(set *Set) {
	for key, value := range set.set {
		s.set[key] = value
	}
}

func (s *Set) Add(value string) bool {
	if _, ok := s.set[value]; ok {
		return false
	}
	s.set[value] = nil
	return true
}

func (s *Set) Contain(value string) bool {
	if _, ok := s.set[value]; ok {
		return true
	}
	return false
}

func (s *Set) Remove(value string) bool {
	if _, ok := s.set[value]; ok {
		delete(s.set, value)
		return true
	}
	return false
}

func (s *Set) AllItems() []string {
	result := make([]string, 0, len(s.set))
	for item := range s.set {
		result = append(result, item)
	}
	return result
}
