package utils

import (
	"fmt"
	"testing"
)

func TestWalkDir(t *testing.T) {
	dirPath := "D:/test/instances/_base"
	result := WalkDir(dirPath)

	for _, item := range result {
		fmt.Println(item)
	}
}
