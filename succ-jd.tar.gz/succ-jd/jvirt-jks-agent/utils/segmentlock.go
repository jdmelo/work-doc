package utils

import "sync"

//分段锁
type SegmentLock struct {
	segments map[string]*sync.Mutex
	mut      *sync.Mutex
}

func NewSegmentLock() *SegmentLock {
	return &SegmentLock{segments: make(map[string]*sync.Mutex), mut: &sync.Mutex{}}
}

func (sl *SegmentLock) Lock(name string, f func() error) error {
	sl.mut.Lock()
	locker, ok := sl.segments[name]
	if !ok {
		locker = &sync.Mutex{}
		sl.segments[name] = locker
	}
	sl.mut.Unlock()
	locker.Lock()
	defer func() {
		locker.Unlock()
		sl.mut.Lock()
		delete(sl.segments, name)
		sl.mut.Unlock()
	}()

	return f()
}
