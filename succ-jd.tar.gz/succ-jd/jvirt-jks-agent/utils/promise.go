package utils

import (
	"github.com/fanliao/go-promise"
)

func PromiseWhenAll(acts ...func() (interface{}, error)) error {
	funcs := make([]interface{}, 0)

	for _, item := range acts {
		funcs = append(funcs, item)
	}

	fu := promise.WhenAll(funcs...)
	resp, err := fu.Get()
	if err != nil {
		return err
	}

	for _, item := range resp.([]interface{}) {
		if item != nil {
			return item.(error)
		}
	}

	return nil
}
