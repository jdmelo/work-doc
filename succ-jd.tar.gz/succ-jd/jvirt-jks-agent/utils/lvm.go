package utils

import (
	"errors"
	"fmt"
	"os/exec"
	"path"
	"strconv"
	"strings"
	"syscall"
	"time"
)

const (
	EXEC_CMD_TIMEOUT = 20 * time.Second
	MKFS_CMD_TIMEOUT = 60 * time.Second
	EXT4             = "ext4"
	XFS              = "xfs"
)

type VGState struct {
	VgName string
	VgSize uint // GB
	VgFree uint // GB
}

func GetVGState(vgName string) (*VGState, error) {
	args := []string{
		"--noheadings",
		"--nosuffix",
		"--units", "B",
		"-o", "vg_name,vg_size,vg_free",
		vgName,
	}

	out, err := Command(EXEC_CMD_TIMEOUT, "vgs", args...)
	if err != nil {
		return nil, err
	}

	vg := strings.TrimSpace(string(out))

	vgSlice := strings.Split(vg, " ")
	vgSize, err := strconv.ParseUint(vgSlice[1], 10, 64)
	if err != nil {
		return nil, err
	}
	vgFree, err := strconv.ParseUint(vgSlice[2], 10, 64)
	if err != nil {
		return nil, err
	}

	info := &VGState{
		VgName: vgName,
		VgSize: uint(vgSize),
		VgFree: uint(vgFree),
	}

	return info, nil
}

func CreateLV(vgName, lvName string, size uint) (string, error) {
	vgInfo, err := GetVGState(vgName)
	if err != nil {
		return "", err
	}
	if vgInfo.VgFree < size {
		return "", errors.New("VG not enough space")
	}

	args := []string{"-L", fmt.Sprintf("%dG", size), "-n", lvName, vgName}
	_, err = Command(EXEC_CMD_TIMEOUT, "lvcreate", args...)
	if err != nil {
		return "", err
	}

	lvPath := path.Join("/dev/", vgName, lvName)

	return lvPath, nil
}

func IsLvExist(vgName, lvName string) (bool, error) {
	args := []string{"--noheadings", "-o", "lv_name", vgName}
	lines, err := CommandLines(EXEC_CMD_TIMEOUT, "lvs", args...)
	if err != nil {
		return false, err
	}

	for _, l := range lines {
		if strings.TrimSpace(l) == lvName {
			return true, nil
		}
	}

	return false, nil
}

func RemoveLV(vgName, lvName string) error {
	lvPath := path.Join("/dev/", vgName, lvName)
	args := []string{"-f", lvPath}
	_, err := Command(EXEC_CMD_TIMEOUT, "lvremove", args...)
	if err != nil {
		return err
	}

	return nil
}

func ExtendLV(vgName, lvName string, size uint) error {
	lvPath := path.Join("/dev/", vgName, lvName)
	args := []string{lvPath, "-L", fmt.Sprintf("%dG", size), "--resizefs"}
	_, err := Command(EXEC_CMD_TIMEOUT, "lvextend", args...)
	if err != nil {
		return err
	}

	return nil
}

func ChangeLV(vgName, lvName string) error {
	lvPath := path.Join("/dev/", vgName, lvName)
	args := []string{"-ay", lvPath}

	_, err := Command(EXEC_CMD_TIMEOUT, "lvchange", args...)
	if err != nil {
		return err
	}

	return nil
}

func GetLVDeviceNumber(vgName, lvName string) (string, error) {
	args := []string{path.Join("/dev/", vgName, lvName)}
	lines, err := CommandLines(EXEC_CMD_TIMEOUT, "lvdisplay", args...)
	if err != nil {
		return "", err
	}

	for _, line := range lines {
		if strings.Contains(line, "Block device") {
			l := strings.TrimSpace(line)
			return strings.TrimSpace(strings.TrimPrefix(l, "Block device")), nil
		}
	}

	return "", errors.New("Get lv device number failed")
}

func MakeFileSystem(path, fsType string) (string, error) {
	var args []string
	switch fsType {
	case EXT4:
		args = []string{"-t", fsType, path}
	case XFS:
		args = []string{"-t", fsType, "-f", path}
	default:
		return "", errors.New("unsupported filesystem " + fsType)
	}

	out, err := Command(MKFS_CMD_TIMEOUT, "mkfs", args...)
	if err != nil {
		return "", err
	}
	ret := strings.TrimSpace(string(out))

	return ret, nil
}

func MountFS(fsPath, mountPoint, fsType string) error {
	args := []string{"-t", fsType, fsPath, mountPoint}

	_, err := Command(EXEC_CMD_TIMEOUT, "mount", args...)
	if err != nil {
		return err
	}

	return nil
}

func IsMounted(path string) (bool, error) {
	lines, err := ReadLines("/etc/mtab")
	if err != nil {
		return false, err
	}

	for _, line := range lines {
		fields := strings.Fields(line)
		if fields[1] == path {
			return true, nil
		}
	}

	return false, nil
}

func UMountFS(mountPoint string) error {
	args := []string{"-f", mountPoint}
	_, err := Command(EXEC_CMD_TIMEOUT, "umount", args...)
	if err != nil {
		return err
	}

	return nil
}

func GetFileSystem(path string) (string, error) {
	if !FileExist(path) {
		return "", errors.New("file not exist")
	}

	args := []string{"-p", "-s", "TYPE", "-o", "value", "--", path}
	out, err := Command(EXEC_CMD_TIMEOUT, "blkid", args...)
	if err != nil {
		if exitError, ok := err.(*exec.ExitError); ok {
			ws := exitError.Sys().(syscall.WaitStatus)
			exitCode := ws.ExitStatus()
			if exitCode == 2 {
				return "", nil
			}
		}
		return "", err
	}
	ret := strings.TrimSpace(string(out))

	return ret, err
}
