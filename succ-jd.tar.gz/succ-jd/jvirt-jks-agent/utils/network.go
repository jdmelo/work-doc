package utils

import (
	"fmt"
	"path"
	"time"

	"jd.com/jvirt/jvirt-common/utils/log"
)

const (
	DEFAULT_TIMEOUT = 30 * time.Second
)

const (
	CMD_IP      = "/usr/sbin/ip"
	CMD_OVS_CTL = "/usr/bin/ovs-vsctl"
)

func DeviceExists(dev string) bool {
	return DirExist(path.Join("/sys/class/net/", dev))
}

func ipCtl(args ...string) error {
	out, err := Command(DEFAULT_TIMEOUT, CMD_IP, args...)
	if err != nil {
		log.Error("Run ip command failed. Output: %s.", string(out))
		return err
	}

	return nil
}

func CreateOvsPort(bridge, dev, mac, instanceId string) error {
	args := []string{
		"--timeout=120",
		"--",
		"--if-exists", "del-port", dev,
		"--", "add-port", bridge, dev,
		"--", "set", "Interface", dev, fmt.Sprintf("external-ids:iface-id=%s", dev),
		"external-ids:iface-status=active",
		fmt.Sprintf("external-ids:attached-mac=%s", mac),
		fmt.Sprintf("external-ids:vm-uuid=%s", instanceId)}

	out, err := Command(120*time.Second, CMD_OVS_CTL, args...)
	if err != nil {
		log.Error("CreateOvsPort failed. Output: %s.", string(out))
		return err
	}

	return nil
}

//检查port是否存在，如果存在返回true, 不存在return false
func CheckOvsPortExist(portId string) bool {
	timeout := 30 * time.Second
	cmd := "ovs-vsctl"
	args := []string{"get", "interface", portId, "ofport"}

	_, err := Command(timeout, cmd, args...)
	if err != nil {
		return false
	}
	return true
}

func DeleteOvsPort(bridge, dev string) error {
	args := []string{"--timeout=120", "--", "--if-exists", "del-port", bridge, dev}

	out, err := Command(120*time.Second, CMD_OVS_CTL, args...)
	if err != nil {
		log.Error("DeleteOvsPort failed. Output: %s.", string(out))
		return err
	}

	return nil
}

func CreateTap(devName string) error {
	args := []string{"tuntap", "add", "dev", devName, "mode", "tap"}

	return ipCtl(args...)
}

func DeleteTap(devName string) error {
	args := []string{"tuntap", "del", "dev", devName, "mode", "tap"}

	return ipCtl(args...)
}

func SetNetDevUp(dev string) error {
	args := []string{"link", "set", dev, "up"}
	return ipCtl(args...)
}

func SetNetDevDown(dev string) error {
	args := []string{"link", "set", dev, "down"}
	return ipCtl(args...)
}
