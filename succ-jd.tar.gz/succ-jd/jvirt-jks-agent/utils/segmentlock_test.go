package utils

import (
	"sync"
	"testing"
	"time"
)

func TestLock(t *testing.T) {
	sl := NewSegmentLock()
	wg := sync.WaitGroup{}
	isExe := false
	for i := 0; i < 100; i++ {
		go func() {
			wg.Add(1)
			sl.Lock("abc", func() error {
				defer wg.Done()
				if isExe {
					return nil
				}
				isExe = true
				println("test")
				return nil

			})

		}()
	}
	for i := 0; i < 100; i++ {
		go func() {
			wg.Add(1)
			sl.Lock("abc", func() error {
				defer wg.Done()
				if isExe {
					return nil
				}
				isExe = true
				println("test")
				return nil

			})

		}()
	}
	time.Sleep(time.Second)
	wg.Wait()
}
