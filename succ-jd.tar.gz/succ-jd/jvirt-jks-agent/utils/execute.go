package utils

import (
	"bytes"
	"encoding/json"
	"errors"
	"os/exec"
	"strings"
	"time"
)

// WaitTimeout waits for the given command to finish with a timeout.
// It assumes the command has already been started.
// If the command times out, it attempts to kill the process.
func waitTimeout(c *exec.Cmd, timeout time.Duration) error {
	timer := time.NewTimer(timeout)
	done := make(chan error)
	go func() { done <- c.Wait() }()
	select {
	case err := <-done:
		timer.Stop()
		return err
	case <-timer.C:
		if err := c.Process.Kill(); err != nil {
			return err
		}
		// wait for the command to return after killing it
		<-done
		return errors.New("command execute timeout")
	}
}

// CombinedOutputTimeout runs the given command with the given timeout and
// returns the combined output of stdout and stderr.
// If the command times out, it attempts to kill the process.
// timeOut is equal to the zero, Close the timeout.
func combinedOutputTimeout(c *exec.Cmd, timeout time.Duration) ([]byte, error) {
	var b bytes.Buffer
	var err error
	c.Stdout = &b
	c.Stderr = &b
	if err = c.Start(); err != nil {
		return nil, err
	}

	if timeout > 0 {
		err = waitTimeout(c, timeout)
	} else {
		c.Wait()
	}

	return b.Bytes(), err
}

func Command(timeOut time.Duration, name string, arg ...string) ([]byte, error) {
	// timeOut Is equal to the zero, Close the timeout.
	a := []string{name}
	a = append(a, arg...)
	cmd := exec.Command(name, arg...)
	return combinedOutputTimeout(cmd, timeOut)
}

func CommandLines(timeout time.Duration, name string, arg ...string) ([]string, error) {
	cmd, err := exec.LookPath(name)
	if err != nil {
		return nil, err
	}

	out, err := Command(timeout, cmd, arg...)
	if err != nil {
		return nil, err
	}

	outStr := strings.TrimSpace(string(out))
	lines := strings.Split(outStr, "\n")

	return lines, nil
}

// parse qemu-img info output info.
type QemuImgInfoOutput struct {
	Filename    string `json:"filename"`
	Format      string `json:"format"`
	VirtualSize uint   `json:"virtual-size"`
	ActualSize  uint   `json:"actual-size"`
	ClusterSize uint   `json:"cluster-size"`
	BackingFile string `json:"backing-filename"`
}

func (out *QemuImgInfoOutput) Parse(output []byte) error {
	err := json.Unmarshal(output, out)

	return err
}

func CmdQemuImgInfo(filePath string) (*QemuImgInfoOutput, error) {
	timeout := 5 * time.Second
	cmd := "qemu-img"
	args := []string{"info", "--output", "json", filePath}

	out, err := Command(timeout, cmd, args...)
	if err != nil {
		return nil, err
	}

	image := new(QemuImgInfoOutput)
	if err := image.Parse(out); err != nil {
		return nil, err
	}

	return image, nil
}
