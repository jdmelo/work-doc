package utils

import "testing"

func TestGetVGState(t *testing.T) {
	vgName := "data_vg"

	ret, err := GetVGState(vgName)
	if err != nil {
		t.Error(err.Error())
	}

	t.Log(ret.VgName, ret.VgSize, ret.VgFree)
}
