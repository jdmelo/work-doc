package utils

import "testing"

func TestCmdQemuImgInfo(t *testing.T) {

}
