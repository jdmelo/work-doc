package utils

import (
	"fmt"
	"testing"
)

func TestValidateIP4(t *testing.T) {
	ip := "192.168.187.14"
	if ValidateIP4(ip) {
		fmt.Println("Validate Pass", ip)
	} else {
		fmt.Println("Validate Fialed", ip)
	}

	ip1 := "a.b.c.d"
	if ValidateIP4(ip1) {
		fmt.Println("Validate Pass", ip1)
	} else {
		fmt.Println("Validate Fialed", ip1)
	}
}
