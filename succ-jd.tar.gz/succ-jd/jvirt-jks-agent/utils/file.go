package utils

import (
	"bufio"
	"errors"
	"os"
	"path"
	"path/filepath"
	"strings"
)

func WriteToFile(fileName string, context string, flags int, mode os.FileMode) error {

	if !DirExist(path.Dir(fileName)) {
		err := CreateDir(path.Dir(fileName), mode)
		if err != nil {
			return err
		}
	}
	newFile, err := os.OpenFile(fileName, flags, mode)
	if err != nil {
		return err
	}
	defer newFile.Close()

	_, err = newFile.WriteString(context)

	if err != nil {
		return err
	}

	return nil
}

func RemoveFile(fileName string) error {
	if FileExist(fileName) {
		err := os.Remove(fileName)
		return err
	}

	return nil
}

func RenameFile(oldPath, newPath string) error {
	err := os.Rename(oldPath, newPath)

	return err
}

func CreateDir(dirPath string, mode os.FileMode) error {

	if DirExist(dirPath) {
		os.Chmod(dirPath, mode)
		return nil
	}

	err := os.MkdirAll(dirPath, mode)

	return err
}

func RemoveDir(dirPath string) error {
	if DirExist(dirPath) {
		err := os.Remove(dirPath)
		return err
	}

	return nil
}

func DirExist(dirPath string) bool {
	state, err := os.Stat(dirPath)
	if err != nil {
		return false
	}

	if state.IsDir() {
		return true
	} else {
		return false
	}
}

func FileExist(filePath string) bool {
	state, err := os.Stat(filePath)
	if err != nil {
		return false
	}

	if state.IsDir() {
		return false
	} else {
		return true
	}
}

//列出dirPath下的所有对象，包括子目录和子目录下的文件
func WalkDir(dirPath string) []string {
	result := make([]string, 0)
	walkFunc := func(path string, info os.FileInfo, err error) error {
		if path != dirPath {
			_, filePath := filepath.Split(path)
			result = append(result, filePath)
		}
		return nil
	}
	filepath.Walk(dirPath, walkFunc)
	return result
}

//列出dirPath下的所有文件，不包括子目录和子目录下的文件
func ListFilesInDir(dirPath string) []string {
	result := make([]string, 0)
	walkFunc := func(path string, info os.FileInfo, err error) error {
		if path != dirPath {
			fileInfo, _ := os.Stat(path)
			if fileInfo.IsDir() {
				return errors.New("This is not file")
			}
			_, filePath := filepath.Split(path)
			result = append(result, filePath)
		}
		return nil
	}
	filepath.Walk(dirPath, walkFunc)
	return result
}

func RemoveAll(dirPath string) error {
	if DirExist(dirPath) {
		err := os.RemoveAll(dirPath)
		return err
	}
	return nil
}

func ReadLines(filename string) ([]string, error) {
	f, err := os.Open(filename)
	if err != nil {
		return []string{""}, err
	}
	defer f.Close()

	var ret []string

	r := bufio.NewReader(f)
	for {
		line, err := r.ReadString('\n')
		if err != nil {
			break
		}
		ret = append(ret, strings.Trim(line, "\n"))
	}

	return ret, nil
}
