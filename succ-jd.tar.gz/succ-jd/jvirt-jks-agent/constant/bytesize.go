package constant

const (
	SIZE_KB = 1 << (10 * 1) // KB to B
	SIZE_MB = 1 << (10 * 2) // MB to B
	SIZE_GB = 1 << (10 * 3) // GB to B
	SIZE_TB = 1 << (10 * 4) // TB to B
)
