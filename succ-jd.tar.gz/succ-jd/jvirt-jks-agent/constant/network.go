package constant

const (
	OVSKernel = "ovs-kernel"
	OVSDpdk   = "ovs-dpdk"
)

const (
	Ipv4 = "ipv4"
	Ipv6 = "ipv6"
)
