package constant

// operation action type.
const (
	CreatePodAction  = "create.pod"
	StartPodAction   = "start.pod"
	StopPodAction    = "stop.pod"
	DeletePodAction  = "delete.pod"
	MigratePodAction = "migrate.pod"
	RebuildPodAction = "rebuild.pod"
	CleanPodAction   = "clean.pod"
	ResizePodAction  = "resize.pod"
	ExtendVolumeAction = "extend.volume"
)

// stage
const (
	StartStage    = "start"
	FailedStage   = "failed"
	FinishedStage = "finished"
)

const OK = "OK"

const CreateByJks = "create_by_jks"
