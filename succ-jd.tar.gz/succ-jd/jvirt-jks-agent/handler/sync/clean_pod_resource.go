package sync

import (
	"encoding/json"
	"runtime/debug"

	"jd.com/jvirt/jvirt-common/inner/jks/agent"
	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/url"
	"jd.com/jvirt/jvirt-jks-agent/constant"
)

func (p *PodHandler) CleanPodResource(req *url.Request, resp *url.Response) common.JvirtError {
	p.Logger.Debug("CleanPodResource start...")

	defer func() {
		if e := recover(); e != nil {
			p.Logger.Error("CleanPodResource panic.\nTrace: %s.", debug.Stack())
		}
	}()

	params := &agent.CleanResourceRequest{}
	if err := json.Unmarshal(req.Content, params); err != nil {
		p.Logger.Error("CleanPodResource Json unmarshal failed. Error: %s.", err.Error())
		return common.NewSysErr(err)
	}
	p.Logger.Debug("CleanPodResource Params: %+v", *params)

	podId := params.PodId

	// 调用jks-api-server接口,获取实例信息
	pod, err := p.JksApi.GetRecordPodById(podId)
	if err != nil {
		p.Logger.Error("GetInstanceFromJksApi failed. ContainerId: %s; Error: %#v.", podId, err)
		return common.NewError(common.RErrInstance, common.TErrNotFound, common.PErrId, err.Error())
	}
	// 生成参数
	reqParams, err := p.Adapter.ConvertPodCommon2Agent(constant.CleanPodAction, pod)
	if err != nil {
		p.Logger.Error("[CleanPodResource] ConvertPodCommon2Agent failed. PodId: %s, Error: %s.", podId, err.Error())
		return common.NewSysErr(err)
	}

	if err := p.ServiceManager.CleanPodResource(reqParams); err != nil {
		p.Logger.Error("[CleanPodResource] service.CleanPodResource failed. PodId: %s, Error: %s", podId, err.Error())
		return common.NewSysErr(err)
	}

	data := &common.CommonResponse{}
	resp.Response = data

	return nil
}
