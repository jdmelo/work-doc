package sync

import (
	"encoding/json"
	"runtime/debug"

	"jd.com/jvirt/jvirt-common/inner/jks/agent"
	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/url"
)

func (p *PodHandler) GetContainerLogs(req *url.Request, resp *url.Response) common.JvirtError {
	p.Logger.Debug("GetContainerLogs start...")

	defer func() {
		if e := recover(); e != nil {
			p.Logger.Error("GetContainerLogs panic.\nTrace: %s.", debug.Stack())
		}
	}()

	params := &agent.GetContainerLogsRequest{}
	if err := json.Unmarshal(req.Content, params); err != nil {
		p.Logger.Error("GetContainerLogs Json unmarshal failed. Error: %#v.", err)
		return common.NewSysErr(err)
	}

	p.Logger.Debug("GetContainerLogs Params: %+v", *params)

	result, err := p.ServiceManager.GetContainerLogs(params)
	if err != nil {
		p.Logger.Error("GetContainerLogs failed. Error: %s.", err.Error())
		return common.NewSysErr(err)
	}

	consoleLog := &agent.ContainerLogResp{
		Content: result,
	}

	respData := &common.CommonResponse{
		Data: consoleLog,
	}
	resp.Response = respData

	return nil
}
