package sync

import (
	"jd.com/jvirt/jvirt-common/inner/jks/agent"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/url"
	"jd.com/jvirt/jvirt-jks-agent/adapter"
	"jd.com/jvirt/jvirt-jks-agent/httpclient"
	"jd.com/jvirt/jvirt-jks-agent/service"
)

type PodHandler struct {
	Logger         log.Logger               `inject:""`
	ServiceManager *service.PodService      `inject:""`
	JksApi         *httpclient.JksApiClient `inject:""`
	Adapter        *adapter.ModelAdapter    `inject:""`
}

func (p *PodHandler) RegisterHandler(r *url.Router) {
	r.RegisterHandleFunc(agent.ActionGetContainerLogs, p.GetContainerLogs)
	r.RegisterHandleFunc(agent.ActionMigrateFailedCleanDst, p.CleanPodResource)
	r.RegisterHandleFunc(agent.ActionMigrateFinishCleanSrc, p.CleanPodResource)
	r.RegisterHandleFunc(agent.ActionResizePodRollBack, p.ResizePodRollBack)
}
