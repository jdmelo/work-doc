package sync

import (
	"encoding/json"
	"runtime/debug"

	"jd.com/jvirt/jvirt-common/inner/jks/agent"
	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/url"
	"jd.com/jvirt/jvirt-jks-agent/constant"
)

func (p *PodHandler) ResizePodRollBack(req *url.Request, resp *url.Response) common.JvirtError {
	p.Logger.Debug("ResizePodRollBack start...")
	params := &agent.ResizePodRequest{}
	if err := json.Unmarshal(req.Content, params); err != nil {
		p.Logger.Error("ResizePodRollBack Json unmarshal failed. Error: %s.", err.Error())
		return common.NewSysErr(err)
	}
	p.Logger.Debug("ResizePodRollBack Params: %+v", *params)

	podId := params.PodId
	defer func() {
		if e := recover(); e != nil {
			p.Logger.Error("ResizePodRollBack panic.\n Trace: %s.", debug.Stack())
		}
	}()

	pod, err := p.JksApi.GetPodById(podId, "")
	if err != nil {
		p.Logger.Error("[ResizePodRollBack] GetPodFromJksApi Failed. PodId: %s; Error: %s.", podId, err.Error())
		return common.NewError(common.RErrInstance, common.TErrNotFound, common.PErrId, err.Error())
	}

	resizeArgs, err := p.Adapter.ConvertPodCommon2Agent(constant.ResizePodAction, pod)
	if err != nil {
		p.Logger.Error("[ResizePodRollBack] ConvertPodCommon2Agent Failed. PodId: %s, Error: %s.", podId, err.Error())
		return common.NewError(common.RErrPod, common.TErrInvalid, common.PErrRequestId, err.Error())
	}

	p.Logger.Debug("[ResizePodRollBack] SameNode podId: %s, resizeArgs: %v", podId, *resizeArgs)
	if err := p.ServiceManager.ResizePod(resizeArgs); err != nil {
		p.Logger.Error("[ResizePodRollBack] ResizePod Pod failed. PodId: %s, Error: %#v.", podId, err)
		return common.NewError(common.RErrAgent, common.TErrError, common.PErrXCGroup, err.Error())
	}

	data := &common.CommonResponse{}
	resp.Response = data
	return nil
}
