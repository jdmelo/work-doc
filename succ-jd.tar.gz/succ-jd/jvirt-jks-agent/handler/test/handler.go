package test

import (
	"encoding/json"
	"time"

	"jd.com/jvirt/jvirt-common/inner/jks/agent"
	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/url"
)

type TestHandler struct {
	Logger log.Logger `inject:""`
}

func (p *TestHandler) Ping(req *url.Request, resp *url.Response) common.JvirtError {
	params := &agent.PingRequest{}
	if err := json.Unmarshal(req.Content, params); err != nil {
		p.Logger.Error("[Ping] Json unmarshal failed. Error: %s.", err.Error())
		return common.NewSysErr(err)
	}
	p.Logger.Debug("[Ping] params: %+v", *params)

	time.Sleep(time.Second * 5)
	resp.Response = &common.CommonResponse{}

	p.Logger.Debug("[Ping] finished")

	return nil
}

func (p *TestHandler) RegisterHandler(r *url.Router) {
	r.RegisterHandleFunc(agent.ActionPing, p.Ping)
}
