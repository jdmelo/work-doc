package async

import (
	"encoding/json"
	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	"jd.com/jvirt/jvirt-jks-agent/constant"
)

func (p *TaskDispatcher) ExecResizePod(task *jks.Task, updateTask *api.UpdateTaskRequest) error {
	p.Logger.Info("[ExecResizePod] statr running ResizePod, task: %v,  updateTask: %v", *task, *updateTask)
	taskId := task.TaskId
	podId := task.ReferId

	// 调用jks-api-server接口,获取实例信息
	pod, err := p.JksApi.GetPodById(podId, "")
	if err != nil {
		p.Logger.Error("[ExecResizePod] GetPodFromJksApi failed. TaskId: %d, InstanceId: %s; Error: %s.", taskId, podId, err.Error())
		return err
	}
	if pod == nil {
		p.Logger.Error("[ExecResizePod] GetPodFromJksApi result is nil. TaskId: %d, PodId: %s.", taskId, podId)
		return err
	}
	argsJson, err := json.Marshal(pod)
	if err == nil {
		p.Logger.Debug("[ExecResizePod] GetPodFromJksApi result: %s", argsJson)
	}

	// 生成参数
	taskContent := &api.ResizePodResources{}
	if err := json.Unmarshal([]byte(task.Content), taskContent); err != nil {
		return err
	}
	pod.InstanceType = taskContent.InstanceType

	if pod.ResourceType == jks.ResourceTypePod {
		resourceMap := make(map[string]*api.ResourceRequestsSpec)
		for _, resource := range taskContent.Resources {
			resourceMap[resource.Name] = resource.Resources
		}
		for _, container := range pod.Containers {
			if resource, ok := resourceMap[container.Name]; ok {
				resourceRequests := container.Resources

				if resource.Limits != nil {
					limit := resourceRequests.Limits
					if resource.Limits.CPU != nil {
						limit.CPU = *resource.Limits.CPU
					}
					if resource.Limits.MemoryMB != nil {
						limit.MemoryMB = *resource.Limits.MemoryMB
					}
				}

				if resource.Requests != nil {
					request := resourceRequests.Requests
					if resource.Requests.CPU != nil {
						request.CPU = *resource.Requests.CPU
					}
					if resource.Requests.MemoryMB != nil {
						request.MemoryMB = *resource.Requests.MemoryMB
					}
				}

				container.Resources = resourceRequests
			}
		}

		argsJson, err = json.Marshal(pod)
		if err == nil {
			p.Logger.Debug("[ExecResizePod] GetPodFromJksApi result: %s", argsJson)
		}
	}

	if taskContent.ResizeType == jks.ResizePodSameNode {
		p.Logger.Info("[ExecResizePod] SameNode podId: %s, host: %s", podId, pod.HostIP)

		resizeArgs, err := p.Adapter.ConvertPodCommon2Agent(constant.ResizePodAction, pod)
		if err != nil {
			p.Logger.Error("[ExecResizePod] ConvertPodCommon2Agent failed. TaskId: %d, PodId: %s, Error: %s.", taskId, podId, err.Error())
			return err
		}

		p.Logger.Debug("[ExecResizePod] SameNode podId: %s, resizeArgs: %v", podId, *resizeArgs)
		if err := p.ServiceManager.ResizePod(resizeArgs); err != nil {
			p.Logger.Error("ResizePod Pod failed. TaskId: %d, PodId: %s, Error: %#v.", taskId, podId, err)
			updateTask.Rollback = err.Rollback()
			updateTask.TaskState = jks.TaskFailed
			updateTask.FailReason = jks.PodStatusReasonPodResizeFailed
			updateTask.FailMessage = err.Error()
		} else {
			updateTask.TaskState = jks.TaskFinished
		}
	}

	//迁移
	if taskContent.ResizeType == jks.ResizePodDiffNode {
		p.Logger.Info("[ExecResizePod] DiffNode podId: %s, host: %s", podId, pod.HostIP)

		migrateArgs, err := p.Adapter.ConvertPodCommon2Agent(constant.MigratePodAction, pod)
		if err != nil {
			p.Logger.Error("[ExecResizePod] ConvertPodCommon2Agent failed. TaskId: %d, PodId: %s, Error: %s.", taskId, podId, err.Error())
			return err
		}

		p.Logger.Debug("[ExecResizePod] DiffNode podId: %s, resizeArgs: %v", podId, *migrateArgs)
		if err := p.ServiceManager.MigratePod(migrateArgs); err != nil {
			p.Logger.Error("Resize migrate instance failed. TaskId: %d, InstanceId: %s, Error: %#v.", taskId, podId, err)
			updateTask.Rollback = err.Rollback()
			updateTask.TaskState = jks.TaskFailed
			updateTask.FailReason = jks.PodStatusReasonPodResizeFailed
			updateTask.FailMessage = err.Error()
		} else {
			updateTask.TaskState = jks.TaskFinished
		}
	}

	return nil
}
