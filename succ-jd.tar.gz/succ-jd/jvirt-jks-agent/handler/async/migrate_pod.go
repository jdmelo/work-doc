package async

import (
	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	"jd.com/jvirt/jvirt-jks-agent/constant"
)

func (p *TaskDispatcher) ExecMigratePod(task *jks.Task, updateTask *api.UpdateTaskRequest) error {

	taskId := task.TaskId
	podId := task.ReferId

	// 调用jks-api-server接口,获取实例信息
	// hostIp非必传，因为pod目前还没有迁到这个节点，所以不能用hostip查询
	pod, err := p.JksApi.GetPodById(podId, "")
	if err != nil {
		p.Logger.Error("[ExecMigratePod] GetPodFromJksApi failed. TaskId: %d, InstanceId: %s; Error: %s.", taskId, podId, err.Error())
		return err
	}

	// 生成参数
	migrateArgs, err := p.Adapter.ConvertPodCommon2Agent(constant.MigratePodAction, pod)
	if err != nil {
		p.Logger.Error("[ExecDeletePod] ConvertPodCommon2Agent failed. TaskId: %d, PodId: %s, Error: %s.", taskId, podId, err.Error())
		return err
	}

	if err := p.ServiceManager.MigratePod(migrateArgs); err != nil {
		p.Logger.Error("Migrate Instance failed. TaskId: %d, InstanceId: %s, Error: %#v.", taskId, podId, err)
		updateTask.Rollback = err.Rollback()
		updateTask.TaskState = jks.TaskFailed
		updateTask.FailReason = jks.PodStatusReasonPodMigrateFailed
		updateTask.FailMessage = err.Error()
	} else {
		updateTask.TaskState = jks.TaskFinished
	}

	return nil
}
