package async

import (
	"encoding/json"
	"strings"

	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	"jd.com/jvirt/jvirt-jks-agent/constant"
)

func (p *TaskDispatcher) ExecRebuildPod(task *jks.Task, updateTask *api.UpdateTaskRequest) error {
	podId := task.ReferId
	taskId := task.TaskId

	// 调用jvirt-jks-api接口,获取实例信息
	pod, err := p.JksApi.GetPodById(podId, task.HostIp)
	if err != nil {
		p.Logger.Error("[ExecRebuildPod] GetPodFromJksApi failed. TaskId: %d, PodId: %s; Error: %s.", taskId, podId, err.Error())
		return err
	}
	if pod == nil {
		p.Logger.Error("[ExecRebuildPod] GetPodFromJksApi result is nil. TaskId: %d, PodId: %s.", taskId, podId)
		return err
	}

	argsJson, err := json.Marshal(pod)
	if err == nil {
		p.Logger.Debug("[ExecRebuildPod] GetPodFromJksApi result: %s", argsJson)
	}

	// 生成参数
	rebuildArgs, err := p.Adapter.ConvertPodCommon2Agent(constant.RebuildPodAction, pod)
	if err != nil {
		p.Logger.Error("[ExecRebuildPod] ConvertPodCommon2Agent failed. TaskId: %d, PodId: %s, Error: %s.", taskId, podId, err.Error())
		return err
	}

	rebuildContainerMap := make(map[string]interface{})
	for _, cName := range strings.Split(task.Content, ",") {
		rebuildContainerMap[cName] = nil
	}

	for _, container := range rebuildArgs.Containers {
		if _, ok := rebuildContainerMap[container.Name]; ok {
			container.IsRebuild = true
		}

		if rebuildArgs.ResourceType == jks.ResourceTypeNativeContainer {
			container.IsRebuild = true
		}
	}

	if inErr := p.ServiceManager.RebuildPod(rebuildArgs); inErr != nil {
		p.Logger.Error("[ExecRebuildPod] service.RebuildPod failed. TaskId: %v, PodId: %s, Rollback: %v, Error: %s",
			taskId, podId, inErr.Rollback(), inErr.Error())
		updateTask.TaskState = jks.TaskFailed
		updateTask.Rollback = inErr.Rollback()
		updateTask.FailReason = jks.PodStatusReasonPodRebuildFailed
		updateTask.FailMessage = inErr.Error()
	} else {
		p.Logger.Info("[ExecRebuildPod] RebuildPod success. TaskId: %v, PodId: %s.", taskId, podId)
		updateTask.TaskState = jks.TaskFinished
	}

	return nil
}
