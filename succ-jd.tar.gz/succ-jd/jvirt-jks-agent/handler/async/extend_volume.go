package async

import (
	"encoding/json"
	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	"jd.com/jvirt/jvirt-jks-agent/constant"
)

func (p *TaskDispatcher) ExecExtendVolume(task *jks.Task, updateTask *api.UpdateTaskRequest) error {
	podId := task.ReferId
	taskId := task.TaskId

	// 调用jvirt-jks-api接口,获取实例信息
	pod, err := p.JksApi.GetPodById(podId, task.HostIp)
	if err != nil {
		p.Logger.Error("[ExecExtendVolume] GetPodFromJksApi failed. TaskId: %d, PodId: %s; Error: %s.", taskId, podId, err.Error())
		return err
	}
	if pod == nil {
		p.Logger.Error("[ExecExtendVolume] GetPodFromJksApi result is nil. TaskId: %d, PodId: %s.", taskId, podId)
		return err
	}

	// Debug 1
	argsJson, err := json.Marshal(pod)
	if err == nil {
		p.Logger.Debug("[ExecExtendVolume] GetPodFromJksApi result: %s", argsJson)
	}

	// 生成参数
	extendVolArg, err := p.Adapter.ConvertPodCommon2Agent(constant.ExtendVolumeAction, pod)
	if err != nil {
		p.Logger.Error("[ExecExtendVolume] ConvertPodCommon2Agent failed. TaskId: %d, PodId: %s, Error: %s.", taskId, podId, err.Error())
		return err
	}

	// 更新参数 -- task content
	taskContent := &api.ExtendPodVolume{}
	if err := json.Unmarshal([]byte(task.Content), taskContent); err != nil {
		return err
	}

	// Debug 2
	argsJson, err = json.Marshal(pod)
	if err == nil {
		p.Logger.Debug("[ExecExtendVolume] GetPodFromJksApi result: %s", argsJson)
	}

	if err := p.ServiceManager.ExtendPodVolume(taskContent, extendVolArg); err != nil {
		p.Logger.Error("Extend Volume failed. TaskId: %d, InstanceId: %s, Error: %#v.", taskId, podId, err)
		updateTask.Rollback = err.Rollback()
		updateTask.TaskState = jks.TaskFailed
		updateTask.FailReason = jks.VolumeStatusReasonVolumeExtendFailed
		updateTask.FailMessage = err.Error()
	} else {
		updateTask.TaskState = jks.TaskFinished
	}


	return nil
}
