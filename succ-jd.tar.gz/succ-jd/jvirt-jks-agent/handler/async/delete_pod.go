package async

import (
	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	"jd.com/jvirt/jvirt-jks-agent/constant"
)

func (p *TaskDispatcher) ExecDeletePod(task *jks.Task, updateTask *api.UpdateTaskRequest) error {
	podId := task.ReferId
	taskId := task.TaskId

	// 调用jvirt-jks-api接口,获取实例信息
	pod, err := p.JksApi.GetPodById(podId, task.HostIp)
	if err != nil {
		p.Logger.Error("[ExecDeletePod] GetPodFromJksApi failed. TaskId: %d, PodId: %s; Error: %s.", taskId, podId, err.Error())
		return err
	}

	// 生成参数
	deleteArgs, err := p.Adapter.ConvertPodCommon2Agent(constant.DeletePodAction, pod)
	if err != nil {
		p.Logger.Error("[ExecDeletePod] ConvertPodCommon2Agent failed. TaskId: %d, PodId: %s, Error: %s.", taskId, podId, err.Error())
		return err
	}

	if err := p.ServiceManager.DeletePod(deleteArgs); err != nil {
		p.Logger.Error("[ExecDeletePod] service.DeletePod failed. TaskId: %d, PodId: %s, Error: %#v.", taskId, podId, err)
		updateTask.TaskState = jks.TaskFailed
		updateTask.Rollback = err.Rollback()
		updateTask.FailReason = jks.PodStatusReasonPodDeleteFailed
		updateTask.FailMessage = err.Error()
	} else {
		p.Logger.Info("[ExecDeletePod] DeletePod success. TaskId: %v, PodId: %s.", taskId, podId)
		updateTask.TaskState = jks.TaskFinished
	}

	return nil
}
