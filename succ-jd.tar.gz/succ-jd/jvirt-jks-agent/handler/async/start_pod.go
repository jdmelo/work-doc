package async

import (
	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	"jd.com/jvirt/jvirt-jks-agent/constant"
)

func (p *TaskDispatcher) ExecStartPod(task *jks.Task, updateTask *api.UpdateTaskRequest) error {
	podId := task.ReferId
	taskId := task.TaskId

	// 调用jvirt-jks-api接口,获取实例信息
	pod, err := p.JksApi.GetPodById(podId, task.HostIp)
	if err != nil {
		p.Logger.Error("[ExecStartPod] GetPodFromJksApi failed. TaskId: %d, PodId: %s; Error: %s.", taskId, podId, err.Error())
		return err
	}

	// 生成参数
	startArgs, err := p.Adapter.ConvertPodCommon2Agent(constant.StartPodAction, pod)
	if err != nil {
		p.Logger.Error("[ExecStartPod] ConvertPodCommon2Agent failed. TaskId: %d, PodId: %s, Error: %s.", taskId, podId, err.Error())
		return err
	}

	if err := p.ServiceManager.StartPod(startArgs); err != nil {
		p.Logger.Error("[ExecStartPod] service.StartPod failed. TaskId: %d, PodId: %s, Error: %s.", taskId, podId, err.Error())
		updateTask.Rollback = err.Rollback()
		updateTask.TaskState = jks.TaskFailed
		updateTask.FailReason = jks.PodStatusReasonPodStartFailed
		updateTask.FailMessage = err.Error()
	} else {
		updateTask.TaskState = jks.TaskFinished
	}

	return nil
}
