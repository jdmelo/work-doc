package async

import (
	"encoding/json"

	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	"jd.com/jvirt/jvirt-jks-agent/constant"
)

func (p *TaskDispatcher) ExecCreatePod(task *jks.Task, updateTask *api.UpdateTaskRequest) error {
	podId := task.ReferId
	taskId := task.TaskId

	// 调用jvirt-jks-api接口,获取实例信息
	pod, err := p.JksApi.GetPodById(podId, task.HostIp)
	if err != nil {
		p.Logger.Error("[ExecCreatePod] GetPodFromJksApi failed. TaskId: %d, PodId: %s; Error: %s.", taskId, podId, err.Error())
		return err
	}
	if pod == nil {
		p.Logger.Error("[ExecCreatePod] GetPodFromJksApi result is nil. TaskId: %d, PodId: %s.", taskId, podId)
		return err
	}

	argsJson, err := json.Marshal(pod)
	if err == nil {
		p.Logger.Debug("[ExecCreatePod] GetPodFromJksApi result: %s", argsJson)
	}

	// 生成参数
	createArgs, err := p.Adapter.ConvertPodCommon2Agent(constant.CreatePodAction, pod)
	if err != nil {
		p.Logger.Error("[ExecCreatePod] ConvertPodCommon2Agent failed. TaskId: %d, PodId: %s, Error: %s.", taskId, podId, err.Error())
		return err
	}
	if inErr := p.ServiceManager.CreatePod(createArgs); inErr != nil {
		p.Logger.Error("[ExecCreatePod] service.CreatePod failed. TaskId: %v, PodId: %s, Rollback: %v, Error: %s",
			taskId, podId, inErr.Rollback(), inErr.Error())
		updateTask.TaskState = jks.TaskFailed
		updateTask.Rollback = inErr.Rollback()
		updateTask.FailReason = jks.PodStatusReasonPodCreateFailed
		updateTask.FailMessage = inErr.Error()
	} else {
		p.Logger.Info("[ExecCreatePod] CreatePod success. TaskId: %v, PodId: %s.", taskId, podId)
		updateTask.TaskState = jks.TaskFinished
	}

	return nil
}
