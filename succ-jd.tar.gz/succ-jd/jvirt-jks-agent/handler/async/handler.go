package async

import (
	"encoding/json"

	"jd.com/jvirt/jvirt-common/inner/jks/agent"
	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/url"
)

type TaskHandler struct {
	Logger     log.Logger      `inject:""`
	Dispatcher *TaskDispatcher `inject:""`
}

func (p *TaskHandler) LaunchTask(req *url.Request, resp *url.Response) common.JvirtError {
	params := &agent.LaunchTaskRequest{}
	if err := json.Unmarshal(req.Content, params); err != nil {
		p.Logger.Error("Json unmarshal failed. Error: %#v.", err)
		return common.NewSysErr(err)
	}
	p.Logger.Debug("LaunchTask params: %+v", *params)

	if err := p.Dispatcher.Dispatcher(params.Task); err != nil {
		p.Logger.Error("Dispatcher async failed. Error: %s, Detail: %s.", err.Error(), err.Detail())
		return err
	}

	data := &common.CommonResponse{}
	resp.Response = data

	return nil
}

func (p *TaskHandler) RegisterHandler(r *url.Router) {
	r.RegisterHandleFunc(agent.ActionLaunchTask, p.LaunchTask)
}
