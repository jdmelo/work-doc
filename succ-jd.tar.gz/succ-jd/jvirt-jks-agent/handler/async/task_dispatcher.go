package async

import (
	"errors"
	"runtime/debug"
	"sync"
	"time"

	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/golocal"
	"jd.com/jvirt/jvirt-common/utils/limit"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/runtime"
	"jd.com/jvirt/jvirt-common/utils/server"
	"jd.com/jvirt/jvirt-jks-agent/adapter"
	"jd.com/jvirt/jvirt-jks-agent/cfg"
	"jd.com/jvirt/jvirt-jks-agent/httpclient"
	"jd.com/jvirt/jvirt-jks-agent/service"
)

const (
	CleanFinishTaskInternal = 60 * 60 * 24 // 单位：秒
)

type ExecTaskFunc func(task *jks.Task, updateTask *api.UpdateTaskRequest) error

/*
 职责：
 1.管理整个任务周期;
 2.保障task串行;
 3.任务的action上报.

 三个队列以管道的形式使用：
 doingQueue->pushingQueue->finishedTasked
 1:添加任务是调用AddTaskToDoingTasks方法。
 2:任务执行完成添加到pushingTasks，定期push，直到push成功，从pushingTasks移除，添加到finishedTask列表。
 3:finishedTasks保存已经push成功的task，会定时清理，防止内存泄露。
*/
const (
	CREATE_INSTANCE_LIMIT = 20
)
const (
	LIMIT_TIMEOUT = time.Second * 5
)

type TaskDispatcher struct {
	*server.Server
	queueLock         *sync.Mutex
	submitTask        chan *api.UpdateTaskRequest      // Submit async from doingQueue to pushingQueue.
	doingQueue        map[int64]*jks.Task              // 正在执行任务列表
	pushingQueue      map[int64]*api.UpdateTaskRequest // 等待需要定期更新的任务列表
	finishedQueue     map[int64]*api.UpdateTaskRequest // 处理结束的任务列表,需要定期清理否则内存泄露
	registerTaskFuncs map[string]ExecTaskFunc
	confine           *limit.Confine             //limit
	Logger            log.Logger                 `inject:""`
	ComputeCfg        *cfg.ComputeConfig         `inject:""`
	JksApi            *httpclient.JksApiClient   `inject:""`
	JksAgent          *httpclient.JksAgentClient `inject:""`
	ServiceManager    *service.PodService        `inject:""`
	Adapter           *adapter.ModelAdapter      `inject:""`
}

func NewTaskDispatcher() *TaskDispatcher {

	td := &TaskDispatcher{
		queueLock:         &sync.Mutex{},
		submitTask:        make(chan *api.UpdateTaskRequest),
		doingQueue:        make(map[int64]*jks.Task),
		pushingQueue:      make(map[int64]*api.UpdateTaskRequest),
		finishedQueue:     make(map[int64]*api.UpdateTaskRequest),
		registerTaskFuncs: make(map[string]ExecTaskFunc),
		confine:           limit.NewConfine(),
	}

	td.registerTaskFuncs[jks.PodCreateTask] = td.ExecCreatePod
	td.registerTaskFuncs[jks.PodStartTask] = td.ExecStartPod
	td.registerTaskFuncs[jks.PodStopTask] = td.ExecStopPod
	td.registerTaskFuncs[jks.PodDeleteTask] = td.ExecDeletePod
	td.registerTaskFuncs[jks.PodMigrateTask] = td.ExecMigratePod
	td.registerTaskFuncs[jks.PodRebuildTask] = td.ExecRebuildPod
	td.registerTaskFuncs[jks.PodResizeTask] = td.ExecResizePod
	td.registerTaskFuncs[jks.PodExtendVolumeTask] = td.ExecExtendVolume

	td.confine.AddLimit(jks.PodCreateTask, CREATE_INSTANCE_LIMIT)
	td.Server = server.NewServer(td.doStart, td.doStop)

	return td
}

func (p *TaskDispatcher) doStart() error {
	p.Logger.Debug("Invoke TaskDispatcher doStart ......")
	// 服务启动前先初始化,调用jvirt-jks-api接口获取instance列表.
	go func() {
		p.doPushingQueue()
	}()

	p.Logger.Debug("Invoke TaskDispatcher doStart finished.")

	return nil
}

func (p *TaskDispatcher) doStop() {
	p.Logger.Debug("Invoke TaskDispatcher doStop.")
}

func (p *TaskDispatcher) AddTaskToDoingQueue(task *jks.Task) error {
	p.queueLock.Lock()
	defer p.queueLock.Unlock()

	// 检查任务是否在doingTasks任务列表
	if item, ok := p.doingQueue[task.TaskId]; ok {
		p.Logger.Warn("Conflict The async [%d] already exist in the doingQueue.", item.TaskId)
		return errors.New("Conflict the async already exist.")
	}

	// 检查任务是否在pushFailedTasks任务列表
	if item, ok := p.pushingQueue[task.TaskId]; ok {
		p.Logger.Warn("Conflict The async [%d] already exist in the pushingQueue.", item.TaskId)
		return errors.New("Conflict the async already exist.")
	}

	// 检查任务是否在finishTasks任务列表
	if item, ok := p.finishedQueue[task.TaskId]; ok {
		p.Logger.Warn("Conflict The async [%d] already exist in the finishedQueue.", item.TaskId)
		return errors.New("Conflict the async already exist.")
	}

	// 检测task的对象instance是否正在处理任务
	for _, doing := range p.doingQueue {
		if doing.ReferId == task.ReferId {
			p.Logger.Warn("Conflict The sync [%s] is running async [%d]. Not accept async [%d].",
				doing.ReferId, doing.TaskId, task.TaskId)
			return errors.New("Conflict the sync is running async.")
		}
	}
	// 限制task数量
	if err := p.confine.Add(task.TaskType, LIMIT_TIMEOUT); err != nil {
		p.Logger.Debug("Dispatcher debug limit failed, %s; err: %s", task.ReferId, err.Error())
		return err
	}
	p.doingQueue[task.TaskId] = task
	p.Logger.Debug("add async success")
	return nil
}

func (p *TaskDispatcher) AddTaskToPushingQueue(task *api.UpdateTaskRequest) {
	// Submit async from doingQueue to pushingQueue.
	p.submitTask <- task

	p.queueLock.Lock()
	defer p.queueLock.Unlock()
	delete(p.doingQueue, task.TaskId)
}

func (p *TaskDispatcher) doPushingQueue() {
	defer func() {
		runtime.HandleCrash(func(v interface{}) {
			p.Logger.Error("doPushingQueue goroutine failed;panic:%v", v)
			p.Logger.Error("doPushingQueue goroutine failed;panic stack:%s", string(debug.Stack()))
		})
	}()

	cleanTicker := time.NewTicker(CleanFinishTaskInternal * time.Second)
	updateTaskTicker := time.NewTicker(time.Millisecond * 100)
	for {
		select {
		case item := <-p.submitTask:
			// 防止lock无法释放。
			func() {
				p.queueLock.Lock()
				defer p.queueLock.Unlock()
				// 接收任务，添加到pushingQueue队列。
				if _, ok := p.pushingQueue[item.TaskId]; !ok {
					p.pushingQueue[item.TaskId] = item
				}
			}()

		case <-updateTaskTicker.C:
			// 防止lock无法释放。
			func() {
				// 定时执行更新任务
				p.queueLock.Lock()
				defer p.queueLock.Unlock()
				for id, item := range p.pushingQueue {
					go func(task *api.UpdateTaskRequest) {
						for {
							err := p.JksApi.UpdateTask(task, 1)
							if err == nil {
								break
							}
							time.Sleep(500 * time.Millisecond)
						}
					}(item)

					item.UpdatedAt = time.Now().Unix()
					p.finishedQueue[id] = item
					delete(p.pushingQueue, id)
				}

			}()

		case <-cleanTicker.C:
			func() {
				p.queueLock.Lock()
				defer p.queueLock.Unlock()
				// 清理finishedQueue中上一天的任务，防止内存泄露.
				currentTime := time.Now().Unix()
				for id, item := range p.finishedQueue {
					if currentTime-item.UpdatedAt >= CleanFinishTaskInternal {
						delete(p.finishedQueue, id)
					}
				}
			}()

		case <-p.Close():
			return
		}
	}
}

func (p *TaskDispatcher) Dispatcher(task *jks.Task) common.JvirtError {
	p.Logger.Debug("Dispatcher async. TaskId: %d, TaskState: %s, PodID: %s.",
		task.TaskId, task.TaskState, task.ReferId)

	if !p.IsStart() {
		p.Logger.Error("TaskDispatcher is stopped.")
		return nil
	}

	// 检测任务类型是否支持
	execute, ok := p.registerTaskFuncs[task.TaskType]
	if !ok {
		p.Logger.Error("Not support %s.", task.TaskType)
		return common.NewError(common.RErrSystem, common.TErrForbidden, "", "Not support "+task.TaskType)
	}

	// 添加任务
	if err := p.AddTaskToDoingQueue(task); err != nil {
		p.Logger.Debug("AddTaskToDoingQueue failed. TaskId: %s, Error: %s.", task.ReferId, err.Error())
		return nil
	}

	// 执行任务
	go func() {
		var err error
		golocal.GoContext.Put(&golocal.GoValue{RequestId: task.RequestId, TaskType: task.TaskType})
		updateTask := &api.UpdateTaskRequest{
			RequestId: task.RequestId,
			TaskId:    task.TaskId,
			TaskState: jks.TaskFailed,
			TaskType:  task.TaskType,
			PodId:     task.ReferId,
			Rollback:  true,
			HostIp:    p.ComputeCfg.HostIp,
		}

		defer func() {
			p.confine.Done(task.TaskType)
			if r := recover(); r != nil {
				p.Logger.Error("Execute async panic. TaskId: %d, TaskType: %s, InstanceId: %s.\n Error: %#v.\n Trace: %s.",
					task.TaskId, task.TaskType, task.ReferId, r, debug.Stack())
				//updateTask.FailReason = "AgentExecTaskPanic"
				//updateTask.FailMessage = "jks-agent panic, please check cause"
			} else if err != nil {
				p.Logger.Error("Execute async failed. TaskId: %d, TaskType: %s, InstanceId: %s, Error: %s",
					task.TaskId, task.TaskType, task.ReferId, err.Error())
				//updateTask.FailReason = "AgentExecTaskFailed"
				//updateTask.FailMessage = err.Error()
			} else {
				p.Logger.Info("Execute async finish. TaskId: %d, TaskType: %s, TaskState: %s, InstanceId: %s.",
					task.TaskId, task.TaskType, updateTask.TaskState, task.ReferId)
			}

			p.AddTaskToPushingQueue(updateTask)
			golocal.GoContext.Remove()
		}()

		p.Logger.Info("Execute async start. TaskId: %d, TaskType: %s, InstanceId: %s.",
			task.TaskId, task.TaskType, task.ReferId)
		err = execute(task, updateTask)
	}()

	return nil
}
