package service

import (
	"errors"
	"fmt"
	"path"
	"runtime/debug"
	"time"

	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/inner/jks/agent"
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/server"
	"jd.com/jvirt/jvirt-jks-agent/cfg"
	"jd.com/jvirt/jvirt-jks-agent/constant"
	"jd.com/jvirt/jvirt-jks-agent/em"
	"jd.com/jvirt/jvirt-jks-agent/httpclient"
	. "jd.com/jvirt/jvirt-jks-agent/model"
	"jd.com/jvirt/jvirt-jks-agent/runtime"
	"jd.com/jvirt/jvirt-jks-agent/utils"
)

type PodService struct {
	*server.Server
	Logger         log.Logger                      `inject:""`
	EventHandler   *em.EventManagerService         `inject:""`
	ImageClient    *httpclient.ImageRegistryClient `inject:""`
	NetClient      *httpclient.NetworkClient       `inject:""`
	VolClient      *httpclient.VolumeClient        `inject:""`
	XCgroupCli     *httpclient.XcgroupClient       `inject:""`
	ComputeCfg     *cfg.ComputeConfig              `inject:""`
	RuntimeManager *runtime.RuntimeManager         `inject:""`
}

func NewPodService() *PodService {
	resp := &PodService{}
	resp.Server = server.NewServer(resp.doStart, resp.doStop)

	return resp
}

//// 初始化流程
func (p *PodService) doStart() error {
	p.Server.Start()

	p.Logger.Info("PodService Initialization ......")
	for n, driver := range p.RuntimeManager.ListDriver() {
		p.Logger.Info("Driver [%s] Initialization start", n)
		if err := driver.Initialization(); err != nil {
			p.Logger.Error("Driver [%s] Initialization failed. Error: %s.", n, err.Error())
			return err
		}
		p.Logger.Info("Driver [%s] Initialization stop", n)
	}

	return nil
}

func (p *PodService) doStop() {
	p.Server.Stop()
	for n, driver := range p.RuntimeManager.ListDriver() {
		p.Logger.Info("Driver [%s] Cleanup start", n)
		if err := driver.Cleanup(); err != nil {
			p.Logger.Error("Driver [%s] Cleanup failed. Error: %s.", n, err.Error())
			continue
		}
		p.Logger.Info("Driver [%s] Cleanup stop", n)
	}
}

func (p *PodService) rollback(instId, action string, err *InError, rollbackFunc func() error) {
	if r := recover(); r != nil || (*err) != nil {
		if (*err) != nil {
			detail := (*err).Error()
			p.EventHandler.EmitOperationEvent(instId, action, constant.FailedStage, detail)
			p.Logger.Error("%s failed. InstanceId: %s, Error: %s.", action, instId, (*err).Error())
		}
		//无论时panic还是返回错误，err *InError必须不能是nil， 否则下面rollbackFunc失败后调用InError相关接口会出错
		if (*err) == nil {
			*err = NewAgentError(true, fmt.Sprintf("panic when %s .", action))
		}

		if r != nil {
			detail := action + " panic."
			p.EventHandler.EmitOperationEvent(instId, action, constant.FailedStage, detail)
			p.Logger.Error("%s panic. InstanceId: %s. \n Error: %#v.\n Trace: %s.", action, instId, r, debug.Stack())
			// 如果panic 上面的taskhandler中的createInstance，将无法处理error，直接调到handler的defer流程。
			// 无法获知是否rollback是否成功或者失败
			//panic(r)
		}

		if rollbackFunc != nil {
			defer func() {
				if r := recover(); r != nil {
					p.Logger.Error("%s rollback panic. InstanceId: %s. \n Error: %#v.\n Trace: %s.", action, instId, r, debug.Stack())
					(*err).SetRollback(false)
					(*err).SetMsg(errors.New("rollback panic"))
				}
			}()
			if e := rollbackFunc(); e != nil {
				p.Logger.Error("%s rollback failed. InstanceId: %s. Error: %#v.", action, instId, e)
				(*err).SetRollback(false)
				(*err).SetMsg(e)
			}
		}

	} else {
		detail := action + " sync success."
		p.Logger.Debug("%s success. InstanceId: %s.", action, instId)
		p.EventHandler.EmitOperationEvent(instId, action, constant.FinishedStage, detail)
	}
}

func (p *PodService) getRuntime(driverType string) (runtime.IRuntime, error) {
	rt := p.RuntimeManager.GetDriver(driverType)
	if rt == nil {
		msg := fmt.Sprintf("Runtime [%s] not found", driverType)
		return nil, errors.New(msg)
	}

	return rt, nil
}

func (p *PodService) podExist(args *Pod) (bool, error) {
	rt, err := p.getRuntime(args.RuntimeType)
	if err != nil {
		return false, err
	}

	return rt.PodExist(args.PodId, args.PodPath)
}

func (p *PodService) cleanPodResource(pod *Pod) error {
	podId := pod.PodId
	p.Logger.Info("[cleanPodResource] PodId: %s start", podId)

	isExist, err := p.podExist(pod)
	if err != nil {
		p.Logger.Error("[cleanPodResource] Invoke podExist failed. PodId: %s, Error: %s", podId, err.Error())
		return err
	}

	if !isExist {
		p.Logger.Info("[cleanPodResource] Pod has delete. PodId: %s", podId)
	} else {
		// 1. Invoke driver delete.
		rt, err := p.getRuntime(pod.RuntimeType)
		if err != nil {
			return err
		}
		if err := rt.DeletePod(pod); err != nil {
			p.Logger.Error("[cleanPodResource] Invoke driver DeletePod [%v] failed.  Error: %s.", podId, err.Error())
			return err
		}
	}

	if err := p.VolClient.DetachVolumesFromPod(pod); err != nil {
		p.Logger.Error("[cleanPodResource] DetachVolumesFromPod failed. PodId: %s, Error: %s", podId, err.Error())

		return err
	}

	if err := p.XCgroupCli.Free(podId); err != nil {
		p.Logger.Error("[cleanPodResource] XCGroup free resource failed. PodId: %s, Error: %s. ", podId, err.Error())
		return err
	}

	return nil
}

func (p *PodService) addTapToOVS(pod *Pod) error {
	podId := pod.PodId
	priInterface := pod.PrimaryInterface
	tapName := priInterface.PortId
	netMac := priInterface.Mac

	if utils.DeviceExists(tapName) {
		p.Logger.Info("[AddTapToOVS] tap device [%s] has exist, must be delete.", tapName)

		if err := utils.DeleteTap(tapName); err != nil {
			p.Logger.Error("[AddTapToOVS] DeleteTap failed. TapName: %s, Error: %s.", tapName, err.Error())
			return err
		}
	}

	if err := utils.CreateTap(tapName); err != nil {
		p.Logger.Error("[AddTapToOVS] CreateTap failed. TapName: %s, Error: %s.", tapName, err.Error())
		return err
	}

	if err := utils.CreateOvsPort(p.ComputeCfg.OVSBridge, tapName, netMac, podId); err != nil {
		p.Logger.Error("[AddTapToOVS] CreateOvsPort failed. TapName: %s, Error: %s.", tapName, err.Error())
		return err
	}

	if err := utils.SetNetDevUp(tapName); err != nil {
		p.Logger.Error("[AddTapToOVS] SetNetDevUp failed. TapName: %s, Error: %s.", tapName, err.Error())
		return err
	}

	return nil
}

func (p *PodService) delTapFromOVS(pod *Pod) error {
	podId := pod.PodId
	priInterface := pod.PrimaryInterface
	tapName := priInterface.PortId

	if tapName == "" || !utils.DeviceExists(tapName) {
		p.Logger.Warn("[DelTapFromOVS] Tap not exist, PodId: %s, TapName: %s.", podId, tapName)
		return nil
	}

	if err := utils.SetNetDevDown(tapName); err != nil {
		p.Logger.Error("[DelTapFromOVS] SetNetDevDown failed. PodId: %s, TapName: %s, Error: %s.", podId, tapName, err.Error())
		return err
	}

	if err := utils.DeleteOvsPort(p.ComputeCfg.OVSBridge, tapName); err != nil {
		p.Logger.Error("[DelTapFromOVS] DeleteOvsPort failed. PodId: %s, TapName: %s, Error: %s.", podId, tapName, err.Error())
		return err
	}

	if err := utils.DeleteTap(tapName); err != nil {
		p.Logger.Error("[DelTapFromOVS] DeleteTap failed. PodId: %s, TapName: %s, Error: %s.", podId, tapName, err)
		return err
	}

	return nil
}

func (p *PodService) buildPodResources(taskType string, pod *Pod) error {
	podId := pod.PodId
	primaryInterface := pod.PrimaryInterface

	if primaryInterface == nil {
		p.Logger.Error("[buildPodResources] Pod.PrimaryInterface is nil. PodId: %s", podId)
		return errors.New("PrimaryInterface is nil")
	}
	networkType := pod.NetworkType

	p.Logger.Debug("[buildPodResources] PodId %s.", podId)
	p.EventHandler.EmitExecuteTimeEvent(podId, "buildPodResources", constant.StartStage, false)
	defer p.EventHandler.EmitExecuteTimeEvent(podId, "buildPodResources", constant.FinishedStage, true)

	// 1. 申请cpu和memory
	switch taskType {
	case jks.PodCreateTask, jks.PodMigrateTask, jks.PodRebuildTask:
		resView, err := p.XCgroupCli.Alloc(pod.RuntimeType, pod.PodId, pod.InstanceType)
		if err != nil {
			p.Logger.Error("[buildPodResources] Alloc resource failed from XCGroup. PodId: %s, Error: %#v.", podId, err.Error())
			return err
		}
		pod.PhysicalResource = resView
		p.EventHandler.EmitExecuteTimeEvent(podId, "buildPodResources", "XCgroupCli.Alloc", false)
	}

	// 2. build network resource for pod.
	if err := p.NetClient.AllocPorts(p.ComputeCfg.Hostname, pod); err != nil {
		p.Logger.Error("[buildPodResources] prepareNetwork failed. Error: %s", err.Error())
		return err
	}
	p.EventHandler.EmitExecuteTimeEvent(podId, "buildPodResources", "NetClient.AllocPorts", false)
	// 只有创建和迁移时, 需要在计算节点创建网卡设备.
	switch taskType {
	case jks.PodCreateTask, jks.PodMigrateTask:
		if networkType == constant.OVSKernel {
			p.Logger.Debug("[buildPodResources] OVS Type is %s, nic device need to create by jks-agent", networkType)
			if err := p.addTapToOVS(pod); err != nil {
				p.Logger.Error("[buildPodResources] AddTapToOVS failed. Error: %s.", err.Error())
				return err
			}
			p.EventHandler.EmitExecuteTimeEvent(podId, "XAgentDriver.doCreatePod", "addTapToOVS", false)
		} else if networkType == constant.OVSDpdk {
			p.Logger.Debug("[buildPodResources] OVS Type is %s, nic device need to create by dpdk", networkType)
		} else {
			p.Logger.Error("[buildPodResources] not support ovs type %s.", networkType)
			return errors.New("not support ovs type")
		}
	}

	// 执行PortUP操作
	if _, err := p.NetClient.PortUp(pod.UserId, podId, networkType); err != nil {
		p.Logger.Error("[buildPodResources] PortUp failed. PodId: %s, Error: %s", podId, err.Error())
		return err
	}

	// 1. prepare volume for pod.
	if err := p.VolClient.AttachVolumesToPod(taskType, pod); err != nil {
		p.Logger.Error("[buildPodResources] attachVolumeToPod failed. Error: %s", err.Error())
		return err
	}
	p.EventHandler.EmitExecuteTimeEvent(podId, "buildPodResources", "VolClient.AttachVolumesToPod", false)

	// 3. check volume is attached or not
	if err := p.VolClient.CheckPodVolumesAttached(pod); err != nil {
		p.Logger.Error("[buildPodResources] checkVolumeAttached failed. Error: %s", err.Error())
		return err
	}
	p.EventHandler.EmitExecuteTimeEvent(podId, "buildPodResources", "VolClient.CheckPodVolumesAttached", false)

	p.Logger.Debug("[buildPodResources] finish PodId: %s", podId)

	return nil
}

func (p *PodService) RuntimeIsAlive() bool {
	isAlive := true

	for name, driver := range p.RuntimeManager.ListDriver() {
		if alive := driver.DriverIsAlive(); !alive {
			isAlive = false
			p.Logger.Error("Runtime [%s] is dead", name)
		}
	}

	return isAlive
}

func (p *PodService) doCreatePod(pod *Pod) error {
	podId := pod.PodId

	rt, err := p.getRuntime(pod.RuntimeType)
	if err != nil {
		return NewAgentError(false, err.Error())
	}
	if err := rt.DeletePod(pod); err != nil {
		p.Logger.Error("[doCreatePod] Invoke driver DeletePod [%v] failed.  Error: %s.", podId, err.Error())
		return NewAgentError(false, err.Error())
	}

	// prepare disk resources and network resources
	if err := p.buildPodResources(jks.PodCreateTask, pod); err != nil {
		p.Logger.Error("[doCreatePod] Prepare Resources failed. PodId: %s, Error: %s", podId, err.Error())
		return err
	}

	if err := rt.CreatePod(pod); err != nil {
		p.Logger.Error("[doCreatePod] Invoke driver CreatePod [%v] failed.  Error: %s.", podId, err.Error())
		return err
	}

	return nil
}

func (p *PodService) CreatePod(pod *Pod) (inError InError) {
	podId := pod.PodId
	p.Logger.Info("[CreatePod] start. PodId: %s", podId)

	p.EventHandler.EmitOperationEvent(podId, constant.CreatePodAction, constant.StartStage, "PodId: "+podId)
	p.EventHandler.EmitExecuteTimeEvent(podId, "PodService.CreatePod", constant.StartStage, false)
	defer p.rollback(podId, constant.CreatePodAction, &inError, func() error {
		if err := p.cleanPodResource(pod); err != nil {
			return err
		}
		return nil
	})

	if err := p.doCreatePod(pod); err != nil {
		p.EventHandler.EmitExecuteTimeEvent(podId, "PodService.CreatePod", constant.FailedStage, true)
		p.Logger.Error("[CreatePod] doCreatePod failed. PodId: %s, Error: %s", podId, err.Error())
		return NewAgentError(true, err.Error())
	}

	p.EventHandler.EmitExecuteTimeEvent(podId, "PodService.CreatePod", constant.FinishedStage, true)
	return nil
}

func (p *PodService) doRebuildPod(pod *Pod) error {
	podId := pod.PodId

	rt, err := p.getRuntime(pod.RuntimeType)
	if err != nil {
		return NewAgentError(false, err.Error())
	}
	if err := rt.DeletePod(pod); err != nil {
		p.Logger.Error("[doRebuildPod] Invoke driver DeletePod [%v] failed.  Error: %s.", podId, err.Error())
		return NewAgentError(false, err.Error())
	}

	// prepare disk resources and network resources
	if err := p.buildPodResources(jks.PodRebuildTask, pod); err != nil {
		p.Logger.Error("[doRebuildPod] Prepare Resources failed. PodId: %s, Error: %s", podId, err.Error())
		return err
	}

	if err := rt.RebuildPod(pod); err != nil {
		p.Logger.Error("[doRebuildPod] Invoke driver RebuildPod [%v] failed.  Error: %s.", podId, err.Error())
		return err
	}

	return nil
}

func (p *PodService) RebuildPod(pod *Pod) (inError InError) {
	podId := pod.PodId
	p.Logger.Info("[RebuildPod] start. PodId: %s", podId)

	p.EventHandler.EmitOperationEvent(podId, constant.RebuildPodAction, constant.StartStage, "PodId: "+podId)
	p.EventHandler.EmitExecuteTimeEvent(podId, "PodService.RebuildPod", constant.StartStage, false)
	defer p.rollback(podId, constant.RebuildPodAction, &inError, nil)

	if err := p.doRebuildPod(pod); err != nil {
		p.EventHandler.EmitExecuteTimeEvent(podId, "PodService.RebuildPod", constant.FailedStage, true)
		p.Logger.Error("[RebuildPod] doRebuildPod failed. PodId: %s, Error: %s", podId, err.Error())
		return NewAgentError(true, err.Error())
	}

	p.EventHandler.EmitExecuteTimeEvent(podId, "PodService.RebuildPod", constant.FinishedStage, true)

	if err := p.doStopPod(pod); err != nil {
		p.Logger.Error("[RebuildPod] doStopPod failed. PodId: %s, Error: %s", pod.PodId, err.Error())
		return NewAgentError(true, err.Error())
	}

	return nil
}

func (p *PodService) doStartPod(pod *Pod) error {
	podId := pod.PodId

	// prepare disk resources and network resources
	if err := p.buildPodResources(jks.PodStartTask, pod); err != nil {
		p.Logger.Error("[doStartPod] Prepare Resources failed. PodId: %s, Error: %s", podId, err.Error())
		return err
	}

	rt, err := p.getRuntime(pod.RuntimeType)
	if err != nil {
		return err
	}
	if err := rt.StartPod(pod); err != nil {
		p.Logger.Error("[doStartPod] Invoke driver StartPod [%v] failed.  Error: %s.", pod.PodId, err.Error())
		return err
	}

	return nil
}

func (p *PodService) StartPod(pod *Pod) (inError InError) {
	podId := pod.PodId

	status, err := p.GetPodStatus(pod.RuntimeType, podId)
	if err != nil {
		p.Logger.Error("[StartPod] GetPodStatus failed. PodId: %s, Error: %s.", podId, err.Error())
		return NewAgentError(true, err.Error())
	}

	podPhase := status.Phase
	if podPhase == jks.PodPhaseRunning {
		p.Logger.Info("[StartPod] Pod is already running. PodId: %s, PodPhase: %s", podId, podPhase)
		return nil
	}

	p.EventHandler.EmitOperationEvent(podId, constant.StartPodAction, constant.StartStage, "PodId: "+podId)
	defer p.rollback(pod.PodId, constant.StartPodAction, &inError, func() error {
		// 开机失败, 需要执行PortDown操作.
		if _, err := p.NetClient.PortDown(pod.UserId, podId); err != nil {
			return err
		}
		return nil
	})

	if err := p.doStartPod(pod); err != nil {
		p.Logger.Error("[StartPod] doStartPod failed. PodId: %s, Error: %s", pod.PodId, err.Error())
		return NewAgentError(true, err.Error())
	}

	return nil
}

func (p *PodService) doStopPod(pod *Pod) error {
	podId := pod.PodId

	rt, err := p.getRuntime(pod.RuntimeType)
	if err != nil {
		return err
	}
	if err := rt.StopPod(pod); err != nil {
		p.Logger.Error("[doStopPod] Invoke driver StopPod [%v] failed.  Error: %s.", pod.PodId, err.Error())
		return err
	}

	// Stop时, 必须执行PortDown操作
	if _, err := p.NetClient.PortDown(pod.UserId, pod.PodId); err != nil {
		p.Logger.Error("[doStopPod] PortDown failed. PodId: %s, Error: %s", podId, err.Error())
	}

	return nil
}

func (p *PodService) StopPod(pod *Pod) (inError InError) {
	podId := pod.PodId

	state, err := p.GetPodStatus(pod.RuntimeType, podId)
	if err != nil {
		p.Logger.Error("[StopPod] GetPodStatus failed. PodId: %s, Error: %s.", podId, err.Error())
		return NewAgentError(false, err.Error())
	}

	podPhase := state.Phase
	if podPhase == jks.PodPhaseStopped || podPhase == jks.PodPhaseStopping {
		p.Logger.Info("[StopPod] Pod is already %s. PodId: %s", podPhase, podId)
		return nil
	}

	p.EventHandler.EmitOperationEvent(podId, constant.StopPodAction, constant.StartStage, "PodId: "+podId)
	defer p.rollback(pod.PodId, constant.StopPodAction, &inError, nil)

	if err := p.doStopPod(pod); err != nil {
		p.Logger.Error("[StopPod] doStopPod failed. PodId: %s, Error: %s", pod.PodId, err.Error())
		return NewAgentError(true, err.Error())
	}

	return nil
}

func (p *PodService) doDeletePod(pod *Pod) error {
	podId := pod.PodId

	// 1. 释放资源
	if err := p.cleanPodResource(pod); err != nil {
		p.Logger.Error("[doDeletePod] cleanPodResource failed. PodId: %s, Error: %s", podId, err.Error())
		return err
	}

	// 2. 清理网络资源
	if pod.NetworkType == constant.OVSKernel {
		if err := p.delTapFromOVS(pod); err != nil {
			p.Logger.Error("[doDeletePod] DelTapFromOVS failed. PodId: %s, Error: %s", podId, err.Error())
			return err
		}
	}
	priInterface := pod.PrimaryInterface
	if priInterface != nil && priInterface.DeleteOnTermination {
		portId := priInterface.PortId
		// 2. deallocate network
		if err := p.NetClient.DeletePort(pod.UserId, portId); err != nil {
			p.Logger.Error("[doDeletePod] Delete port failed. PodId: %s, Error: %s.", podId, err.Error())
			return err
		}
	}

	return nil
}

func (p *PodService) DeletePod(pod *Pod) (inError InError) {
	podId := pod.PodId

	p.EventHandler.EmitOperationEvent(podId, constant.DeletePodAction, constant.StartStage, "PodId: "+podId)
	defer p.rollback(pod.PodId, constant.DeletePodAction, &inError, nil)

	if err := p.doDeletePod(pod); err != nil {
		p.Logger.Error("[DeletePod] doDeletePod failed. PodId: %s, Error: %s", pod.PodId, err.Error())
		return NewAgentError(true, err.Error())
	}

	return nil
}

func (p *PodService) doMigratePod(pod *Pod) error {
	podId := pod.PodId

	rt, err := p.getRuntime(pod.RuntimeType)
	if err != nil {
		return NewAgentError(false, err.Error())
	}
	if err := rt.DeletePod(pod); err != nil {
		p.Logger.Error("[doMigratePod] Invoke driver DeletePod [%v] failed.  Error: %s.", podId, err.Error())
		return NewAgentError(false, err.Error())
	}

	// prepare disk resources and network resources
	if err := p.buildPodResources(jks.PodMigrateTask, pod); err != nil {
		p.Logger.Error("[doMigratePod] Prepare Resources failed. PodId: %s, Error: %s", podId, err.Error())
		return err
	}

	if err := rt.MigratePod(pod); err != nil {
		p.Logger.Error("[doMigratePod] Invoke driver MigratePod [%v] failed.  Error: %s.", podId, err.Error())
		return err
	}

	return nil
}

// 在目标节点执行.
func (p *PodService) MigratePod(pod *Pod) (inError InError) {
	podId := pod.PodId
	p.Logger.Info("[MigratePod] start. PodId: %s", podId)
	pod.HostIP = p.ComputeCfg.HostIp

	p.EventHandler.EmitOperationEvent(podId, constant.MigratePodAction, constant.StartStage, "PodId: "+podId)
	defer p.rollback(podId, constant.MigratePodAction, &inError, func() error {
		if err := p.cleanPodResource(pod); err != nil {
			return err
		}
		return nil
	})

	if err := p.doMigratePod(pod); err != nil {
		p.Logger.Error("[MigratePod] doMigratePod failed. PodId: %s, Error: %s", podId, err.Error())
		return NewAgentError(false, err.Error())
	}

	if err := p.doStopPod(pod); err != nil {
		p.Logger.Error("[MigratePod] doStopPod failed. PodId: %s, Error: %s", pod.PodId, err.Error())
		return NewAgentError(true, err.Error())
	}

	return nil
}

/*
迁移成功:
由目标节点或者补偿任务发送请求到srcHost, 清理迁移完成后源节点残留垃圾.

迁移失败:
补偿任务发送请求到dstHost, 清理迁移未完成在目标节点残留垃圾.
*/
func (p *PodService) CleanPodResource(pod *Pod) error {
	podId := pod.PodId
	pod.HostIP = p.ComputeCfg.HostIp

	p.Logger.Info("[FinishMigratePod] start. PodId: %s", podId)
	if err := p.cleanPodResource(pod); err != nil {
		p.Logger.Error("[FinishMigratePod] cleanPodResource failed. PodId: %s, Error: %s", podId, err.Error())
		return err
	}

	return nil
}

func (p *PodService) GetContainerLogs(args *agent.GetContainerLogsRequest) (string, error) {
	rt, err := p.getRuntime(args.RuntimeType)
	if err != nil {
		return "", err
	}

	logs, err := rt.GetContainerLogs(args)
	if err != nil {
		p.Logger.Error("[GetContainerLogs] Invoke driver GetContainerLogs [%v] failed.  Error: %s.", args.PodId, err.Error())
		return "", err
	}

	return logs, nil
}

func (p *PodService) ListPodStatuses(driverType string) (map[string]*jks.PodStatus, error) {
	p.Logger.Debug("[ListPodStatuses] start. RuntimeType: %s", driverType)
	rt, err := p.getRuntime(driverType)
	if err != nil {
		return nil, err
	}

	pods, err := rt.ListPodStatuses()
	if err != nil {
		p.Logger.Error("[ListPodStatuses] Invoke driver ListPodStatuses failed. Error: %s.", err.Error())
		return nil, err
	}

	return pods, nil
}

func (p *PodService) GetPodStatus(dType, podId string) (*jks.PodStatus, error) {
	p.Logger.Debug("[GetPodStatus] start. RuntimeType: %s, PodId: %s", dType, podId)

	rt, err := p.getRuntime(dType)
	if err != nil {
		return nil, err
	}

	pStatus, err := rt.GetPodStatus(podId)
	if err != nil {
		p.Logger.Error("[GetPodStatus] Invoke driver GetPodStatus failed. PodId: %s, Error: %s.", podId, err.Error())
		return nil, err
	}

	return pStatus, nil
}

// 在目标节点执行.
func (p *PodService) ResizePod(pod *Pod) (inError InError) {
	podId := pod.PodId
	p.Logger.Info("[ResizePod] start. PodId: %s", podId)
	pod.HostIP = p.ComputeCfg.HostIp

	p.EventHandler.EmitOperationEvent(podId, constant.ResizePodAction, constant.StartStage, "PodId: "+podId)
	resView, err := p.XCgroupCli.ReAlloc(pod.RuntimeType, pod.PodId, pod.InstanceType)
	if err != nil {
		p.Logger.Error("[buildPodResources] Alloc resource failed from XCGroup. PodId: %s, Error: %#v.", podId, err.Error())
		return NewAgentError(false, err.Error())
	}
	pod.PhysicalResource = resView

	p.EventHandler.EmitExecuteTimeEvent(podId, "ResizePodBuildResources", "XCgroupCli.ReAlloc", false)
	if err := p.UpdatePod(pod); err != nil {
		p.Logger.Error("[ResizePod] failed, podId: %s, err: %v", podId, err)
		return NewAgentError(false, err.Error())
	}

	return nil
}

func (p *PodService) UpdatePod(pod *Pod) error {
	podId := pod.PodId
	rt, err := p.getRuntime(pod.RuntimeType)
	if err != nil {
		return NewAgentError(false, err.Error())
	}

	if err := rt.UpdatePod(pod); err != nil {
		p.Logger.Error("[UpdatePod] Invoke driver PodId [%v] failed.  Error: %s.", podId, err.Error())
		return err
	}

	return nil
}

func (p *PodService) ExtendPodVolume(extVol *api.ExtendPodVolume, pod *Pod) (inError InError) {
	podId := pod.PodId
	p.Logger.Info("[ExtendVolume] start. PodId: %s", podId)
	pod.HostIP = p.ComputeCfg.HostIp

	p.EventHandler.EmitOperationEvent(podId, constant.ExtendVolumeAction, constant.StartStage, "PodId: "+podId)
	p.EventHandler.EmitExecuteTimeEvent(podId, "PodService.ExtendVolume", constant.StartStage, false)
	defer p.rollback(podId, constant.ExtendVolumeAction, &inError, nil)

	if err := p.doExtendPodVolume(extVol, pod); err != nil {
		p.EventHandler.EmitExecuteTimeEvent(podId, "PodService.ExtendVolume", constant.FailedStage, true)
		p.Logger.Error("[ExtendVolume] doExtendVolume failed. PodId: %s, Error: %s", podId, err.Error())
		return NewAgentError(true, err.Error())
	}
	p.EventHandler.EmitExecuteTimeEvent(podId, "PodService.ExtendVolume", constant.FinishedStage, true)
	return nil
}

func (p *PodService) doExtendPodVolume(extVol *api.ExtendPodVolume, pod *Pod) error {

	// 停pod
	rt, err := p.getRuntime(pod.RuntimeType)
	if err != nil {
		return NewAgentError(false, err.Error())
	}
	if err := rt.StopPod(pod); err != nil {
		p.Logger.Error("[doExtendVolume] Invoke driver StopPod [%v] failed.  Error: %s.", pod.PodId, err.Error())
		return NewAgentError(false, err.Error())
	}

	// pod detach volume
	if err := p.VolClient.DetachVolumesFromPodById(extVol.VolumeId, pod); err != nil {
		p.Logger.Error("[doExtendVolume] Invoke VolClient DetachVolumesFromPod [%v] failed.  Error: %s.", pod.PodId, err.Error())
		return NewAgentError(false, err.Error())
	}

	// resize volume && wait available
	if err := p.VolClient.ExtendVolume(extVol.VolumeId, extVol.Size, pod); err != nil {
		p.Logger.Error("[doExtendVolume] Invoke VolClient ExtendVolumeFromPodById [%v] failed.  Error: %s.", pod.PodId, err.Error())
		return NewAgentError(false, err.Error())
	}

	// attach  extended volume
	if err := p.VolClient.AttachExtendVolume(extVol.VolumeId, pod); err != nil {
		p.Logger.Error("[doExtendVolume] Invoke VolClient AttachExtendVolume [%v] failed.  Error: %s.", pod.PodId, err.Error())
		return NewAgentError(false, err.Error())
	}

	// extend filesystem
	devName := utils.ZbsSoftLinkName(extVol.VolumeId, pod.PodId)
	devPath := path.Join(p.ComputeCfg.ZbsLinkFileDir, devName)
	mountPath := path.Join(pod.PodPath, "extend-volumes", extVol.VolumeId)
	mountPath, err = p.toGetMountedPoint(devPath, mountPath)
	if err != nil {
		p.Logger.Error("[doExtendVolume] Invoke VolClient generate mountpoint [%v] failed.  Error: %s.", pod.PodId, err.Error())
		return NewAgentError(false, err.Error())
	}
	if err := p.toExtendFileSystem(devPath, mountPath); err != nil {
		p.Logger.Error("[doExtendVolume] Invoke VolClient extend Filesystem [%v] failed.  Error: %s.", pod.PodId, err.Error())
		return NewAgentError(false, err.Error())
	}
	return nil
}

func (p *PodService) toExtendFileSystem(file, softLink string) error {
	fileSystem, err := utils.GetFileSystem(file)
	if err != nil {
		p.Logger.Error("[getMountedPoint] GetFileSystem failed. error : %s", err.Error())
		return err
	}
	if fileSystem == utils.XFS {
		_, err := utils.Command(300*time.Second, "xfs_growfs", softLink)
		if err != nil {
			return err
		}
	} else {
		_, err := utils.Command(300*time.Second, "resize2fs", softLink)
		if err != nil {
			return err
		}
	}
	return nil
}

func (p *PodService) toGetMountedPoint(file, mountPoint string) (string, error) {
	// check filesystem and format
	p.Logger.Debug("[getMountedPoint] file = %s", file)
	fileSystem, err := utils.GetFileSystem(file)
	if err != nil {
		p.Logger.Error("[getMountedPoint] GetFileSystem failed. error : %s", err.Error())
		return "", err
	}
	if fileSystem != utils.XFS && fileSystem != utils.EXT4 {
		return "", errors.New("Invalid File System")
	}
	// check if mounted and mountfs
	isMounted, err := utils.IsMounted(mountPoint)
	if err != nil {
		p.Logger.Error("[getMountedPoint] check dev IsMounted error %s", err.Error())
		return "", err
	}
	if !isMounted {
		p.Logger.Debug("[getMountedPoint]  %s not mounted, do MountFS.", mountPoint)
		err = utils.CreateDir(mountPoint, 0644)
		if err != nil {
			p.Logger.Error("[getMountedPoint] CreateDir %s error %s", mountPoint, err.Error())
			return "", err
		}
		if err := utils.MountFS(file, mountPoint, fileSystem); err != nil {
			p.Logger.Error("[getMountedPoint] MountFS failed. err : %s", err.Error())
			return "", err
		}
	}
	return mountPoint, nil
}
