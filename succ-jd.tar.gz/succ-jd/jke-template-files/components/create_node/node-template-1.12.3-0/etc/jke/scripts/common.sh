#!/bin/bash

function error_log()
{
    echo "[ERROR] $1" >&2

}

function retry()
{
        local n=0;local try=$1
        local cmd="${@: 2}"
        [[ $# -le 1 ]] && {
            error_log "Usage $0 <retry_number> <Command>"
            return 1
        }
        until [[ $n -ge $try ]]
        do
                $cmd && return || {
                        #error_log "Command Fail.."
                        ((n++))
                        #error_log "retry $n :: [$cmd]" >2
                        sleep 2;
                        }
        done
        if [[ $n -ge $try ]];then
            error_log "retry failed with exceeded max retry count($try), $cmd"
            return 2
        fi
}


function logger(){
    echo $(date +"[%Y%m%d %H:%M:%S]: ") $1
}

function getMetadata() {
    key=$1
    if [ -z key ]
    then
        error_log "not specified a metadata key"
        return 2
    fi
    output=`curl http://169.254.169.254/jcs-metadata/latest/attributes/${key} | awk -F "\"" '{print $2}'`

    if [[ -z ${output} ]]; then
        error_log "failed get metadata ${key}"
        return 2
    fi

    echo $output
}