#!/usr/bin/env bash

METADATA_URL="http://169.254.169.254/jcs-metadata/latest/"
DEPLOY_DIR="/etc/jke/"
VARIABLES_METADATA_KEY="k8s-node-variables"
DOWNLOAD_SERVER_URL_KEY="k8s-download-url"
#KUBELET_RPM_VERSION_KEY="k8s-kubelet-version"
CLUSTER_CA_KEY="k8s-root-ca-crt"
source ${DEPLOY_DIR}scripts/common.sh


function check_empty() {
    if [ -z $2 ]
    then
        logger "$1 is empty"
        exit 1
    fi
}

function check_code_or_exit() {
    if [ $? != 0 ]
    then
        logger "$1"
        exit 1
    fi
}

function fetch_metadata_info() {

    NODE_LABEL_REGION=`curl http://169.254.169.254/jcs-metadata/latest/placement/region | awk -F "\"" '{print $2}'`
    NODE_LABEL_ZONE=`curl http://169.254.169.254/jcs-metadata/latest/placement/availability-zone | awk -F "\"" '{print $2}'`
    NODE_LABEL_CUSTOM=`curl http://169.254.169.254/jcs-metadata/latest/attributes/k8s-node-labels | awk -F "\"" '{print $2}'`
    KUBE_RESERVED_CPU=`curl http://169.254.169.254/jcs-metadata/latest/attributes/k8s-kube-reserved-cpu | awk -F "\"" '{print $2}'`
    KUBE_RESERVED_MEM=`curl http://169.254.169.254/jcs-metadata/latest/attributes/k8s-kube-reserved-mem | awk -F "\"" '{print $2}'`

    variables=`getMetadata ${VARIABLES_METADATA_KEY} | base64 -d | gzip -d` || exit 1
    #eval variables=${variables}
    echo ${variables}

    PAUSE_IMAGE=`echo ${variables} | jq ".PAUSE_IMAGE" | sed -e 's/^"//g' -e 's/"$//g'`
    #CLUSTER_CA_BASE64=`echo ${variables} | jq ".CLUSTER_CA_BASE64" | sed -e 's/^"//g' -e 's/"$//g'`
    CLUSTER_INNER_IP=`echo ${variables} | jq ".CLUSTER_INNER_IP" | sed -e 's/^"//g' -e 's/"$//g'`
    BOOTSTRAP_TOKEN=`echo ${variables} | jq ".BOOTSTRAP_TOKEN" | sed -e 's/^"//g' -e 's/"$//g'`
    CLUSTER_DNS=`echo ${variables} | jq ".CLUSTER_DNS" | sed -e 's/^"//g' -e 's/"$//g'`
    METADATA_SUBNET_NAME=`echo ${variables} | jq ".METADATA_SUBNET_NAME" | sed -e 's/^"//g' -e 's/"$//g'`
    METADATA_SUBNET_ID=`echo ${variables} | jq ".METADATA_SUBNET_ID" | sed -e 's/^"//g' -e 's/"$//g'`
    METADATA_VPC_ID=`echo ${variables} | jq ".METADATA_VPC_ID" | sed -e 's/^"//g' -e 's/"$//g'`
    METADATA_AZS=`echo ${variables} | jq ".METADATA_AZS" | sed -e 's/^"//g' -e 's/"$//g'`
    METADATA_CLUSTER_ID=`echo ${variables} | jq ".METADATA_CLUSTER_ID" | sed -e 's/^"//g' -e 's/"$//g'`
    METADATA_ACCESS_KEY=`echo ${variables} | jq ".METADATA_ACCESS_KEY" | sed -e 's/^"//g' -e 's/"$//g'`
    METADATA_SECRET_KEY=`echo ${variables} | jq ".METADATA_SECRET_KEY" | sed -e 's/^"//g' -e 's/"$//g'`
    #KUBE_RESERVED_CPU=`echo ${variables} | jq ".KUBE_RESERVED_CPU" | sed -e 's/^"//g' -e 's/"$//g'`
    #KUBE_RESERVED_MEM=`echo ${variables} | jq ".KUBE_RESERVED_MEM" | sed -e 's/^"//g' -e 's/"$//g'`
    NODE_TEMPLATE_K8S_VERSION=`echo ${variables} | jq ".NODE_TEMPLATE_K8S_VERSION" | sed -e 's/^"//g' -e 's/"$//g'`
    NODE_NTP_SERVER=`echo ${variables} | jq ".NODE_NTP_SERVER" | sed -e 's/^"//g' -e 's/"$//g'`

    TEST_ENV=`echo ${variables} | jq ".TEST_ENV" | sed -e 's/^"//g' -e 's/"$//g'`
    TEST_OPENAPI_LB=`echo ${variables} | jq ".TEST_OPENAPI_LB" | sed -e 's/^"//g' -e 's/"$//g'`
    TEST_OPENAPI_CC=`echo ${variables} | jq ".TEST_OPENAPI_CC" | sed -e 's/^"//g' -e 's/"$//g'`
    TEST_USERPIN=`echo ${variables} | jq ".TEST_USERPIN" | sed -e 's/^"//g' -e 's/"$//g'`
    TEST_USERPIN=`echo ${variables} | jq ".TEST_USERPIN" | sed -e 's/^"//g' -e 's/"$//g'`
    TEST_OPENAPI_VM=`echo ${variables} | jq ".TEST_OPENAPI_VM" | sed -e 's/^"//g' -e 's/"$//g'`
    TEST_OPENAPI_DISK=`echo ${variables} | jq ".TEST_OPENAPI_DISK" | sed -e 's/^"//g' -e 's/"$//g'`
    TEST_OPENAPI_JKE=`echo ${variables} | jq ".TEST_OPENAPI_JKE" | sed -e 's/^"//g' -e 's/"$//g'`
    TEST_ADMINUSERPIN=`echo ${variables} | jq ".TEST_ADMINUSERPIN" | sed -e 's/^"//g' -e 's/"$//g'`
    TEST_ADMINUSERPIN=`echo ${variables} | jq ".TEST_ADMINUSERPIN" | sed -e 's/^"//g' -e 's/"$//g'`
    TEST_USERPIN=`echo ${variables} | jq ".TEST_USERPIN" | sed -e 's/^"//g' -e 's/"$//g'`
    TEST_USERPIN=`echo ${variables} | jq ".TEST_USERPIN" | sed -e 's/^"//g' -e 's/"$//g'`

    check_empty NODE_LABEL_REGION ${NODE_LABEL_REGION}
    check_empty NODE_LABEL_ZONE ${NODE_LABEL_ZONE}
    check_empty NODE_LABEL_CUSTOM ${NODE_LABEL_CUSTOM}

    check_empty PAUSE_IMAGE ${PAUSE_IMAGE}
    #check_empty CLUSTER_CA_BASE64 ${CLUSTER_CA_BASE64}
    check_empty CLUSTER_INNER_IP ${CLUSTER_INNER_IP}
    check_empty BOOTSTRAP_TOKEN ${BOOTSTRAP_TOKEN}
    check_empty CLUSTER_DNS ${CLUSTER_DNS}
    check_empty METADATA_SUBNET_NAME ${METADATA_SUBNET_NAME}
    #check_empty METADATA_SUBNET_ID ${METADATA_SUBNET_ID}
    check_empty METADATA_VPC_ID ${METADATA_VPC_ID}
    check_empty METADATA_AZS ${METADATA_AZS}
    check_empty METADATA_CLUSTER_ID ${METADATA_CLUSTER_ID}
    check_empty METADATA_ACCESS_KEY ${METADATA_ACCESS_KEY}
    check_empty METADATA_SECRET_KEY ${METADATA_SECRET_KEY}
    check_empty KUBE_RESERVED_CPU ${KUBE_RESERVED_CPU}
    check_empty KUBE_RESERVED_MEM ${KUBE_RESERVED_MEM}
    check_empty NODE_NTP_SERVER ${NODE_NTP_SERVER}

}

function write_ca_cert() {
    local ca_cert_path="/etc/kubernetes/pki/"
    local ca_cert_file=${ca_cert_path}ca.crt
    mkdir -p ${ca_cert_path}

    CLUSTER_CA_BASE64=`getMetadata ${CLUSTER_CA_KEY}` || exit 1
    check_empty CLUSTER_CA_BASE64 ${CLUSTER_CA_BASE64}

    echo -e ${CLUSTER_CA_BASE64} > ${ca_cert_file}
    check_code_or_exit "base64 decode and write to ca file failed"
}

function fill_ntp_conf() {
    local ntp_meta_conf="/etc/node-ntp.conf"
    local ntp_conf="/etc/ntp.conf"

    sed -i -e "s|NODE_NTP_SERVER|${NODE_NTP_SERVER}|g" ${ntp_meta_conf}
    mv -f ${ntp_meta_conf} ${ntp_conf}

}

function fill_kubelet_conf() {
    local systemd_target="/etc/systemd/system/kubelet.service.d/10-node-kubeadm.conf"

    NODE_LABEL_CUSTOM=${NODE_LABEL_CUSTOM//:/=}
    sed -i -e "s|PAUSE_IMAGE|${PAUSE_IMAGE}|g" \
           -e "s|NODE_LABEL_REGION|${NODE_LABEL_REGION}|g" \
           -e "s|NODE_LABEL_ZONE|${NODE_LABEL_ZONE}|g" \
           -e "s|NODE_LABEL_CUSTOM|${NODE_LABEL_CUSTOM}|g" \
           -e "s|KUBE_RESERVED_CPU|${KUBE_RESERVED_CPU}|g" \
           -e "s|KUBE_RESERVED_MEM|${KUBE_RESERVED_MEM}|g" \
           ${systemd_target}
    check_code_or_exit "fill_kubelet_conf systemd_target failed"

    CLUSTER_CA_BASE64=`echo -e ${CLUSTER_CA_BASE64} | base64 | tr -d '\n'`
    local bootstrap_target="/etc/kubernetes/node-bootstrap-kubelet.conf"
    sed -i -e "s|CLUSTER_CA_BASE64|${CLUSTER_CA_BASE64}|g" \
           -e "s|CLUSTER_INNER_IP|${CLUSTER_INNER_IP}|g" \
           -e "s|BOOTSTRAP_TOKEN|${BOOTSTRAP_TOKEN}|g" \
           ${bootstrap_target}
    check_code_or_exit "fill_kubelet_conf bootstrap_target failed"

    local config_target="/etc/kubelet/node-config.yaml"
    sed -i -e "s|CLUSTER_DNS|${CLUSTER_DNS}|g" ${config_target}
    check_code_or_exit "fill_kubelet_conf config_target failed"
}

function fill_cloud_conf() {
    local target="/etc/kubernetes/pki/node-cloud-config.yml"
    sed -i -e "s|METADATA_SUBNET_NAME|${METADATA_SUBNET_NAME}|g" \
           -e "s|METADATA_SUBNET_ID|${METADATA_SUBNET_ID}|g" \
           -e "s|METADATA_VPC_ID|${METADATA_VPC_ID}|g" \
           -e "s|METADATA_AZS|${METADATA_AZS}|g" \
           -e "s|METADATA_CLUSTER_ID|${METADATA_CLUSTER_ID}|g" \
           -e "s|METADATA_ACCESS_KEY|${METADATA_ACCESS_KEY}|g" \
           -e "s|METADATA_SECRET_KEY|${METADATA_SECRET_KEY}|g" \
           ${target}
    check_code_or_exit "fill_cloud_conf failed"

    if [ -n ${TEST_ENV} ] && [ "xnull" != "x${TEST_ENV}" ]
    then
        cat >> ${target} << EOF
  lb :
    host: ${TEST_OPENAPI_LB}
    scheme: http
  vpc :
    host: ${TEST_OPENAPI_CC}
    scheme: http
  disable_strict_zone_check: true
test:
  x-jcloud-pin: ${TEST_USERPIN}
  x-jdcloud-pin: ${TEST_USERPIN}
  vm-openapi-addr: ${TEST_OPENAPI_VM}
  vm-openapi-scheme: http
  vm-openapi-timeout: 300000
  disk-openapi-addr: ${TEST_OPENAPI_DISK}
  disk-openapi-scheme: http
  disk-openapi-timeout: 300000
  jke-openapi-addr: ${TEST_OPENAPI_JKE}
  jke-openapi-scheme: http
  jke-openapi-timeout: 300000
master:
  x-jcloud-pin: ${TEST_ADMINUSERPIN}
  x-jdcloud-pin: ${TEST_ADMINUSERPIN}
worker:
  x-jcloud-pin: ${TEST_USERPIN}
  x-jdcloud-pin: ${TEST_USERPIN}
EOF

    fi
}

function enable_and_start_kubelet() {

    if [ -n ${NODE_TEMPLATE_K8S_VERSION} ]
    then
        logger "kubelet rpm version set to ${NODE_TEMPLATE_K8S_VERSION} from metadata"
        if ! rpm -qa | grep kubelet | grep "${NODE_TEMPLATE_K8S_VERSION}" 2>&1
        then
            download_url=`getMetadata ${DOWNLOAD_SERVER_URL_KEY}`
            check_code_or_exit "get download_url from metadata failed"

            kubelet_rpm_name="kubelet-${NODE_TEMPLATE_K8S_VERSION}.x86_64.rpm"
            kubelet_rpm_url="${download_url}/rpm/${kubelet_rpm_name}"
            kubelet_rpm_file="${DEPLOY_DIR}/downloads/${kubelet_rpm_name}"
            retry 10 wget ${kubelet_rpm_url} -O ${kubelet_rpm_file}
            check_code_or_exit "wget get ${kubelet_rpm_url} failed"

            if [ ! -f ${kubelet_rpm_file} ]
            then
                logger "there is no such file ${kubelet_rpm_file}"
                exit 1
            fi

            yum install -y ${kubelet_rpm_file} 2>&1
            if ! rpm -qa | grep kubelet | grep "${NODE_TEMPLATE_K8S_VERSION}" 2>&1
            then
                logger "yum install ${kubelet_rpm_file} seems failed, no rpm with version ${NODE_TEMPLATE_K8S_VERSION} found"
                logger "try downgrade kubelet"
                yum downgrade -y ${kubelet_rpm_file} 2>&1
            fi
        else
            logger "rpm has been installed, skip download and install again"
        fi

        logger "let's check kubelet version again"
        rpm -qa | grep kubelet | grep "${NODE_TEMPLATE_K8S_VERSION}" 2>&1
        check_code_or_exit "there is no kubelet with version ${NODE_TEMPLATE_K8S_VERSION} found after install or downgrade"
    else
        logger "there is no kubelet version specified in metadata, let's check if any kubelet is installed"
        rpm -qa | grep kubelet 2>&1
        check_code_or_exit "there is not any kubelet found"
    fi


    systemctl daemon-reload
    systemctl enable ntpd && systemctl restart ntpd
    check_code_or_exit "restart ntpd failed"
    systemctl enable kubelet && systemctl start kubelet
    check_code_or_exit "start kubelet failed"
}

logger "==== start to check_metadata_info"
fetch_metadata_info
logger "==== start to write_ca_cert"
write_ca_cert
logger "==== start to fill_ntp_conf"
fill_ntp_conf
logger "==== strat to fill_kubelet_conf"
fill_kubelet_conf
logger "==== start to fill_cloud_conf"
fill_cloud_conf
logger "==== start to enable_and_start_kubelet"
enable_and_start_kubelet
logger "==== deploy node finished"