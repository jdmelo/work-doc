#!/usr/bin/env bash

LOCKER_FILE="/etc/jke/tagfile"
DEPLOY_DIR="/etc/jke/"
DOWNLOAD_SERVER_URL_KEY="k8s-download-url"
DEPLOY_TAR_PATH="k8s-node-deploy-tar"

source ${DEPLOY_DIR}scripts/common.sh
download_url=`getMetadata ${DOWNLOAD_SERVER_URL_KEY}` || exit 1
deploy_tar=`getMetadata ${DEPLOY_TAR_PATH}` || exit 1
tarFile=${download_url}/tar/${deploy_tar}.tgz

function checkRunOnce(){
    tagfile="${LOCKER_FILE}"
    if [ -f ${tagfile} ]
    then
        echo "kubernetes tag file ${tagfile} is exist"
        exit 0
    fi
}

function runDeployScript() {
    retry 10 wget ${tarFile} -O ${DEPLOY_DIR}jke.tgz || exit 1
    tar -zvxf ${DEPLOY_DIR}jke.tgz -C / && ${DEPLOY_DIR}scripts/deploy_node.sh || exit 1
}

function makeAutolaunchLocker() {
    mkdir -p /etc/jke
    touch ${LOCKER_FILE}
}

function entry(){

    logger "== start check_run_once"
    checkRunOnce
    logger "== start runDeployScript"
    runDeployScript
    logger "== start makeAutolaunchLocker"
    makeAutolaunchLocker
}

entry > /tmp/auto_launch.log 2>&1
