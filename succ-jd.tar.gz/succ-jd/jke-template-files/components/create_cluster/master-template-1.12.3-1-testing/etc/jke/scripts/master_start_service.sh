#!/bin/bash

function error_log()
{
    echo "[ERROR] $1" >&2
    echo "[ERROR] $1" >> /tmp/deploy.log

}
function log()
{
    echo "[DEBUG] $1"
    echo "[DEBUG] $1" >> /tmp/deploy.log

}

COMMON_SCRIPT="/etc/jke/scripts/common.sh"
source ${COMMON_SCRIPT}

IP=`ip -4 addr show eth0 | grep -oP "(?<=inet )[\d\.]+(?=/)"`
HOSTNAME=`hostname`
if ! grep "$IP $HOSTNAME" /etc/hosts > /dev/null 2>&1
then
    echo "$IP $HOSTNAME" >> /etc/hosts
fi

if [[ $? != 0 ]]
then
    error_log "${COMMON_SCRIPT} not exist"
    exit 1
fi

OFFICIAL_REGISTRY="jdcloud"

systemctl status docker | grep Active | grep running || systemctl start docker

#for region in cn-north-1 cn-south-1 cn-east-2
#do
#    registry="${OFFICIAL_REGISTRY}-${region}.jcr.service.jdcloud.com/"
#
#    image_id=`docker images | grep "{{ images_etcd_image }}" | grep "{{ images_etcd_version }}" | awk '{print $3}' | uniq | head -1`
#    if [ ! -z ${image_id} ]
#    then
#        docker tag ${image_id} "${registry}{{ images_etcd_image }}:{{ images_etcd_version }}"
#    fi
#    image_id=`docker images | grep "{{ images_pause_image }}" | grep "{{ images_pause_version }}" | awk '{print $3}' | uniq | head -1`
#    if [ ! -z ${image_id} ]
#    then
#        docker tag ${image_id} "${registry}{{ images_pause_image }}:{{ images_pause_version }}"
#    fi
#    image_id=`docker images | grep "{{ images_apiserver_image }}" | grep "{{ images_apiserver_version }}" | awk '{print $3}' | uniq | head -1`
#    if [ ! -z ${image_id} ]
#    then
#        docker tag ${image_id} "${registry}{{ images_apiserver_image }}:{{ images_apiserver_version }}"
#    fi
#    image_id=`docker images | grep "{{ images_controller_manager_image }}" | grep "{{ images_controller_manager_version }}" | awk '{print $3}' | uniq | head -1`
#    if [ ! -z ${image_id} ]
#    then
#        docker tag ${image_id} "${registry}{{ images_controller_manager_image }}:{{ images_controller_manager_version }}"
#    fi
#    image_id=`docker images | grep "{{ images_scheduler_image }}" | grep "{{ images_scheduler_version }}" | awk '{print $3}' | uniq | head -1`
#    if [ ! -z ${image_id} ]
#    then
#        docker tag ${image_id} "${registry}{{ images_scheduler_image }}:{{ images_scheduler_version }}"
#    fi
#    image_id=`docker images | grep "{{ images_dashboard_image }}" | grep "{{ images_dashboard_version }}" | awk '{print $3}' | uniq | head -1`
#    if [ ! -z ${image_id} ]
#    then
#        docker tag ${image_id} "${registry}{{ images_dashboard_image }}:{{ images_dashboard_version }}"
#    fi
#    image_id=`docker images | grep "{{ images_heapster_image }}" | grep "{{ images_heapster_version }}" | awk '{print $3}' | uniq | head -1`
#    if [ ! -z ${image_id} ]
#    then
#        docker tag ${image_id} "${registry}{{ images_heapster_image }}:{{ images_heapster_version }}"
#    fi
#    image_id=`docker images | grep "{{ images_jdcloud_k8s_cni_image }}" | grep "{{ images_jdcloud_k8s_cni_version }}" | awk '{print $3}' | uniq | head -1`
#    if [ ! -z ${image_id} ]
#    then
#        docker tag ${image_id} "${registry}{{ images_jdcloud_k8s_cni_image }}:{{ images_jdcloud_k8s_cni_version }}"
#    fi
#    image_id=`docker images | grep "{{ images_kubedns_image }}" | grep "{{ images_kubedns_version }}" | awk '{print $3}' | uniq | head -1`
#    if [ ! -z ${image_id} ]
#    then
#        docker tag ${image_id} "${registry}{{ images_kubedns_image }}:{{ images_kubedns_version }}"
#    fi
#    image_id=`docker images | grep "{{ images_nginx_image }}" | grep "{{ images_nginx_version }}" | awk '{print $3}' | uniq | head -1`
#    if [ ! -z ${image_id} ]
#    then
#        docker tag ${image_id} "${registry}{{ images_nginx_image }}:{{ images_nginx_version }}"
#    fi
#    image_id=`docker images | grep "{{ images_dnsmasq_image }}" | grep "{{ images_dnsmasq_version }}" | awk '{print $3}' | uniq | head -1`
#    if [ ! -z ${image_id} ]
#    then
#        docker tag ${image_id} "${registry}{{ images_dnsmasq_image }}:{{ images_dnsmasq_version }}"
#    fi
#    image_id=`docker images | grep "{{ images_sidecar_image }}" | grep "{{ images_sidecar_version }}" | awk '{print $3}' | uniq | head -1`
#    if [ ! -z ${image_id} ]
#    then
#        docker tag ${image_id} "${registry}{{ images_sidecar_image }}:{{ images_sidecar_version }}"
#    fi
#    image_id=`docker images | grep "{{ images_kubeproxy_master_image }}" | grep "{{ images_kubeproxy_master_version }}" | awk '{print $3}' | uniq | head -1`
#    if [ ! -z ${image_id} ]
#    then
#        docker tag ${image_id} "${registry}{{ images_kubeproxy_master_image }}:{{ images_kubeproxy_master_version }}"
#    fi
#    image_id=`docker images | grep "{{ images_kubeproxy_node_image }}" | grep "{{ images_kubeproxy_node_version }}" | awk '{print $3}' | uniq | head -1`
#    if [ ! -z ${image_id} ]
#    then
#        docker tag ${image_id} "${registry}{{ images_kubeproxy_node_image }}:{{ images_kubeproxy_node_version }}"
#    fi
#    image_id=`docker images | grep "{{ images_scheduler_extender_image }}" | grep "{{ images_scheduler_extender_version }}" | awk '{print $3}' | uniq | head -1`
#    if [ ! -z ${image_id} ]
#    then
#        docker tag ${image_id} "${registry}{{ images_scheduler_extender_image }}:{{ images_scheduler_extender_version }}"
#    fi
#    image_id=`docker images | grep "{{ images_jke_master_controller_image }}" | grep "{{ images_jke_master_controller_version }}" | awk '{print $3}' | uniq | head -1`
#    if [ ! -z ${image_id} ]
#    then
#        docker tag ${image_id} "${registry}{{ images_jke_master_controller_image }}:{{ images_jke_master_controller_version }}"
#    fi
#    image_id=`docker images | grep "{{ images_prometheus_image }}" | grep "{{ images_prometheus_version }}" | awk '{print $3}' | uniq | head -1`
#    if [ ! -z ${image_id} ]
#    then
#        docker tag ${image_id} "${registry}{{ images_prometheus_image }}:{{ images_prometheus_version }}"
#    fi
#    image_id=`docker images | grep "{{ images_node_exporter_image }}" | grep "{{ images_node_exporter_version }}" | awk '{print $3}' | uniq | head -1`
#    if [ ! -z ${image_id} ]
#    then
#        docker tag ${image_id} "${registry}{{ images_node_exporter_image }}:{{ images_node_exporter_version }}"
#    fi
#    image_id=`docker images | grep "{{ images_kube_state_metrics_image }}" | grep "{{ images_kube_state_metrics_version }}" | awk '{print $3}' | uniq | head -1`
#    if [ ! -z ${image_id} ]
#    then
#        docker tag ${image_id} "${registry}{{ images_kube_state_metrics_image }}:{{ images_kube_state_metrics_version }}"
#    fi
#    image_id=`docker images | grep "{{ images_jdmon_image }}" | grep "{{ images_jdmon_version }}" | awk '{print $3}' | uniq | head -1`
#    if [ ! -z ${image_id} ]
#    then
#        docker tag ${image_id} "${registry}{{ images_jdmon_image }}:{{ images_jdmon_version }}"
#    fi
#    image_id=`docker images | grep "{{ images_addon_resizer_image }}" | grep "{{ images_addon_resizer_version }}" | awk '{print $3}' | uniq | head -1`
#    if [ ! -z ${image_id} ]
#    then
#        docker tag ${image_id} "${registry}{{ images_addon_resizer_image }}:{{ images_addon_resizer_version }}"
#    fi
#
#done



kubeletVersion="{{ reserved_k8s_version }}"
fileServer="{{ fileServer }}"

yum -y install `curl ${fileServer}/rpm/k8s.${kubeletVersion}.list.rpm`
#if [ "x" != "x${kubeletVersion}" ] && [ "x" != "x${fileServer}" ]
#then
#    if ! rpm -qa | grep kubelet | grep "${kubeletVersion}" > /dev/null 2>&1
#    then
#        pkg="${fileServer}/rpm/kubelet-${kubeletVersion}.x86_64.rpm"
#        output=`yum -y install ${pkg} 2>&1`
#        if [[ $? != 0 ]]
#        then
#            error_log "install ${pkg} failed (${output})"
#            output=`yum -y downgrade ${pkg} 2>&1`
#            if [[ $? != 0 ]]
#            then
#                error_log "downgrade ${pkg} failed (${output})"
#                #exit 1
#            else
#                log "downgrade succeed"
#            fi
#        else
#            log "install succeed"
#        fi
#        if ! rpm -qa | grep kubelet | grep "${kubeletVersion}" > /dev/null 2>&1
#        then
#            error_log "install ${pkg} succeed but can't find rpm"
#            #exit 1
#
#            if ! rpm -qa | grep kubelet > /dev/null 2>&1
#            then
#                error_log "install ${pkg} failed and there no other kubelet here"
#                exit 1
#            else
#                log "install ${pkg} failed but there is other kubelet here"
#            fi
#        else
#            log "specified kubelet found after install"
#        fi
#    else
#        log "specified kubelet already installed"
#    fi
#fi

systemctl daemon-reload
systemctl enable docker
systemctl enable kubelet

#retry 2 systemctl start docker
#if [[ $? != 0 ]]
#then
#    exit $?
#fi
systemctl restart kubelet
exit $?