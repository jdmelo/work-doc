#!/bin/bash

source `dirname $0`/etcd_common.sh

PLAN_ID=$1

if [ "x" = "x${PLAN_ID}" ]
then
    PLAN_ID="NOPLAN"
fi

$ETCDCTL snapshot save /root/etcd-snapshot.${PLAN_ID}.db
gzip -f /root/etcd-snapshot.${PLAN_ID}.db

bash `dirname $0`/etcd_keys.sh ${PLAN_ID}