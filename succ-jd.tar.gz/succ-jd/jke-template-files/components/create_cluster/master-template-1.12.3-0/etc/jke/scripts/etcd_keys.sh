#!/bin/bash

source `dirname $0`/common.sh
source `dirname $0`/etcd_common.sh

PLAN_ID=$1

if [ "x" = "x${PLAN_ID}" ]
then
    PLAN_ID="NOPLAN"
fi

$ETCDCTL get /registry --prefix=true | grep -a "/registry" | sort > /root/etcd-snapshot.${PLAN_ID}.db.list