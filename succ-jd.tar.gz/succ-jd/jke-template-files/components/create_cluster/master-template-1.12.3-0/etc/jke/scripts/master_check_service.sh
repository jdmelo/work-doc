#!/bin/bash

function error_log()
{
    echo "[ERROR] $1" >&2

}

COMMON_SCRIPT="/etc/jke/scripts/common.sh"
source ${COMMON_SCRIPT}
if [[ $? != 0 ]]
then
    error_log "${COMMON_SCRIPT} not exist"
    exit 1
fi

function test_api() {
    if [[ "403" != `curl -s -o /dev/null -w "%{http_code}" -k https://127.0.0.1:6443` ]]
    then
        return 1
    fi
}

retry 20 test_api