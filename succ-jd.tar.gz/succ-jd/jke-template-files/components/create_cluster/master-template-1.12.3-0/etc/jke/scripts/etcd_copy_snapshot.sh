#!/bin/bash

SOURCE_HOST=$1
PASS=$2
PLAN_ID=$3

if [ "x" = "x${SOURCE_HOST}" ] || [ "x" = "x${PASS}" ]
then
    echo "no host or pass set" >&2
    exit 2
fi

if [ "x" = "x${PLAN_ID}" ]
then
    PLAN_ID="NOPLAN"
fi

#yum -y install sshpass
#
#if ! rpm -qa | grep sshpass > /dev/null 2>&1
#then
#    yum install -y {{ fileServer }}/rpm/sshpass-1.05-5.el7.x86_64.rpm
#fi

if ! which sshpass > /dev/null 2>&1
then
    if curl -m 3 -I {{ fileServer }}/rpm/sshpass-1.05-5.el7.x86_64.rpm > /dev/null
    then
        yum install -y {{ fileServer }}/rpm/sshpass-1.05-5.el7.x86_64.rpm
    else
        yum -y install sshpass
    fi
fi

echo "sshpass -p $PASS scp -o ConnectTimeout=20 -oStrictHostKeyChecking=no -oCheckHostIP=no ${SOURCE_HOST}:/root/etcd-snapshot.${PLAN_ID}.db /root/" > /tmp/scp.log
sshpass -p $PASS scp -o ConnectTimeout=20 -oStrictHostKeyChecking=no -oCheckHostIP=no ${SOURCE_HOST}:/root/etcd-snapshot.${PLAN_ID}.db.gz /root/
sshpass -p $PASS scp -o ConnectTimeout=20 -oStrictHostKeyChecking=no -oCheckHostIP=no ${SOURCE_HOST}:/root/etcd-snapshot.${PLAN_ID}.db.list /root/etcd-snapshot.${PLAN_ID}.db.list.src