#!/bin/bash

source `dirname $0`/common.sh
source `dirname $0`/etcd_common.sh

if [ "x" = "x${PLAN_ID}" ]
then
    PLAN_ID="NOPLAN"
fi

count=`$ETCDCTL endpoint health | grep "is healthy" | wc -l`
if [ "x3" != "x$count" ]
then
    error_log "check health member number is $count, not 3"
    exit 2
fi

logger "health member is $count"