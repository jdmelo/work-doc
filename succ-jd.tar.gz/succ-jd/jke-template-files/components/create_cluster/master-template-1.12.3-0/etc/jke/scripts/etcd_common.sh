#!/bin/bash

export ETCDCTL_API=3
export ETCDCTL="etcdctl \
    --endpoints {{ metadata_etcd_cluster_apiconf }} \
    --cacert /etc/kubernetes/pki/etcd/etcd-ca.crt \
    --cert /etc/kubernetes/pki/etcd/etcd-client.crt \
    --key /etc/kubernetes/pki/etcd/etcd-client.key "

export RESTORE_ETCDCTL="etcdctl \
    --name {{ masters_node_name }} \
    --initial-cluster {{ metadata_etcd_cluster }} \
    --initial-advertise-peer-urls https://{{ metadata_master_fixed_ip }}:2380 \
    --data-dir /var/lib/etcd "

export MANIFEST_DIR="/etc/kubernetes/manifests/"
export MANIFEST_DEPLOY_DIR="/etc/kubernetes/manifests.deploy.tmp/"
export MANIFEST_TEMP_DIR="/etc/kubernetes/manifests.tmp/"
export ETCD_SPEC_YAML="etcd.yaml"

