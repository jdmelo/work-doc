#!/bin/bash

PLAN_ID=$1

source `dirname $0`/common.sh
source `dirname $0`/etcd_common.sh

if [ "x" = "x${PLAN_ID}" ]
then
    PLAN_ID="NOPLAN"
fi

bash `dirname $0`/etcd_keys.sh ${PLAN_ID} > /dev/null 2>&1

output=`diff /root/etcd-snapshot.${PLAN_ID}.db.list /root/etcd-snapshot.${PLAN_ID}.db.list.src`
if [ $? != 0 ]
then
    error_log "/root/etcd-snapshot.${PLAN_ID}.db.list /root/etcd-snapshot.${PLAN_ID}.db.list.src not the same (${output})"
    exit 2
fi