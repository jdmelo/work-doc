#!/bin/bash

source `dirname $0`/common.sh
source `dirname $0`/etcd_common.sh

if [ ! -f ${MANIFEST_DEPLOY_DIR}${ETCD_SPEC_YAML} ]
then
    echo "deploy file ${MANIFEST_DEPLOY_DIR}${ETCD_SPEC_YAML} not exist" >&2
    exit 2
fi

if [ ! -f ${MANIFEST_DIR}${ETCD_SPEC_YAML} ]
then
    cp -f ${MANIFEST_DEPLOY_DIR}${ETCD_SPEC_YAML} ${MANIFEST_DIR}${ETCD_SPEC_YAML}
    if [ $? != 0 ]
    then
        error_log "cp ${MANIFEST_DEPLOY_DIR}${ETCD_SPEC_YAML} to ${MANIFEST_DIR}${ETCD_SPEC_YAML} failed"
        exit 2
    else
        exit 0
    fi
fi

if ! diff ${MANIFEST_DIR}${ETCD_SPEC_YAML} ${MANIFEST_DIR}${ETCD_SPEC_YAML} >/dev/null 2>&1
then
    cp -f ${MANIFEST_DEPLOY_DIR}${ETCD_SPEC_YAML} ${MANIFEST_DIR}${ETCD_SPEC_YAML}
    if [ $? != 0 ]
    then
        error_log "cp ${MANIFEST_DEPLOY_DIR}${ETCD_SPEC_YAML} to ${MANIFEST_DIR}${ETCD_SPEC_YAML} failed"
        exit 2
    else
        exit 0
    fi
fi