package jcloudwatch

import (
	"context"

	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jcs-eye/utils"
	"jd.com/jvirt/jvirt-jcs-eye/utils/http"
)

type DataPoint struct {
	Metric    string                 `json:"metric"`
	Value     interface{}            `json:"value"`
	Timestamp int64                  `json:"timestamp"`
	Tags      map[string]interface{} `json:"tags"`
}

// IaaS monitor request data.
type RequestData struct {
	AppCode     string      `json:"appCode"`
	ServiceCode string      `json:"serviceCode"`
	DataCenter  string      `json:"dataCenter"`
	ResourceId  string      `json:"resourceId"`
	DataPoints  []DataPoint `json:"dataPoints"`
}

// IaaS monitor response data.
type ResponseData struct {
	Failed  int `json:"failed"`
	Success int `json:"success"`
}

type IMonitorClient struct {
	*http.Client
	ServerUrl string
	log       log.Logger
}

func NewIMonitorClient(client *http.Client, serverUrl string, log log.Logger) *IMonitorClient {
	return &IMonitorClient{
		Client:    client,
		ServerUrl: serverUrl,
		log:       log,
	}
}

func (imc *IMonitorClient) UploadData(ctx context.Context, params *RequestData) error {
	header := make(map[string]string)
	header["Content-Type"] = "application/json"
	traceId := ctx.Value("trace_id").(string)
	if traceId == "" {
		header["Trace-Id"] = utils.Uuid()
	} else {
		header["Trace-Id"] = traceId
	}

	// 添加重试机制
	resp := new(ResponseData)
	err := imc.Client.DoRequest("POST", imc.ServerUrl, header, params, resp)
	if err != nil {
		imc.log.Error("Invoke IMonitorClient Post failed. Error: %#v.", err)
		return err
	}

	return nil
}
