package vm

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"runtime/debug"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/libvirt/libvirt-go"
	uuid "github.com/satori/go.uuid"
	"jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/retry"
	"jd.com/jvirt/jvirt-jcs-eye/cfg"
)

const (
	VM_NOSTATE         = "nostate"
	VM_RUNNING         = "running"
	VM_BLOCKED         = "blocked"
	VM_PAUSED          = "paused"
	VM_SHUTDOWN        = "shutdown"
	VM_SHUTOFF         = "shutoff"
	VM_CRASHED         = "crashed"
	VM_SUSPENDED       = "suspended"
	SmartCardStatsPath = "/sys/class/net/%s/device/sriov/%s/stats"
	TxBytesField       = "tx_bytes"
	RxBytesField       = "rx_bytes"
	vfNameField        = "vf-name"
)

type VMCollector struct {
	conn     *libvirt.Connect // connect to libvirtd.
	connLock sync.Mutex       // Mutex Lock
	//	connectChan chan HypervisorEvent
	Initialized bool
	log         log.Logger
}

func NewVMCollector(logger log.Logger) (*VMCollector, error) {
	c := &VMCollector{
		log: logger,
		//connectChan: make(chan HypervisorEvent, 1),
		connLock: sync.Mutex{},
	}
	err := c.InitVMCollector()
	if err != nil {
		log.Error("InitVMCollector faied : %s", err.Error())
		return nil, err
	}

	return c, nil
}

// 任务处理时捕获未知错误, 防止panic使应用程序退出
func (vm *VMCollector) OnError() {
	if r := recover(); r != nil {
		vm.log.Error("VMCollector: 发生未知错误： %v ,%s", r, string(debug.Stack()))
	}
}

func (vm *VMCollector) InitVMCollector() error {
	libvirt.EventRegisterDefaultImpl()
	// Dispatch callback event.
	//go func() {
	//	defer vm.OnError()
	//	vm.log.Debug("InitVMCollector libvirt callback event dispatch.")
	//	for {
	//		select {
	//		case data := <-vm.connectChan:
	//			if !data.IsConnect {
	//				vm.log.Warn("libvirt connection is lost, run cleanupHost.")
	//				vm.cleanupConn()
	//			}
	//		}
	//	}
	//}()

	vm.getConnection()
	// Receives async events coming in from libvirtd.
	go func() {
		defer vm.OnError()
		vm.log.Debug("InitHostManager libvirt EventRunDefaultImpl start.")
		for {
			libvirt.EventRunDefaultImpl()
		}
	}()

	vm.Initialized = true

	return nil
}

func (vm *VMCollector) ParseDomainXML(ctx context.Context, dom *libvirt.Domain) (*model.Domain, error) {
	xmlDoc, err := dom.GetXMLDesc(0)
	if err != nil {
		vm.log.Error("Invoke GetXMLDesc failed. Error: %#v.", err)
		return nil, err
	}

	domCfg := &model.Domain{}
	err = domCfg.Unmarshal(xmlDoc)
	if err != nil {
		vm.log.Error("Invoke Unmarshal failed. Error: %#v.", err)
		return nil, err
	}

	return domCfg, nil
}

func (vm *VMCollector) getDomain(ctx context.Context, domName string) (*libvirt.Domain, error) {
	conn, err := vm.getConnection()
	if err != nil {
		vm.log.Error("Invoke getConnection failed. Error: %#v.", err)
		return nil, err
	}

	if _, err := uuid.FromString(domName); err != nil {
		dom, err := conn.LookupDomainByName(domName)
		if err != nil {
			vm.log.Error("Invoke LookupDomainByName failed. Error: %#v.", err)
			return nil, err
		}

		return dom, nil
	}

	dom, err := conn.LookupDomainByUUIDString(domName)
	if err != nil {
		vm.log.Error("Invoke LookupDomainByUUIDString failed. Error: %#v.", err)
		return nil, err
	}

	return dom, nil
}

func (vm *VMCollector) listDomains(ctx context.Context) ([]libvirt.Domain, error) {
	conn, err := vm.getConnection()
	if err != nil {
		vm.log.Error("Invoke getConnection failed. Error: %#v.", err)
		return nil, err
	}

	doms, err := conn.ListAllDomains(libvirt.CONNECT_LIST_DOMAINS_ACTIVE | libvirt.CONNECT_LIST_DOMAINS_INACTIVE)
	if err != nil {
		vm.log.Error("Invoke ListAllDomains failed. Error: %#v.", err)
		return nil, err
	}

	return doms, nil
}

func (vm *VMCollector) GetPowerState(ctx context.Context, domName string) (string, error) {
	dom, err := vm.getDomain(ctx, domName)
	if err != nil {
		vm.log.Error("Invoke getDomain failed. Error: %#v.", err)
		return VM_NOSTATE, err
	}
	defer dom.Free()

	state, _, err := dom.GetState()
	if err != nil {
		vm.log.Error("Invoke Domain GetState failed. Error: %#v.", err)
		return VM_NOSTATE, err
	}

	powerState := VM_NOSTATE
	switch int(state) {
	case 0:
		powerState = VM_NOSTATE
	case 1:
		powerState = VM_RUNNING
	case 2:
		powerState = VM_BLOCKED
	case 3:
		powerState = VM_PAUSED
	case 4:
		powerState = VM_SHUTDOWN
	case 5:
		powerState = VM_SHUTOFF
	case 6:
		powerState = VM_CRASHED
	case 7:
		powerState = VM_SUSPENDED
	}

	return powerState, nil
}

func (vm *VMCollector) GetBlkRWBytes(ctx context.Context, domName string) (*DiskState, error) {
	dom, err := vm.getDomain(ctx, domName)
	if err != nil {
		vm.log.Error("Invoke getDomain failed. Error: %#v.", err)
		return nil, err
	}
	defer dom.Free()

	disk := &DiskState{RdBytes: 0, WrBytes: 0}

	domXml, err := vm.ParseDomainXML(ctx, dom)
	if err != nil {
		vm.log.Error("Invoke ParseDomainXML failed. Error: %$v.", err)
		return nil, err
	}

	for _, diskInfo := range domXml.Devices.Disks {
		vm.log.Debug("Device : %s\n", diskInfo.Target.Dev)
		// 获取磁盘信息
		diskInfo, err := dom.BlockStats(diskInfo.Target.Dev)
		if err != nil {
			vm.log.Error("Invoke dom.BlockStats failed. Error: %#v.", err)
			return disk, err
		}
		disk.RdBytes += uint64(diskInfo.RdBytes)
		disk.WrBytes += uint64(diskInfo.WrBytes)
	}

	return disk, nil
}

func ReadLines(filename string) ([]string, error) {
	f, err := os.Open(filename)
	if err != nil {
		return []string{""}, err
	}
	defer f.Close()

	var ret []string

	r := bufio.NewReader(f)
	for {
		line, err := r.ReadString('\n')
		if err != nil {
			break
		}
		ret = append(ret, strings.Trim(line, "\n"))
	}

	return ret, nil
}

//从文件中读取智能网卡的端口统计信息 "sys/class/net/p6p1/device/sriov/10/stats"
func (vm *VMCollector) SmartCardInterfaceStats(path string) (*libvirt.DomainInterfaceStats, error) {
	vfName, err := vm.getSmartNicVfNameInfoByPortId(path)
	if err != nil {
		vm.log.Error("SmartCardInterfaceStats failed, err=%v", err)
		return nil, err
	}
	//parse the string '"p6p10_10",' into p6p10 and 10
	vfName = strings.TrimSuffix(vfName, "\",")
	items := strings.Split(vfName, "_")
	//vm.log.Debug("items=%#v", items)
	if items == nil || len(items[0]) == 0 || len(items[1]) == 0 {
		return nil, errors.New("parse vf_name error!")
	}

	pathVf := fmt.Sprintf(SmartCardStatsPath, items[0], items[1])
	nicInfoView := new(SmartCardInfo)
	// 文件读取，逐行解析. 示例如下:
	// line="rx_bytes      : 2343768"
	// fields=[]string{"rx_bytes", ":", "2343768"}
	lines, err := ReadLines(pathVf)
	if err != nil {
		vm.log.Error("ReadLines error=%#v", err)
		return nil, err
	}
	for _, line := range lines {
		fields := strings.Fields(line)
		//vm.log.Debug("line=%#v, fields=%#v", line, fields)
		//处理tx_bytes
		if strings.Contains(fields[0], TxBytesField) {
			tmp, err := strconv.Atoi(fields[2])
			if err != nil {
				return nil, err
			}
			nicInfoView.TxBytes = int64(tmp)
		}
		//处理rx_bytes
		if strings.Contains(fields[0], RxBytesField) {
			tmp, err := strconv.Atoi(fields[2])
			if err != nil {
				return nil, err
			}
			nicInfoView.RxBytes = int64(tmp)
		}
	}

	vm.log.Debug("nicInfoView=%#v", nicInfoView)
	ret := &libvirt.DomainInterfaceStats{
		TxBytes: nicInfoView.TxBytes,
		RxBytes: nicInfoView.RxBytes,
	}

	return ret, nil
	//bytes, err := ioutil.ReadFile(pathVf)
	//if err != nil {
	//	vm.log.Error("ReadFile Error : %v\n", err.Error())
	//	return nil, err
	//}
	//vm.log.Debug("bytes=%#v", bytes)
	//vm.log.Debug("bytes string=%#v", string(bytes))
}

func (vm *VMCollector) getSmartNicVfNameInfoByPortId(portId string) (string, error) {
	var vfNameInfo string
	f := func() error {
		tmpVfNameInfo, err := GetVfBus(portId)
		if err != nil {
			return err
		}
		vfNameInfo = tmpVfNameInfo
		return nil
	}

	if err := retry.Retry(f, 5, 1*time.Second); err != nil {
		return "", err
	}

	return vfNameInfo, nil

}

func Command(timeOut time.Duration, name string, arg ...string) ([]byte, error) {
	// timeOut Is equal to the zero, Close the timeout.
	//a := []string{name}
	//a = append(a, arg...)
	cmd := exec.Command(name, arg...)
	return combinedOutputTimeout(cmd, timeOut)
}

// WaitTimeout waits for the given command to finish with a timeout.
// It assumes the command has already been started.
// If the command times out, it attempts to kill the process.
func waitTimeout(c *exec.Cmd, timeout time.Duration) error {
	timer := time.NewTimer(timeout)
	done := make(chan error)
	go func() { done <- c.Wait() }()
	select {
	case err := <-done:
		timer.Stop()
		return err
	case <-timer.C:
		if err := c.Process.Kill(); err != nil {
			return err
		}
		// wait for the command to return after killing it
		<-done
		return errors.New("command execute timeout")
	}
}

// CombinedOutputTimeout runs the given command with the given timeout and
// returns the combined output of stdout and stderr.
// If the command times out, it attempts to kill the process.
// timeOut is equal to the zero, Close the timeout.
func combinedOutputTimeout(c *exec.Cmd, timeout time.Duration) ([]byte, error) {
	var b bytes.Buffer
	var err error
	c.Stdout = &b
	c.Stderr = &b
	if err = c.Start(); err != nil {
		return nil, err
	}

	if timeout > 0 {
		err = waitTimeout(c, timeout)
	} else {
		c.Wait()
	}

	return b.Bytes(), err
}
func GetVfBus(portId string) (string, error) {
	timeout := 10 * time.Second
	cmd := "ovs-vsctl"
	args := []string{"--columns=external_ids", "find", "interface", fmt.Sprintf("external_ids:iface-id=%s", portId)}
	out, err := Command(timeout, cmd, args...)
	if err != nil {
		return "", err
	}
	vfInfo := string(out)

	vfNameInfo, err := getVfNameFromVfInfo(vfInfo)
	if err != nil {
		return "", err
	}
	return vfNameInfo, nil
}
func getVfNameFromVfInfo(vfInfo string) (string, error) {
	items := strings.Fields(vfInfo)
	for _, item := range items {
		if !strings.Contains(item, "=") {
			continue
		}
		k, v, err := parseKeyValue(item)
		if err != nil {
			return "", err
		}
		if k == vfNameField {
			return v, nil
		}
	}
	errMsg := fmt.Sprintf("vf-name not found! String: %s .", vfInfo)
	return "", errors.New(errMsg)
}

func parseKeyValue(str string) (string, string, error) {
	errMsg := fmt.Sprintf("Format error, String: %s .", str)
	items := strings.Split(str, "=")
	if len(items) != 2 {
		return "", "", errors.New(errMsg)
	}
	k := strings.Trim(strings.Trim(strings.Trim(items[0], "}"), "{"), "\"")
	v := strings.Trim(strings.Trim(strings.Trim(items[1], "}"), "{"), "\"")
	return k, v, nil
}

func (vm *VMCollector) GetNicRWBytes(ctx context.Context, domName string) (*NicState, error) {
	dom, err := vm.getDomain(ctx, domName)
	if err != nil {
		vm.log.Error("Invoke getDomain failed. Error: %#v.", err)
		return nil, err
	}
	defer dom.Free()

	nic := &NicState{RxBytes: 0, TxBytes: 0}

	domXml, err := vm.ParseDomainXML(ctx, dom)
	if err != nil {
		vm.log.Error("Invoke ParseDomainXML failed. Error: %$v.", err)
		return nil, err
	}

	for _, nicInfo := range domXml.Devices.Interfaces {
		vm.log.Debug("Interface : %s\n", nicInfo.Target.Dev)
		// 获取网卡信息
		nicInfoView := new(libvirt.DomainInterfaceStats)
		if cfg.VMUploadCfg.SmartCardEnable {
			nicInfoView, err = vm.SmartCardInterfaceStats(nicInfo.Target.Dev)
			if err != nil {
				vm.log.Error("Invoke SmartCardInterfaceStats failed. Error: %#v.", err)
				return nic, err
			}
		} else {
			nicInfoView, err = dom.InterfaceStats(nicInfo.Target.Dev)
			if err != nil {
				vm.log.Error("Invoke dom.InterfaceStats failed. Error: %#v.", err)
				return nic, err
			}
		}

		nic.RxBytes += uint64(nicInfoView.RxBytes)
		nic.TxBytes += uint64(nicInfoView.TxBytes)

	}

	return nic, nil
}

func (vm *VMCollector) GetVMCpu(ctx context.Context, domName string) (*CpuState, error) {
	conn, err := vm.getNewConnection()
	if err != nil {
		return nil, err
	}
	defer func() {
		_, err = conn.Close()
		if err != nil {
			vm.log.Error("close conn err= %s", err.Error())
		}
	}()
	dom, err := vm.getDomainByConn(ctx, domName, conn)
	if err != nil {
		vm.log.Error("Invoke getDomain failed. Error: %#v.", err)
		return nil, err
	}
	defer dom.Free()

	cpuInfo := new(guestCpuState)

	//path, err := exec.LookPath("virsh")
	//if err != nil {
	//	vm.log.Error("Invoke exec.LookPath failed. Error: %#v.", err)
	//	return nil, err
	//}
	//
	//args := []string{"qemu-agent-command", domName, "{\"execute\":\"guest-get-cpu-usage\"}"}
	//out, err := utils.Command(5*time.Second, path, args...)
	//if err != nil {
	//	vm.log.Error("Invoke guest-get-cpu-usage failed. Error: %#v.", err)
	//	return nil, errors.New("exec guest-get-cpu-usage failed")
	//}
	//args := []string{domName, "{\"execute\":\"guest-get-cpu-usage\"}"}
	//s := fmt.Sprintf("\nbefore %v", Curfn.Func.Nname.Sym)

	cmd := fmt.Sprintf("%s", "{\"execute\":\"guest-get-cpu-usage\"}")
	out, err := dom.QemuAgentCommand(cmd, libvirt.DomainQemuAgentCommandTimeout(5), 0)
	vm.log.Debug("out: %s.", out)
	if err != nil {
		vm.log.Error("Invoke QemuAgentCommand failed. Error: %#v.", err)
		return nil, err
	}

	err = json.Unmarshal([]byte(out), cpuInfo)
	if err != nil {
		vm.log.Error("Invoke json.Unmarshal failed. Error: %#v.", err)
		return nil, err
	}

	vm.log.Debug("GetVMCpu cpuInfo: %#v.", cpuInfo)

	return cpuInfo.Return, nil
}

func (vm *VMCollector) GetVMMem(ctx context.Context, domName string) (*MemState, error) {
	conn, err := vm.getNewConnection()
	if err != nil {
		return nil, err
	}
	defer func() {
		_, err = conn.Close()
		if err != nil {
			vm.log.Error("close conn err= %s", err.Error())
		}
	}()
	dom, err := vm.getDomainByConn(ctx, domName, conn)
	if err != nil {
		vm.log.Error("Invoke getDomain failed. Error: %#v.", err)
		return nil, err
	}
	defer dom.Free()
	memInfo := new(guestMemState)

	//path, err := exec.LookPath("virsh")
	//if err != nil {
	//	vm.log.Error("Invoke exec.LookPath failed. Error: %#v.", err)
	//	return nil, err
	//}
	//
	//args := []string{"qemu-agent-command", domName, "{\"execute\":\"guest-get-mem-usage\"}"}
	//out, err := utils.Command(5*time.Second, path, args...)
	//if err != nil {
	//	vm.log.Error("Invoke guest-get-mem-usage failed. Error: %#v.", err)
	//	return nil, errors.New("exec guest-get-mem-usage failed")
	//}
	cmd := fmt.Sprintf("%s", "{\"execute\":\"guest-get-mem-usage\"}")
	out, err := dom.QemuAgentCommand(cmd, libvirt.DomainQemuAgentCommandTimeout(5), 0)
	vm.log.Debug("out: %s.", out)
	if err != nil {
		vm.log.Error("Invoke guest-get-mem-usage failed. Error: %#v.", err)
		return nil, errors.New("exec guest-get-mem-usage failed")
	}
	err = json.Unmarshal([]byte(out), memInfo)
	if err != nil {
		vm.log.Error("Invoke json.Unmarshal failed. Error: %#v.", err)
		return nil, err
	}

	return memInfo.Return, nil
}
func (vm *VMCollector) GetVMGpu(ctx context.Context, domName string) ([]*GpuState, error) {
	conn, err := vm.getNewConnection()
	if err != nil {
		return nil, err
	}
	defer func() {
		_, err = conn.Close()
		if err != nil {
			vm.log.Error("close conn err= %s", err.Error())
		}
	}()
	dom, err := vm.getDomainByConn(ctx, domName, conn)
	if err != nil {
		vm.log.Error("Invoke getDomain failed. Error: %#v.", err)
		return nil, err
	}
	defer dom.Free()

	gpuInfo := new(guestGpuState)

	//path, err := exec.LookPath("virsh")
	//if err != nil {
	//	vm.log.Error("Invoke exec.LookPath failed. Error: %#v.", err)
	//	return nil, err
	//}
	//
	//args := []string{"qemu-agent-command", domName, "{\"execute\":\"guest-get-gpu-usage\"}"}
	//out, err := utils.Command(5*time.Second, path, args...)
	//if err != nil {
	//	vm.log.Error("Invoke guest-get-gpu-usage failed. Error: %#v.", err)
	//	return nil, errors.New("exec guest-get-gpu-usage failed")
	//}
	//
	//err = json.Unmarshal(out, gpuInfo)

	cmd := fmt.Sprintf("%s", "{\"execute\":\"guest-get-gpu-usage\"}")
	out, err := dom.QemuAgentCommand(cmd, libvirt.DomainQemuAgentCommandTimeout(5), 0)
	vm.log.Debug("out: %s.", out)
	if err != nil {
		vm.log.Error("Invoke guest-get-gpu-usage failed. Error: %#v.", err)
		return nil, errors.New("exec guest-get-gpu-usage failed")
	}
	err = json.Unmarshal([]byte(out), gpuInfo)
	if err != nil {
		vm.log.Error("Invoke json.Unmarshal failed. Error: %#v.", err)
		return nil, err
	}
	vm.log.Debug("GetVMGpu gpuInfo: %#v.", gpuInfo)

	return gpuInfo.Return, nil
}

func (vm *VMCollector) GetInstanceState(ctx context.Context, domName string) (*VMState, error) {

	domState, err := vm.GetPowerState(ctx, domName)
	if err != nil {
		return nil, err
	}

	info := &VMState{
		Id:    domName,
		State: domState,
	}
	if domState != VM_RUNNING {
		vm.log.Debug("GetPowerState did not get running state. VmId: %s, state: %#v.", domName, domState)
	}
	if domState == VM_RUNNING {
		blkInfo, err := vm.GetBlkRWBytes(ctx, domName)
		if err != nil {
			vm.log.Error("Invoke GetBlkRWBytes failed. VmId: %s, Error: %#v.", domName, err)
			return nil, err
		}

		nicInfo, err := vm.GetNicRWBytes(ctx, domName)
		if err != nil {
			vm.log.Error("Invoke GetNicRWBytes failed. VmId: %s, Error: %#v.", domName, err)
			return nil, err
		}

		cpuInfo, err := vm.GetVMCpu(ctx, domName)
		if err != nil {
			vm.log.Error("Invoke GetVMCpu failed. VmId: %s, Error: %#v.", domName, err)
			return nil, err
		}

		memInfo, err := vm.GetVMMem(ctx, domName)
		if err != nil {
			vm.log.Error("Invoke GetVMMem failed. VmId: %s, Error: %#v.", domName, err)
			return nil, err
		}

		if cfg.VMUploadCfg.GpuEnable {
			info.GpuInfo, err = vm.GetVMGpu(ctx, domName)
			if err != nil {
				vm.log.Warn("Invoke GetVMCpu failed. VmId: %s, Error: %#v.", domName, err)
			}
		}

		info.CpuNum = cpuInfo.ProcessNum
		info.CpuUsage = cpuInfo.Usage
		info.MemTotal = memInfo.Total
		info.MemUsage = memInfo.Usage
		info.DiskRdBytes = blkInfo.RdBytes
		info.DiskWrBytes = blkInfo.WrBytes
		info.NicRxBytes = nicInfo.RxBytes
		info.NicTxBytes = nicInfo.TxBytes
	}

	return info, nil
}

func (vm *VMCollector) ListInstances(ctx context.Context) ([]*Instance, error) {
	doms, err := vm.listDomains(ctx)
	if err != nil {
		vm.log.Error("Invoke listDomains failed. Error: %#v.", err)
		return nil, err
	}

	instances := make([]*Instance, 0)

	for _, dom := range doms {
		xmlData, err := vm.ParseDomainXML(ctx, &dom)
		if err != nil {
			vm.log.Error("Invoke ParseDomainXML failed. Error: %#v.", err)
			return nil, err
		}
		instName := xmlData.Name
		powerState, err := vm.GetPowerState(ctx, instName)

		metadata := xmlData.Metadata
		if metadata == nil || metadata.Jvirt == nil {
			vm.log.Warn("The instance [%s] is not created by the jvirt.", instName)
			continue
		} else {
			jvirt := xmlData.Metadata.Jvirt

			inst := &Instance{
				Id:         jvirt.Id,
				Az:         jvirt.Az,
				AgId:       jvirt.AgId,
				Type:       "kvm",
				UserId:     jvirt.User,
				PowerState: powerState,
				ImageId:    jvirt.Image,
				OsType:     jvirt.OsType,
				Arch:       jvirt.Arch,
				Vcpus:      jvirt.Cpus,
				MemKB:      jvirt.Memory,
			}

			instances = append(instances, inst)
		}

	}

	return instances, nil
}

func (vm *VMCollector) connectCloseCB(c *libvirt.Connect, reason libvirt.ConnectCloseReason) {
	var detail string

	switch reason {
	case libvirt.CONNECT_CLOSE_REASON_ERROR:
		detail = "connect error"
	case libvirt.CONNECT_CLOSE_REASON_CLIENT:
		detail = "client close connection"
	case libvirt.CONNECT_CLOSE_REASON_KEEPALIVE:
		detail = "keepalive timeout."
	case libvirt.CONNECT_CLOSE_REASON_EOF:
		detail = "EOF"
	default:
		detail = "unknown"
	}

	vm.log.Error("%v, Connection is closed with the libvirtd.", detail)

	if c == nil {
		vm.log.Debug("connectCloseCB connect is nil,return")
		return
	}
	_, err := c.Close()
	if err != nil {
		vm.log.Error("close connect with libvitd failed: %v", err.Error())
	}
	vm.log.Debug("connect close, connect chan end")

}

func (vm *VMCollector) cleanupConn() error {
	vm.connLock.Lock()
	defer vm.connLock.Unlock()

	// Bug fix: nil pointer protection
	if vm.conn == nil {
		return errors.New("cleanupConn: vm.conn is nil")
	}

	// Close connect with libvitd.
	_, err := vm.conn.Close()
	if err != nil {
		vm.log.Error("Close connect with libvitd failed : %s", err.Error())
	}
	vm.conn = nil
	return err
}

func (vm *VMCollector) getConnection() (conn *libvirt.Connect, err error) {
	vm.connLock.Lock()
	defer vm.connLock.Unlock()
	if vm.conn != nil {
		alive, err := vm.conn.IsAlive()
		if alive {
			return vm.conn, nil
		} else {
			vm.log.Warn("get connection is not alive")
			if err != nil {
				vm.log.Error("isAlive get Error:%s", err.Error())
			}
			_, err = vm.conn.Close()
			if err != nil {
				vm.log.Error("close connect with libvitd failed: %v", err.Error())
			}
			vm.conn = nil
		}
	}

	//conEvent := HypervisorEvent{
	//	IsConnect: true,
	//}
	conn, err = libvirt.NewConnect("qemu:///system")
	if err != nil {
		//conEvent.IsConnect = false
		//conEvent.Detail = err.Error()
		//vm.connectChan <- conEvent
		vm.log.Error("NewConnectReadOnly failed,Error:%s", err.Error())
		return nil, err
	}
	vm.conn = conn

	// Registering for close connection event.
	conn.RegisterCloseCallback(vm.connectCloseCB)

	//vm.connectChan <- conEvent
	return conn, nil
}

func (vm *VMCollector) getNewConnection() (conn *libvirt.Connect, err error) {
	conn, err = libvirt.NewConnect("qemu:///system")
	if err != nil {
		vm.log.Error("get new connection error: %s", err.Error())
		return nil, err
	}
	return conn, nil
}

func (vm *VMCollector) getDomainByConn(ctx context.Context, domName string, conn *libvirt.Connect) (*libvirt.Domain, error) {

	if _, err := uuid.FromString(domName); err != nil {
		dom, err := conn.LookupDomainByName(domName)
		if err != nil {
			vm.log.Error("Invoke LookupDomainByName failed. Error: %#v.", err)
			return nil, err
		}

		return dom, nil
	}

	dom, err := conn.LookupDomainByUUIDString(domName)
	if err != nil {
		vm.log.Error("Invoke LookupDomainByUUIDString failed. Error: %#v.", err)
		return nil, err
	}

	return dom, nil
}
