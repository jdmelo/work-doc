package vm

type CpuState struct {
	ProcessNum int `json:"process_num"`
	Usage      int `json:"usage"`
}
type GpuState struct {
	Vendor      string `json:"vendor"`
	Index       int    `json:"index"`
	Power       int    `json:"power"`
	Brand       string `json:"brand"`
	DevName     string `json:"devName"`
	Temperature int    `json:"temperature"`
	UtilDecoder int    `json:"utilDecoder"`
	UtilEncoder int    `json:"utilEncoder"`
	UtilGpu     int    `json:"utilGPU"`
	UtilMem     int    `json:"utilMEM"`
}
type guestCpuState struct {
	Return *CpuState `json:"return"`
}
type guestGpuState struct {
	Return []*GpuState `json:"return"`
}
type MemState struct {
	Total int `json:"total"`
	Usage int `json:"usage"`
}

type guestMemState struct {
	Return *MemState `json:"return"`
}

type DiskState struct {
	RdBytes uint64 `json:"rd_bytes"`
	WrBytes uint64 `json:"wr_bytes"`
}

type NicState struct {
	RxBytes uint64 `json:"rx_bytes"`
	TxBytes uint64 `json:"tx_bytes"`
}
type GpuInfo struct {
	GpuPower       int `json:"power"`
	GpuTemperature int `json:"temperature"`
	GpuUtil        int `json:"util_gpu"`
	GpuUtilDecoder int `json:"util_decoder"`
	GpuUtilEncoder int `json:"util_encoder"`
	GpuUtilMem     int `json:"util_mem"`
}
type VMState struct {
	Id          string `json:"id"`
	State       string `json:"state"`
	CpuNum      int    `json:"cpu_num"`
	CpuUsage    int    `json:"cpu_usage"`
	MemTotal    int    `json:"mem_total"`
	MemUsage    int    `json:"mem_usage"`
	DiskRdBytes uint64 `json:"disk_rd_bytes"`
	DiskWrBytes uint64 `json:"disk_wr_bytes"`
	NicRxBytes  uint64 `json:"nic_rx_bytes"`
	NicTxBytes  uint64 `json:"nic_tx_bytes"`
	GpuInfo     []*GpuState
}

type Instance struct {
	Id          string `json:"id"`
	Type        string `json:"type"` // container|vm
	UserId      string `json:"user_id"`
	ImageId     string `json:"image_id"`
	OsType      string `json:"os_type"`
	Arch        string `json:"arch"`
	PowerState  string `json:"power_state"`
	StateReason string `json:"state_reason"` // used by docker
	Vcpus       uint   `json:"vcpus"`
	MemKB       uint   `json:"mem_kb"`
	Az          string `json:"az"`
	AgId        string `json:"ag_id"`
}

//type HypervisorEvent struct {
//	IsConnect bool   `json:"is_connect"`
//	Detail    string `json:"detail"`
//}

type SmartCardInfo struct {
	TxBytes int64 `json:"tx_bytes"`
	RxBytes int64 `json:"rx_bytes"`

	TxDropped int `json:"tx_dropped"`
	RxDropped int `json:"rx_dropped"`

	TxPackets int `json:"tx_packets"`
	RxPackets int `json:"rx_packets"`

	TxBroadcast int `json:"tx_broadcast"`
	RxBroadcast int `json:"rx_broadcast"`

	TxMulticast int `json:"tx_multicast"`
	RxMulticast int `json:"rx_multicast"`
}
