package cntr

import (
	"bufio"
	"context"
	"errors"
	"os"
	"path"
	"runtime/debug"
	"strconv"
	"strings"
	"time"

	docker "github.com/fsouza/go-dockerclient"
	"github.com/shirou/gopsutil/cpu"
	"github.com/shirou/gopsutil/disk"
	"github.com/shirou/gopsutil/net"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jcs-eye/utils"
)

const (
	CNTR_EXITED     = "exited"
	CNTR_CREATED    = "created"
	CNTR_RESTARTING = "restarting"
	CNTR_RUNNING    = "running"
	CNTR_PAUSED     = "paused"
	CNTR_DEAD       = "dead"
)

var (
	// Common Configure
	HostId                string
	DataCenter            string
	TimerInterval         int    = 60
	ConnectTimeout               = 500
	ResponseHeaderTimeout        = 1000
	RequestTotalTimeout          = 2000
	MaxIdleConns                 = 100
	AppCode               string = "jcloud"
	MonitorUrl                   = "iaas-monitor.jcloud.com/put"
	IsCollectHost                = false
	IsCollectContainer           = false
	IsCollectVm                  = false
	ListenPort            string = "1024"

	// Log setup
	LogFileName    = "/export/Logs/dcollector/jstack-dcollector.log"
	LogFileMaxSize = 1073741824
	LogFileCount   = 5
	LogLevel       = 2

	// Host Configure
	HostServiceCode   string            = "host"
	NetInterfaces     []string          = make([]string, 0)
	DiskDevices       []string          = make([]string, 0)
	MountPoints       []string          = make([]string, 0)
	VolumeGroups      []string          = make([]string, 0)
	MountToPartitions map[string]string = make(map[string]string)

	// Docker Configure
	ContainerServiceCode string = "container"
	DockerInfoPath              = "/export/Data/nova"
	DockerProtocol       string = "unix"
	DockerAddress        string = "/var/run/docker.sock"
	CGroupMountPoint     string = "/sys/fs/cgroup"
	DockerDataVg         string
	DockerSysDisk        string
	DockerNet            string
	HostSysDisk          string

	// Libvirt Configure
	VmServiceCode string = "vm"
)

const nanoSecondsPerSecond = 1e9

type CntrCollector struct {
	ApiVersion   string
	DockerClient *docker.Client
	log          log.Logger
}

func NewCntrCollector(version string, logger log.Logger) (*CntrCollector, error) {

	c := &CntrCollector{
		ApiVersion: version,
		log:        logger,
	}

	return c, nil
}

func (c *CntrCollector) getDockerClient(ctx context.Context) (*docker.Client, error) {
	if c.DockerClient != nil {
		return c.DockerClient, nil
	}

	client, err := docker.NewVersionedClient("unix:///var/run/docker.sock", c.ApiVersion)
	if err != nil {
		c.log.Error("Invoke docker.NewVersionedClient failed. Error: %#v.", err)
		return nil, err
	}

	c.DockerClient = client

	return client, nil
}

func (c *CntrCollector) getContainer(ctx context.Context, cntrName string) (*docker.APIContainers, error) {
	filters := make(map[string][]string)
	filters["name"] = []string{cntrName}

	options := docker.ListContainersOptions{
		All:     true,
		Context: ctx,
		Filters: filters,
	}

	client, err := c.getDockerClient(ctx)
	if err != nil {
		c.log.Error("Invoke getDockerClient failed. Error: %#v.", err)
		return nil, err
	}

	containers, err := client.ListContainers(options)
	if err != nil {
		c.log.Error("Invoke DockerClient.listContainers failed. Error: %#v.", err)
		return nil, err
	}
	if len(containers) == 1 {
		return &containers[0], nil
	}

	return nil, errors.New("Container no found.")
}

func (c *CntrCollector) listContainers(ctx context.Context) ([]docker.APIContainers, error) {
	options := docker.ListContainersOptions{
		All:     true,
		Context: ctx,
	}

	client, err := c.getDockerClient(ctx)
	if err != nil {
		c.log.Error("Invoke getDockerClient failed. Error: %#v.", err)
		return nil, err
	}

	containers, err := client.ListContainers(options)
	if err != nil {
		c.log.Error("Invoke DockerClient.listContainers failed. Error: %#v.", err)
		return nil, err
	}

	return containers, nil
}

func (c *CntrCollector) inspectContainer(ctx context.Context, cntrId string) (*docker.Container, error) {
	client, err := c.getDockerClient(ctx)
	if err != nil {
		c.log.Error("Invoke getDockerClient failed. Error: %#v.", err)
		return nil, err
	}

	info, err := client.InspectContainer(cntrId)
	if err != nil {
		c.log.Error("Invoke DockerClient.inspectContainer failed. Error: %#v.", err)
		return nil, err
	}

	return info, nil
}

func (c *CntrCollector) statsContainer(ctx context.Context, cntrId string) (*docker.Stats, error) {
	var err error
	errC := make(chan error, 1)
	statsC := make(chan *docker.Stats)
	done := make(chan bool)
	defer close(done)
	client, err := c.getDockerClient(ctx)
	if err != nil {
		c.log.Error("Invoke getDockerClient failed. Error: %#v.", err)
		return nil, err
	}

	go func() {
		defer func() {
			if err := recover(); err != nil {
				c.log.Error("create goroutine catch error = %v %s", err, string(debug.Stack()))
			}
		}()

		errC <- client.Stats(docker.StatsOptions{ID: cntrId, Stats: statsC, Stream: false, Done: done, Timeout: 10 * time.Second, Context: ctx})
		close(errC)
	}()

	select {
	case stats := <-statsC:
		return stats, nil
	case <-errC:
		err = <-errC
		c.log.Error("Invoke DockerClient.Stats failed. Error: %#v.", err)
		return nil, err
	}
}

func (c *CntrCollector) GetPowerState(ctx context.Context, cntrId string) (string, error) {
	container, err := c.getContainer(ctx, cntrId)
	if err != nil {
		c.log.Error("Invoke getContainer failed. Error: %#v.", err)
		return "", err
	}

	return container.State, nil
}

func parserCgroupCpuUsage(ctx context.Context, containerID string) (float64, error) {
	var f *os.File
	var err error

	filePath := path.Join(CGroupMountPoint, "cpu,cpuacct/system.slice/docker-"+containerID+".scope/cpuacct.usage")
	filePath2 := path.Join(CGroupMountPoint, "cpu,cpuacct/docker/"+containerID+"/cpuacct.usage")

	f, err = os.Open(filePath)
	if err != nil {
		f, err = os.Open(filePath2)
		if err != nil {
			return 0, err
		}
	}
	defer f.Close()

	r := bufio.NewReader(f)
	v, err := r.ReadString('\n')
	if err != nil {
		return 0, err
	}

	cpuUsage, err := strconv.ParseFloat(strings.Trim(v, "\n"), 64)
	if err != nil {
		return 0, err
	}

	log.Debug("ContainerID: %s; CpuUsage: %#v.", containerID, cpuUsage)

	return cpuUsage, nil
}

func parserCgroupCpuSet(ctx context.Context, containerID string) ([]string, error) {
	var f *os.File
	var err error

	filePath := path.Join(CGroupMountPoint, "cpuset/system.slice/docker-"+containerID+".scope/cpuset.cpus")
	filePath2 := path.Join(CGroupMountPoint, "cpuset/docker/"+containerID+"/cpuset.cpus")

	f, err = os.Open(filePath)
	if err != nil {
		f, err = os.Open(filePath2)
		if err != nil {
			return nil, err
		}
	}
	defer f.Close()

	r := bufio.NewReader(f)
	v, err := r.ReadBytes('\n')
	if err != nil {
		return nil, err
	}
	bitm, err := utils.CgBitmapParse(v)
	if err != nil {
		return nil, err
	}
	cpuSets := utils.CgBitmapToList(bitm)
	log.Debug("ContainerID: %s; CpuSets: %#v.", containerID, cpuSets)

	return cpuSets, nil
}

func (c *CntrCollector) calculateCPUInfo(ctx context.Context, containerName string) (CpuState, error) {
	var (
		preCpuAcctUsage = 0.0
		curCpuAcctUsage = 0.0
		preTotalUsage   = 0.0
		curTotalUsage   = 0.0
	)
	procStatCpuMap := make(map[string]cpu.TimesStat)
	ret := CpuState{}

	containerInfo, err := c.inspectContainer(ctx, containerName)
	if err != nil {
		c.log.Error("Invoke DockerInspect failed. Error: %#v.", err)
		return ret, err
	}
	containerID := containerInfo.ID
	cpuSets, err := parserCgroupCpuSet(ctx, containerID)
	if err != nil {
		c.log.Error("Invoke parserCgroupCpuSet failed. Error: %#v.", err)
		return ret, err
	}

	preCpuAcctUsage, err = parserCgroupCpuUsage(ctx, containerID)
	if err != nil {
		c.log.Error("Invoke parserCgroupCpuUsage failed. Error: #v.", err)
		return ret, err
	}
	procCpus, err := cpu.Times(true)
	if err != nil {
		c.log.Error("Invoke Times failed. Error: %#v.", err)
		return ret, err
	}
	for _, v := range procCpus {
		procStatCpuMap[v.CPU] = v
	}
	for _, v := range cpuSets {
		cpuID := "cpu" + v
		if cpuUsage, ok := procStatCpuMap[cpuID]; ok {
			preTotalUsage += cpuUsage.User + cpuUsage.System + cpuUsage.Idle + cpuUsage.Nice + cpuUsage.Iowait + cpuUsage.Irq + cpuUsage.Softirq
		}
	}

	time.Sleep(1 * time.Second)

	curCpuAcctUsage, err = parserCgroupCpuUsage(ctx, containerID)
	if err != nil {
		c.log.Error("Invoke parserCgroupCpuUsage failed. Error: %#v.", err)
		return ret, err
	}
	procCpus, err = cpu.Times(true)
	if err != nil {
		c.log.Error("Invoke Times failed. Error: %#v.", err)
		return ret, err
	}
	for _, v := range procCpus {
		procStatCpuMap[v.CPU] = v
	}
	for _, v := range cpuSets {
		cpuID := "cpu" + v
		if cpuUsage, ok := procStatCpuMap[cpuID]; ok {
			curTotalUsage += cpuUsage.User + cpuUsage.System + cpuUsage.Idle + cpuUsage.Nice + cpuUsage.Iowait + cpuUsage.Irq + cpuUsage.Softirq
		}
	}

	cpuDelta := curCpuAcctUsage - preCpuAcctUsage
	systemDelta := (curTotalUsage - preTotalUsage) * nanoSecondsPerSecond

	ret.Num = len(cpuSets)
	if systemDelta > 0.0 && cpuDelta > 0.0 {
		cpuPercent := (cpuDelta / systemDelta) * 100.0
		c.log.Debug("ContainerID: %s; cpuDelta: %#v; systemDelta: %#v; cpuPercent: %#v.", containerID, cpuDelta, systemDelta, cpuPercent)
		ret.Usage = cpuPercent
	}

	return ret, nil
}
func (c *CntrCollector) GetCpu(ctx context.Context, stats *docker.Stats) *CpuState {
	preCpuStats := stats.PreCPUStats
	curCpuStats := stats.CPUStats
	var (
		cpuPercent     = 0.0
		previousCPU    = preCpuStats.CPUUsage.TotalUsage
		previousSystem = preCpuStats.SystemCPUUsage
		// calculate the change for the cpu usage of the container in between readings
		cpuDelta = float64(curCpuStats.CPUUsage.TotalUsage) - float64(previousCPU)
		// calculate the change for the entire system between readings
		systemDelta = float64(curCpuStats.SystemCPUUsage) - float64(previousSystem)
	)

	info := &CpuState{}
	info.Num = len(curCpuStats.CPUUsage.PercpuUsage)
	if systemDelta > 0.0 && cpuDelta > 0.0 {
		cpuPercent = (cpuDelta / systemDelta) * float64(info.Num) * 100.0
	}
	info.Usage = cpuPercent

	return info
}

func (c *CntrCollector) GetMem(ctx context.Context, stats *docker.Stats) *MemState {
	info := &MemState{}
	memStats := stats.MemoryStats

	memTotal := memStats.Limit
	memUsage := memStats.Usage
	memCache := memStats.Stats.Cache
	memRSS := memStats.Stats.Rss
	memMappedFile := memStats.Stats.MappedFile
	memUsed := memRSS + memMappedFile

	if memTotal != 0 {
		info.Usage = float64(memUsed) / float64(memTotal) * 100.0
	}
	// 单位: B
	info.Total = memTotal
	info.Available = memTotal - memUsed

	c.log.Debug("MemTotal: %v. MemUsage: %v. MemCache: %v. MemRss: %v. MemMappedFile: %v. MemInfo: %v.",
		memTotal, memUsage, memCache, memRSS, memMappedFile, *info)

	return info
}

func (c *CntrCollector) GetSystemDisk(ctx context.Context, stats *docker.Stats) *SystemDiskState {
	info := &SystemDiskState{}
	blkioStats := stats.BlkioStats
	for _, bioEntry := range blkioStats.IOServiceBytesRecursive {
		switch strings.ToLower(bioEntry.Op) {
		case "read":
			info.ReadBytes += bioEntry.Value
		case "write":
			info.WriteBytes += bioEntry.Value
		}
	}
	return info
}

func (c *CntrCollector) GetDataDiskState(ctx context.Context, cntrName string) (*MountPointState, error) {
	var (
		devicePath string
		mountPoint string
	)

	info, err := c.inspectContainer(ctx, cntrName)
	if err != nil {
		c.log.Error("Invoke inspectContainer failed. Error: %#v.", err)
		return nil, err
	}
	for _, mount := range info.Mounts {
		if strings.HasPrefix(mount.Source, "/mnt/") {
			mountPoint = mount.Source
			break
		}
	}
	if mountPoint == "" {
		return nil, errors.New("The mount point not exist, the container has not data disk.")
	}

	lines, err := utils.ReadLines("/etc/mtab")
	if err != nil {
		c.log.Error("Invoke ReadLines from mtab file failed. Error: %#v.", err)
		return nil, err
	}
	for _, line := range lines {
		fields := strings.Fields(line)
		if fields[1] == mountPoint {
			devicePath = fields[0]
		}
	}
	if devicePath == "" {
		return nil, errors.New("The container has not data disk.")
	}

	// 根据设备文件的路径，路径获取对应的真实路径。
	realPath, err := utils.Realpath(devicePath)
	if err != nil {
		return nil, err
	}
	temp := strings.Split(realPath, "/")
	// 获取设备名，例如：dm-0, dm-1
	deviceName := temp[len(temp)-1]

	ioCounters, err := disk.IOCounters()
	if err != nil {
		return nil, err
	}

	deviceInfo, ok := ioCounters[deviceName]
	if ok == false {
		c.log.Error("The device of %s is not found in the map.\n", deviceName)
		return nil, errors.New("The device is not found in the diskstats file.")
	}

	mountPointInfo, err := disk.Usage(mountPoint)
	if err != nil {
		return nil, err
	}

	data := &MountPointState{}
	data.ReadBytes = deviceInfo.ReadBytes
	data.WriteBytes = deviceInfo.WriteBytes
	data.ReadCount = deviceInfo.ReadCount
	data.WriteCount = deviceInfo.WriteCount

	data.Total = mountPointInfo.Total
	data.Free = mountPointInfo.Free
	data.UsedPercent = mountPointInfo.UsedPercent
	data.Fstype = mountPointInfo.Fstype
	data.Path = mountPointInfo.Path

	return data, nil
}

func (c *CntrCollector) getFilename(ctx context.Context, cntrName string) (string, error) {
	container, err := c.inspectContainer(ctx, cntrName)
	if err != nil {
		c.log.Error("Invoke inspectContainer failed. Error: %#v.", err)
		return "", err
	}

	for _, b := range container.Mounts {
		if strings.Contains(b.Destination, "/etc/sysconfig/network_veth") {
			c.log.Debug("Invoke getFilename success. Source: %s", b.Source)
			return b.Source, nil
		}
	}
	return "", nil
}

func (c *CntrCollector) GetNetworkState(ctx context.Context, cntrName string) (*NetState, error) {
	ioStats, err := net.IOCounters(true)
	if err != nil {
		c.log.Error("Invoke net.IOCounters failed. Error: %#v.", err.Error())
		return nil, err
	}

	// 容器网卡信息文件。
	//filename := path.Join(cfg.CntrUploadCfg.ContainerPath, cntrName, "veth")
	filename, err := c.getFilename(ctx, cntrName)
	if err != nil {
		c.log.Error("Invoke getFilename failed. Error: %#v.", err.Error())
		return nil, err
	}

	data, err := utils.ReadJsonFile(filename)
	if err != nil {
		c.log.Error("Read Json File failed. Error: %#v.", err.Error())
		return nil, err
	}

	info := &NetState{}
	for key := range data {
		if ok := strings.HasPrefix(key, "ns-"); ok {
			nicName := strings.Replace(key, "ns-", "port-", -1)
			for _, item := range ioStats {
				if item.Name == nicName {
					info.BytesRecv += item.BytesSent
					info.BytesSent += item.BytesRecv
					break
				}
			}
		}
	}

	return info, nil
}

func (c *CntrCollector) GetInstanceState(ctx context.Context, cntrName string) (*CntrState, error) {
	container, err := c.inspectContainer(ctx, cntrName)
	if err != nil {
		c.log.Error("Invoke inspectContainer failed. Error: %#v.", err)
		return nil, err
	}
	if cntrName != "" && cntrName[0] == 47 {
		cntrName = cntrName[1:]
	}
	containerStats, err := c.statsContainer(ctx, cntrName)
	if err != nil {
		c.log.Error("Invoke StatsContainer failed. Error: %#v.", err)
		return nil, err
	}
	if containerStats == nil {
		c.log.Error("Invoke StatsContainer failed. cntrName: %s", cntrName)
		return nil, errors.New("StatsContainer failed")
	}
	//cpuInfo := c.GetCpu(ctx, containerStats)
	cpuInfo, err := c.calculateCPUInfo(ctx, cntrName)
	if err != nil {
		c.log.Error("Invoke calculateCPUInfo failed. Error: %#v.", err)
		return nil, err
	}
	memInfo := c.GetMem(ctx, containerStats)

	sysDisk := c.GetSystemDisk(ctx, containerStats)

	netInfo, err := c.GetNetworkState(ctx, cntrName)
	if err != nil {
		c.log.Error("Invoke GetNetworkState failed. Error: %#v.", err)
		return nil, err
	}

	dataDisk, err := c.GetDataDiskState(ctx, cntrName)
	if err != nil {
		c.log.Error("Invoke GetDataDiskState failed. Error: %#v.", err)
		return nil, err
	}

	info := &CntrState{
		Id:         container.ID,
		Name:       cntrName,
		State:      container.State.Status,
		CpuNum:     cpuInfo.Num,
		CpuUsage:   cpuInfo.Usage,
		MemTotal:   memInfo.Total,
		MemUsage:   memInfo.Usage,
		Network:    netInfo,
		SystemDisk: sysDisk,
		DataDisk:   dataDisk,
	}

	return info, nil
}

func (c *CntrCollector) ListInstances(ctx context.Context) ([]*Instance, error) {
	instances := make([]*Instance, 0)
	containers, err := c.listContainers(ctx)
	if err != nil {
		c.log.Error("listContainers failed. Error: %#v.", err)
		return nil, err
	}

	for _, container := range containers {
		labels := container.Labels
		name := ""
		nameBytes := []byte(container.Names[0])
		if len(nameBytes) > 1 && nameBytes[0] == 47 {
			name = string(nameBytes[1:])
		}
		//只有i-xxxxxx和d-xxxxxx的是jcs创建的容器资源。nova-yyyyyyy的资源位迁移过来的容器资源，yyyyyyy为资源id
		if strings.HasPrefix(name, "i-") || strings.HasPrefix(name, "d-") || strings.HasPrefix(name, "nova-") {
			instance := &Instance{Id: name}
			createByJcs, findKey := labels["create_by_jcs"]
			if findKey && createByJcs == "true" {
				zone := labels["zone"]
				userId := labels["user_id"]
				imageId := labels["image_id"]
				instance.UserId = userId
				instance.ImageId = imageId
				instance.Az = zone
			}
			instances = append(instances, instance)
		} else {
			c.log.Debug("container %s not create by jcs, not upload", name)
		}
	}
	return instances, nil
}

func (c *CntrCollector) DescribeDocker(ctx context.Context) (*docker.DockerInfo, error) {
	client, err := c.getDockerClient(ctx)
	if err != nil {
		c.log.Error("Invoke getDockerClient failed. Error: %#v.", err)
		return nil, err
	}

	info, err := client.Info()
	if err != nil {
		c.log.Error("Invoke DockerClient.Info failed. Error: %#v.", err)
		return nil, err
	}

	return info, nil
}
