package cntr

type MemState struct {
	Total     uint64  `json:"total"`
	Available uint64  `json:"available"`
	Usage     float64 `json:"usage"`
}

type CpuState struct {
	Num   int     `json:"num"`
	Usage float64 `json:"usage"`
}

type NetState struct {
	BytesSent uint64 `json:"bytesSent"` // number of bytes sent
	BytesRecv uint64 `json:"bytesRecv"` // number of bytes received
}

type MountPointState struct {
	Path        string  `json:"path"`
	Fstype      string  `json:"fstype"`
	Total       uint64  `json:"total"`
	Free        uint64  `json:"free"`
	UsedPercent float64 `json:"usedPercent"`
	ReadBytes   uint64  `json:"readBytes"`
	ReadCount   uint64  `json:"readCount"`
	WriteBytes  uint64  `json:"writeBytes"`
	WriteCount  uint64  `json:"writeCount"`
}

type SystemDiskState struct {
	ReadBytes  uint64 `json:"readBytes"`
	WriteBytes uint64 `json:"writeBytes"`
}

type CntrState struct {
	Id         string           `json:"id"`
	Name       string           `json:"name"`
	State      string           `json:"state"`
	CpuNum     int              `json:"cpu_num"`
	CpuUsage   float64          `json:"cpu_usage"`
	MemTotal   uint64           `json:"mem_total"`
	MemUsage   float64          `json:"mem_usage"`
	Network    *NetState        `json:"network"`
	SystemDisk *SystemDiskState `json:"system_disk"`
	DataDisk   *MountPointState `json:"data_disk"`
}

type Instance struct {
	Id          string `json:"id"`
	Type        string `json:"type"` // container|vm
	UserId      string `json:"user_id"`
	ImageId     string `json:"image_id"`
	OsType      string `json:"os_type"`
	Arch        string `json:"arch"`
	PowerState  string `json:"power_state"`
	StateReason string `json:"state_reason"` // used by docker
	Vcpus       uint   `json:"vcpus"`
	MemKB       uint   `json:"mem_kb"`
	Az          string `json:"az"`
}
