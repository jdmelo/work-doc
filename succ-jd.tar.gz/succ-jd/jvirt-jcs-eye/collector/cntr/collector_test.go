package cntr

import (
	"context"
	"fmt"
	"strings"
	"testing"
)

func TestNewCntrCollector(t *testing.T) {
	cntr, err := NewCntrCollector("1.24")
	if err != nil {
		t.Error(err.Error())
	}

	info, err := cntr.DescribeDocker(context.TODO())
	if err != nil {
		t.Error(err.Error())
	}
	fmt.Printf("Docker Info: %#v.\n", info)

	containers, err := cntr.listContainers(context.TODO())
	if err != nil {
		t.Error(err.Error())
	}
	fmt.Printf("List containers: %#v.\n", len(containers))

	stats, err := cntr.StatsContainer(context.TODO(), "instance-v4mtytmmjb")
	if err != nil {
		t.Error(err.Error())
	}
	fmt.Printf("Stats: %#v.\n", stats)

	container, err := cntr.inspectContainer(context.TODO(), "instance-v4mtytmmjb")
	if err != nil {
		t.Error(err.Error())
	}
	fmt.Printf("container info: %#v.\n", container.Mounts)
	for _, item := range container.Mounts {
		if strings.HasPrefix(item.Source, "/mnt/") {
			fmt.Println(item.Source)
		}
	}

	data, err := cntr.GetDataDiskState(context.TODO(), "instance-v4mtytmmjb")
	if err != nil {
		t.Error(err.Error())
	}
	fmt.Printf("DataDisk state: %#v.\n", data)
}
