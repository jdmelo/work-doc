package collector

import (
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jcs-eye/cfg"
	"jd.com/jvirt/jvirt-jcs-eye/collector/cntr"
	"jd.com/jvirt/jvirt-jcs-eye/collector/host"
	"jd.com/jvirt/jvirt-jcs-eye/collector/hyper"
	"jd.com/jvirt/jvirt-jcs-eye/collector/vm"
)

var (
	HostCollect    *host.HostCollector
	VMCollect      *vm.VMCollector
	CntrCollect    *cntr.CntrCollector
	HyperCollector *hyper.HyperCollector
)

func NewCollectors(logger log.Logger) error {
	var err error
	HostCollect, err = host.NewHostCollector(cfg.DefaultCfg.HostIp, logger)
	if err != nil {
		return err
	}

	VMCollect, err = vm.NewVMCollector(logger)
	if err != nil {
		return err
	}

	CntrCollect, err = cntr.NewCntrCollector(cfg.CntrUploadCfg.DockerApiVersion, logger)
	if err != nil {
		return err
	}

	HyperCollector, err = hyper.NewHyperCollector(logger, cfg.XagentCfg)
	if err != nil {
		return err
	}

	return nil
}
