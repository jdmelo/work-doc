package log

type LogCollector struct {
}

func NewLogCollector() *LogCollector {
	return &LogCollector{}
}
