package hyper

type MemState struct {
	Total     uint64  `json:"total"`
	Available uint64  `json:"available"`
	Usage     float64 `json:"usage"`
}

type CpuState struct {
	Num   int     `json:"num"`
	Usage float64 `json:"usage"`
}

type NetState struct {
	BytesSent uint64 `json:"bytesSent"` // number of bytes sent
	BytesRecv uint64 `json:"bytesRecv"` // number of bytes received
}

type MountPointState struct {
	Path        string  `json:"path"`
	Fstype      string  `json:"fstype"`
	Total       uint64  `json:"total"`
	Free        uint64  `json:"free"`
	UsedPercent float64 `json:"usedPercent"`
	ReadBytes   uint64  `json:"readBytes"`
	ReadCount   uint64  `json:"readCount"`
	WriteBytes  uint64  `json:"writeBytes"`
	WriteCount  uint64  `json:"writeCount"`
}

type DiskState struct {
	ReadBytes  uint64 `json:"readBytes"`
	WriteBytes uint64 `json:"writeBytes"`
}

type HyperState struct {
	Id          string `json:"id"`
	CpuNum      uint64 `json:"cpu_num"`
	CpuUsage    uint64 `json:"cpu_usage"`
	MemTotal    uint64 `json:"mem_total"`
	MemUsage    uint64 `json:"mem_usage"`
	DiskRdBytes uint64 `json:"disk_rd_bytes"`
	DiskWrBytes uint64 `json:"disk_wr_bytes"`
	NicRxBytes  uint64 `json:"nic_rx_bytes"`
	NicTxBytes  uint64 `json:"nic_tx_bytes"`
}
