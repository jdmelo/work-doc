package hyper

import (
	"context"
	"errors"

	"jd.com/jvirt/jvirt-common/integration/xagent"
	"jd.com/jvirt/jvirt-common/utils/config"
	"jd.com/jvirt/jvirt-common/utils/log"
)

type HyperCollector struct {
	HyperClient *xagent.XAgentClient
	log         log.Logger
}

func NewHyperCollector(logger log.Logger, cfg *config.XAgentConfig) (*HyperCollector, error) {

	h := &HyperCollector{
		HyperClient: xagent.NewXAgentClient(logger, cfg),
		log:         logger,
	}

	return h, nil
}

func (h *HyperCollector) GetContainerStats(ctx context.Context, containerId string) (*HyperState, error) {
	podStats, isExist, err := h.HyperClient.GetPodState(containerId)
	if err != nil {
		h.log.Error("[GetContainerStats] GetPotStats failed : %s", err.Error())
		return nil, err
	}
	if !isExist {
		h.log.Error("[GetContainerStats] GetPotStats failed, Container:%s is not exist", containerId)
		return nil, errors.New("Container is not found ")
	}
	hyperState := &HyperState{}
	hyperState.CpuNum = podStats.Cpu.ProcessNum
	hyperState.CpuUsage = podStats.Cpu.Usage
	hyperState.MemTotal = podStats.Memory.Total
	hyperState.MemUsage = podStats.Memory.Usage
	for _, network := range podStats.Network.Interfaces {
		hyperState.NicRxBytes += network.RxBytes
		hyperState.NicTxBytes += network.TxBytes
	}
	for _, block := range podStats.Block.Blocks {
		hyperState.DiskRdBytes += block.RdBytes
		hyperState.DiskWrBytes += block.WrBytes
	}
	return hyperState, nil
}

func (h *HyperCollector) GetContainerInfo(ctx context.Context, containerId string) (*xagent.ContainerInfo, error) {
	containerInfo, err := h.HyperClient.GetContainerInfo(containerId)
	if err != nil {
		h.log.Error("[GetContainerInfo] GetContainerInfo failed : %s", err.Error())
		return nil, err
	}
	return containerInfo, nil
}

func (h *HyperCollector) GetPodInfo(ctx context.Context, podId string) (*xagent.PodInfo, error) {
	podInfo, err := h.HyperClient.GetPod(podId)
	if err != nil {
		h.log.Error("[GetPodInfo] GetPodInfo failed : %s", err.Error())
		return nil, err
	}
	return podInfo, nil
}

//from master add nc

func (h *HyperCollector) ListContainers(ctx context.Context) ([]*xagent.ContainerListResult, error) {
	containers, err := h.HyperClient.ListContainers()
	if err != nil {
		h.log.Error("ListContainers failed. Error: %s.", err.Error())
		return nil, err
	}
	if containers == nil {
		h.log.Error("ListContainers finished, not found container.")
		return nil, nil
	}

	return containers.ContainerList, nil
}

func (h *HyperCollector) ListPods(ctx context.Context) ([]*xagent.PodListResult, error) {
	pods, err := h.HyperClient.ListPods()
	if err != nil {
		h.log.Error("ListPods failed. Error: %s.", err.Error())
		return nil, err
	}
	if pods == nil {
		h.log.Error("ListPods finished, not found pod.")
		return nil, nil
	}

	return pods.PodList, nil
}

func (h *HyperCollector) GetPodStats(ctx context.Context, containerId string) (*HyperState, error) {
	podStats, isExist, err := h.HyperClient.GetPodState(containerId)
	if err != nil {
		h.log.Error("[GetPodStats] GetPodStats failed : %s", err.Error())
		return nil, err
	}
	if !isExist {
		h.log.Error("[GetContainerStats] GetPotStats failed, Container:%s is not exist", containerId)
		return nil, errors.New("Container is not found ")
	}
	hyperState := &HyperState{}
	hyperState.CpuNum = podStats.Cpu.ProcessNum
	hyperState.CpuUsage = podStats.Cpu.Usage
	hyperState.MemTotal = podStats.Memory.Total
	hyperState.MemUsage = podStats.Memory.Usage
	for _, network := range podStats.Network.Interfaces {
		hyperState.NicRxBytes += network.RxBytes
		hyperState.NicTxBytes += network.TxBytes
	}
	for _, block := range podStats.Block.Blocks {
		hyperState.DiskRdBytes += block.RdBytes
		hyperState.DiskWrBytes += block.WrBytes
	}
	return hyperState, nil
}
