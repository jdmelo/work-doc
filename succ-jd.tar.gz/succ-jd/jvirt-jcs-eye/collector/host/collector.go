package host

import (
	"context"
	"errors"
	"strconv"
	"strings"

	"github.com/shirou/gopsutil/cpu"
	"github.com/shirou/gopsutil/disk"
	"github.com/shirou/gopsutil/load"
	"github.com/shirou/gopsutil/mem"
	"github.com/shirou/gopsutil/net"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jcs-eye/utils"
)

type HostCollector struct {
	HostIp string
	log    log.Logger
}

func NewHostCollector(hostIp string, logger log.Logger) (*HostCollector, error) {

	h := &HostCollector{
		HostIp: hostIp,
		log:    logger,
	}

	return h, nil
}

func (h *HostCollector) GetCpu(ctx context.Context) (*CpuState, error) {
	// 获取总的cpu使用率。
	ret := &CpuState{}
	if percents, err := cpu.Percent(0, false); err != nil {
		h.log.Error("Get cpu Percent failed : %#v.", err)
		return nil, err
	} else {
		ret.CpuUsage = percents[0]
		h.log.Debug("Get cpu percents success.")
	}

	// 获取逻辑CPU个数。
	if info, err := cpu.Info(); err != nil {
		h.log.Error("Get cpu Counts failed : %#v.", err)
		return nil, err
	} else {
		ret.CpuNum = len(info)
		h.log.Debug("Get cpu Counts success.")
	}

	return ret, nil
}

func (h *HostCollector) GetMem(ctx context.Context) (*MemState, error) {
	// 获取内存信息。
	virtualMem, err := mem.VirtualMemory()
	if err != nil {
		h.log.Error("Invoke mem.VirtualMemory failed. Error: %#v.", err)
		return nil, err
	}

	ret := &MemState{
		Total:       virtualMem.Total,
		Available:   virtualMem.Available,
		Used:        virtualMem.Used,
		UsedPercent: virtualMem.UsedPercent,
		Free:        virtualMem.Free,
	}

	return ret, nil
}

func (h *HostCollector) GetLoad(ctx context.Context) (*LoadState, error) {
	avgData, err := load.Avg()
	if err != nil {
		h.log.Error("Invoke load.Avg failed. Error: %#v.", err)
		return nil, err
	}

	ret := &LoadState{
		Load1:  avgData.Load1,
		Load5:  avgData.Load5,
		Load15: avgData.Load15,
	}

	return ret, nil
}

func (h *HostCollector) GetDisk(ctx context.Context, diskName string) (*DiskUsageState, error) {
	ioCounters, err := disk.IOCounters()
	if err != nil {
		h.log.Error("Invoke disk.IOCounters failed. Error: %#v.", err)
		return nil, err
	}

	devInfo, ok := ioCounters[diskName]
	if ok == false {
		h.log.Error("The device of %s is not found in the map.", diskName)
		return nil, errors.New("The disk device is not found")
	}

	ret := &DiskUsageState{
		Name:       devInfo.Name,
		ReadCount:  devInfo.ReadCount,
		ReadBytes:  devInfo.ReadBytes,
		ReadTime:   devInfo.ReadTime,
		WriteCount: devInfo.WriteCount,
		WriteBytes: devInfo.WriteBytes,
		WriteTime:  devInfo.WriteTime,
	}

	return ret, nil
}

func (h *HostCollector) GetVGState(ctx context.Context, vgName string) (*VGUsageStat, error) {
	// 根据给的参数解析出卷组的使用信息。
	cmd, err := utils.LookPath("/usr/sbin/vgdisplay")
	if err != nil {
		h.log.Error("Invoke utils.LookPath failed. Error: %#v.", err)
		return nil, err
	}
	args := []string{"-s", "--units", "B", vgName}
	out, err := utils.Command(0, cmd, args...)
	if err != nil {
		h.log.Error("Invoke vgdisplay command failed. Error: %#v.", err)
		return nil, err
	}

	vgInfo := string(out)
	vgInfoSlice := strings.Fields(vgInfo)

	vgUsage := new(VGUsageStat)
	vgUsage.Name = vgName

	for i, s := range vgInfoSlice {
		if i == 1 {
			vgUsage.Total, _ = strconv.ParseUint(s, 10, 64)
		} else if i == 3 {
			vgUsage.Used, _ = strconv.ParseUint(s[1:], 10, 64)
		} else if i == 7 {
			vgUsage.Free, _ = strconv.ParseUint(s, 10, 64)
		}
	}
	if vgUsage.Total != 0 {
		vgUsage.UsedPercent = float64(vgUsage.Used) / float64(vgUsage.Total) * 100
	}

	return vgUsage, nil
}

// Usage returns a file system usage. path is a filessytem path such
// as "/", not device file path like "/dev/vda1".  If you want to use
// a return value of disk.Partitions, use "Mountpoint" not "Device".
func (h *HostCollector) GetMountPointState(ctx context.Context, mountPoint string) (*MountPointState, error) {
	usage, err := disk.Usage(mountPoint)
	if err != nil {
		h.log.Error("Invoke disk.Usage failed. Error: %#v.", err)
		return nil, err
	}

	ret := &MountPointState{
		Path:              usage.Path,
		Fstype:            usage.Fstype,
		Total:             usage.Total,
		Free:              usage.Free,
		Used:              usage.Used,
		UsedPercent:       usage.UsedPercent,
		InodesTotal:       usage.InodesTotal,
		InodesUsed:        usage.InodesUsed,
		InodesFree:        usage.InodesFree,
		InodesUsedPercent: usage.InodesUsedPercent,
	}

	return ret, nil
}

func (h *HostCollector) GetNic(ctx context.Context, nicName string) (*NicState, error) {
	// 获取网络信息。
	var ret *NicState
	flag := true

	ioStats, err := net.IOCounters(true)
	if err != nil {
		h.log.Error("Invoke net.IOCounters failed. Error: %#v.", err)
		return nil, err
	}

	for _, item := range ioStats {
		if nicName == item.Name {
			ret = &NicState{
				Name:        item.Name,
				BytesSent:   item.BytesSent,
				BytesRecv:   item.BytesRecv,
				PacketsRecv: item.PacketsRecv,
				PacketsSent: item.PacketsSent,
				Errin:       item.Errin,
				Errout:      item.Errout,
				Dropin:      item.Dropin,
				Dropout:     item.Dropout,
				Fifoin:      item.Fifoin,
				Fifoout:     item.Fifoout,
			}
			flag = false
			break
		}
	}

	if flag {
		h.log.Error("The device of %s is not found in the map.", nicName)
		return nil, errors.New("The nic device is not found")
	}

	return ret, nil
}

func (h *HostCollector) GetHostState(ctx context.Context) (*HostState, error) {
	cpuInfo, err := h.GetCpu(ctx)
	if err != nil {
		h.log.Error("Invoke HostCollector.GetCpu failed. Error: %#v.", err)
		return nil, err
	}

	memInfo, err := h.GetMem(ctx)
	if err != nil {
		h.log.Error("Invoke HostCollector.GetMem failed. Error: %#v.", err)
		return nil, err
	}

	loadInfo, err := h.GetLoad(ctx)
	if err != nil {
		h.log.Error("Invoke HostCollector.GetLoad failed. Error: %#v.", err)
		return nil, err
	}

	ret := &HostState{
		CpuNum:       cpuInfo.CpuNum,
		CpuUsage:     cpuInfo.CpuUsage,
		MemTotal:     memInfo.Total,
		MemUsed:      memInfo.Used,
		MemUsage:     memInfo.UsedPercent,
		MemAvailable: memInfo.Available,
		Load1:        loadInfo.Load1,
		Load5:        loadInfo.Load5,
		Load15:       loadInfo.Load15,
	}

	return ret, nil
}
