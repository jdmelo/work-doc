package model

type CommResp struct {
	Code    int         `json:"code"`
	Message string      `json:"message"`
	Detail  string      `json:"detail"`
	Data    interface{} `json:"data"`
}

type VMView struct {
	Id          string `json:"id"`
	State       string `json:"state"`
	CpuNum      int    `json:"cpu_num"`
	CpuUsage    int    `json:"cpu_usage"`
	MemTotal    int    `json:"mem_total"`
	MemUsage    int    `json:"mem_usage"`
	DiskRdBytes uint64 `json:"disk_rd_bytes"`
	DiskWrBytes uint64 `json:"disk_wr_bytes"`
	NicRxBytes  uint64 `json:"nic_rx_bytes"`
	NicTxBytes  uint64 `json:"nic_tx_bytes"`
}

type HostView struct {
	CpuNum       int             `json:"cpu_num"`
	CpuUsage     float64         `json:"cpu_usage"`
	MemTotal     uint64          `json:"mem_total"`
	MemUsed      uint64          `json:"mem_used"`
	MemUsage     float64         `json:"mem_usage"`
	MemAvailable uint64          `json:"mem_available"`
	Load1        float64         `json:"load1"`
	Load5        float64         `json:"load5"`
	Load15       float64         `json:"load15"`
	Net          []*NetStatInfo  `json:"net"`
	DiskInfo     []*DiskStatView `json:"diskInfo"`
}

type HostDockerview struct {
	DockerSysDisk  *MountStatView `json:"dockerSysDisk"`
	DockerDataDisk *VGStatView    `json:"dockerDataDisk"`
}

type NetStatInfo struct {
	Name      string `json:"name"`      // interface name
	BytesSent uint64 `json:"bytesSent"` // number of bytes sent
	BytesRecv uint64 `json:"bytesRecv"` // number of bytes received
}

type MountStatView struct {
	Path        string  `json:"path"`
	Fstype      string  `json:"fstype"`
	Total       uint64  `json:"total"`
	Free        uint64  `json:"free"`
	UsedPercent float64 `json:"usedPercent"`
}

type VGStatView struct {
	Name        string  `json:"name"`
	Total       uint64  `json:"total"`
	Used        uint64  `json:"used"`
	Free        uint64  `json:"free"`
	UsedPercent float64 `json:"usedPercent"`
}

type DiskStatView struct {
	ReadCount  uint64 `json:"readCount"`
	WriteCount uint64 `json:"writeCount"`
	ReadBytes  uint64 `json:"readBytes"`
	WriteBytes uint64 `json:"writeBytes"`
	Name       string `json:"name"`
}
