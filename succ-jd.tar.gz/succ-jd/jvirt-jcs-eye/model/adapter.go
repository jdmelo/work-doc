package model

import (
	"jd.com/jvirt/jvirt-jcs-eye/collector/host"
	"jd.com/jvirt/jvirt-jcs-eye/collector/vm"
)

func AdapterVMView(info *vm.VMState) *VMView {

	view := &VMView{
		Id:          info.Id,
		State:       info.State,
		CpuNum:      info.CpuNum,
		CpuUsage:    info.CpuUsage,
		MemUsage:    info.MemUsage,
		MemTotal:    info.MemTotal,
		DiskWrBytes: info.DiskWrBytes,
		DiskRdBytes: info.DiskRdBytes,
		NicTxBytes:  info.NicTxBytes,
		NicRxBytes:  info.NicRxBytes,
	}

	return view
}

func AdapterHostView(info *host.HostState, nicInfos []*NetStatInfo, diskInfos []*DiskStatView) *HostView {
	view := &HostView{
		CpuNum:       info.CpuNum,
		CpuUsage:     info.MemUsage,
		MemTotal:     info.MemTotal,
		MemUsage:     info.MemUsage,
		MemUsed:      info.MemUsed,
		MemAvailable: info.MemAvailable,
		Load1:        info.Load1,
		Load5:        info.Load5,
		Load15:       info.Load15,
		Net:          nicInfos,
		DiskInfo:     diskInfos,
	}

	return view
}

func AdapterHostDockerView(mountInfo *MountStatView, vgInfo *VGStatView) *HostDockerview {
	view := &HostDockerview{
		DockerSysDisk:  mountInfo,
		DockerDataDisk: vgInfo,
	}

	return view
}

func AdapterNicView(info *host.NicState) *NetStatInfo {
	view := &NetStatInfo{
		Name:      info.Name,
		BytesSent: info.BytesSent,
		BytesRecv: info.BytesRecv,
	}

	return view
}

func AdapterDiskView(info *host.DiskUsageState) *DiskStatView {
	view := &DiskStatView{
		ReadCount:  info.ReadCount,
		WriteCount: info.WriteCount,
		ReadBytes:  info.ReadBytes,
		WriteBytes: info.WriteBytes,
		Name:       info.Name,
	}

	return view
}

func AdapterMountView(info *host.MountPointState) *MountStatView {
	view := &MountStatView{
		Path:        info.Path,
		Fstype:      info.Fstype,
		Total:       info.Total,
		Free:        info.Free,
		UsedPercent: info.UsedPercent,
	}

	return view
}

func AdapterVGView(info *host.VGUsageStat) *VGStatView {
	view := &VGStatView{
		Name:        info.Name,
		Total:       info.Total,
		Used:        info.Used,
		Free:        info.Free,
		UsedPercent: info.UsedPercent,
	}

	return view
}
