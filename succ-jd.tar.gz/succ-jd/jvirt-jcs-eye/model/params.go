package model

type DescribeVmReq struct {
	Id string `json:"id"`
}

type DescribeContainerReq struct {
	Id string `json:"id"`
}
