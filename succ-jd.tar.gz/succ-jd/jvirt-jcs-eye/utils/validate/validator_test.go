package validate

import (
	"encoding/json"
	"fmt"
	"testing"
)

type Test struct {
	Name  string
	Inner *Inner
}

type Inner struct {
	Age      int    `json:"age" validate:"min=1"`
	Password string `json:"password" validate:"max=1"`
}

func TestValidate(t *testing.T) {
	test := &Test{Name: "test"}
	test.Inner = &Inner{Age: 12, Password: "ddeeeeeeeeeeeeeeeeeeeeeeedd"}
	text, _ := json.Marshal(test)
	fmt.Println(string(text))

	fmt.Println(json.Unmarshal([]byte(`{"Name":"test","Inner":{"age":"12"","password":"ddeeeeeeeeeeeeeeeeeeeeeeedd"}}`), test))
	if errs := Validate(test); errs != nil {
		// values not valid, deal with errors here
		fmt.Println(errs)
	}
}
