package validate

const (
	UuidPattern    string = `^[a-z0-9]([a-z0-9-])*$`
	DomainPattern  string = `^[a-zA-Z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,6}$`
	UrlpathPattern string = `^\/[a-zA-Z0-9\/\.\%\?\#\&\=]*$`
)
