package utils

import (
	"context"
	"fmt"
	"time"
)

func Timer(ctx context.Context, interval int, f func(ctx context.Context, timestamp int64) error) {
	var slot int64
	var curSec int64
	var slotSize = interval

	slotNano := int64(slotSize) * 1000000000
	curNano := time.Now().UnixNano()
	slot = curNano / slotNano
	nextSlotRemain := (slot+1)*slotNano - curNano
	timer := time.NewTimer(time.Duration(nextSlotRemain) * time.Nanosecond)
	select {
	case <-timer.C:
	case <-ctx.Done():
		fmt.Println("Parent context close.")
		return
	}

	for {
		c, cancelFunc := context.WithCancel(ctx)
		curNano = time.Now().UnixNano()
		curSec = time.Now().Unix()
		curSlot := curNano / slotNano
		if curSlot < slot {
			fmt.Println("Should nerver hidden.")
		} else {
			go f(c, curSec)
			slot = curSlot // new slot
		}
		nextSlotRemain = (slot+1)*slotNano - curNano
		timer.Reset(time.Duration(nextSlotRemain) * time.Nanosecond)
		select {
		case <-timer.C:
			cancelFunc()
		case <-ctx.Done():
			// TODO 清理启动的协程.
			fmt.Println("Parent context close.")
			return
		}
	}
}
