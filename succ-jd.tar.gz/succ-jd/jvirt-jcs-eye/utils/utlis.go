package utils

import (
	"bytes"
	"fmt"
	"sort"
	"strconv"
)

var (
	CgBitmapParseError = fmt.Errorf("emulatorpin cgroup bitmap parse error")
)

type CgBitmap map[int]bool

func CgBitmapToList(cb CgBitmap) []string {
	sets := make([]int, 0)
	for key, value := range cb {
		if value {
			sets = append(sets, key)
		}
	}

	sort.IntSlice(sets).Sort()

	res := make([]string, 0)
	for _, v := range sets {
		res = append(res, strconv.Itoa(v))
	}

	return res
}

func CgBitmapParse(line []byte) (CgBitmap, error) {

	var tmpLine []byte
	bitmap := make(map[int]bool)

	if len(line) == 0 {
		return bitmap, nil
	}

	tmp := bytes.TrimSpace(line)
	for len(tmp) > 0 {
		neg := false
		if tmp[0] == '^' {
			neg = true
			tmp = tmp[1:]
		}

		// get start
		if index := bytes.IndexAny(tmp, " ,-^"); index == -1 {
			tmpLine = tmp
		} else {
			tmpLine = tmp[:index]
		}
		start, err := strconv.Atoi(string(tmpLine))
		if err != nil || start < 0 {
			return nil, CgBitmapParseError
		}

		// forward tmp, tmp maybe empty then
		tmp = bytes.TrimSpace(tmp[len(tmpLine):])

		if len(tmp) == 0 || tmp[0] == ',' {
			// set bitmap
			if neg {
				if _, ok := bitmap[start]; !ok {
					return nil, CgBitmapParseError
				}
				delete(bitmap, start)
			} else {
				if _, ok := bitmap[start]; ok {
					return nil, CgBitmapParseError
				}
				bitmap[start] = true
			}
		} else if tmp[0] == '-' {
			if neg {
				return nil, CgBitmapParseError
			}

			// forward tmp, tmp maybe empty then
			tmp = bytes.TrimSpace(tmp[1:])

			// get last
			if index := bytes.IndexAny(tmp, " ,-^"); index == -1 {
				tmpLine = tmp[:]
			} else {
				tmpLine = tmp[:index]
			}
			last, err := strconv.Atoi(string(tmpLine))
			if err != nil || last < 0 || last < start {
				return nil, CgBitmapParseError
			}

			// set bitmap
			for i := start; i <= last; i++ {
				if _, ok := bitmap[i]; ok {
					return nil, CgBitmapParseError
				}
				bitmap[i] = true
			}

			// forward tmp, tmp maybe empty then
			tmp = bytes.TrimSpace(tmp[len(tmpLine):])
		}

		if len(tmp) == 0 {
			break
		} else if tmp[0] == ',' {
			tmp = bytes.TrimSpace(tmp[1:])
		} else {
			return nil, CgBitmapParseError
		}
	}

	return bitmap, nil
}
