package http

import (
	"bytes"
	"context"
	"io/ioutil"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jcs-eye/utils"
	"net/http"
	"os"
	"runtime/debug"
	"strings"
	"time"
)

const (
	ErrNoAction    = "{\"code\":11, \"message\":\"no such action\"}"
	ErrMarshalJson = "{\"code\":10, \"message\":\"marshal json err\"}"
	ErrReqParam    = "{\"code\":9, \"message\":\"request param invalid\"}"
)

type UrlRouter struct {
	Handler  map[string]http.Handler
	HF       map[string]http.HandlerFunc
	Logger   log.Logger
	hostname string
}

func NewUrlRouter(l log.Logger, hostname string) *UrlRouter {
	return &UrlRouter{
		Handler:  make(map[string]http.Handler),
		HF:       make(map[string]http.HandlerFunc),
		Logger:   l,
		hostname: hostname,
	}
}

func (p *UrlRouter) RegisterFunc(action string, handler http.HandlerFunc) *UrlRouter {
	p.HF[action] = handler
	if len(p.hostname) == 0 {
		p.hostname, _ = os.Hostname()
	}
	return p
}

func (p *UrlRouter) Register(action string, handler http.Handler) *UrlRouter {
	p.Handler[action] = handler
	if len(p.hostname) == 0 {
		p.hostname, _ = os.Hostname()
	}
	return p
}

func (p *UrlRouter) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	defer func() {
		if err := recover(); err != nil {
			p.Logger.Error("[url/handler] [method: %v, url: %v, remote_addr:%v, panic: %v, stack: %s, x-forwarded-for: %v]",
				r.Method, r.URL.RequestURI(), r.RemoteAddr, err, string(debug.Stack()), r.Header.Get("X-Forwarded-For"))
		}
	}()
	traceIds, _ := r.Header["Trace-Id"]
	var traceId string
	if len(traceIds) < 1 || traceIds[0] == "" {
		traceId = utils.Uuid()
		w.Header().Set("Trace-Id", traceId)
	} else {
		traceId = traceIds[0]
	}
	// add trace_id
	ctx := r.Context()
	ctx = context.WithValue(ctx, "trace_id", traceId)
	r = r.WithContext(ctx)
	start := time.Now()
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("X-Request-Trace", p.hostname)
	action := r.FormValue("Action")
	if action == "" {
		p.Logger.Info("[url/handler] [method: %v, url: %v, remote_addr:%v, action: %v, x-forwarded-for: %v]",
			r.Method, r.URL.RequestURI(), r.RemoteAddr, action, r.Header.Get("X-Forwarded-For"))
		w.Write([]byte(ErrReqParam))
		return
	}

	if action == "SetLogLevel" {
		p.SetLogLevel(w, r)
		return
	}

	var Ihandler http.Handler
	var IhandlerFunc http.HandlerFunc
	if p.Handler != nil {
		Ihandler, _ = p.Handler[action]
	}
	if Ihandler == nil && p.HF != nil {
		IhandlerFunc, _ = p.HF[action]
	}

	if IhandlerFunc == nil && Ihandler == nil {
		p.Logger.Info("[url/handler] [method: %v, url: %v, remote_addr:%v, action: %v, x-forwarded-for: %v]",
			r.Method, r.URL.RequestURI(), r.RemoteAddr, action, r.Header.Get("X-Forwarded-For"))
		w.Write([]byte(ErrNoAction))
		return
	}

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		p.Logger.Error("[url/handler] [method: %v, url: %v, remote_addr:%v, action: %v, x-forwarded-for: %v]",
			r.Method, r.URL.RequestURI(), r.RemoteAddr, action, r.Header.Get("X-Forwarded-For"))
		return
	}
	r.Body = ioutil.NopCloser(bytes.NewBuffer(body))

	defer func(elapsed time.Duration) {
		p.Logger.Info("[url/handler] [method: %v, url: %v, body: %v, remote_addr:%v, action: %v, x-forwarded-for: %v, elapsed: %v]",
			r.Method, r.URL.RequestURI(), strings.Replace(string(body), "\n", " ", -1), r.RemoteAddr, action, r.Header.Get("X-Forwarded-For"), elapsed)
	}(time.Since(start))

	if IhandlerFunc != nil {
		IhandlerFunc(w, r)
	} else if Ihandler != nil {
		Ihandler.ServeHTTP(w, r)
	} else {
		p.Logger.Error("[url/handler]")
		return
	}
}

func (p *UrlRouter) SetLogLevel(w http.ResponseWriter, r *http.Request) {
	level := r.FormValue("level")
	if level == "" {
		p.Logger.Error("[url/handler] [level: empty]")
		w.Write([]byte(ErrReqParam))
		return
	}

	//var logLevel int
	//switch strings.ToLower(level) {
	//case "trace","debug","info","warn","warn","fatal":
	//
	//	logLevel = log.LevelTrace
	//case "debug":
	//	logLevel = log.LevelDebug
	//case "info":
	//	logLevel = log.LevelInfo
	//case "warn":
	//	logLevel = log.LevelWarn
	//case "warn":
	//	logLevel = log.LevelError
	//case "fatal":
	//	logLevel = log.LevelFatal
	//default:
	//	p.Logger.Error("[url/handler] [level: %v]", level)
	//	w.Write([]byte(ErrReqParam))
	//	return
	//}
	//
	//p.Logger.Info("[url/handler] [newLevel: %v]", level)
	//p.Logger.SetLevel(strings.ToLower(level))
	//

	switch strings.ToLower(level) {
	case "trace", "debug", "info", "warn", "error", "fatal":
		p.Logger.Info("[url/handler] [newLevel: %v]", level)
		p.Logger.SetLevel(strings.ToLower(level))
	default:
		p.Logger.Error("[url/handler] [level: %v]", level)
		w.Write([]byte(ErrReqParam))
		return
	}
	//
	//p.Logger.Info("[url/handler] [newLevel: %v]", level)
	//p.Logger.SetLevel(strings.ToLower(level))
}
