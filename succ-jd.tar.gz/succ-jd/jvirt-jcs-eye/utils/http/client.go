package http

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jcs-eye/utils"
	"net"
	"net/http"
	"time"
)

type Client struct {
	httpClient *http.Client
	Logger     log.Logger
}

type Config struct {
	ConnectTimeout        int `ini:"connect_timeout"`
	MaxIdleConns          int `ini:"max_idle_conns"`
	TimerInterval         int `ini:"timer_interval"`
	ResponseHeaderTimeout int `ini:"response_header_timeout"`
	RequestTotalTimeout   int `ini:"request_total_timeout"`
}

func NewHttpClient(cfg *Config, logger log.Logger) *Client {
	client := &Client{Logger: logger}
	tr := &http.Transport{
		DialContext: (&net.Dialer{
			// 建立连接超时时间.
			Timeout: time.Duration(cfg.ConnectTimeout) * time.Millisecond,
		}).DialContext,
		// 单个url的最大空闲连接数.
		MaxIdleConnsPerHost: cfg.MaxIdleConns,
		// 最大的空闲连接数.
		MaxIdleConns: cfg.MaxIdleConns,
		// 单位：秒，连接的最大空闲时间.
		IdleConnTimeout: time.Duration(cfg.TimerInterval*2) * time.Second,
		// 单位：毫秒，响应包头的最大超时时间
		ResponseHeaderTimeout: time.Duration(cfg.ResponseHeaderTimeout) * time.Millisecond,
	}
	client.httpClient = &http.Client{Transport: tr, Timeout: time.Duration(cfg.RequestTotalTimeout) * time.Millisecond}

	return client
}

func (c *Client) SetTimeOut(t time.Duration) {
	c.httpClient.Timeout = t
}

func (c *Client) GetRawClient() *http.Client {
	return c.httpClient
}

func (c *Client) DoRequest(method, url string, header map[string]string, params, response interface{}) error {
	requestId := utils.Uuid()
	if reqId, ok := header["RequestId"]; ok && reqId != "" {
		requestId = header["RequestId"]
	}

	input, err := json.Marshal(params)
	if err != nil {
		c.Logger.Error("Marshal json failed. RequestId: %s, Error: %#v.", requestId, err)
		return err
	}
	var req *http.Request
	// adapt to glance  api
	if string(input) == "null" {
		req, err = http.NewRequest(method, url, nil)
	} else {
		req, err = http.NewRequest(method, url, bytes.NewReader(input))
	}

	if err != nil {
		return err
	}

	for key := range header {
		req.Header.Set(key, header[key])
	}
	req.Header.Set("User-Agent", "JcsEyeClient")
	req.Header.Set("Accept", "application/json")

	c.Logger.Debug("Call http request start. RequestId: %s, Method: %s, Url: %s, Body: %v, Header: %s.",
		requestId, method, url, string(input), req.Header)
	resp, err := c.httpClient.Do(req)
	if resp != nil {
		defer resp.Body.Close()
	}
	if err != nil {
		c.Logger.Error("Call http request error. RequestId: %s, Error: %s.", requestId, err.Error())
		return err
	}
	body, _ := ioutil.ReadAll(resp.Body)

	c.Logger.Debug("Call http request success. RequestId: %s, HttpStatusCode = %d, body= %v",
		requestId, resp.StatusCode, string(body))

	if resp.StatusCode == 404 {
		return errors.New(fmt.Sprintf("ItemNotFound"))
	} else if resp.StatusCode < 200 || resp.StatusCode > 299 {
		return errors.New(fmt.Sprintf("HTTP Error Code: %d", resp.StatusCode))
	}

	if len(body) == 0 {
		return nil
	}
	if response != nil {
		decoder := json.NewDecoder(bytes.NewReader(body))
		decoder.UseNumber()
		err = decoder.Decode(response)
		if err != nil {
			return err
		}
	}
	return nil
}

func (c *Client) Post(url string, header map[string]string, params, response interface{}) error {
	return c.DoRequest("POST", url, header, params, response)
}

func (c *Client) Get(url string, header map[string]string, params, response interface{}) error {
	return c.DoRequest("GET", url, header, params, response)
}

func (c *Client) Do(method, url string, header map[string]string, params interface{}) (resp *http.Response, err error) {
	input, err := json.Marshal(params)
	if err != nil {
		c.Logger.Error("Marshal json failed : %v\n", err.Error())
		return nil, err
	}
	var req *http.Request
	// adapt to glance  api
	if string(input) == "null" {
		req, err = http.NewRequest(method, url, nil)
	} else {
		req, err = http.NewRequest(method, url, bytes.NewReader(input))
	}

	if err != nil {
		return nil, err
	}
	if header != nil {
		for key := range header {
			req.Header.Set(key, header[key])
		}
	}

	req.Header.Set("User-Agent", "JcsEyeClient")

	c.Logger.Debug("Request: method = %s, url = %s, body = %v ,header = %s", method, url, string(input), req.Header)
	resp, err = c.httpClient.Do(req)

	if err != nil {
		return nil, err
	}

	c.Logger.Debug("Response: code = %d ", resp.StatusCode)

	return resp, nil
}
