package conf

import (
	"errors"
	"fmt"
	"os/exec"
	"strings"

	"github.com/shirou/gopsutil/disk"
	"github.com/shirou/gopsutil/net"
)

var (
	// Common Configure
	HostId                string
	DataCenter            string
	TimerInterval         = 60
	ConnectTimeout        = 500
	ResponseHeaderTimeout = 1000
	RequestTotalTimeout   = 2000
	MaxIdleConns          = 100
	AppCode               = "jcloud"
	MonitorUrl            = "iaas-monitor.jcloud.com/put"
	IsCollectHost         = false
	IsCollectContainer    = false
	IsCollectVm           = false
	ListenPort            = "1024"

	// Log setup
	LogFileName    = "/export/Logs/dcollector/jstack-dcollector.log"
	LogFileMaxSize = 1073741824
	LogFileCount   = 5
	LogLevel       = 2

	// Host Configure
	HostServiceCode   string            = "host"
	NetInterfaces     []string          = make([]string, 0)
	DiskDevices       []string          = make([]string, 0)
	MountPoints       []string          = make([]string, 0)
	VolumeGroups      []string          = make([]string, 0)
	MountToPartitions map[string]string = make(map[string]string)

	// Docker Configure
	ContainerServiceCode string = "container"
	DockerInfoPath              = "/export/Data/nova"
	DockerProtocol       string = "unix"
	DockerAddress        string = "/var/run/docker.sock"
	CGroupMountPoint     string = "/sys/fs/cgroup"
	DockerDataVg         string
	DockerSysDisk        string
	DockerNet            string
	HostSysDisk          string

	// Libvirt Configure
	VmServiceCode string = "vm"
)

func parseHostConfig(cfg *Config) error {
	// 获取hostServiceCode属性。
	if hostServiceCode, err := cfg.Get("hostServiceCode"); err != nil {
		fmt.Println("WARNNIG: hostServiceCode not configured in the configuration file!")
	} else {
		HostServiceCode = hostServiceCode
		fmt.Println("INFO : ConfigFile HostServiceCode :", HostServiceCode)
	}
	// 获取监控物理机网卡列表。
	if netInterface, err := cfg.Get("netInterfaces"); err != nil {
		fmt.Println("WARNNIG: netInterfaces not configured in the configuration file!")
	} else {
		fmt.Println("INFO : ConfigFile netInterface :", netInterface)
		if netInterface != "" {
			NetInterfaces = strings.Split(netInterface, ",")
			err := validationInterface()
			if err != nil {
				return err
			}
		}
	}
	// 获取监控物理机磁盘列表。
	if diskDevice, err := cfg.Get("diskDevices"); err != nil {
		fmt.Println("WARNNIG: diskDevices not configured in the configuration file!")
	} else {
		fmt.Println("INFO : ConfigFile diskDevice :", diskDevice)
		if diskDevice != "" {
			DiskDevices = strings.Split(diskDevice, ",")
			err := validationDiskDevice()
			if err != nil {
				return err
			}
		}
	}
	// 获取监控物理的挂载点列表。
	if mountPoint, err := cfg.Get("mountPoints"); err != nil {
		fmt.Println("WARNNIG: diskPartitions not configured in the configuration file!")
	} else {
		fmt.Println("INFO : ConfigFile mountPoint :", mountPoint)
		if mountPoint != "" {
			MountPoints = strings.Split(mountPoint, ",")
			err := validationMountPoint()
			if err != nil {
				return err
			}
		}
	}
	// 获取监控物理机的卷组列表。
	if volumeGroup, err := cfg.Get("volumeGroups"); err != nil {
		fmt.Println("WARNNIG: volumeGroups not configured in the configuration file!")
	} else {
		fmt.Println("INFO : ConfigFile volumeGroup :", volumeGroup)
		if volumeGroup != "" {
			VolumeGroups = strings.Split(volumeGroup, ",")
			err := validationVolumeGroup()
			if err != nil {
				return err
			}
		}
	}

	return nil
}

func parseDockerConfig(cfg *Config) error {
	// 获取containerServiceCode属性。
	if containerServiceCode, err := cfg.Get("containerServiceCode"); err != nil {
		fmt.Println("WARNNIG: containerServiceCode not configured in the configuration file!")
	} else {
		ContainerServiceCode = containerServiceCode
		fmt.Println("INFO : ConfigFile ContainerServiceCode :", ContainerServiceCode)
	}
	// 获取dockerProtocol属性。
	if dockerProtocol, err := cfg.Get("dockerProtocol"); err != nil {
		fmt.Println("WARNNIG: dockerProtocol not configured in the configuration file!")
	} else {
		DockerProtocol = dockerProtocol
		fmt.Println("INFO : ConfigFile DockerProtocol :", DockerProtocol)
	}
	// 获取dockerAddress属性。
	if dockerAddress, err := cfg.Get("dockerAddress"); err != nil {
		fmt.Println("WARNNIG: dockerAddress was not configured in the configuration file!")
	} else {
		DockerAddress = dockerAddress
		fmt.Println("INFO : ConfigFile DockerAddress :", DockerAddress)
	}
	// 获取cgroupMountPoint属性。
	if cgroupMountPoint, err := cfg.Get("cgroupMountPoint"); err != nil {
		fmt.Println("WARNNIG: cgroupMountPoint was not configured in the configuration file!")
	} else {
		CGroupMountPoint = cgroupMountPoint
		fmt.Println("INFO : ConfigFile CGroupMountPoint :", CGroupMountPoint)
	}

	/* 如果选择监控容器，配置文件中必须配置的选项 */
	// 获取dockerInfoPath属性。
	if dockerInfoPath, err := cfg.Get("dockerInfoPath"); err != nil {
		fmt.Println("FATAL : dockerInfoPath not configured in the configuration file!")
		return errors.New("dockerInfoPath not configured")
	} else {
		DockerInfoPath = dockerInfoPath
		fmt.Println("INFO : ConfigFile DockerInfoPath :", DockerInfoPath)
	}
	// 获取dockerDataVg属性。
	if dockerDataVg, err := cfg.Get("dockerDataVg"); err != nil {
		fmt.Println("FATAL : dockerDataVg not configured in the configuration file!")
		return errors.New("dockerDataVg not configured")
	} else {
		DockerDataVg = dockerDataVg
		fmt.Println("INFO : ConfigFile DockerDataVg :", DockerDataVg)
	}
	// 获取dockerSysDisk属性。
	if dockerSysDisk, err := cfg.Get("dockerSysDisk"); err != nil {
		fmt.Println("FATAL : dockerSysDisk not configured in the configuration file!")
		return errors.New("dockerSysDisk not configured")
	} else {
		DockerSysDisk = dockerSysDisk
		fmt.Println("INFO : ConfigFile DockerSysDisk :", DockerSysDisk)
	}
	// 获取dockerNet属性。
	if dockerNet, err := cfg.Get("dockerNet"); err != nil {
		fmt.Println("FATAL : dockerNet not configured in the configuration file!")
		return errors.New("dockerNet not configured")
	} else {
		DockerNet = dockerNet
		fmt.Println("INFO : ConfigFile DockerNet :", DockerNet)
	}
	// 获取hostDisk属性。
	if hostSysDisk, err := cfg.Get("hostSysDisk"); err != nil {
		fmt.Println("FATAL : hostSysDisk not configured in the configuration file!")
		return errors.New("hostSysDisk not configured")
	} else {
		HostSysDisk = hostSysDisk
		fmt.Println("INFO : ConfigFile HostDisk :", HostSysDisk)
	}

	return nil
}

func parseLibvirtConfig(cfg *Config) error {
	// 获取vmServiceCode属性。
	if vmServiceCode, err := cfg.Get("vmServiceCode"); err != nil {
		fmt.Println("WARNNIG : vmServiceCode not configured in the configuration file!")
	} else {
		VmServiceCode = vmServiceCode
		fmt.Println("INFO : ConfigFile vmServiceCode :", VmServiceCode)
	}

	return nil
}

func ParseConfigFile(cfg *Config) error {
	var err error
	/* ********** Common Configure ********** */
	// 获取hostid属性。
	if hostId, err := cfg.Get("hostId"); err != nil {
		fmt.Println("FATAL : hostId not configured in the configuration file.")
		return errors.New("hostId not configured")
	} else {
		HostId = hostId
		fmt.Println("INFO : ConfigFile hostid :", HostId)
	}
	// 获取dataCenter属性。
	if dataCenter, err := cfg.Get("dataCenter"); err != nil {
		fmt.Println("FATAL : dataCenter not configured in the configuration file.")
		return errors.New("dataCenter not configured")
	} else {
		DataCenter = dataCenter
		fmt.Println("INFO : ConfigFile appCode :", DataCenter)
	}

	// 获取interval属性。
	if interval, err := cfg.Getint("interval"); err != nil {
		fmt.Println("WARNNING : interval not configured in the configuration file!")
	} else {
		TimerInterval = interval
		fmt.Println("INFO : ConfigFile interval :", TimerInterval)
	}
	// 获取connectTimeout属性。
	if connectTimeout, err := cfg.Getint("connectTimeout"); err != nil {
		fmt.Println("WARNNING : connectTimeout not configured in the configuration file!")
	} else {
		ConnectTimeout = connectTimeout
		fmt.Println("INFO : ConfigFile connectTimeout :", TimerInterval)
	}
	// 获取responseHeaderTimeout属性。
	if responseHeaderTimeout, err := cfg.Getint("responseHeaderTimeout"); err != nil {
		fmt.Println("WARNNING : responseHeaderTimeout not configured in the configuration file!")
	} else {
		ResponseHeaderTimeout = responseHeaderTimeout
		fmt.Println("INFO : ConfigFile responseHeaderTimeout :", TimerInterval)
	}
	// 获取requestTotalTimeout属性。
	if requestTotalTimeout, err := cfg.Getint("requestTotalTimeout"); err != nil {
		fmt.Println("WARNNING : requestTotalTimeout not configured in the configuration file!")
	} else {
		RequestTotalTimeout = requestTotalTimeout
		fmt.Println("INFO : ConfigFile requestTotalTimeout :", TimerInterval)
	}
	// 获取MaxIdleConns属性。
	if maxIdleConns, err := cfg.Getint("maxIdleConns"); err != nil {
		fmt.Println("WARNNING : maxIdleConns not configured in the configuration file!")
	} else {
		MaxIdleConns = maxIdleConns
		fmt.Println("INFO : ConfigFile maxIdleConns :", TimerInterval)
	}
	// 获取appCode属性。
	if appCode, err := cfg.Get("appCode"); err != nil {
		fmt.Println("WARNNING : appCode not configured in the configuration file!")
	} else {
		AppCode = appCode
		fmt.Println("INFO : ConfigFile appCode :", AppCode)
	}
	// 获取iaas-monitor的url属性。
	if monitorUrl, err := cfg.Get("monitorUrl"); err != nil {
		fmt.Println("WARNNING : monitorUrl not configured in the configuration file!")
	} else {
		MonitorUrl = monitorUrl
		fmt.Println("INFO : ConfigFile monitorUrl :", MonitorUrl)
	}
	// 获取listenPort属性。
	if listenPort, err := cfg.Get("listenPort"); err != nil {
		fmt.Println("WARNNING : listenPort not configured in the configuration file!")
	} else {
		ListenPort = listenPort
		fmt.Println("INFO : ConfigFile ListenPort :", ListenPort)
	}

	// 获取LogFileName属性。
	if logFileName, err := cfg.Get("logFileName"); err != nil {
		fmt.Println("WARNNING : logFileName not configured in the configuration file.")
	} else {
		LogFileName = logFileName
		fmt.Println("INFO : ConfigFile LogFileName :", LogFileName)
	}
	// 获取LogFileMaxSize属性。
	if logFileMaxSize, err := cfg.Getint("logFileMaxSize"); err != nil {
		fmt.Println("WARNNING : logFileMaxSize not configured in the configuration file.")
	} else {
		LogFileMaxSize = logFileMaxSize
		fmt.Println("INFO : ConfigFile LogFileMaxSize :", LogFileMaxSize)
	}
	// 获取LogFileCount属性。
	if logFileCount, err := cfg.Getint("logFileCount"); err != nil {
		fmt.Println("WARNNIG : logFileCount not configured in the configuration file!")
	} else {
		LogFileCount = logFileCount
		fmt.Println("INFO : ConfigFile LogFileCount :", LogFileCount)
	}
	// 获取LogLevel属性。
	if logLevel, err := cfg.Getint("logLevel"); err != nil {
		fmt.Println("WARNNING : logLevel not configured in the configuration file!")
	} else {
		LogLevel = logLevel
		fmt.Println("INFO : ConfigFile LogLevel :", LogLevel)
	}

	// 获取isCollectHost属性。
	if isCollectHost, err := cfg.Getbool("isCollectHost"); err != nil {
		fmt.Println("WARNNING : isCollectHost not configured in the configuration file!")
	} else {
		IsCollectHost = isCollectHost
		fmt.Println("INFO : ConfigFile isCollectHost :", IsCollectHost)
	}
	// 获取isCollectVm属性。
	if isCollectVm, err := cfg.Getbool("isCollectVm"); err != nil {
		fmt.Println("WARNNING : isCollectVm not configured in the configuration file!")
	} else {
		IsCollectVm = isCollectVm
		fmt.Println("INFO : ConfigFile isCollectVm :", IsCollectVm)
	}
	// 获取isCollectContainer属性。
	if isCollectContainer, err := cfg.Getbool("isCollectContainer"); err != nil {
		fmt.Println("WARNNING : isCollectContainer not configured in the configuration file!")
	} else {
		IsCollectContainer = isCollectContainer
		fmt.Println("INFO : ConfigFile isCollectContainer :", IsCollectContainer)
	}

	if !(IsCollectHost || IsCollectContainer || IsCollectVm) {
		fmt.Println("FATAL : host,vm or container configure one item at least.")
		return errors.New("host,vm or container is configured at least one.")
	}

	if IsCollectVm && IsCollectContainer {
		fmt.Println("FATAL : libvirt and docker section are mutually exclusive!")
		return errors.New("libvirt and docker section are mutually exclusive.")
	}

	/* ********** Host Configure ********** */
	if IsCollectHost {
		err = parseHostConfig(cfg)
		if err != nil {
			return err
		}
	}

	/* ********** Container Configure ********** */
	if IsCollectContainer {
		err = parseDockerConfig(cfg)
		if err != nil {
			return err
		}
	}

	/* ********** Vm Configure ********** */
	if IsCollectVm {
		err = parseLibvirtConfig(cfg)
		if err != nil {
			return err
		}
	}

	return nil
}

func validationInterface() error {
	// 根据配置文件编写的监控选项验证指定的网卡是否正确。
	// 获取物理机上所有网络接口。
	var is_exist bool

	interfaceStats, err := net.Interfaces()
	if err != nil {
		fmt.Println("FATAL : Get net Interfaces info failed.")
		return err
	} else {
		fmt.Println("INFO : interfaceStats :", interfaceStats)
	}

	for _, nicName := range NetInterfaces {
		is_exist = false
		for _, netStat := range interfaceStats {
			if netStat.Name == nicName {
				is_exist = true
				break
			}
		}

		if is_exist == false {
			fmt.Printf("FATAL : interface of %s is not exist in the machine.\n", nicName)
			return errors.New("Interface not exist")
		}
	}
	return nil
}

func validationDiskDevice() error {
	ioCounters, err := disk.IOCounters()
	if err != nil {
		fmt.Println("FATAL : Get disk io Counters info failed.")
		return err
	} else {
		fmt.Println("INFO : ioCounters :", ioCounters)
	}

	for _, device := range DiskDevices {
		_, ok := ioCounters[device]
		if ok == false {
			fmt.Printf("FATAL : device of %s is not exist in the machine.\n", device)
			return errors.New("Device not exist")
		}
	}

	return nil
}

func volumeGroupList() []string {
	// 获取系统中卷组列表。
	var ret []string

	cmd := exec.Command("vgs", "-a")
	out, _ := cmd.Output()
	vgList := strings.Split(string(out), "\n")
	for i, vg := range vgList {
		if i == 1 {
			ret = append(ret, strings.Fields(vg)[0])
		}
	}

	return ret
}

func validationVolumeGroup() error {
	var is_exist bool

	localVGList := volumeGroupList()

	for _, vgName := range VolumeGroups {
		is_exist = false
		for _, localVgName := range localVGList {
			if localVgName == vgName {
				is_exist = true
				break
			}
		}

		if is_exist == false {
			fmt.Printf("FATAL : volume group of %s is not exist in the machine.\n", vgName)
			return errors.New("Volume not exist")
		}
	}

	return nil
}

func validationMountPoint() error {
	var is_exist bool

	partitions, err := disk.Partitions(false)
	if err != nil {
		fmt.Println("FATAL : Get disk partitions info failed.")
		return err
	} else {
		fmt.Println("INFO : partitions :", partitions)
	}

	for _, mountPoint := range MountPoints {
		is_exist = false
		for _, partition := range partitions {
			if partition.Mountpoint == mountPoint {
				is_exist = true
				MountToPartitions[mountPoint] = partition.Device
				break
			}
		}
		if is_exist == false {
			fmt.Printf("FATAL : mountPoint of %s is not exist in the machine.\n", mountPoint)
			return errors.New("MountPoint not exist")
		}
	}

	return nil
}
