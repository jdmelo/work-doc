package dockerclient

import (
	"errors"
	"net/http"
	"net/url"
	"utils/log"
)

func DockerInfo(request *http.Request) (*http.Response, error) {
	urlPath := basePath + "/info"
	request.URL, _ = url.Parse(urlPath)
	request.Method = "GET"
	request.RequestURI = ""
	response, err := httpClient.Do(request)
	if err != nil {
		return nil, err
	}

	if response.StatusCode < 200 || response.StatusCode >= 400 {
		log.Log.Error("Http Response Status: %s, StatusCode: %d.\n",
			response.Status, response.StatusCode)
		return response, errors.New(response.Status)
	}

	return response, nil
}
