package dockerclient

import (
	"github.com/fsouza/go-dockerclient"
	"net"
	"net/http"
	"time"
	"utils/conf"
)

var basePath string = "http://localhost:5050"
var httpClient *http.Client
var client *docker.Client

func init() {
	// 自定义httpClient。
	var err error
	tr := &http.Transport{
		Dial: func(network, addr string) (net.Conn, error) {
			return net.DialTimeout(conf.DockerProtocol, conf.DockerAddress, time.Duration(10)*time.Second)
		},
		MaxIdleConnsPerHost:   10,
		ResponseHeaderTimeout: time.Duration(10) * time.Second}
	httpClient = &http.Client{Transport: tr, Timeout: time.Duration(10) * time.Second}

	endpoint := conf.DockerProtocol + "://" + conf.DockerAddress
	client, err = docker.NewVersionedClient(endpoint, "1.24")
	if err != nil {
		panic("Connect to docker daemon failed.")
	}
}
