package dockerclient

import (
	"github.com/fsouza/go-dockerclient"
	"utils/log"
)

func DockerInspect(containerID string) (*docker.Container, error) {
	info, err := client.InspectContainer(containerID)
	if err != nil {
		log.Log.Error("Invoke DockerClient.inspectContainer failed. Error: %#v.", err)
		return nil, err
	}

	return info, nil
}
