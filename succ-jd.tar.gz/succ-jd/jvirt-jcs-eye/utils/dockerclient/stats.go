package dockerclient

import (
	"bufio"
	"encoding/json"
	"errors"
	"github.com/shirou/gopsutil/cpu"
	"github.com/shirou/gopsutil/disk"
	"github.com/shirou/gopsutil/docker"
	netio "github.com/shirou/gopsutil/net"
	"io"
	"io/ioutil"
	"net/http"
	"net/url"
	"os"
	"path"
	"strconv"
	"strings"
	"time"
	"utils"
	"utils/conf"
	"utils/log"
	"utils/realpath"
)

const nanoSecondsPerSecond = 1e9

type MemInfo struct {
	Total       uint64  `json:"total"`
	Available   uint64  `json:"available"`
	UsedPercent float64 `json:"usedPercent"`
}

type CpuInfo struct {
	Num         int     `json:"num"`
	UsedPercent float64 `json:"usedPercent"`
}

type NetInfo struct {
	BytesSent uint64 `json:"bytesSent"` // number of bytes sent
	BytesRecv uint64 `json:"bytesRecv"` // number of bytes received
}

type MountPointInfo struct {
	Path        string  `json:"path"`
	Fstype      string  `json:"fstype"`
	Total       uint64  `json:"total"`
	Free        uint64  `json:"free"`
	UsedPercent float64 `json:"usedPercent"`
	ReadBytes   uint64  `json:"readBytes"`
	ReadCount   uint64  `json:"readCount"`
	WriteBytes  uint64  `json:"writeBytes"`
	WriteCount  uint64  `json:"writeCount"`
}

type SysDiskInfo struct {
	ReadBytes  uint64 `json:"readBytes"`
	WriteBytes uint64 `json:"writeBytes"`
}

type ContainerInfo struct {
	CpuInfo  CpuInfo        `json:"cpuInfo"`
	MemInfo  MemInfo        `json:"memInfo"`
	NetInfo  NetInfo        `json:"netInfo"`
	DataDisk MountPointInfo `json:"dataDisk"`
	SysDisk  SysDiskInfo    `json:"sysDisk"`
}

var ErrDiskNotFound = errors.New("The disk device is not found.")

func parserCgroupCpuUsage(containerID string) (float64, error) {
	var f *os.File
	var err error

	filePath := path.Join(conf.CGroupMountPoint, "cpu,cpuacct/system.slice/docker-"+containerID+".scope/cpuacct.usage")
	filePath2 := path.Join(conf.CGroupMountPoint, "cpu,cpuacct/docker/"+containerID+"/cpuacct.usage")

	f, err = os.Open(filePath)
	if err != nil {
		f, err = os.Open(filePath2)
		if err != nil {
			return 0, err
		}
	}
	defer f.Close()

	r := bufio.NewReader(f)
	v, err := r.ReadString('\n')
	if err != nil {
		return 0, err
	}

	cpuUsage, err := strconv.ParseFloat(strings.Trim(v, "\n"), 64)
	if err != nil {
		return 0, err
	}

	log.Log.Debug("ContainerID: %s; CpuUsage: %#v.", containerID, cpuUsage)

	return cpuUsage, nil
}

func parserCgroupCpuSet(containerID string) ([]string, error) {
	var f *os.File
	var err error

	filePath := path.Join(conf.CGroupMountPoint, "cpuset/system.slice/docker-"+containerID+".scope/cpuset.cpus")
	filePath2 := path.Join(conf.CGroupMountPoint, "cpuset/docker/"+containerID+"/cpuset.cpus")

	f, err = os.Open(filePath)
	if err != nil {
		f, err = os.Open(filePath2)
		if err != nil {
			return nil, err
		}
	}
	defer f.Close()

	r := bufio.NewReader(f)
	v, err := r.ReadBytes('\n')
	if err != nil {
		return nil, err
	}
	bitm, err := utils.CgBitmapParse(v)
	if err != nil {
		return nil, err
	}
	cpuSets := utils.CgBitmapToList(bitm)
	log.Log.Debug("ContainerID: %s; CpuSets: %#v.", containerID, cpuSets)

	return cpuSets, nil
}

func calculateCPUInfo(containerName string) (CpuInfo, error) {
	var (
		preCpuAcctUsage = 0.0
		curCpuAcctUsage = 0.0
		preTotalUsage   = 0.0
		curTotalUsage   = 0.0
	)
	procStatCpuMap := make(map[string]cpu.TimesStat)
	ret := CpuInfo{}

	containerInfo, err := DockerInspect(containerName)
	if err != nil {
		log.Log.Error("Invoke DockerInspect failed. Error: %#v.", err)
		return ret, err
	}
	containerID := containerInfo.ID
	cpuSets, err := parserCgroupCpuSet(containerID)
	if err != nil {
		log.Log.Error("Invoke parserCgroupCpuSet failed. Error: %#v.", err)
		return ret, err
	}

	preCpuAcctUsage, err = parserCgroupCpuUsage(containerID)
	if err != nil {
		log.Error("Invoke parserCgroupCpuUsage failed. Error: #v.", err)
		return ret, err
	}
	procCpus, err := cpu.Times(true)
	if err != nil {
		log.Log.Error("Invoke Times failed. Error: %#v.", err)
		return ret, err
	}
	for _, v := range procCpus {
		procStatCpuMap[v.CPU] = v
	}
	for _, v := range cpuSets {
		cpuID := "cpu" + v
		if cpuUsage, ok := procStatCpuMap[cpuID]; ok {
			preTotalUsage += cpuUsage.User + cpuUsage.System + cpuUsage.Idle + cpuUsage.Nice + cpuUsage.Iowait + cpuUsage.Irq + cpuUsage.Softirq
		}
	}

	time.Sleep(1 * time.Second)

	curCpuAcctUsage, err = parserCgroupCpuUsage(containerID)
	if err != nil {
		log.Log.Error("Invoke parserCgroupCpuUsage failed. Error: %#v.", err)
		return ret, err
	}
	procCpus, err = cpu.Times(true)
	if err != nil {
		log.Log.Error("Invoke Times failed. Error: %#v.", err)
		return ret, err
	}
	for _, v := range procCpus {
		procStatCpuMap[v.CPU] = v
	}
	for _, v := range cpuSets {
		cpuID := "cpu" + v
		if cpuUsage, ok := procStatCpuMap[cpuID]; ok {
			curTotalUsage += cpuUsage.User + cpuUsage.System + cpuUsage.Idle + cpuUsage.Nice + cpuUsage.Iowait + cpuUsage.Irq + cpuUsage.Softirq
		}
	}

	cpuDelta := curCpuAcctUsage - preCpuAcctUsage
	systemDelta := (curTotalUsage - preTotalUsage) * nanoSecondsPerSecond

	ret.Num = len(cpuSets)
	if systemDelta > 0.0 && cpuDelta > 0.0 {
		cpuPercent := (cpuDelta / systemDelta) * 100.0
		log.Log.Debug("ContainerID: %s; cpuDelta: %#v; systemDelta: %#v; cpuPercent: %#v.", containerID, cpuDelta, systemDelta, cpuPercent)
		ret.UsedPercent = cpuPercent
	}

	return ret, nil
}

func calculateMemInfo(memStats docker.MemoryStats) MemInfo {
	info := MemInfo{}
	memTotal := memStats.Limit
	memUsage := memStats.Usage
	memCache := memStats.Stats["cache"]
	memRSS := memStats.Stats["rss"]
	memMappedFile := memStats.Stats["mapped_file"]
	memUsed := memRSS + memMappedFile

	if memTotal != 0 {
		info.UsedPercent = float64(memUsed) / float64(memTotal) * 100.0
	}
	// 单位: B
	info.Total = memTotal
	info.Available = memTotal - memUsed

	log.Log.Debug("MemTotal: %v. MemUsage: %v. MemCache: %v. MemRss: %v. MappedFile: %v. MemInfo: %v.",
		memTotal, memUsage, memCache, memRSS, memMappedFile, info)

	return info
}

func calculateDataDiskInfo(containerName string) (MountPointInfo, error) {
	info := MountPointInfo{}
	// 拼接挂载点。
	novaID := strings.TrimPrefix(containerName, "nova-")
	mountPoint := "/mnt/" + novaID

	// 根据LVM挂载点，获取LVM设备文件路径。
	devicePath, err := disk.MountPointToDevice(mountPoint)
	if err != nil {
		if err.Error() == "MountPointNotFound" {
			// 容器没有数据卷。
			return info, nil
		}
		return info, err
	}

	// 根据设备文件的路径，路径获取对应的真实路径。
	realPath, err := realpath.Realpath(devicePath)
	if err != nil {
		return info, err
	}
	temp := strings.Split(realPath, "/")
	// 获取设备名，例如：dm-0, dm-1
	deviceName := temp[len(temp)-1]

	ioCounters, err := disk.IOCounters()
	if err != nil {
		return info, err
	}

	deviceInfo, ok := ioCounters[deviceName]
	if ok == false {
		log.Log.Error("The device of %s is not found in the map.\n", deviceName)
		return info, ErrDiskNotFound
	}

	mountPointInfo, err := disk.Usage(mountPoint)
	if err != nil {
		return info, err
	}

	info.ReadBytes = deviceInfo.ReadBytes
	info.WriteBytes = deviceInfo.WriteBytes
	info.ReadCount = deviceInfo.ReadCount
	info.WriteCount = deviceInfo.WriteCount

	info.Total = mountPointInfo.Total
	info.Free = mountPointInfo.Free
	info.UsedPercent = mountPointInfo.UsedPercent
	info.Fstype = mountPointInfo.Fstype
	info.Path = mountPointInfo.Path

	return info, nil
}

func calculateSysDiskIO(blkio docker.BlkioStats) SysDiskInfo {
	info := SysDiskInfo{}
	for _, bioEntry := range blkio.IoServiceBytesRecursive {
		switch strings.ToLower(bioEntry.Op) {
		case "read":
			info.ReadBytes += bioEntry.Value
		case "write":
			info.WriteBytes += bioEntry.Value
		}
	}
	return info
}

func readJsonFile(filename string) (map[string]interface{}, error) {
	bytes, err := ioutil.ReadFile(filename)
	if err != nil {
		log.Log.Error("ReadFile Error : %v\n", err.Error())
		return nil, err
	}

	data := make(map[string]interface{})
	if err := json.Unmarshal(bytes, &data); err != nil {
		log.Log.Error("Unmarshal Error : %v\n", err.Error())
		return nil, err
	}

	return data, nil
}

func calculateNetInfo(containerName string) (NetInfo, error) {
	info := NetInfo{}
	ioStatsMap, err := netio.IOCountersMap()
	if err != nil {
		log.Log.Error("Get net io Counters stats info failed : %v\n", err.Error())
		return info, err
	}

	novaID := strings.TrimPrefix(containerName, "nova-")
	// 容器网卡信息文件。
	filename := conf.DockerInfoPath + "/instances/network/" + novaID + "_veth"
	data, err := readJsonFile(filename)
	if err != nil {
		log.Log.Error("Read Json File Error : %v\n", err.Error())
		return info, err
	}

	for key := range data {
		if ok := strings.HasPrefix(key, "ns-"); ok {
			nicName := strings.Replace(key, "ns-", "port-", -1)
			info.BytesRecv += ioStatsMap[nicName].BytesSent
			info.BytesSent += ioStatsMap[nicName].BytesRecv
		} else {
			log.Log.Error("The network name of Container is incorrect!\n")
		}
	}
	return info, nil
}

func GetContainerStats(containerName string) (*ContainerInfo, *http.Response, error) {
	var err error
	value := new(docker.StatsJSON)
	request := new(http.Request)

	response, err := DockerStats(request, containerName)
	if err != nil {
		log.Log.Error("Send docker stats Http request failed : %v\n", err.Error())
		return nil, response, err
	}
	defer response.Body.Close()

	dec := json.NewDecoder(response.Body)
	for {
		if err := dec.Decode(&value); err != nil {
			dec = json.NewDecoder(io.MultiReader(dec.Buffered(), response.Body))
			log.Log.Error("Decoder Json Data failed : %v\n", err.Error())
			if err == io.EOF {
				break
			}
			time.Sleep(100 * time.Millisecond)
			continue
		} else {
			break
		}
	}

	containerInfo := new(ContainerInfo)

	containerInfo.NetInfo, err = calculateNetInfo(containerName)
	if err != nil {
		log.Log.Error("calculate Network failed : %v\n", err.Error())
		return nil, nil, err
	}
	containerInfo.DataDisk, err = calculateDataDiskInfo(containerName)
	if err != nil {
		log.Log.Error("calculate DataDisk Info failed : %v\n", err.Error())
		return nil, nil, err
	}
	containerInfo.CpuInfo, err = calculateCPUInfo(containerName)
	if err != nil {
		log.Log.Error("calculate CPU Info failed : %v\n", err.Error())
		return nil, nil, err
	}
	containerInfo.MemInfo = calculateMemInfo(value.MemoryStats)
	containerInfo.SysDisk = calculateSysDiskIO(value.BlkioStats)

	return containerInfo, nil, nil
}

func DockerStats(request *http.Request, containerID string) (*http.Response, error) {
	urlPath := basePath + "/containers/" + containerID + "/stats?stream=false"
	request.URL, _ = url.Parse(urlPath)
	request.Method = "GET"
	request.RequestURI = ""
	response, err := httpClient.Do(request)
	if err != nil {
		return nil, err
	}

	if response.StatusCode < 200 || response.StatusCode >= 400 {
		log.Log.Error("Http Response Status: %s, StatusCode: %d.\n",
			response.Status, response.StatusCode)
		return response, errors.New(response.Status)
	}

	return response, nil
}
