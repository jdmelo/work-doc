package utils

const (
	ErrNull = ""
)

// R
const (
	ErrSystem    = "system"
	ErrInstance  = "instance"
	ErrContainer = "container"
)

// T
const (
	ErrError       = "error"
	ErrMantaining  = "mantaining"
	ErrInvalid     = "invalid"
	ErrMiss        = "miss"
	ErrMalformed   = "malformed"
	ErrNotFound    = "notfound"
	ErrInuse       = "inuse"
	ErrConflict    = "conflict"
	ErrUnsupported = "unsupported"
	ErrForbidden   = "forbidden"
	ErrLimit       = "limit"
	ErrExceeded    = "exceeded"
	ErrDuplicate   = "duplicate"
	ErrNorse       = "norse"
)

// P
const (
	ErrField     = "field"
	ErrBackendId = "backend_id"
	ErrType      = "type"
	ErrName      = "name"
	ErrPath      = "path"
	ErrPort      = "port"
)

/*
 * R: Resource Type
 * T: Error Type (invalid, notfound)
 * P: Parameter (name, cidr)
 * D: Detail
 */
type EyeErrObj struct {
	R string
	T string
	P string
	D string
}

type EyeError interface {
	Error() string
	Detail() string
}

func (e *EyeErrObj) Error() string {
	s := e.R + "." + e.T
	if e.P != ErrNull {
		s += "." + e.P
	}
	return s
}

func (e *EyeErrObj) Detail() string {
	return e.D
}

func NewErr(r, t, p, d string) EyeError {
	if t == ErrNotFound {
		return &EyeErrObj{r, t, p, "Unable to find " + r}
	}
	return &EyeErrObj{r, t, p, d}
}

func NewSysErr(err error) EyeError {
	return &EyeErrObj{ErrSystem, ErrError, ErrNull, err.Error()}
}
