package server

import (
	"context"
	"fmt"
	"net/http"
	"os"
	"strings"
	"time"

	"jd.com/jvirt/jvirt-jcs-eye/jcloudwatch"

	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/server"
	"jd.com/jvirt/jvirt-common/utils/url"
	"jd.com/jvirt/jvirt-jcs-eye/cfg"
	"jd.com/jvirt/jvirt-jcs-eye/collector"
	"jd.com/jvirt/jvirt-jcs-eye/handler"
	eye_http "jd.com/jvirt/jvirt-jcs-eye/utils/http"
	"jd.com/jvirt/jvirt-jcs-eye/worker"
)

type JcsEyeServer struct {
	*server.Server
	logger        log.Logger
	httpUrl       string
	httpPort      string
	httpRouter    *url.Router
	httpServer    *http.Server
	ctx           context.Context
	workerManager *worker.WorkerManager
}

func NewJcsEyeServer(logger log.Logger, config *cfg.Config) (*JcsEyeServer, error) {
	httpUrl := config.HttpServerConfig.BaseUrl
	fmt.Fprintf(os.Stdout, "JcsEyeServer is starting...\r\n    Server ip: %s \n",
		config.DefaultConfig.HostIp)
	if !strings.HasPrefix(httpUrl, "/") {
		httpUrl = "/" + httpUrl
	}
	jcsEyeServer := &JcsEyeServer{
		logger:   logger,
		httpUrl:  httpUrl,
		httpPort: config.HttpServerConfig.Port,
	}

	//初始化collector
	if err := collector.NewCollectors(logger); err != nil {
		fmt.Printf("Initialize collector failed. Error: %#v.\n", err)
		return nil, err
	}

	//初始化http router
	httpRouter := url.NewRouter()
	httpRouter.Logger = logger
	httpRouter.RegisterFilters(httpRouter.InvokerFilter)
	//初始化handler
	hostHandler := handler.NewHostHandler(logger)
	hostHandler.RegisterHandler(httpRouter)
	dockerHandler := handler.NewDockerHandler(logger)
	dockerHandler.RegisterHandler(httpRouter)
	vmHandler := handler.NewVMHandler(logger)
	vmHandler.RegisterHandler(httpRouter)
	jcsEyeServer.httpRouter = httpRouter
	jcsEyeServer.httpServer = &http.Server{Addr: fmt.Sprintf(":%s", config.HttpServerConfig.Port)}
	jcsEyeServer.Server = server.NewServer(jcsEyeServer.doStart, jcsEyeServer.doStop)

	c := cfg.IaasMonitorCfg
	monitorConfig := &eye_http.Config{
		ConnectTimeout:        c.ConnectTimeout,
		MaxIdleConns:          c.MaxIdleConns,
		TimerInterval:         c.TimerInterval,
		RequestTotalTimeout:   c.RequestTotalTimeout,
		ResponseHeaderTimeout: c.ResponseHeaderTimeout,
	}
	client := eye_http.NewHttpClient(monitorConfig, logger)
	workerManager := worker.NewWorkerManager(logger)
	factoryArgs := &worker.FactoryArgs{
		Logger:         logger,
		IMonitorClient: jcloudwatch.NewIMonitorClient(client, c.UploadUrl, logger),
	}
	workerMap := make(map[string]int)
	for _, item := range cfg.DefaultCfg.Workers {
		workerMap[item] = 1
	}
	for _, factory := range worker.WorkerFactorys {
		w, err := factory(factoryArgs)
		if err != nil {
			return nil, err
		}
		workerName := w.Name()
		if _, ok := workerMap[workerName]; ok {
			fmt.Printf("worker started. Name:%s\n", workerName)
			workerManager.AddWorker(w)
		}
	}

	jcsEyeServer.workerManager = workerManager

	return jcsEyeServer, nil
}

func (s *JcsEyeServer) doStart() error {
	fmt.Fprintf(os.Stdout, "JcsEyeServer started\n")
	//启动worker-定时上报监控数据，即搜集到的host,vm,cntr,hyper信息
	s.workerManager.Start()

	s.logger.Info("[%s],JcsEyeServer started\n", time.Now())
	// 启动HttpServer
	http.Handle(s.httpUrl, s.httpRouter)
	if err := s.httpServer.ListenAndServe(); err != nil {
		s.logger.Error("start JcsEyeServer http server failed,Error:%v", err.Error())
		return err
	}

	return nil
}

func (s *JcsEyeServer) doStop() {
	if s.httpServer != nil {
		ctx, _ := context.WithCancel(context.Background())
		s.httpServer.Shutdown(ctx)
		ctx.Done()
	}
	//停掉所有的worker
	s.workerManager.Stop()
	s.logger.Info("[%s],JcsEyeServer stopped\n", time.Now())
}
