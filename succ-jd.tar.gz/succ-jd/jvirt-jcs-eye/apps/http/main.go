package main

import (
	"flag"
	"fmt"
	"os"
	"runtime"
	"sync"
	"time"

	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/termination"
	app_server "jd.com/jvirt/jvirt-jcs-eye/apps/http/server"
	"jd.com/jvirt/jvirt-jcs-eye/cfg"
)

var configFileName string

func init() {
	flag.StringVar(&configFileName, "config", "/etc/jcs/jcs-eye.conf", "configure file!")
	flag.Usage = func() {
		fmt.Fprintf(os.Stderr, "Usage: %s [arguments] \n", os.Args[0])
		flag.PrintDefaults()
	}
	flag.Parse()
}

func main() {
	jcsEyeServer, err := initJcsEyeServer()
	var wg sync.WaitGroup
	wg.Add(1)

	if err != nil {
		fmt.Fprintf(os.Stderr, "init JcsEyeServer failed,Error:%v\n", err.Error())
		os.Exit(1)
	}

	startNotify := func() error {
		fmt.Fprintf(os.Stdout, "JcsEyeServer starting...\n")
		if err := jcsEyeServer.Start(); err != nil {
			fmt.Fprintf(os.Stderr, "[%s], JcsEyeServer start failed, err:%#v\n",
				time.Now(), err.Error())
			return err
		}
		wg.Wait()
		return nil
	}

	stopNotify := func() {
		defer wg.Done()
		fmt.Fprintf(os.Stdout, "[%s], JcsEyeServer stopped\n", time.Now())
	}

	interrupt := termination.New(nil, jcsEyeServer.Stop, stopNotify)
	interrupt.Run(startNotify)
}

// 初始化log
func initLogger(c *cfg.LogConfig) (log.Logger, error) {
	logger := log.New()
	file, err := os.OpenFile(c.FileName, os.O_WRONLY|os.O_APPEND|os.O_CREATE, 0755)
	if err != nil {
		return nil, err
	}
	logger.SetOutput(file)
	log.SetOutput(file)
	logger.SetLevel(c.Level)
	log.SetLevelString(c.Level)
	return logger, nil
}

func initJcsEyeServer() (*app_server.JcsEyeServer, error) {
	var err error
	config, err := cfg.InitConfig(&configFileName)
	if err != nil {
		fmt.Printf("InitConfig failed, Error:%v", err.Error())
		return nil, err
	}

	// 设置并行cpu核数
	runtime.GOMAXPROCS(cfg.DefaultCfg.RunCores)
	// 初始化log
	logger, err := initLogger(cfg.LogCfg)
	if err != nil {
		fmt.Printf("New Logger failed. Error: %#v.\n", err)
		return nil, err
	}

	// 初始化HostProbe和VMCollector
	jcsEyeServer, err := app_server.NewJcsEyeServer(logger, config)
	return jcsEyeServer, err

}
