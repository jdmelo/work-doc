package handler

import (
	//"net/http"

	//"encoding/json"
	"fmt"
	"github.com/fsouza/go-dockerclient"
	//"io/ioutil"
	"context"
	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/url"
	"jd.com/jvirt/jvirt-jcs-eye/cfg"
	"jd.com/jvirt/jvirt-jcs-eye/collector"
	"jd.com/jvirt/jvirt-jcs-eye/model"
	. "jd.com/jvirt/jvirt-jcs-eye/utils"
	"strings"

	"encoding/json"
)

const (
	DOCKER_INFO_GET_ACTION    = "DockerInfoGet"
	DOCKER_LIST_ACTION        = "DockerList"
	DESCRIBE_CONTAINER_ACTION = "DescribeContainer"
)

type DockerHandler struct {
	//	BaseHandler
	dockerClient *docker.Client
	log          log.Logger
}

//func NewDockerHandler(base BaseHandler, log log.Logger) *DockerHandler {
func NewDockerHandler(log log.Logger) *DockerHandler {
	dockerClient, err := docker.NewVersionedClient(cfg.CntrUploadCfg.DockerEndpoint, cfg.CntrUploadCfg.DockerApiVersion)
	if err != nil {
		panic(err)
	}
	return &DockerHandler{
		//		BaseHandler:  base,
		dockerClient: dockerClient,
		log:          log,
	}
}

//func (d *DockerHandler) Register(r *UrlRouter) {
//	r.RegisterFunc(DOCKER_LIST_ACTION, d.DockerList)
//	r.RegisterFunc(DOCKER_INFO_GET_ACTION, d.DockerInfoGet)
//	r.RegisterFunc(DESCRIBE_CONTAINER_ACTION, d.DescribeContainer)
//
//}
func (d *DockerHandler) RegisterHandler(r *url.Router) {
	r.RegisterHandleFunc(DOCKER_LIST_ACTION, d.DockerList)
	r.RegisterHandleFunc(DOCKER_INFO_GET_ACTION, d.DockerInfoGet)
	r.RegisterHandleFunc(DESCRIBE_CONTAINER_ACTION, d.DescribeContainer)
}

func (d *DockerHandler) DockerList(r *url.Request, w *url.Response) common.JvirtError {
	//func (d *DockerHandler) DockerList(w http.ResponseWriter, r *http.Request) {
	// 操作验证。
	d.log.Debug("DockerList")
	listContainersOptions := docker.ListContainersOptions{
		All: true,
	}

	containers, err := d.dockerClient.ListContainers(listContainersOptions)
	if err != nil {
		d.log.Error("ListContainers failed. Error: %#v.", err)
		eyeErr := NewErr(ErrContainer, ErrError, ErrNull, err.Error())
		return common.NewSysErr(eyeErr)
	}

	w.Response.Data = containers
	return nil
}

func (d *DockerHandler) DockerInfoGet(r *url.Request, w *url.Response) common.JvirtError {
	// 操作验证。
	d.log.Debug("DockerInfoGet")
	dockerInfo, err := d.dockerClient.Info()
	if err != nil {
		d.log.Error("DockerInfoGet error : %s", err.Error())
		eyeErr := NewErr(ErrContainer, ErrError, ErrNull, err.Error())
		return common.NewSysErr(eyeErr)
	}

	w.Response.Data = dockerInfo
	return nil
}

func (d *DockerHandler) DescribeContainer(r *url.Request, w *url.Response) common.JvirtError {
	// 操作验证。
	d.log.Debug("DescribeContainer")
	var ctx context.Context
	//req := &model.DescribeContainerReq{}
	req := new(model.DescribeContainerReq)
	err := json.Unmarshal(r.Content, req)
	if err != nil {
		d.log.Error("DescribeContainer Unmarshal failed : %s", err.Error())
		eyeErr := NewErr(ErrContainer, ErrInvalid, ErrNull, err.Error())
		return common.NewSysErr(eyeErr)
	}

	containerId := adapt(req.Id)
	dockerStats, err := collector.CntrCollect.GetInstanceState(ctx, containerId)
	if err != nil {
		d.log.Error("GetInstanceState failed. Error: %#v.", err)
		eyeErr := NewErr(ErrContainer, ErrError, ErrNull, err.Error())
		return common.NewSysErr(eyeErr)
	}

	w.Response.Data = dockerStats
	return nil

}

func adapt(raw string) string {
	if strings.HasPrefix(raw, "nova-") {
		return raw
	}
	if len(raw) == 36 {
		return fmt.Sprintf("nova-%s", raw)
	}
	return raw
}
