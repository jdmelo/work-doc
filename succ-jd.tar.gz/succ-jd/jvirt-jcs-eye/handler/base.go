package handler

import (
	"context"
	"encoding/json"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jcs-eye/model"
	"jd.com/jvirt/jvirt-jcs-eye/utils"
	"net/http"
)

type BaseHandler struct {
}

func NewBaseHandler() BaseHandler {
	return BaseHandler{}
}

func (h *BaseHandler) Response(ctx context.Context, w http.ResponseWriter, e utils.EyeError, data interface{}) {
	rsp := &model.CommResp{Code: 0, Data: data}
	if e != nil {
		rsp.Code = -1
		rsp.Message = e.Error()
		rsp.Detail = e.Detail()
	}

	jsonRsp, _ := json.Marshal(rsp)
	if e != nil {
		log.Warn("[init/handler/Response] [response: %s, error: %s]", string(jsonRsp), e.Error())
	}

	w.Header().Set("Content-Type", "application/json")
	w.Write(jsonRsp)
}
