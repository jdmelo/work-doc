package handler

import (
	"context"
	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/url"
	"jd.com/jvirt/jvirt-jcs-eye/cfg"
	"jd.com/jvirt/jvirt-jcs-eye/collector"
	"jd.com/jvirt/jvirt-jcs-eye/model"
	. "jd.com/jvirt/jvirt-jcs-eye/utils"
)

const (
	HOST_DETAIL_ACTION        = "DescribeHost"
	HOST_DOCKER_DETAIL_ACTION = "DescribeHostDocker"
)

type HostHandler struct {
	//	BaseHandler
	log log.Logger
}

//func NewHostHandler(base BaseHandler, logger log.Logger) *HostHandler {
func NewHostHandler(logger log.Logger) *HostHandler {
	return &HostHandler{
		//		BaseHandler: base,
		log: logger,
	}
}

//func (h *HostHandler) Register(r *UrlRouter) {
//	r.RegisterFunc(HOST_DETAIL_ACTION, h.DescribeHost)
//	r.RegisterFunc(HOST_DOCKER_DETAIL_ACTION, h.DescribeHostDocker)
//}

func (h *HostHandler) RegisterHandler(r *url.Router) {
	r.RegisterHandleFunc(HOST_DETAIL_ACTION, h.DescribeHost)
	r.RegisterHandleFunc(HOST_DOCKER_DETAIL_ACTION, h.DescribeHostDocker)
}

func (h *HostHandler) DescribeHost(r *url.Request, w *url.Response) common.JvirtError {
	//func (h *HostHandler) DescribeHost(w http.ResponseWriter, r *http.Request) {
	log.Info("Invoke HostHandler DescribeHost.")
	var ctx context.Context
	//info, err := collector.HostCollect.GetHostState(r.Context())
	info, err := collector.HostCollect.GetHostState(ctx)
	if err != nil {
		h.log.Error("GetHostState failed. Error: %#v.", err)
		eyeErr := NewErr(ErrInstance, ErrError, ErrNull, err.Error())
		return common.NewSysErr(eyeErr)
	}

	h.log.Info("Invoke HostHandler DescribeNic.")
	nicInfos := []*model.NetStatInfo{}
	for _, name := range cfg.HostUploadCfg.Interfaces {
		nicInfo, err := collector.HostCollect.GetNic(ctx, name)
		if err != nil {
			h.log.Error("GetNic failed. Error: %#v.", err)
			eyeErr := NewErr(ErrInstance, ErrError, ErrNull, err.Error())
			return common.NewSysErr(eyeErr)
		}
		nicInfos = append(nicInfos, model.AdapterNicView(nicInfo))
	}

	h.log.Info("Invoke HostHandler DescribeDisk.")
	diskInfos := []*model.DiskStatView{}
	for _, name := range cfg.HostUploadCfg.Disks {
		diskInfo, err := collector.HostCollect.GetDisk(ctx, name)
		if err != nil {
			h.log.Error("GetDisk failed. Error: %#v.", err)
			eyeErr := NewErr(ErrInstance, ErrError, ErrNull, err.Error())
			return common.NewSysErr(eyeErr)
		}
		diskInfos = append(diskInfos, model.AdapterDiskView(diskInfo))
	}

	respData := model.AdapterHostView(info, nicInfos, diskInfos)
	w.Response.Data = respData
	return nil
}

func (h *HostHandler) DescribeHostDocker(r *url.Request, w *url.Response) common.JvirtError {
	//func (h *HostHandler) DescribeHostDocker(w http.ResponseWriter, r *http.Request) {
	h.log.Info("Invoke HostHandler DescribeHostDocker DataDisk.")
	var ctx context.Context
	dataDiskInfo, err := collector.HostCollect.GetVGState(ctx, cfg.CntrUploadCfg.DataDisk)
	if err != nil {
		h.log.Error("GetVGState failed. Error: %#v.", err)
		eyeErr := NewErr(ErrInstance, ErrError, ErrNull, err.Error())
		return common.NewSysErr(eyeErr)
	}

	h.log.Info("Invoke HostHandler DescribeHostDocker SystemDisk.")
	systemDiskInfo, err := collector.HostCollect.GetMountPointState(ctx, cfg.CntrUploadCfg.SystemDisk)
	if err != nil {
		h.log.Error("GetMountPointState failed. Error: %#v.", err)
		eyeErr := NewErr(ErrInstance, ErrError, ErrNull, err.Error())
		return common.NewSysErr(eyeErr)
	}

	respData := model.AdapterHostDockerView(model.AdapterMountView(systemDiskInfo), model.AdapterVGView(dataDiskInfo))
	w.Response.Data = respData
	return nil
}
