package handler

import (
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jcs-eye/utils/http"
)

func Setup(r *http.UrlRouter, logger log.Logger) {
	//baseHandler := NewBaseHandler()

	//hostHandler := NewHostHandler(baseHandler, logger)
	//hostHandler.RegisterHandler(r)

	//dockerHandler := NewDockerHandler(baseHandler, logger)
	////dockerHandler.Register(r)
	//
	//vmHandler := NewVMHandler(baseHandler, logger)
	////vmHandler.Register(r)
}
