package handler

import (
	"context"
	"encoding/json"

	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/url"
	"jd.com/jvirt/jvirt-jcs-eye/collector"
	"jd.com/jvirt/jvirt-jcs-eye/model"
	. "jd.com/jvirt/jvirt-jcs-eye/utils"
)

const (
	ACTION_DESCRIBE_VM = "DescribeVm"
)

type VMHandler struct {
	//	BaseHandler
	log log.Logger
}

//func NewVMHandler(base BaseHandler, log log.Logger) *VMHandler {
func NewVMHandler(log log.Logger) *VMHandler {
	return &VMHandler{
		//		BaseHandler: base,
		log: log,
	}
}

//func (h *VMHandler) Register(r *UrlRouter) {
//	r.RegisterFunc(ACTION_DESCRIBE_VM, h.DescribeVm)
//}
func (h *VMHandler) RegisterHandler(r *url.Router) {
	r.RegisterHandleFunc(ACTION_DESCRIBE_VM, h.DescribeVm)
}

//func (h *VMHandler) DescribeVm(w http.ResponseWriter, r *http.Request) {
func (h *VMHandler) DescribeVm(r *url.Request, w *url.Response) common.JvirtError {
	//params := &model.DescribeContainerReq{}
	h.log.Info("Invoke VMHandler DescribeVm.")
	// TODO 参数验证
	params := new(model.DescribeContainerReq)
	err := json.Unmarshal(r.Content, params)
	if err != nil {
		h.log.Error("Params validate failed. Error: %#v.", err)
		eyeErr := NewErr(ErrInstance, ErrMalformed, ErrNull, err.Error())
		return common.NewSysErr(eyeErr)
	}
	var ctx context.Context

	h.log.Debug("GetPowerState params: %#v.", params)

	info, err := collector.VMCollect.GetInstanceState(ctx, params.Id)
	if err != nil {
		h.log.Error("GetPowerState failed. Error: %#v.", err)
		eyeErr := NewErr(ErrInstance, ErrError, ErrNull, err.Error())
		return common.NewSysErr(eyeErr)
	}

	respData := model.AdapterVMView(info)
	w.Response.Data = respData
	return nil
}
