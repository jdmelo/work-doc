package worker

import (
	"context"
	"encoding/json"
	"fmt"
	"runtime/debug"
	"strings"
	"time"

	"jd.com/jvirt/jvirt-common/integration/xagent"
	"jd.com/jvirt/jvirt-common/utils"
	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jcs-eye/cfg"
	"jd.com/jvirt/jvirt-jcs-eye/collector"
	"jd.com/jvirt/jvirt-jcs-eye/jcloudwatch"
)

const (
	//pod and container status
	PodPhaseCreating  = "Creating"
	PodPhaseCreated   = "Created"
	PodPhaseStarting  = "Starting"
	PodPhaseRunning   = "Running"
	PodPhaseStopping  = "Stopping"
	PodPhaseStopped   = "Stopped"
	PodPhaseDeleting  = "Deleting"
	PodPhaseUnknown   = "Unknown"
	PodPhaseError     = "Error"
	PodPhaseSucceeded = "Succeeded"
	PodPhaseFailed    = "Failed"
)

func (cw *PodWorker) PodStatusCode(status string) int64 {
	switch status {
	case PodPhaseCreating:
		return 1
	case PodPhaseCreated:
		return 2
	case PodPhaseStarting:
		return 3
	case PodPhaseRunning:
		return 4
	case PodPhaseStopping:
		return 5
	case PodPhaseStopped:
		return 6
	case PodPhaseDeleting:
		return 7
	case PodPhaseUnknown:
		return 8
	case PodPhaseError:
		return 9
	case PodPhaseSucceeded:
		return 10
	case PodPhaseFailed:
		return 11
	}
	return 0
}

type PodWorker struct {
	backupTimePoint int
	logger          log.Logger
	syncInterval    time.Duration
	dbOperator      *db.ExtendDB
	UploadPeriod    int
	AppCode         string
	DataCenter      string
	IMClient        *jcloudwatch.IMonitorClient
}

func init() {
	RegisterCollector(cfg.JKS_POD_SERVICE_CODE, func(args *FactoryArgs) (Worker, error) {
		return &PodWorker{
			logger:       args.Logger,
			syncInterval: time.Duration(cfg.PodUploadCfg.TimerInterval) * time.Second,
			IMClient:     args.IMonitorClient,
		}, nil
	})
}

func (cw *PodWorker) Interval() time.Duration {
	return cw.syncInterval
}

func (cw *PodWorker) Name() string {
	return cfg.JKS_POD_SERVICE_CODE
}

func (cw *PodWorker) Work() error {
	enabledPod := cfg.PodUploadCfg.Enable
	cw.logger.Debug("enabledPod is %v", enabledPod)

	timestamp := time.Now().Unix() / int64(cfg.DefaultCfg.TimeUnit)
	uploadtimestamp := timestamp * int64(cfg.DefaultCfg.TimeUnit)
	ctx := context.WithValue(context.Background(), "trace_id", utils.Uuid())

	if enabledPod {
		pods, err := collector.HyperCollector.ListPods(ctx)
		if err != nil {
			cw.logger.Error("ListPods error : %s", err.Error())
			return err
		}
		cw.logger.Debug("ListPodsResult %+v", pods)
		for _, pod := range pods {
			go cw.PodDataUpload(ctx, uploadtimestamp, pod)
		}
	}

	return nil
}

// 任务处理时捕获未知错误, 防止panic使应用程序退出
func (u *PodWorker) onError() {
	if r := recover(); r != nil {
		u.logger.Error("PodWorker: 发生未知错误： %v ,%s", r, string(debug.Stack()))
		fmt.Printf("PodWorker: 发生未知错误： %v ,%s\n", r, string(debug.Stack()))
	}
}

func (cw *PodWorker) upload(ctx context.Context, serviceCode, resId string, data []jcloudwatch.DataPoint) error {
	reqData := &jcloudwatch.RequestData{
		AppCode:     cfg.IaasMonitorCfg.AppCode,
		ServiceCode: serviceCode,
		DataCenter:  cfg.IaasMonitorCfg.DataCenter,
		ResourceId:  resId,
		DataPoints:  data,
	}
	jsonData, err := json.Marshal(reqData)
	if err != nil {
		cw.logger.Error("Invoke IMClient.UploadData Marshal failed. Error:%s", err.Error())
	}
	cw.logger.Debug("Invoke IMClient.UploadData %s", string(jsonData))

	if err := cw.IMClient.UploadData(ctx, reqData); err != nil {
		cw.logger.Error("Invoke IMClient.UploadData failed. Error: %#v.", err)
		return err
	}

	return nil
}

// 对于pod nc融合后创建的native container，也会进到此接口中。此时需要更改其serviceCode为native container
func (cw *PodWorker) PodDataUpload(ctx context.Context, timestamp int64, pod *xagent.PodListResult) error {
	//捕获panic
	defer cw.onError()

	podId := pod.PodID
	ctx = context.WithValue(ctx, "trace_id", utils.Uuid())

	labels := pod.Labels

	zone := labels["zone"]
	userId := labels["user_id"]
	serviceCode := cfg.PodUploadCfg.ServiceCode
	podPhase := pod.Status.Phase

	if _, ok := labels["create_by_jks"]; !ok {
		cw.logger.Warn("pod %s not create by jks, not upload", podId)
		return nil
	}

	if strings.ToLower(labels["resource_type"]) == "nc" {
		serviceCode = cfg.NcUploadCfg.ServiceCode
		containerInfo, err := collector.HyperCollector.GetContainerInfo(ctx, podId)
		if err != nil {
			cw.logger.Error("Invoke HyperCollector.GetPodInfo failed. Error: %#v.", err)
			return err
		}
		podPhase = containerInfo.Status.Phase
	}

	// 创建和初始化标签。
	dataPoints := make([]jcloudwatch.DataPoint, 0)
	tags := make(map[string]interface{})
	tags["hostname"] = cfg.DefaultCfg.Hostname
	if len(userId) != 0 {
		tags["project_id"] = userId
	}
	if len(zone) != 0 {
		tags["az"] = zone
	}
	tmpData := jcloudwatch.DataPoint{Timestamp: timestamp, Tags: tags}

	tmpData.Metric = serviceCode + ".power_state"
	tmpData.Value = cw.PodStatusCode(podPhase)
	dataPoints = append(dataPoints, tmpData)

	if podPhase == PodPhaseRunning {
		podStats, err := collector.HyperCollector.GetPodStats(ctx, podId)
		if err != nil {
			cw.logger.Error("Invoke HyperCollector.GetPodStats failed. Error: %#v.", err)
			return err
		}

		tmpData.Metric = serviceCode + ".cpu.util"
		tmpData.Value = podStats.CpuUsage
		dataPoints = append(dataPoints, tmpData)

		tmpData.Metric = serviceCode + ".memory.usage"
		tmpData.Value = podStats.MemUsage
		dataPoints = append(dataPoints, tmpData)

		tmpData.Metric = serviceCode + ".disk.bytes.read"
		tmpData.Value = podStats.DiskRdBytes
		dataPoints = append(dataPoints, tmpData)

		tmpData.Metric = serviceCode + ".disk.bytes.write"
		tmpData.Value = podStats.DiskWrBytes
		dataPoints = append(dataPoints, tmpData)

		tmpData.Metric = serviceCode + ".network.bytes.incoming"
		tmpData.Value = podStats.NicRxBytes
		dataPoints = append(dataPoints, tmpData)

		tmpData.Metric = serviceCode + ".network.bytes.outgoing"
		tmpData.Value = podStats.NicTxBytes
		dataPoints = append(dataPoints, tmpData)
	}

	if err := cw.upload(ctx, serviceCode, podId, dataPoints); err != nil {
		return err
	}

	return nil
}
