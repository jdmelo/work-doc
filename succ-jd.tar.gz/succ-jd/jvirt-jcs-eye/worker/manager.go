package worker

import (
	"errors"
	"sync"
	"time"

	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/runtime"
	"jd.com/jvirt/jvirt-common/utils/wait"
)

// 数据库表迁移周期.
const (
	moveTime = time.Hour * -7 * 24 // 一周
)

type WorkerManager struct {
	logger    log.Logger
	workers   []Worker
	stop      chan struct{}
	mut       *sync.Mutex
	isStarted bool
	waitGroup *sync.WaitGroup
}

func NewWorkerManager(logger log.Logger) *WorkerManager {
	return &WorkerManager{
		workers:   make([]Worker, 0),
		stop:      make(chan struct{}),
		mut:       &sync.Mutex{},
		isStarted: false,
		waitGroup: &sync.WaitGroup{},
		logger:    logger,
	}
}

func (wm *WorkerManager) AddWorker(worker Worker) {
	wm.mut.Lock()
	defer wm.mut.Unlock()

	wm.workers = append(wm.workers, worker)
}

func (wm *WorkerManager) Start() error {
	wm.logger.Info("WorkerManager Start lock")
	wm.mut.Lock()
	defer wm.mut.Unlock()
	wm.logger.Info("WorkerManager Start lock success")

	wm.stop = make(chan struct{})

	if wm.isStarted {
		return errors.New("manager is started")
	}
	wm.isStarted = true
	if len(wm.workers) == 0 {
		return nil
	}
	for _, worker := range wm.workers {
		wm.waitGroup.Add(1)
		go func(worker Worker) {
			defer wm.waitGroup.Done()
			wait.Until(wm.trigger(worker), worker.Interval(), wm.stop)
		}(worker)
	}
	return nil

}

func (wm *WorkerManager) Stop() {
	wm.logger.Info("WorkerManager Stop lock")
	wm.mut.Lock()
	defer wm.mut.Unlock()
	wm.logger.Info("WorkerManager Stop lock success")
	if wm.isStarted {
		close(wm.stop)
		wm.waitGroup.Wait()
	}
	wm.isStarted = false
}

func (wm *WorkerManager) trigger(worker Worker) func() {
	return func() {
		defer runtime.HandleCrash(func(err interface{}) {
			wm.logger.Error("worker run panic. Detail: %v.", err)
		})
		workerName := worker.Name()
		wm.logger.Info("Worker [%s] begins to start.", workerName)
		if err := worker.Work(); err != nil {
			wm.logger.Error("Worker [%s] runs failed. Error: %#v.", workerName, err)
		}
		wm.logger.Info("Worker [%s] end of the run.", workerName)
	}
}
