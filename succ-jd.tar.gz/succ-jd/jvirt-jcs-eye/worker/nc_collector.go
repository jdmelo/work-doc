package worker

import (
	"context"
	"encoding/json"
	"fmt"
	"runtime/debug"
	"time"

	"jd.com/jvirt/jvirt-common/integration/xagent"
	"jd.com/jvirt/jvirt-common/utils"
	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jcs-eye/cfg"
	"jd.com/jvirt/jvirt-jcs-eye/collector"
	"jd.com/jvirt/jvirt-jcs-eye/jcloudwatch"
)

const (
	ContainerPhaseCreating = "Creating"
	ContainerPhaseCreated  = "Created"
	ContainerPhaseStarting = "Starting"
	ContainerPhaseRunning  = "Running"
	ContainerPhaseStopping = "Stopping"
	ContainerPhaseStopped  = "Stopped"
	ContainerPhaseDeleting = "Deleting"
	ContainerPhaseUnknown  = "Unknown"
	ContainerPhaseError    = "Error"
)

func (cw *HyperWorker) NCStatusCode(status string) int64 {
	switch status {
	case ContainerPhaseCreating:
		return 1
	case ContainerPhaseCreated:
		return 2
	case ContainerPhaseStarting:
		return 3
	case ContainerPhaseRunning:
		return 4
	case ContainerPhaseStopping:
		return 5
	case ContainerPhaseStopped:
		return 6
	case ContainerPhaseDeleting:
		return 7
	case ContainerPhaseUnknown:
		return 8
	case ContainerPhaseError:
		return 9
	}

	return 0
}

type HyperWorker struct {
	backupTimePoint int
	logger          log.Logger
	syncInterval    time.Duration
	dbOperator      *db.ExtendDB
	UploadPeriod    int
	AppCode         string
	DataCenter      string
	IMClient        *jcloudwatch.IMonitorClient
}

func init() {
	RegisterCollector(cfg.JKS_NC_SERVICE_CODE, func(args *FactoryArgs) (Worker, error) {
		return &HyperWorker{
			logger:       args.Logger,
			syncInterval: time.Duration(cfg.NcUploadCfg.TimerInterval) * time.Second,
			IMClient:     args.IMonitorClient,
		}, nil
	})
}

func (cw *HyperWorker) Interval() time.Duration {
	return cw.syncInterval
}

func (cw *HyperWorker) Name() string {
	return cfg.JKS_NC_SERVICE_CODE
}

func (cw *HyperWorker) Work() error {
	enabledNc := cfg.NcUploadCfg.Enable
	cw.logger.Debug("enabledNc is %v", enabledNc)

	timestamp := time.Now().Unix() / int64(cfg.DefaultCfg.TimeUnit)
	uploadtimestamp := timestamp * int64(cfg.DefaultCfg.TimeUnit)
	ctx := context.WithValue(context.Background(), "trace_id", utils.Uuid())

	if enabledNc {
		containers, err := collector.HyperCollector.ListContainers(ctx)
		if err != nil {
			cw.logger.Error("ListContainers error : %s", err.Error())
			return err
		}
		cw.logger.Debug("ListContainersResult %+v", containers)
		for _, container := range containers {
			go cw.NcDataUpload(ctx, uploadtimestamp, container)
		}

	}

	return nil
}

// 任务处理时捕获未知错误, 防止panic使应用程序退出
func (u *HyperWorker) onError() {
	if r := recover(); r != nil {
		u.logger.Error("HyperWorker: 发生未知错误： %v ,%s", r, string(debug.Stack()))
		fmt.Printf("HyperWorker: 发生未知错误： %v ,%s\n", r, string(debug.Stack()))
	}
}

func (cw *HyperWorker) upload(ctx context.Context, serviceCode, resId string, data []jcloudwatch.DataPoint) error {
	reqData := &jcloudwatch.RequestData{
		AppCode:     cfg.IaasMonitorCfg.AppCode,
		ServiceCode: serviceCode,
		DataCenter:  cfg.IaasMonitorCfg.DataCenter,
		ResourceId:  resId,
		DataPoints:  data,
	}
	jsonData, err := json.Marshal(reqData)
	if err != nil {
		cw.logger.Error("Invoke IMClient.UploadData Marshal failed. Error:%s", err.Error())
	}
	cw.logger.Debug("Invoke IMClient.UploadData %s", string(jsonData))

	if err := cw.IMClient.UploadData(ctx, reqData); err != nil {
		cw.logger.Error("Invoke IMClient.UploadData failed. Error: %#v.", err)
		return err
	}

	return nil
}

// 上报重构之前的.
func (cw *HyperWorker) NcDataUpload(ctx context.Context, timestamp int64, container *xagent.ContainerListResult) error {
	podId := container.PodID
	serviceCode := cfg.NcUploadCfg.ServiceCode
	ctx = context.WithValue(ctx, "trace_id", utils.Uuid())

	labels := container.Labels
	if _, ok := labels["create_by_jks"]; !ok {
		cw.logger.Warn("container %s not create by jks, not upload", podId)
		return nil
	}

	containerInfo, err := collector.HyperCollector.GetContainerInfo(ctx, podId)
	if err != nil {
		cw.logger.Error("Invoke HyperCollector.GetPodInfo failed. Error: %#v.", err)
		return err
	}
	containerPhase := containerInfo.Status.Phase

	// 创建和初始化标签。
	dataPoints := make([]jcloudwatch.DataPoint, 0)
	zone := labels["zone"]
	userId := labels["user_id"]

	tags := make(map[string]interface{})
	tags["hostname"] = cfg.DefaultCfg.Hostname
	tags["project_id"] = userId
	tags["az"] = zone
	tmpData := jcloudwatch.DataPoint{Timestamp: timestamp, Tags: tags}

	tmpData.Metric = serviceCode + ".power_state"
	tmpData.Value = cw.NCStatusCode(containerPhase)
	dataPoints = append(dataPoints, tmpData)

	if containerPhase == ContainerPhaseRunning {
		podStats, err := collector.HyperCollector.GetPodStats(ctx, podId)
		if err != nil {
			cw.logger.Error("Invoke GetPodStats failed. PodId: %s, Error: %s.", podId, err.Error())
			return err
		}

		tmpData.Metric = serviceCode + ".cpu.util"
		tmpData.Value = podStats.CpuUsage
		dataPoints = append(dataPoints, tmpData)

		tmpData.Metric = serviceCode + ".memory.usage"
		tmpData.Value = podStats.MemUsage
		dataPoints = append(dataPoints, tmpData)

		tmpData.Metric = serviceCode + ".disk.bytes.read"
		tmpData.Value = podStats.DiskRdBytes
		dataPoints = append(dataPoints, tmpData)

		tmpData.Metric = serviceCode + ".disk.bytes.write"
		tmpData.Value = podStats.DiskWrBytes
		dataPoints = append(dataPoints, tmpData)

		tmpData.Metric = serviceCode + ".network.bytes.incoming"
		tmpData.Value = podStats.NicRxBytes
		dataPoints = append(dataPoints, tmpData)

		tmpData.Metric = serviceCode + ".network.bytes.outgoing"
		tmpData.Value = podStats.NicTxBytes
		dataPoints = append(dataPoints, tmpData)
	}

	if err := cw.upload(ctx, serviceCode, podId, dataPoints); err != nil {
		return err
	}

	return nil
}
