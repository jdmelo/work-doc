package worker

import (
	"time"
)

type Worker interface {
	Name() string            // 采集器名称
	Work() error             // 采集信息
	Interval() time.Duration // 间隔时间
}

//from iaas_monitor client
type DataPoint struct {
	Metric    string                 `json:"metric"`
	Value     interface{}            `json:"value"`
	Timestamp int64                  `json:"timestamp"`
	Tags      map[string]interface{} `json:"tags"`
}

// IaaS monitor request data.
type RequestData struct {
	AppCode     string      `json:"appCode"`
	ServiceCode string      `json:"serviceCode"`
	DataCenter  string      `json:"dataCenter"`
	ResourceId  string      `json:"resourceId"`
	DataPoints  []DataPoint `json:"dataPoints"`
}

// IaaS monitor response data.
type ResponseData struct {
	Failed  int `json:"failed"`
	Success int `json:"success"`
}
