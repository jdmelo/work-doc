package worker

import (
	"context"
	"encoding/json"
	"fmt"
	"runtime/debug"
	"time"

	"jd.com/jvirt/jvirt-common/utils"
	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jcs-eye/cfg"
	"jd.com/jvirt/jvirt-jcs-eye/collector"
	"jd.com/jvirt/jvirt-jcs-eye/jcloudwatch"
)

type HostWorker struct {
	backupTimePoint int
	logger          log.Logger
	syncInterval    time.Duration
	dbOperator      *db.ExtendDB
	UploadPeriod    int
	AppCode         string
	DataCenter      string
	IMClient        *jcloudwatch.IMonitorClient
}

func init() {
	RegisterCollector(cfg.HOST_SERVICE_CODE, func(args *FactoryArgs) (Worker, error) {
		//c:=cfg.IaasMonitorCfg
		//config := &http.Config{
		//	ConnectTimeout:        c.ConnectTimeout,
		//	MaxIdleConns:          c.MaxIdleConns,
		//	TimerInterval:         c.TimerInterval,
		//	RequestTotalTimeout:   c.RequestTotalTimeout,
		//	ResponseHeaderTimeout: c.ResponseHeaderTimeout,
		//}
		//client := http.NewHttpClient(config, args.Logger)
		//args.IMonitorClient = NewIMonitorClient(client, c.UploadUrl, args.Logger)

		return &HostWorker{
			logger:       args.Logger,
			syncInterval: time.Duration(cfg.HostUploadCfg.TimerInterval) * time.Second,
			dbOperator:   args.DBCli,
			IMClient:     args.IMonitorClient,
		}, nil
	})
}

func (hw *HostWorker) Interval() time.Duration {
	return hw.syncInterval
}

func (hw *HostWorker) Name() string {
	return cfg.HOST_SERVICE_CODE
}

func (hw *HostWorker) Work() error {
	enabledHost := cfg.HostUploadCfg.Enable
	hw.logger.Debug("enabledHost is %v", enabledHost)
	timestamp := time.Now().Unix() / int64(cfg.DefaultCfg.TimeUnit)
	uploadtimestamp := timestamp * int64(cfg.DefaultCfg.TimeUnit)
	ctx := context.WithValue(context.Background(), "trace_id", utils.Uuid())

	if enabledHost {
		go hw.hostBaseDataUpload(ctx, uploadtimestamp)
		for _, name := range cfg.HostUploadCfg.Interfaces {
			go hw.hostNicUpload(ctx, uploadtimestamp, name)
		}
		for _, name := range cfg.HostUploadCfg.Disks {
			go hw.hostDiskUpload(ctx, uploadtimestamp, name)
		}
		for _, name := range cfg.HostUploadCfg.VolumeGroups {
			go hw.hostVGUpload(ctx, uploadtimestamp, name)
		}
		for _, name := range cfg.HostUploadCfg.MountPoints {
			go hw.hostMountPointUpload(ctx, uploadtimestamp, name)
		}
	}

	return nil
}

// 任务处理时捕获未知错误, 防止panic使应用程序退出
func (u *HostWorker) onError() {
	if r := recover(); r != nil {
		u.logger.Error("HostWorker: 发生未知错误： %v ,%s", r, string(debug.Stack()))
		fmt.Printf("HostWorker: 发生未知错误： %v ,%s\n", r, string(debug.Stack()))
	}
}

func (hw *HostWorker) upload(ctx context.Context, serviceCode, resId string, data []jcloudwatch.DataPoint) error {
	reqData := &jcloudwatch.RequestData{
		AppCode:     cfg.IaasMonitorCfg.AppCode,
		ServiceCode: serviceCode,
		DataCenter:  cfg.IaasMonitorCfg.DataCenter,
		ResourceId:  resId,
		DataPoints:  data,
	}
	jsonData, err := json.Marshal(reqData)
	if err != nil {
		hw.logger.Error("Invoke IMClient.UploadData Marshal failed. Error:%s", err.Error())
	}
	hw.logger.Debug("Invoke IMClient.UploadData %s", string(jsonData))

	if err := hw.IMClient.UploadData(ctx, reqData); err != nil {
		hw.logger.Error("Invoke IMClient.UploadData failed. Error: %#v.", err)
		return err
	}

	return nil
}

func (u *HostWorker) hostBaseDataUpload(ctx context.Context, timestamp int64) error {
	//捕获panic
	defer u.onError()

	serviceCode := cfg.HostUploadCfg.ServiceCode
	hostname := cfg.DefaultCfg.Hostname
	ctx = context.WithValue(ctx, "trace_id", utils.Uuid())

	info, err := collector.HostCollect.GetHostState(ctx)
	if err != nil {
		u.logger.Error("Invoke HostCollect.GetHostState failed. Error: %#v.", err)
		return err
	}

	// 创建和初始化标签。
	dataPoints := make([]jcloudwatch.DataPoint, 0)

	tags := make(map[string]interface{})
	tags["hostname"] = hostname

	tmpData := jcloudwatch.DataPoint{Timestamp: timestamp, Tags: tags}

	tmpData.Metric = serviceCode + ".cpu.num"
	tmpData.Value = info.CpuNum
	dataPoints = append(dataPoints, tmpData)

	tmpData.Metric = serviceCode + ".cpu.util"
	tmpData.Value = info.CpuUsage
	dataPoints = append(dataPoints, tmpData)

	tmpData.Metric = serviceCode + ".memory.total"
	tmpData.Value = info.MemTotal
	dataPoints = append(dataPoints, tmpData)

	tmpData.Metric = serviceCode + ".memory.available"
	tmpData.Value = info.MemAvailable
	dataPoints = append(dataPoints, tmpData)

	tmpData.Metric = serviceCode + ".memory.usage"
	tmpData.Value = info.MemUsage
	dataPoints = append(dataPoints, tmpData)

	tmpData.Metric = serviceCode + ".load.avg"
	tmpData.Value = info.Load1
	dataPoints = append(dataPoints, tmpData)

	if err := u.upload(ctx, serviceCode, hostname, dataPoints); err != nil {
		return err
	}

	return nil
}

func (u *HostWorker) hostNicUpload(ctx context.Context, timestamp int64, nicName string) error {
	//捕获panic
	defer u.onError()

	serviceCode := cfg.HostUploadCfg.ServiceCode
	hostname := cfg.DefaultCfg.Hostname
	ctx = context.WithValue(ctx, "trace_id", utils.Uuid())

	info, err := collector.HostCollect.GetNic(ctx, nicName)
	if err != nil {
		u.logger.Error("Invoke HostCollect.GetNic failed. Error: %#v.", err)
		return err
	}

	// 创建并且初始化dataPoints结构体。
	dataPoints := make([]jcloudwatch.DataPoint, 4)

	tags := make(map[string]interface{})
	tags["hostname"] = hostname
	tags["interface"] = nicName

	index := 0
	dataPoints[index].Metric = serviceCode + ".interface.bytes.incoming"
	dataPoints[index].Timestamp = timestamp
	dataPoints[index].Value = info.BytesRecv
	dataPoints[index].Tags = tags

	index += 1
	dataPoints[index].Metric = serviceCode + ".interface.bytes.outgoing"
	dataPoints[index].Timestamp = timestamp
	dataPoints[index].Value = info.BytesSent
	dataPoints[index].Tags = tags

	index += 1
	dataPoints[index].Metric = serviceCode + ".interface.packets.incoming"
	dataPoints[index].Timestamp = timestamp
	dataPoints[index].Value = info.PacketsRecv
	dataPoints[index].Tags = tags

	index += 1
	dataPoints[index].Metric = serviceCode + ".interface.packets.outgoing"
	dataPoints[index].Timestamp = timestamp
	dataPoints[index].Value = info.PacketsSent
	dataPoints[index].Tags = tags

	if err := u.upload(ctx, serviceCode, hostname, dataPoints); err != nil {
		return err
	}

	return nil
}

func (u *HostWorker) hostDiskUpload(ctx context.Context, timestamp int64, diskName string) error {
	//捕获panic
	defer u.onError()

	serviceCode := cfg.HostUploadCfg.ServiceCode
	hostname := cfg.DefaultCfg.Hostname
	ctx = context.WithValue(ctx, "trace_id", utils.Uuid())

	info, err := collector.HostCollect.GetDisk(ctx, diskName)
	if err != nil {
		u.logger.Error("Invoke HostCollect.GetDisk failed. Error: %#v.", err)
		return err
	}
	// 创建和初始化标签。
	tags := make(map[string]interface{})
	tags["device"] = diskName
	tags["hostname"] = hostname

	// 创建并且初始化dataPoints结构体。
	dataPoints := make([]jcloudwatch.DataPoint, 2)

	index := 0
	dataPoints[index].Metric = serviceCode + ".device.bytes.read"
	dataPoints[index].Timestamp = timestamp
	dataPoints[index].Value = info.ReadBytes
	dataPoints[index].Tags = tags

	index += 1
	dataPoints[index].Metric = serviceCode + ".device.bytes.write"
	dataPoints[index].Timestamp = timestamp
	dataPoints[index].Value = info.WriteBytes
	dataPoints[index].Tags = tags

	if err := u.upload(ctx, serviceCode, hostname, dataPoints); err != nil {
		return err
	}

	return nil
}

func (u *HostWorker) hostIopsUpload(ctx context.Context, timestamp int64, diskName string) error {
	//捕获panic
	defer u.onError()

	serviceCode := cfg.HostUploadCfg.ServiceCode
	hostname := cfg.DefaultCfg.Hostname
	ctx = context.WithValue(ctx, "trace_id", utils.Uuid())

	//首次去采样/proc/diskstats
	infoFirst, err := collector.HostCollect.GetDisk(ctx, diskName)
	if err != nil {
		u.logger.Error("Invoke HostCollect.GetDisk failed. Error: %#v.", err)
		return err
	}
	//休眠一秒，再次去采样/proc/diskstats
	time.Sleep(time.Duration(cfg.HostUploadCfg.IopsInterval) * time.Second)

	infoSecond, err := collector.HostCollect.GetDisk(ctx, diskName)
	if err != nil {
		u.logger.Error("Invoke HostCollect.GetDisk failed. Error: %#v.", err)
		return err
	}

	u.logger.Debug("1st IO Detail: ReadCount[%d],WriteCount[%d].", infoFirst.ReadCount, infoFirst.WriteCount)
	u.logger.Debug("2nd IO Detail: ReadCount[%d],WriteCount[%d].", infoSecond.ReadCount, infoSecond.WriteCount)

	// 创建和初始化标签。
	tags := make(map[string]interface{})
	tags["device"] = diskName
	tags["hostname"] = hostname

	// 创建并且初始化dataPoints结构体。
	dataPoints := make([]jcloudwatch.DataPoint, 2)

	index := 0
	dataPoints[index].Metric = serviceCode + ".device.iops.read"
	dataPoints[index].Timestamp = timestamp
	dataPoints[index].Value = (infoSecond.ReadCount - infoFirst.ReadCount) / uint64(cfg.HostUploadCfg.IopsInterval)
	dataPoints[index].Tags = tags

	index += 1
	dataPoints[index].Metric = serviceCode + ".device.iops.write"
	dataPoints[index].Timestamp = timestamp
	dataPoints[index].Value = (infoSecond.WriteCount - infoFirst.WriteCount) / uint64(cfg.HostUploadCfg.IopsInterval)
	dataPoints[index].Tags = tags

	if err := u.upload(ctx, serviceCode, hostname, dataPoints); err != nil {
		u.logger.Error("Invoke HostWorker upload failed. Error: %#v.", err)
		return err
	}

	return nil
}

func (u *HostWorker) hostVGUpload(ctx context.Context, timestamp int64, vgName string) error {
	//捕获panic
	defer u.onError()

	serviceCode := cfg.HostUploadCfg.ServiceCode
	hostname := cfg.DefaultCfg.Hostname
	ctx = context.WithValue(ctx, "trace_id", utils.Uuid())

	info, err := collector.HostCollect.GetVGState(ctx, vgName)
	if err != nil {
		u.logger.Error("Invoke HostCollect.GetVGState failed. Error: %#v.", err)
		return err
	}

	// 创建和初始化标签。
	tags := make(map[string]interface{})
	tags["vgname"] = vgName
	tags["hostname"] = hostname
	// 创建并且初始化dataPoints结构体。
	dataPoints := make([]jcloudwatch.DataPoint, 4)

	index := 0
	dataPoints[index].Metric = serviceCode + ".volumegroup.total"
	dataPoints[index].Timestamp = timestamp
	dataPoints[index].Value = info.Total
	dataPoints[index].Tags = tags

	index += 1
	dataPoints[index].Metric = serviceCode + ".volumegroup.used"
	dataPoints[index].Timestamp = timestamp
	dataPoints[index].Value = info.Used
	dataPoints[index].Tags = tags

	index += 1
	dataPoints[index].Metric = serviceCode + ".volumegroup.free"
	dataPoints[index].Timestamp = timestamp
	dataPoints[index].Value = info.Free
	dataPoints[index].Tags = tags

	index += 1
	dataPoints[index].Metric = serviceCode + ".volumegroup.usage"
	dataPoints[index].Timestamp = timestamp
	dataPoints[index].Value = info.UsedPercent
	dataPoints[index].Tags = tags

	if err := u.upload(ctx, serviceCode, hostname, dataPoints); err != nil {
		return err
	}

	return nil
}

func (u *HostWorker) hostMountPointUpload(ctx context.Context, timestamp int64, mp string) error {
	//捕获panic
	defer u.onError()

	serviceCode := cfg.HostUploadCfg.ServiceCode
	hostname := cfg.DefaultCfg.Hostname
	ctx = context.WithValue(ctx, "trace_id", utils.Uuid())

	info, err := collector.HostCollect.GetMountPointState(ctx, mp)
	if err != nil {
		u.logger.Error("Invoke HostCollect.GetMountPointState failed. Error: %#v.", err)
		return err
	}

	// 创建和初始化标签。
	tags := make(map[string]interface{})
	tags["mountpoint"] = mp
	tags["hostname"] = hostname

	// 创建并且初始化dataPoints结构体。
	dataPoints := make([]jcloudwatch.DataPoint, 4)

	index := 0
	dataPoints[index].Metric = serviceCode + ".device.mountpoint.total"
	dataPoints[index].Timestamp = timestamp
	dataPoints[index].Value = info.Total
	dataPoints[index].Tags = tags

	index += 1
	dataPoints[index].Metric = serviceCode + ".device.mountpoint.used"
	dataPoints[index].Timestamp = timestamp
	dataPoints[index].Value = info.Used
	dataPoints[index].Tags = tags

	index += 1
	dataPoints[index].Metric = serviceCode + ".device.mountpoint.free"
	dataPoints[index].Timestamp = timestamp
	dataPoints[index].Value = info.Free
	dataPoints[index].Tags = tags

	index += 1
	dataPoints[index].Metric = serviceCode + ".device.mountpoint.usage"
	dataPoints[index].Timestamp = timestamp
	dataPoints[index].Value = info.UsedPercent
	dataPoints[index].Tags = tags

	if err := u.upload(ctx, serviceCode, hostname, dataPoints); err != nil {
		return err
	}

	return nil
}
