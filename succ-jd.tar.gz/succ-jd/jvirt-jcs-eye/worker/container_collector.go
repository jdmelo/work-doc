package worker

import (
	"context"
	"encoding/json"
	"fmt"
	"runtime/debug"
	"time"

	"jd.com/jvirt/jvirt-common/utils"
	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jcs-eye/cfg"
	"jd.com/jvirt/jvirt-jcs-eye/collector"
	"jd.com/jvirt/jvirt-jcs-eye/collector/cntr"
	"jd.com/jvirt/jvirt-jcs-eye/jcloudwatch"
)

type ContainerWorker struct {
	backupTimePoint int
	logger          log.Logger
	syncInterval    time.Duration
	dbOperator      *db.ExtendDB
	UploadPeriod    int
	AppCode         string
	DataCenter      string
	IMClient        *jcloudwatch.IMonitorClient
}

func init() {
	RegisterCollector(cfg.CNTR_SERVICE_CODE, func(args *FactoryArgs) (Worker, error) {
		return &ContainerWorker{
			logger:       args.Logger,
			syncInterval: time.Duration(cfg.CntrUploadCfg.TimerInterval) * time.Second,
			dbOperator:   args.DBCli,
			IMClient:     args.IMonitorClient,
		}, nil
	})
}

func (cw *ContainerWorker) Interval() time.Duration {
	return cw.syncInterval
}

func (cw *ContainerWorker) Name() string {
	return cfg.CNTR_SERVICE_CODE
}

func (cw *ContainerWorker) Work() error {
	enabledCntr := cfg.CntrUploadCfg.Enable
	cw.logger.Debug("enabledCntr is %v", enabledCntr)

	timestamp := time.Now().Unix() / int64(cfg.DefaultCfg.TimeUnit)
	uploadtimestamp := timestamp * int64(cfg.DefaultCfg.TimeUnit)
	ctx := context.WithValue(context.Background(), "trace_id", utils.Uuid())

	if enabledCntr {
		instances, err := collector.CntrCollect.ListInstances(ctx)
		if err != nil {
			cw.logger.Error("DockerInfoList error : %s", err.Error())
			return err
		}
		for _, instance := range instances {
			go cw.cntrDataUpload(ctx, uploadtimestamp, instance.Id, instance.UserId, instance.Az)
			go cw.cntrIopsUpload(ctx, uploadtimestamp, instance.Id, instance.UserId, instance.Az)
		}
	}

	return nil
}

// 任务处理时捕获未知错误, 防止panic使应用程序退出
func (u *ContainerWorker) onError() {
	if r := recover(); r != nil {
		u.logger.Error("ContainerWorker: 发生未知错误： %v ,%s", r, string(debug.Stack()))
		fmt.Printf("ContainerWorker: 发生未知错误： %v ,%s\n", r, string(debug.Stack()))
	}
}

func (cw *ContainerWorker) upload(ctx context.Context, serviceCode, resId string, data []jcloudwatch.DataPoint) error {
	reqData := &jcloudwatch.RequestData{
		AppCode:     cfg.IaasMonitorCfg.AppCode,
		ServiceCode: serviceCode,
		DataCenter:  cfg.IaasMonitorCfg.DataCenter,
		ResourceId:  resId,
		DataPoints:  data,
	}
	jsonData, err := json.Marshal(reqData)
	if err != nil {
		cw.logger.Error("Invoke IMClient.UploadData Marshal failed. Error:%s", err.Error())
	}
	cw.logger.Debug("Invoke IMClient.UploadData %s", string(jsonData))

	if err := cw.IMClient.UploadData(ctx, reqData); err != nil {
		cw.logger.Error("Invoke IMClient.UploadData failed. Error: %#v.", err)
		return err
	}

	return nil
}
func (cw *ContainerWorker) cntrIopsUpload(ctx context.Context, timestamp int64, cntrName, projectId, az string) error {
	//捕获panic
	defer cw.onError()
	serviceCode := cfg.CntrUploadCfg.ServiceCode
	ctx = context.WithValue(ctx, "trace_id", utils.Uuid())

	powerState, err := collector.CntrCollect.GetPowerState(ctx, cntrName)
	if err != nil {
		cw.logger.Error("Invoke CntrCollect.GetPowerState failed. Error: %#v.", err)
		return err
	}

	// 创建和初始化标签
	dataPoints := make([]jcloudwatch.DataPoint, 0)

	tags := make(map[string]interface{})
	if len(cfg.DefaultCfg.Hostname) > 0 {
		tags["hostname"] = cfg.DefaultCfg.Hostname
	}
	if len(projectId) > 0 {
		tags["project_id"] = projectId
	}

	if len(az) > 0 {
		tags["az"] = az
	}

	tmpData := jcloudwatch.DataPoint{Timestamp: timestamp, Tags: tags}

	tmpData.Metric = serviceCode + ".power_state"
	if powerState == cntr.CNTR_RUNNING {
		tmpData.Value = 1
	} else {
		tmpData.Value = 0
	}
	dataPoints = append(dataPoints, tmpData)

	if powerState == cntr.CNTR_RUNNING {
		cw.logger.Debug("powerState is running")
		//首次去采样
		iopsFirst, err := collector.CntrCollect.GetDataDiskState(ctx, cntrName)
		if err != nil {
			cw.logger.Error("Invoke HostCollect.GetDisk failed. Error: %#v.", err)
			return err
		}
		//休眠一秒，再次去采样
		time.Sleep(time.Duration(cfg.CntrUploadCfg.IopsInterval) * time.Second)
		iopsSecond, err := collector.CntrCollect.GetDataDiskState(ctx, cntrName)
		if err != nil {
			cw.logger.Error("Invoke HostCollect.GetDisk failed. Error: %#v.", err)
			return err
		}
		cw.logger.Debug("1st IO Detail: ReadCount[%d],WriteCount[%d].", iopsFirst.ReadCount, iopsFirst.WriteCount)
		cw.logger.Debug("2nd IO Detail: ReadCount[%d],WriteCount[%d].", iopsSecond.ReadCount, iopsSecond.WriteCount)

		tmpData.Metric = serviceCode + ".disk.iops.read"
		// 负值的保护
		if iopsSecond.ReadCount >= iopsFirst.ReadCount {
			tmpData.Value = (iopsSecond.ReadCount - iopsFirst.ReadCount) / uint64(cfg.CntrUploadCfg.IopsInterval)
		} else {
			cw.logger.Debug("ReadCount error, 2nd read count %d is less than 1st read count %d, set 0",
				iopsSecond.ReadCount, iopsFirst.ReadCount)
			tmpData.Value = 0
		}
		dataPoints = append(dataPoints, tmpData)

		tmpData.Metric = serviceCode + ".disk.iops.write"
		// 负值的保护
		if iopsSecond.WriteCount >= iopsFirst.WriteCount {
			tmpData.Value = (iopsSecond.WriteCount - iopsFirst.WriteCount) / uint64(cfg.CntrUploadCfg.IopsInterval)
		} else {
			cw.logger.Debug("WriteCount error, 2nd write count %d is less than 1st write count %d, set 0",
				iopsSecond.WriteCount, iopsFirst.WriteCount)
			tmpData.Value = 0
		}
		dataPoints = append(dataPoints, tmpData)
	}
	if err := cw.upload(ctx, serviceCode, cntrName, dataPoints); err != nil {
		cw.logger.Error("Invoke ContainerWorker upload failed. Error: %#v.", err)
		return err
	}

	return nil
}

func (cw *ContainerWorker) cntrDataUpload(ctx context.Context, timestamp int64, cntrName, projectId, az string) error {
	//捕获panic
	defer cw.onError()
	serviceCode := cfg.CntrUploadCfg.ServiceCode
	ctx = context.WithValue(ctx, "trace_id", utils.Uuid())

	powerState, err := collector.CntrCollect.GetPowerState(ctx, cntrName)
	if err != nil {
		cw.logger.Error("Invoke CntrCollect.inspectContainer failed. Error: %#v.", err)
		return err
	}
	// 创建和初始化标签
	dataPoints := make([]jcloudwatch.DataPoint, 0)

	tags := make(map[string]interface{})
	if len(cfg.DefaultCfg.Hostname) > 0 {
		tags["hostname"] = cfg.DefaultCfg.Hostname
	}
	if len(projectId) > 0 {
		tags["project_id"] = projectId
	}

	if len(az) > 0 {
		tags["az"] = az
	}

	tmpData := jcloudwatch.DataPoint{Timestamp: timestamp, Tags: tags}

	tmpData.Metric = serviceCode + ".power_state"
	if powerState == cntr.CNTR_RUNNING {
		tmpData.Value = 1
	} else {
		tmpData.Value = 0
	}
	dataPoints = append(dataPoints, tmpData)

	if powerState == cntr.CNTR_RUNNING {
		cntrInfo, err := collector.CntrCollect.GetInstanceState(ctx, cntrName)
		if err != nil {
			cw.logger.Error("Invoke CntrCollect.GetPowerState failed. Error: %#v.", err)
		} else {
			tmpData.Metric = serviceCode + ".cpu.util"
			tmpData.Value = cntrInfo.CpuUsage
			dataPoints = append(dataPoints, tmpData)

			tmpData.Metric = serviceCode + ".memory.usage"
			tmpData.Value = cntrInfo.MemUsage
			dataPoints = append(dataPoints, tmpData)

			tmpData.Metric = serviceCode + ".disk.bytes.read"
			tmpData.Value = cntrInfo.SystemDisk.ReadBytes
			dataPoints = append(dataPoints, tmpData)

			tmpData.Metric = serviceCode + ".disk.bytes.write"
			tmpData.Value = cntrInfo.SystemDisk.WriteBytes
			dataPoints = append(dataPoints, tmpData)

			tmpData.Metric = serviceCode + ".network.bytes.incoming"
			tmpData.Value = cntrInfo.Network.BytesRecv
			dataPoints = append(dataPoints, tmpData)

			tmpData.Metric = serviceCode + ".network.bytes.outgoing"
			tmpData.Value = cntrInfo.Network.BytesSent
			dataPoints = append(dataPoints, tmpData)
		}
	}

	if err := cw.upload(ctx, serviceCode, cntrName, dataPoints); err != nil {
		return err
	}

	return nil
}
