package worker

import (
	"context"
	"encoding/json"
	"fmt"
	"runtime/debug"
	"strconv"
	"time"

	"jd.com/jvirt/jvirt-common/utils"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jcs-eye/cfg"
	"jd.com/jvirt/jvirt-jcs-eye/collector"
	"jd.com/jvirt/jvirt-jcs-eye/collector/vm"
	"jd.com/jvirt/jvirt-jcs-eye/jcloudwatch"
)

type VmWorker struct {
	backupTimePoint int
	logger          log.Logger
	syncInterval    time.Duration
	UploadPeriod    int
	AppCode         string
	DataCenter      string
	IMClient        *jcloudwatch.IMonitorClient
}

func init() {
	RegisterCollector(cfg.VM_SERVICE_CODE, func(args *FactoryArgs) (Worker, error) {
		return &VmWorker{
			logger:       args.Logger,
			syncInterval: time.Duration(cfg.VMUploadCfg.TimerInterval) * time.Second,
			IMClient:     args.IMonitorClient,
		}, nil
	})
}

func (vw *VmWorker) Interval() time.Duration {
	return vw.syncInterval
}

func (vw *VmWorker) Name() string {
	return cfg.VM_SERVICE_CODE
}

func (vw *VmWorker) Work() error {
	enabledVm := cfg.VMUploadCfg.Enable
	vw.logger.Debug("enabledVm is %v", enabledVm)

	timestamp := time.Now().Unix() / int64(cfg.DefaultCfg.TimeUnit)
	uploadtimestamp := timestamp * int64(cfg.DefaultCfg.TimeUnit)
	ctx := context.WithValue(context.Background(), "trace_id", utils.Uuid())

	if enabledVm {
		instances, err := collector.VMCollect.ListInstances(ctx)
		if err != nil {
			vw.logger.Error("InstanceInfoList error : %s", err.Error())
			return err
		}

		for _, instance := range instances {
			go vw.vmDataUpload(ctx, uploadtimestamp, instance.Id, instance.UserId, instance.Az, instance.AgId)
		}
	}

	return nil
}

// 任务处理时捕获未知错误, 防止panic使应用程序退出
func (u *VmWorker) onError() {
	if r := recover(); r != nil {
		u.logger.Error("VmWorker: 发生未知错误： %v ,%s", r, string(debug.Stack()))
		fmt.Printf("VmWorker: 发生未知错误： %v ,%s\n", r, string(debug.Stack()))
	}
}
func (vw *VmWorker) upload(ctx context.Context, serviceCode, resId string, data []jcloudwatch.DataPoint) error {
	reqData := &jcloudwatch.RequestData{
		AppCode:     cfg.IaasMonitorCfg.AppCode,
		ServiceCode: serviceCode,
		DataCenter:  cfg.IaasMonitorCfg.DataCenter,
		ResourceId:  resId,
		DataPoints:  data,
	}
	jsonData, err := json.Marshal(reqData)
	if err != nil {
		vw.logger.Error("Invoke IMClient.UploadData Marshal failed. Error:%s", err.Error())
	}
	vw.logger.Debug("Invoke IMClient.UploadData %s", string(jsonData))

	if err := vw.IMClient.UploadData(ctx, reqData); err != nil {
		vw.logger.Error("Invoke IMClient.UploadData failed. Error: %#v.", err)
		return err
	}

	return nil
}

func (vw *VmWorker) vmDataUpload(ctx context.Context, timestamp int64, vmId, projectId, az, agId string) error {
	//捕获panic
	defer vw.onError()
	serviceCode := cfg.VMUploadCfg.ServiceCode
	enableGpu := cfg.VMUploadCfg.GpuEnable

	ctx = context.WithValue(ctx, "trace_id", utils.Uuid())

	info, err := collector.VMCollect.GetInstanceState(ctx, vmId)
	if err != nil {
		vw.logger.Error("Invoke VMCollect.GetInstanceState failed. VmId: %s, Error: %#v.", vmId, err)
		return err
	}

	// 创建和初始化标签。
	dataPoints := make([]jcloudwatch.DataPoint, 0)

	tags := make(map[string]interface{})
	if len(cfg.DefaultCfg.Hostname) > 0 {
		tags["hostname"] = cfg.DefaultCfg.Hostname
	}
	if len(projectId) > 0 {
		tags["project_id"] = projectId
	}
	if len(az) > 0 {
		tags["az"] = az
	}
	if len(agId) > 0 {
		tags["agid"] = agId
	}

	tmpData := jcloudwatch.DataPoint{Timestamp: timestamp, Tags: tags}

	tmpData.Metric = serviceCode + ".power_state"
	tmpData.Value = vw.convPowerState(info.State)
	dataPoints = append(dataPoints, tmpData)

	tmpData.Metric = serviceCode + ".disk.bytes.read"
	tmpData.Value = info.DiskRdBytes
	dataPoints = append(dataPoints, tmpData)

	tmpData.Metric = serviceCode + ".disk.bytes.write"
	tmpData.Value = info.DiskWrBytes
	dataPoints = append(dataPoints, tmpData)

	tmpData.Metric = serviceCode + ".network.bytes.incoming"
	tmpData.Value = info.NicRxBytes
	dataPoints = append(dataPoints, tmpData)

	tmpData.Metric = serviceCode + ".network.bytes.outgoing"
	tmpData.Value = info.NicTxBytes
	dataPoints = append(dataPoints, tmpData)

	tmpData.Metric = serviceCode + ".memory.usage"
	tmpData.Value = info.MemUsage
	dataPoints = append(dataPoints, tmpData)

	tmpData.Metric = serviceCode + ".cpu.util"
	tmpData.Value = info.CpuUsage
	dataPoints = append(dataPoints, tmpData)

	// Gpu info
	if enableGpu {
		for index, gpuInfo := range info.GpuInfo {
			gpuData := jcloudwatch.DataPoint{Timestamp: timestamp, Tags: make(map[string]interface{})}
			gpuData.Tags["gpu_index"] = strconv.Itoa(index)

			gpuData.Metric = serviceCode + ".gpu.power"
			gpuData.Value = gpuInfo.Power
			dataPoints = append(dataPoints, gpuData)

			gpuData.Metric = serviceCode + ".gpu.temperature"
			gpuData.Value = gpuInfo.Temperature
			dataPoints = append(dataPoints, gpuData)

			gpuData.Metric = serviceCode + ".gpu.util.gpu"
			gpuData.Value = gpuInfo.UtilGpu
			dataPoints = append(dataPoints, gpuData)

			gpuData.Metric = serviceCode + ".gpu.util.decoder"
			gpuData.Value = gpuInfo.UtilDecoder
			dataPoints = append(dataPoints, gpuData)

			gpuData.Metric = serviceCode + ".gpu.util.encoder"
			gpuData.Value = gpuInfo.UtilEncoder
			dataPoints = append(dataPoints, gpuData)

			gpuData.Metric = serviceCode + ".gpu.util.mem"
			gpuData.Value = gpuInfo.UtilMem
			dataPoints = append(dataPoints, gpuData)
		}

	}

	if err := vw.upload(ctx, serviceCode, vmId, dataPoints); err != nil {
		return err
	}

	return nil
}

func (vw *VmWorker) convPowerState(state string) int {
	powerState := 0

	switch state {
	case vm.VM_NOSTATE:
		powerState = 0
	case vm.VM_RUNNING:
		powerState = 1
	case vm.VM_BLOCKED:
		powerState = 2
	case vm.VM_PAUSED:
		powerState = 3
	case vm.VM_SHUTDOWN:
		powerState = 4
	case vm.VM_SHUTOFF:
		powerState = 5
	case vm.VM_CRASHED:
		powerState = 6
	case vm.VM_SUSPENDED:
		powerState = 7
	}

	return powerState
}
