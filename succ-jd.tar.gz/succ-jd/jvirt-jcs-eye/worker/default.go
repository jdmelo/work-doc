package worker

import (
	jcsApi "jd.com/jvirt/jvirt-common/inner/jcs/api-server"
	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/redis"
	"jd.com/jvirt/jvirt-jcs-eye/jcloudwatch"
)

var WorkerFactorys = make(map[string]Factory)

type FactoryArgs struct {
	Logger         log.Logger
	DBCli          *db.ExtendDB
	RedisCli       redis.Redis
	JcsApiClient   jcsApi.ApiServerClient
	IMonitorClient *jcloudwatch.IMonitorClient
}

type Factory func(factoryArgs *FactoryArgs) (Worker, error)

func RegisterCollector(name string, factory Factory) {
	WorkerFactorys[name] = factory
}
