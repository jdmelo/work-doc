package cfg

type Config struct {
	DefaultConfig     *DefaultConfig
	LogConfig         *LogConfig
	HttpServerConfig  *HttpServerConfig
	IaasMonitorConfig *IaasMonitorConfig
}

type DefaultConfig struct {
	RunCores      int    `ini:"run_cores"`
	Hostname      string `ini:"hostname" validate:"nonzero"`
	HostIp        string `ini:"host_ip" validate:"nonzero"`
	CheckUploader bool   `ini:"check_uploader"`
	//add by re-struct
	Debug    bool     `ini:"debug"`
	Workers  []string `ini:"workers" validate:"nonzero"` // 需要加载的 workers,以逗号分隔
	TimeUnit int      `ini:"time_unit"`
}

type JvirtJcsApiConfig struct {
	Url                   string `ini:"url" validate:"nonzero"`
	ConnectTimeout        int    `ini:"connect_timeout"`
	MaxIdleConns          int    `ini:"max_idle_conns"`
	TimerInterval         int    `ini:"timer_interval"`
	ResponseHeaderTimeout int    `ini:"response_header_timeout"`
	RequestTotalTimeout   int    `ini:"request_total_timeout"`
}

type JvirtRmsApiConfig struct {
	Url                   string `ini:"url" validate:"nonzero"`
	ConnectTimeout        int    `ini:"connect_timeout"`
	MaxIdleConns          int    `ini:"max_idle_conns"`
	TimerInterval         int    `ini:"timer_interval"`
	ResponseHeaderTimeout int    `ini:"response_header_timeout"`
	RequestTotalTimeout   int    `ini:"request_total_timeout"`
}

type HttpServerConfig struct {
	BaseUrl string `ini:"base_url"`
	Port    string `ini:"port"`
}

type LogConfig struct {
	FileName string `ini:"file_name" validate:"nonzero"`
	//FileCount   int    `ini:"file_count"`
	//FileMaxSize int    `ini:"file_max_size"`
	Level string `ini:"level"`
}

type IaasMonitorConfig struct {
	UploadUrl             string `ini:"upload_url" validate:"nonzero"`
	UploadPeriod          int    `ini:"upload_period" validate:"nonzero"`
	AppCode               string `ini:"app_code" validate:"nonzero"`
	DataCenter            string `ini:"data_center" validate:"nonzero"`
	ConnectTimeout        int    `ini:"connect_timeout"`
	MaxIdleConns          int    `ini:"max_idle_conns"`
	TimerInterval         int    `ini:"timer_interval"`
	ResponseHeaderTimeout int    `ini:"response_header_timeout"`
	RequestTotalTimeout   int    `ini:"request_total_timeout"`
}

type HostUploadConfig struct {
	ServiceCode   string   `ini:"service_code"` // default host
	Enable        bool     `ini:"enable"`
	Interfaces    []string `ini:"interfaces" validate:"nonzero"`
	Disks         []string `ini:"disks" validate:"nonzero"`
	MountPoints   []string `ini:"mount_points" validate:"nonzero"`
	VolumeGroups  []string `ini:"volume_groups"`
	TimerInterval int      `ini:"timer_interval"`
	IopsInterval  int      `ini:"iops_interval"`
}

type VMUploadConfig struct {
	ServiceCode     string `ini:"service_code"` // default vm
	Enable          bool   `ini:"enable"`
	TimerInterval   int    `ini:"timer_interval"`
	GpuEnable       bool   `ini:"gpu_enable"`
	SmartCardEnable bool   `ini:"smart_card_enable"`
}

type CntrUploadConfig struct {
	ServiceCode      string `ini:"service_code"` // default container
	Enable           bool   `ini:"enable"`
	DockerApiVersion string `ini:"docker_api_version" validate:"nonzero"`
	DockerEndpoint   string `ini:"docker_endpoint" validate:"nonzero"`
	DockerNet        string `ini:"docker_net" validate:"nonzero"`
	ContainerPath    string `ini:"container_path" validate:"nonzero"`
	SystemDisk       string `ini:"system_disk" validate:"nonzero"`
	DataDisk         string `ini:"data_disk" validate:"nonzero"`
	TimerInterval    int    `ini:"timer_interval"`
	IopsInterval     int    `ini:"iops_interval"`
}

type NcUploadConfig struct {
	ServiceCode   string `ini:"service_code"` // default container
	Enable        bool   `ini:"enable"`
	TimerInterval int    `ini:"timer_interval"`
}

type PodUploadConfig struct {
	ServiceCode   string `ini:"service_code"` // default container
	Enable        bool   `ini:"enable"`
	TimerInterval int    `ini:"timer_interval"`
}
