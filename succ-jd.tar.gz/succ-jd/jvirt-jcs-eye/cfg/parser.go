package cfg

import (
	"errors"
	"fmt"
	"os"

	"github.com/go-ini/ini"

	"jd.com/jvirt/jvirt-common/utils/config"
	"jd.com/jvirt/jvirt-jcs-eye/utils/validate"
)

const (
	DefaultSection     = "default"
	JvirtJcsApiSection = "jvirt_jcs_api"
	JvirtRmsApiSection = "jvirt_rms_api"
	HttpServerSection  = "http_server"
	LogSection         = "log"
	IaasMonitorSection = "iaas_monitor"
	HostUploadSection  = "host_upload"
	VMUploadSection    = "vm_upload"
	CntrUploadSection  = "container_upload"
	//HyperUploadSection  = "container_upload"
	NcUploadSection  = "nc_upload"
	PodUploadSection = "pod_upload"
	XagentSection    = "xagent"
)

// default config.
const (
	APP_CODE      = "jcloud"
	RUN_CORES     = 4
	UPLOAD_PERIOD = 60

	HTTP_PORT = "8900"
	BASE_URL  = "jvirt-jcs-eye"

	LOG_FILE_COUNT    = 5
	LOG_FILE_MAX_SIZE = 1073741824 // 1G
	//LOG_LEVEL         = 2          // DEBUG
	LOG_LEVEL = "debug" // DEBUG

	HOST_SERVICE_CODE    = "host"
	VM_SERVICE_CODE      = "vm"
	CNTR_SERVICE_CODE    = "container"
	HYPER_SERVICE_CODE   = "hyper"
	JKS_NC_SERVICE_CODE  = "nativecontainer"
	JKS_POD_SERVICE_CODE = "pod"
)

var (
	DefaultCfg     *DefaultConfig
	JvirtJcsApiCfg *JvirtJcsApiConfig
	JvirtRmsApiCfg *JvirtRmsApiConfig
	HttpServerCfg  *HttpServerConfig
	LogCfg         *LogConfig
	IaasMonitorCfg *IaasMonitorConfig
	HostUploadCfg  *HostUploadConfig
	VMUploadCfg    *VMUploadConfig
	CntrUploadCfg  *CntrUploadConfig
	NcUploadCfg    *NcUploadConfig
	PodUploadCfg   *PodUploadConfig
	XagentCfg      *config.XAgentConfig
)

func init() {
	DefaultCfg = &DefaultConfig{
		RunCores:      RUN_CORES,
		CheckUploader: false,
	}
	JvirtJcsApiCfg = &JvirtJcsApiConfig{
		TimerInterval:         60,
		ConnectTimeout:        500,
		MaxIdleConns:          100,
		ResponseHeaderTimeout: 1000,
		RequestTotalTimeout:   2000,
	}
	JvirtRmsApiCfg = &JvirtRmsApiConfig{
		TimerInterval:         60,
		ConnectTimeout:        500,
		MaxIdleConns:          100,
		ResponseHeaderTimeout: 1000,
		RequestTotalTimeout:   2000,
	}
	HttpServerCfg = &HttpServerConfig{
		BaseUrl: BASE_URL,
		Port:    HTTP_PORT,
	}
	LogCfg = &LogConfig{
		//FileCount:   LOG_FILE_COUNT,
		//FileMaxSize: LOG_FILE_MAX_SIZE,
		Level: LOG_LEVEL,
	}
	IaasMonitorCfg = &IaasMonitorConfig{
		AppCode:               APP_CODE,
		UploadPeriod:          UPLOAD_PERIOD,
		TimerInterval:         60,
		ConnectTimeout:        500,
		MaxIdleConns:          100,
		ResponseHeaderTimeout: 1000,
		RequestTotalTimeout:   2000,
	}
	HostUploadCfg = &HostUploadConfig{
		ServiceCode: HOST_SERVICE_CODE,
		Enable:      false,
	}
	VMUploadCfg = &VMUploadConfig{
		ServiceCode: VM_SERVICE_CODE,
		Enable:      false,
	}
	CntrUploadCfg = &CntrUploadConfig{
		ServiceCode: CNTR_SERVICE_CODE,
		Enable:      false,
	}
	NcUploadCfg = &NcUploadConfig{
		ServiceCode: JKS_NC_SERVICE_CODE,
		Enable:      false,
	}
	PodUploadCfg = &PodUploadConfig{
		ServiceCode: JKS_POD_SERVICE_CODE,
		Enable:      false,
	}
	XagentCfg = &config.XAgentConfig{
		TimerInterval:         60,
		ConnectTimeout:        500,
		MaxIdleConns:          100,
		ResponseHeaderTimeout: 5000,
		RequestTotalTimeout:   10000,
	}
}

func InitConfig(configPath *string) (*Config, error) {

	conf := &Config{
		DefaultConfig:     DefaultCfg,
		LogConfig:         LogCfg,
		HttpServerConfig:  HttpServerCfg,
		IaasMonitorConfig: IaasMonitorCfg,
	}

	if err := ParserCfg(configPath); err != nil {
		fmt.Printf("Parser config file failed. Error: %#v.\n", err)
		return nil, err
	}
	return conf, nil
}
func ParserCfg(cfgFile *string) error {
	if cfgFile == nil {
		fmt.Printf("The config file is empty.\n")
		return errors.New("The config file is empty.")
	}

	file, err := ini.Load(*cfgFile)
	if err != nil {
		fmt.Printf("Invoke ini.Load failed. Error: %#v.\n", err)
		return err
	}

	if err := file.Section(DefaultSection).MapTo(DefaultCfg); err != nil {
		fmt.Printf("Invoke MapTo DefaultCfg failed. Error: %#v.\n", err)
		return err
	}
	if err := validate.Validate(DefaultCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate DefaultSession failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("DefaultCfg: %#v.\n", DefaultCfg)

	if err := file.Section(JvirtJcsApiSection).MapTo(JvirtJcsApiCfg); err != nil {
		fmt.Printf("Invoke MapTo JvirtJcsApiCfg failed. Error: %#v.\n", err)
		return err
	}
	if err := validate.Validate(JvirtJcsApiCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate JvirtJcsApiSection failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("JvirtJcsApiSection: %#v.\n", JvirtJcsApiCfg)

	if err := file.Section(JvirtRmsApiSection).MapTo(JvirtRmsApiCfg); err != nil {
		fmt.Printf("Invoke MapTo JvirtRmsApiCfg failed. Error: %#v.\n", err)
		return err
	}
	if err := validate.Validate(JvirtRmsApiCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate JvirtRmsApiSection failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("JvirtRmsApiSection: %#v.\n", JvirtRmsApiCfg)

	if err := file.Section(HttpServerSection).MapTo(HttpServerCfg); err != nil {
		fmt.Printf("Invoke MapTo HttpServerCfg failed. Error: %#v.\n", err)
		return err
	}
	if err := validate.Validate(HttpServerCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate HttpServerSection failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("HttpServerSection: %#v.\n", HttpServerCfg)

	if err := file.Section(LogSection).MapTo(LogCfg); err != nil {
		fmt.Printf("Invoke MapTo LogCfg failed. Error: %#v.\n", err)
		return err
	}
	if err := validate.Validate(LogCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate LogSection failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("LogCfg: %#v.\n", LogCfg)

	if err := file.Section(IaasMonitorSection).MapTo(IaasMonitorCfg); err != nil {
		fmt.Printf("Invoke MapTo IaasMonitorCfg failed. Error: %#v.\n", err)
		return err
	}
	if err := validate.Validate(IaasMonitorCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate IaasMonitorSection failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("IaasMonitorCfg: %#v.\n", IaasMonitorCfg)

	if err := file.Section(HostUploadSection).MapTo(HostUploadCfg); err != nil {
		fmt.Printf("Invoke MapTo HostUploadCfg failed. Error: %#v.\n", err)
		return err
	}
	if err := validate.Validate(HostUploadCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate LogSection failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("HostUploadCfg: %#v.\n", HostUploadCfg)

	if err := file.Section(VMUploadSection).MapTo(VMUploadCfg); err != nil {
		fmt.Printf("Invoke MapTo VMUploadCfg failed. Error: %#v.\n", err)
		return err
	}
	if err := validate.Validate(VMUploadCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate VMUploadSection failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("VMUploadCfg: %#v.\n", VMUploadCfg)

	if err := file.Section(CntrUploadSection).MapTo(CntrUploadCfg); err != nil {
		fmt.Printf("Invoke MapTo CntrUploadCfg failed. Error: %#v.\n", err)
		return err
	}
	if err := validate.Validate(CntrUploadCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate CntrUploadSection failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("CntrUploadCfg: %#v.\n", CntrUploadCfg)

	//if err := file.Section(HyperUploadSection).MapTo(HyperUploadCfg); err != nil {
	//	fmt.Printf("Invoke MapTo CntrUploadCfg failed. Error: %#v.\n", err)
	//	return err
	//}
	//if err := validate.Validate(HyperUploadCfg); err != nil {
	//	fmt.Fprintf(os.Stderr, "Validate HyperUploadCfg failed. Error: %v.\n", err.Error())
	//	return err
	//}
	//fmt.Printf("HyperUploadCfg: %#v.\n", HyperUploadCfg)

	if err := file.Section(NcUploadSection).MapTo(NcUploadCfg); err != nil {
		fmt.Printf("Invoke MapTo CntrUploadCfg failed. Error: %#v.\n", err)
		return err
	}
	if err := validate.Validate(NcUploadCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate NcUploadCfg failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("NcUploadCfg: %#v.\n", NcUploadCfg)

	if err := file.Section(PodUploadSection).MapTo(PodUploadCfg); err != nil {
		fmt.Printf("Invoke MapTo PodUploadCfg failed. Error: %#v.\n", err)
		return err
	}
	if err := validate.Validate(PodUploadCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate PodUploadCfg failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("PodUploadCfg: %#v.\n", PodUploadCfg)

	if err := file.Section(XagentSection).MapTo(XagentCfg); err != nil {
		fmt.Printf("Invoke MapTo XagentCfg failed. Error: %#v.\n", err)
		return err
	}
	if err := validate.Validate(XagentCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate XagentCfg failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("XagentCfg: %#v.\n", XagentCfg)

	return nil
}
