package cfg

import "testing"

func TestParserCfg(t *testing.T) {
	cfgFile := "/home/succ/Gopath/src/jd.com/jvirt/jvirt-jcs-eye/etc/jcs/jcs-eye.conf"

	if err := ParserCfg(&cfgFile); err != nil {
		t.Error(err.Error())
	}
}
