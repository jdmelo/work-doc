package rmsapi

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	"net"
	"net/http"
	"strings"
	"time"

	"jd.com/jvirt/jvirt-common/utils"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jcs-eye/cfg"
)

var (
	MAX_IDLE_CONNS          int = 100
	IDLE_CONNS_TIMEOUT      int = 60
	CONNECT_TIMEOUT         int = 10000
	RESPONSE_HEADER_TIMEOUT int = 10000
	REQUEST_TOTAL_TIMEOUT   int = 20000
)

const DescribeHost = "DescribeHost"

type RmsApiClient struct {
	Url    string
	Client *http.Client
	log    log.Logger
}

func NewRmsApiClient(log log.Logger) *RmsApiClient {
	c := &RmsApiClient{
		Url: cfg.JvirtRmsApiCfg.Url,
		log: log,
	}

	connTimeout := time.Duration(utils.IntValue(CONNECT_TIMEOUT, cfg.JvirtRmsApiCfg.ConnectTimeout)) * time.Millisecond

	tr := &http.Transport{
		// 单个url的最大空闲连接数.
		MaxIdleConnsPerHost: utils.IntValue(MAX_IDLE_CONNS, cfg.JvirtRmsApiCfg.MaxIdleConns),
		// 最大的空闲连接数.
		MaxIdleConns: utils.IntValue(MAX_IDLE_CONNS, cfg.JvirtRmsApiCfg.MaxIdleConns),
		// 单位：秒，连接的最大空闲时间.
		IdleConnTimeout: time.Duration(utils.IntValue(IDLE_CONNS_TIMEOUT, cfg.JvirtRmsApiCfg.TimerInterval)) * time.Second,
		// 单位：毫秒，响应包头的最大超时时间
		ResponseHeaderTimeout: time.Duration(utils.IntValue(RESPONSE_HEADER_TIMEOUT, cfg.JvirtRmsApiCfg.ResponseHeaderTimeout)) * time.Millisecond,
	}

	tr.Proxy = http.ProxyFromEnvironment
	tr.DialContext = (&net.Dialer{
		// 建立连接超时时间.
		Timeout: connTimeout,
	}).DialContext

	c.Client = &http.Client{
		Transport: tr,
		Timeout:   time.Duration(utils.IntValue(REQUEST_TOTAL_TIMEOUT, cfg.JvirtRmsApiCfg.RequestTotalTimeout)) * time.Millisecond,
	}

	return c
}

func (rac *RmsApiClient) DoRequest(method, url string, header map[string]string, params, response interface{}) error {
	requestId := utils.GenerateUuid("req")
	if reqId, ok := header["Request-Id"]; ok && reqId != "" {
		requestId = header["Request-Id"]
	}

	input, err := json.Marshal(params)
	if err != nil {
		rac.log.Error("Marshal json failed. RequestId: %s, Error: %#v.", requestId, err)
		return err
	}
	var req *http.Request
	// adapt to glance  api
	if string(input) == "null" {
		req, err = http.NewRequest(method, url, nil)
	} else {
		req, err = http.NewRequest(method, url, bytes.NewReader(input))
	}

	if err != nil {
		return err
	}

	for key := range header {
		req.Header.Set(key, header[key])
	}
	req.Header.Set("User-Agent", "JvirtClient")
	req.Header.Set("Accept", "application/json")

	//防止body体很大刷屏的情况。
	if strings.Count(string(input), "") < 1000 {
		rac.log.Debug("Call http request start. RequestId: %s, Method: %s, Url: %s, Body: %v, Header: %s.",
			requestId, method, url, string(input), req.Header)
	} else {
		rac.log.Debug("Call http request start. RequestId: %s, Method: %s, Url: %s,  Header: %s.",
			requestId, method, url, req.Header)
	}

	resp, err := rac.Client.Do(req)
	if resp != nil {
		defer resp.Body.Close()
	}
	if err != nil {
		rac.log.Error("Call http request error. RequestId: %s, Error: %s.", requestId, err.Error())
		return err
	}
	body, _ := ioutil.ReadAll(resp.Body)

	if strings.Count(string(body), "") < 1000 {
		rac.log.Debug("Call http request success. RequestId: %s, HttpStatusCode = %d, body= %v",
			requestId, resp.StatusCode, string(body))
	} else {
		rac.log.Debug("Call http request success. RequestId: %s, HttpStatusCode = %d",
			requestId, resp.StatusCode)
	}

	if resp.StatusCode == 404 {
		return errors.New(fmt.Sprintf("ItemNotFound"))
	} else if resp.StatusCode < 200 || resp.StatusCode > 299 {
		return errors.New(fmt.Sprintf("HTTP Error Code: %d", resp.StatusCode))
	}

	if len(body) == 0 {
		return nil
	}
	if response != nil {
		decoder := json.NewDecoder(bytes.NewReader(body))
		decoder.UseNumber()
		err = decoder.Decode(response)
		if err != nil {
			return err
		}
	}

	return nil
}

func (rac *RmsApiClient) CallHttpResponse(url string, action string, param interface{}, result interface{}) error {
	url = url + "?Action=" + action
	response := &CommonResponse{}
	response.Data = result

	header := make(map[string]string)

	if err := rac.DoRequest("POST", url, header, param, response); err != nil {
		return err
	}

	if response.Code != 0 {
		rac.log.Warn("The Http call ResponseCode: %d.", response.Code)
		return errors.New(response.Message + response.Detail)
	}

	return nil
}

func (rac *RmsApiClient) DescribeHost(hostIp string) (*HostDescription, error) {
	hostRequest := DescribeHostRequest{Host: hostIp}
	describedHost := HostDescription{}
	if err := rac.CallHttpResponse(rac.Url, DescribeHost, hostRequest, &describedHost); err != nil {
		return nil, err
	}
	return &describedHost, nil
}
