package rmsapi

type CommonResponse struct {
	Code    int         `json:"code"`
	Message string      `json:"message"`
	Detail  string      `json:"detail"`
	Data    interface{} `json:"data"`
}

type HostDescription struct {
	Name             string  `json:"name"` //turta added for host CRUD ops
	Host             string  `json:"host"` //todo ip format
	Tag              string  `json:"tag"`  //turta added
	Az               string  `json:"az"`
	DataCenter       string  `json:"data_center"`
	Rack             string  `json:"rack"`
	Machine          string  `json:"machine"`
	ServiceType      string  `json:"service_type"`
	Cpus             int     `json:"cpus" validate:"nonzero"`
	Memory           int     `json:"memory" validate:"nonzero"`
	Disk             int     `json:"disk" validate:"nonzero"`
	MemoryReserved   int     `json:"memory_reserved"`
	CpusReserved     int     `json:"cpus_reserved"`
	DiskReserved     int     `json:"disk_reserved"`
	CpuMode          string  `json:"cpu_mode"`
	CpuallocRatio    float64 `json:"cpualloc_ratio"`
	CpusReservedInfo string  `json:"cpus_reserved_info"`
	TotalVCPUs       int     `json:"total_vcpus"`
	TotalMem         int     `json:"total_mem"`
	TotalDisk        int     `json:"total_disk"`
	CpusUsed         int     `json:"cpus_used"`
	MemoryUsed       int     `json:"memory_used"`
	DiskUsed         int     `json:"disk_used"`
	RunVms           int     `json:"run_vms"` //turta added for host CRUD ops
	State            string  `json:"state"`
}

type DescribeHostRequest struct {
	Host string `json:"host" validate:"nonzero"` // host ip
}
