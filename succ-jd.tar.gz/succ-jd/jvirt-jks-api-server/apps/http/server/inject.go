package server

import (
	"errors"
	"reflect"

	"github.com/facebookgo/inject"
	"jd.com/jvirt/jvirt-common/utils/url"
	"jd.com/jvirt/jvirt-jks-api-server/dao"
	"jd.com/jvirt/jvirt-jks-api-server/handler/inner"
	outerContainer "jd.com/jvirt/jvirt-jks-api-server/handler/outer/container"
	outerImageSecret "jd.com/jvirt/jvirt-jks-api-server/handler/outer/imagesecret"
	outerNC "jd.com/jvirt/jvirt-jks-api-server/handler/outer/nc"
	outerPod "jd.com/jvirt/jvirt-jks-api-server/handler/outer/pod"
	outerQuota "jd.com/jvirt/jvirt-jks-api-server/handler/outer/quota"
	outerTask "jd.com/jvirt/jvirt-jks-api-server/handler/outer/task"
	outerTools "jd.com/jvirt/jvirt-jks-api-server/handler/outer/tools"
	"jd.com/jvirt/jvirt-jks-api-server/service/base"
	"jd.com/jvirt/jvirt-jks-api-server/service/container"
	"jd.com/jvirt/jvirt-jks-api-server/service/event"
	"jd.com/jvirt/jvirt-jks-api-server/service/imagesecret"
	"jd.com/jvirt/jvirt-jks-api-server/service/pod"
	"jd.com/jvirt/jvirt-jks-api-server/service/quota"
	"jd.com/jvirt/jvirt-jks-api-server/service/task"
	"jd.com/jvirt/jvirt-jks-api-server/service/tools"
)

var g *inject.Graph

func init() {
	g = &inject.Graph{}
}

func injectDao() {
	InjectObject(&dao.TaskDao{})
	InjectObject(&dao.ConfigInfoDao{})
	InjectObject(&dao.ImageSecretDao{})
	InjectObject(&dao.IdempotencyDao{})
	InjectObject(&dao.EventDao{})
	InjectObject(&dao.QuotaDao{})
	InjectObject(&dao.ContainerDao{})
	InjectObject(&dao.ContainerEnvDao{})
	InjectObject(&dao.ContainerImageDao{})
	InjectObject(&dao.ContainerProbeDao{})
	InjectObject(&dao.ContainerStatusDao{})
	InjectObject(&dao.ContainerSystemDiskDao{})
	InjectObject(&dao.ContainerVolumeMountDao{})
	InjectObject(&dao.PodDao{})
	InjectObject(&dao.PodConditionDao{})
	InjectObject(&dao.PodHostAliasDao{})
	InjectObject(&dao.PodNetworkDao{})
	InjectObject(&dao.PodStatusDao{})
	InjectObject(&dao.PodVolumeDao{})
}

func injectBaseService() {
	InjectObject(&base.AgentService{})
	InjectObject(&base.DBService{})
	InjectObject(&base.RmsService{})
	InjectObject(&base.NetworkService{})
	InjectObject(&base.ImageService{})
	InjectObject(&base.VolumeService{})
	InjectObject(&base.PodCommonService{})
}

func injectService() {
	InjectObject(&container.ContainerService{})
	InjectObject(&imagesecret.ImageSecretService{})
	InjectObject(&pod.PodService{})
	InjectObject(&quota.QuotaService{})
	InjectObject(&task.TaskService{})
	InjectObject(&event.EventService{})
	InjectObject(&tools.ToolsService{})
}

func injectExternalHandler(r *url.Router) {
	containerHandler := &outerContainer.ContainerHandler{}
	containerHandler.Register(r)
	InjectObject(containerHandler)

	imageSecretHandler := &outerImageSecret.ImageSecretHandler{}
	imageSecretHandler.Register(r)
	InjectObject(imageSecretHandler)

	ncHandler := &outerNC.NativeContainerHandler{}
	ncHandler.Register(r)
	InjectObject(ncHandler)

	podHandler := &outerPod.PodHandler{}
	podHandler.Register(r)
	InjectObject(podHandler)

	quotaHandler := &outerQuota.QuotaHandler{}
	quotaHandler.Register(r)
	InjectObject(quotaHandler)

	taskHandler := &outerTask.TaskHandler{}
	taskHandler.Register(r)
	InjectObject(taskHandler)

	toolsHandler := &outerTools.ToolsHandler{}
	toolsHandler.Register(r)
	InjectObject(toolsHandler)
}

func injectInternalHandler(r *url.Router) {
	innerHandler := &inner.InnerHandler{}
	innerHandler.Register(r)
	InjectObject(innerHandler)
}

func InjectObject(obj interface{}) {
	if obj == nil {
		panic(errors.New("service is null"))
	}
	if reflect.TypeOf(obj).Kind() != reflect.Ptr {
		panic(errors.New("service is not point type"))
	}
	g.Provide(
		&inject.Object{Value: obj},
	)
}

func InjectAll(outRouter, inRouter *url.Router) {
	injectDao()
	injectBaseService()
	injectService()
	injectInternalHandler(inRouter)
	injectExternalHandler(outRouter)
}

func PopulateInject() {
	g.Populate()
}
