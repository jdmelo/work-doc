package server

import (
	"context"
	"fmt"
	"net/http"
	"os"
	"time"

	"jd.com/jvirt/jvirt-common/inner/jks/agent"
	rms "jd.com/jvirt/jvirt-common/inner/rms/api-server"
	"jd.com/jvirt/jvirt-common/integration/network"
	"jd.com/jvirt/jvirt-common/integration/registry/v2"
	"jd.com/jvirt/jvirt-common/integration/volume"
	"jd.com/jvirt/jvirt-common/utils/config"
	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/limit"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/server"
	"jd.com/jvirt/jvirt-common/utils/url"
	"jd.com/jvirt/jvirt-jks-api-server/cfg"
	"jd.com/jvirt/jvirt-jks-api-server/em"
	"jd.com/jvirt/jvirt-jks-api-server/em/loglistener"
	"jd.com/jvirt/jvirt-jks-api-server/filter"
	"jd.com/jvirt/jvirt-jks-api-server/workers"
)

type Server struct {
	*server.Server
	done            chan struct{}
	outerPort       int
	outerBasePath   string
	outerHttpServer *http.Server
	outerRouter     *url.Router // 对外访问的router

	innerPort       int
	innerHttpServer *http.Server
	innerBasePath   string
	innerRouter     *url.Router // 对内访问的router

	eventManager  *em.EventManagerService
	contextWorker *workers.ApiContextWorker
}

// 初始化log
func initLogger(c *cfg.LogConfig) (log.Logger, error) {
	logger := log.New()
	file, err := os.OpenFile(c.FilePath, os.O_WRONLY|os.O_APPEND|os.O_CREATE, 0755)
	if err != nil {
		return nil, err
	}
	logger.SetOutput(file)
	log.SetOutput(file)
	logger.SetLevel(c.Level)
	log.SetLevelString(c.Level)
	return logger, nil
}

func initDatabase(databaseConfig *config.Database) (*db.ExtendDB, error) {
	instance := &db.MysqlInstance{Conf: databaseConfig}
	databaseInstance, err := instance.NewMysqlInstance()
	if err != nil {
		return nil, err
	}
	database := db.NewExtendDB(databaseInstance)
	return database, nil
}

func initRouter(l log.Logger) *url.Router {
	httpRouter := url.NewRouter()
	httpRouter.Logger = l
	return httpRouter
}

func initImageClient(l log.Logger) *v2.RegClientV2 {
	return v2.New(l)
}

func initNetworkClient(l log.Logger, c *config.Cc) network.INetWorkClient {
	return network.NewNetworManager(url.NewClient(c.HttpClient(), l), c, l)
}

func initVolumeClient(l log.Logger, c *config.Volume) volume.IVolumeManager {
	return volume.NewDefaultVolumeManager(url.NewClient(c.HttpClient(), l), c, l)
}

func initRMSClient(l log.Logger, c *config.Rms) (rms.ResourceManager, error) {
	return rms.NewRmsClient(url.NewClient(c.HttpClient(), l), l, c)
}

func initJksAgentClient(l log.Logger, c *config.Agent) (agent.IAgentHttpClient, error) {
	return agent.NewAgentHTTPClient(l, url.NewClient(c.HttpClient(), l), c.Port, c.BasePath)
}

func initEventManger(l log.Logger) *em.EventManagerService {
	emService := em.NewEventManager(l)

	instEventListener := loglistener.NewInstanceEventListener(l)
	emService.AddListener(instEventListener)

	depEventListener := loglistener.NewDependenceEventListener(l)
	emService.AddListener(depEventListener)

	return emService
}

func NewServer() (*Server, error) {
	l, err := initLogger(cfg.LogCfg)
	if err != nil {
		return nil, err
	}
	InjectObject(l)

	apiCfg := cfg.ApiCfg

	database, err := initDatabase(cfg.DatabaseCfg)
	if err != nil {
		return nil, err
	}
	InjectObject(database)

	imageClient := initImageClient(l)
	InjectObject(imageClient)

	networkClient := initNetworkClient(l, cfg.NetworkCfg)
	InjectObject(networkClient)

	volumeClient := initVolumeClient(l, cfg.VolumeCfg)
	InjectObject(volumeClient)

	rmsClient, err := initRMSClient(l, cfg.RMSCfg)
	if err != nil {
		return nil, err
	}
	InjectObject(rmsClient)

	agentClient, err := initJksAgentClient(l, cfg.AgentCfg)
	if err != nil {
		return nil, err
	}
	InjectObject(agentClient)

	eventManager := initEventManger(l)
	InjectObject(eventManager)

	apiContextWorker := &workers.ApiContextWorker{}
	InjectObject(apiContextWorker)

	groupLimits := limit.NewLimitGroup()
	InjectObject(groupLimits)

	statsFilter := &filter.StatsFilter{}
	headerFilter := &filter.HeaderCheckFilter{}
	outerParamsFilter := &filter.OuterParamsValidateFilter{}
	rateLimitFilter := filter.NewRequestRateLimitFilter(apiCfg.QPSLimit, apiCfg.UserQPSLimit, apiCfg.GetLogsQPSLimit, apiCfg.GetLogsUserQpsLimit)
	authorizeFilter := &filter.ActionAuthorizeFilter{}
	idempotentFilter := &filter.RequestIdempotentFilter{}
	quotaFilter := &filter.QuotaFilter{}

	InjectObject(statsFilter)
	InjectObject(headerFilter)
	InjectObject(outerParamsFilter)
	InjectObject(rateLimitFilter)
	InjectObject(authorizeFilter)
	InjectObject(idempotentFilter)
	InjectObject(quotaFilter)

	innerRouter := initRouter(l)
	innerRouter.RegisterFilters(innerRouter.InvokerFilter)
	innerHttpServer := &http.Server{
		Addr:         fmt.Sprintf(":%d", apiCfg.InnerPort),
		ReadTimeout:  60 * time.Second,
		WriteTimeout: 60 * time.Second,
	}

	outerRouter := initRouter(l)
	outerRouter.RegisterFilters(statsFilter.TimeConsumeFilter)
	outerRouter.RegisterFilters(headerFilter.Filter)
	outerRouter.RegisterFilters(outerParamsFilter.Filter)
	outerRouter.RegisterFilters(rateLimitFilter.Filter)
	outerRouter.RegisterFilters(authorizeFilter.Filter)
	outerRouter.RegisterFilters(idempotentFilter.Filter)
	outerRouter.RegisterFilters(quotaFilter.Filter)
	outerRouter.RegisterFilters(outerRouter.InvokerFilter)
	outerHttpServer := &http.Server{
		Addr:         fmt.Sprintf(":%d", apiCfg.OuterPort),
		ReadTimeout:  30 * time.Second,  // Recv failure: Connection reset by peer
		WriteTimeout: 120 * time.Second, // Empty reply from server (EOF)
	}

	serv := &Server{
		done:            make(chan struct{}),
		outerPort:       apiCfg.OuterPort,
		outerBasePath:   apiCfg.OuterBasePath,
		outerRouter:     outerRouter,
		outerHttpServer: outerHttpServer,
		innerPort:       apiCfg.InnerPort,
		innerBasePath:   apiCfg.InnerBasePath,
		innerRouter:     innerRouter,
		innerHttpServer: innerHttpServer,
		eventManager:    eventManager,
		contextWorker:   apiContextWorker,
	}

	serv.Server = server.NewServer(serv.doStart, serv.doStop)

	InjectAll(outerRouter, innerRouter)
	PopulateInject()

	return serv, nil
}

func (s *Server) doStart() error {
	s.contextWorker.StartSync(s.Close())

	if err := s.eventManager.Start(); err != nil {
		return err
	}

	var serviceError error
	go func() {
		mux := http.NewServeMux()
		mux.Handle(fmt.Sprintf("/%s", s.innerBasePath), s.innerRouter)
		s.innerHttpServer.Handler = mux
		if err := s.innerHttpServer.ListenAndServe(); err != nil {
			serviceError = err
		}
	}()
	go func() {
		mux := http.NewServeMux()
		mux.Handle(fmt.Sprintf("/%s", s.outerBasePath), s.outerRouter)
		s.outerHttpServer.Handler = mux
		if err := s.outerHttpServer.ListenAndServe(); err != nil {
			serviceError = err
		}
	}()

	time.Sleep(1 * time.Second)

	return serviceError
}

func (s *Server) doStop() {
	if s.eventManager != nil {
		s.eventManager.Stop()
	}

	if s.outerHttpServer != nil {
		ctx, cancel := context.WithCancel(context.Background())
		s.outerHttpServer.Shutdown(ctx)
		cancel()
	}

	if s.innerHttpServer != nil {
		ctx, cancel := context.WithCancel(context.Background())
		s.innerHttpServer.Shutdown(ctx)
		cancel()
	}

	close(s.done)
}
