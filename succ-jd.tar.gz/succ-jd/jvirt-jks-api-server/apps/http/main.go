package main

import (
	"flag"
	"fmt"
	"os"
	"runtime"
	"sync"
	"time"

	comRuntime "jd.com/jvirt/jvirt-common/utils/runtime"
	"jd.com/jvirt/jvirt-common/utils/termination"
	"jd.com/jvirt/jvirt-jks-api-server/apps/http/server"
	"jd.com/jvirt/jvirt-jks-api-server/cfg"
)

const (
	//defaultConfig = "/etc/jks/jks-api-server.conf"
	defaultConfig = "D:/workplace/goproject/src/jd.com/jvirt/jvirt-jks-api-server/cfg/jks-api-server-test.conf"
)

func InitServer() (*server.Server, error) {
	// 1: 参数解析
	var configPath string
	flag.StringVar(&configPath, "config", defaultConfig, "configure file!")
	flag.Usage = func() {
		fmt.Fprintf(os.Stderr, "Usage: %s [-config <file_path>] \n", os.Args[0])
		flag.PrintDefaults()
	}
	flag.Parse()

	// 2：配置文件解析
	if err := cfg.ParseConfig(&configPath); err != nil {
		return nil, err
	}

	// 3. 根据配置文件，设置程序并发.
	runtime.GOMAXPROCS(cfg.DefaultCfg.Core)
	comRuntime.ReallyCrash = cfg.DefaultCfg.Debug

	// 5: start http server.
	return server.NewServer()
}

func main() {
	s, err := InitServer()
	if err != nil {
		fmt.Fprintf(os.Stderr, "create server failed. Err: %s\n", err.Error())
		os.Exit(1)
	}

	wg := &sync.WaitGroup{}
	tn := termination.New(nil, s.Stop, func() {
		fmt.Fprintf(os.Stderr, "%s jks-spi-server stopped.\n", time.Now())
		wg.Done()
	})
	tn.Run(func() error {
		wg.Add(1)
		fmt.Fprintf(os.Stderr, "%s jks-spi-server start.\n", time.Now())
		if err := s.Start(); err != nil {
			fmt.Fprintf(os.Stderr, "%s jks-spi-server start failed. Err: %s", time.Now(), err.Error())
			panic(err)
		}
		wg.Wait()
		return nil
	})
}
