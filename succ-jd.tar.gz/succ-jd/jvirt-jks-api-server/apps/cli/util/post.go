package util

import (
	"jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils"
	"jd.com/jvirt/jvirt-common/utils/url"
)

type Post struct {
	httpClient *url.Client
	url        string
	userId     string
	adminToken string
}

func NewPost(httpClient *url.Client, url, userId, adminToken string) *Post {
	return &Post{httpClient: httpClient, url: url, userId: userId, adminToken: adminToken}
}
func (p *Post) Call(action string, param interface{}) error {

	response := &model.CommonResponse{}
	if err := p.httpClient.Post(p.url+"?Action="+action, p.commonHeader(), param, response); err != nil {
		return err
	}

	if response.Code != 0 {
		return model.NewResError(response.Message, response.Detail)
	}
	return nil
}
func (p *Post) CallResponse(action string, param, response interface{}) error {
	commonResponse := &model.CommonResponse{}
	commonResponse.Data = response
	if err := p.httpClient.Post(p.url+"?Action="+action, p.commonHeader(), param, commonResponse); err != nil {
		return err
	}
	if commonResponse.Code != 0 {
		return model.NewResError(commonResponse.Message, commonResponse.Detail)
	}
	return nil
}

func (p *Post) commonHeader() map[string]string {
	header := make(map[string]string)
	header["Request-Id"] = utils.GenerateUuid("req")
	header["Client-Token"] = utils.GenerateUuid("ct")
	if p.userId != "" {
		header["User-Id"] = p.userId
	}
	if p.adminToken != "" {
		header["Admin-Token"] = p.adminToken
	}
	return header
}
