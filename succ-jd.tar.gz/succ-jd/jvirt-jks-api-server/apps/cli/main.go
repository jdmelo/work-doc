package main

import (
	"os"

	"jd.com/jvirt/jvirt-common/inner/jks/api"
	"jd.com/jvirt/jvirt-common/utils/config"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jks-api-server/apps/cli/command"
)

const (
	bashCompleteFile = "/etc/bash_completion.d/jvirt-jks.bash_complete"
)

func main() {
	logger := log.New()
	logger.SetLevel("info")
	cmd := command.NewJvirtCli()
	cmd.GenBashCompletionFile(bashCompleteFile)
	if command.IsHelp {
		cmd.Execute()
		return
	}

	if command.IsAdmin {
		adminToken := os.Getenv("JVIRT_JKS_ADMIN_TOKEN")
		if adminToken == "" {
			println("ERROR (CommandError): You must provide AdminToken via env[JVIRT_JKS_ADMIN_TOKEN]")
			return
		}
		command.CommonHeader["Admin-Token"] = adminToken
	}

	if command.JksApiUrl == "" {
		jksApiUrl := os.Getenv("JVIRT_JKS_SERVER_URL")
		if jksApiUrl == "" {
			println("ERROR (CommandError): You must provide server_url via --jks-api-url or env[JVIRT_JKS_SERVER_URL]")
			return
		}
		command.JksApiUrl = jksApiUrl
	}

	if command.UserId == "" {
		userId := os.Getenv("JVIRT_USER_ID")
		if userId == "" {
			println("ERROR (CommandError): You must provide user_id via --user-id or env[JVIRT_USER_ID]")
			return
		}
		command.UserId = userId
	}
	command.CommonHeader["User-Id"] = command.UserId

	if command.IsDebug {
		logger.SetLevel("debug")
	}

	c := &config.JksApiConfig{
		Url:                   command.JksApiUrl,
		ConnectTimeout:        5000,
		MaxIdleConns:          100,
		TimerInterval:         60,
		ResponseHeaderTimeout: 10000,
		RequestTotalTimeout:   20000,
	}
	command.JksApiClient = api.NewJksOutApiClient(c, logger)

	cmd.Execute()
}
