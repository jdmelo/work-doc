package command

import (
	"github.com/spf13/cobra"
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	"jd.com/jvirt/jvirt-jks-api-server/apps/cli/util"
)

func DescribePodContainerCommand() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "container-show [OPTIONS] POD_ID CONTAINER_NAME",
		Short: "show pod container detail info",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {
			if len(args) != 2 {
				cmd.Help()
				return
			}

			params := &api.DescribeContainerRequest{
				PodId:         args[0],
				ContainerName: args[1],
			}

			resp, err := JksApiClient.DescribeContainer(CommonHeader, params)
			if err != nil {
				util.FormatJErrorOutput(err)
				return
			}

			if resp == nil || resp.Container == nil {
				util.FormatMessageOutput(">> pod container not found!")
				return
			}
			util.FormatJSonOutput(resp)
		},
	}

	return cmd
}

func GetContainerLogsCommand() *cobra.Command {
	params := &api.GetContainerLogsRequest{}
	cmd := &cobra.Command{
		Use:   "container-logs [OPTIONS] POD_ID CONTAINER_NAME",
		Short: "get pod container logs info",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {
			if len(args) != 2 {
				cmd.Help()
				return
			}

			params.PodId = args[0]
			params.ContainerName = args[1]

			resp, err := JksApiClient.GetContainerLogs(CommonHeader, params)
			if err != nil {
				util.FormatJErrorOutput(err)
				return
			}

			if resp == nil || resp.Content == "" {
				return
			}

			util.FormatMessageOutput(resp.Content)
		},
	}

	cmd.Flags().IntVar(&params.TailLines, "tail-lines", 0, "Number of lines to show from the end of the logs")
	cmd.Flags().IntVar(&params.SinceSeconds, "since-seconds", 0, "Show logs of latest timestamp seconds")
	cmd.Flags().IntVar(&params.LimitBytes, "limit-bytes", 4096, "Number of bytes to show from the end of the logs")
	cmd.Flags().StringVar(&params.StartTime, "start-time", "", "Show logs of Start timestamp, format: RFC3339(2006-01-02T15:04:05Z) or RFC3339Nano(2006-01-02T15:04:05.999999999Z)")
	cmd.Flags().StringVar(&params.EndTime, "end-time", "", "Show logs of End timestamp, format: RFC3339(2006-01-02T15:04:05Z) or RFC3339Nano(2006-01-02T15:04:05.999999999Z)")

	return cmd
}

func NewPodContainerCommand(cmd *cobra.Command) {
	cmd.AddCommand(DescribePodContainerCommand())
	cmd.AddCommand(GetContainerLogsCommand())
}
