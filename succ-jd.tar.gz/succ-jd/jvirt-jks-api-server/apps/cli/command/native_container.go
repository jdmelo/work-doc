package command

import (
	"fmt"

	"github.com/spf13/cobra"
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	"jd.com/jvirt/jvirt-jks-api-server/apps/cli/util"
)

const (
	ncVolume1    = "vol-yxg3qva14d"
	ncVolume2    = "vol-qap5d9cyoq"
	rootVolumeId = "vol-9vg6y1x7sh"
)

func showCreateNCJson() {
	boolFalse := false
	casp := &api.CreateNativeContainerRequest{
		Name:        "cli-test",
		Description: "nc about cli test",
		Hostname:    "hostname",

		Image: "busybox:latest",
		//SecretName: "hami_secret",

		Command: []string{"/bin/sh", "-c"},
		Args:    []string{"i=1; while true; do let i+=1; echo $i; sleep 2; done"},

		TTY:        true,
		WorkingDir: "/home/cli",

		Envs: []*api.EnvSpec{
			{
				Name:  "path",
				Value: "/usr/bin",
			},
		},

		HostAliases: []*api.HostAliasSpec{
			{
				IP:        "127.0.0.1",
				Hostnames: []string{"localhost", "localhost.localdomain"},
			},
		},

		Networks: []*api.NetworkPortSpec{
			{
				VpcId:          "vpc-8dgcoequ4t",
				SubnetId:       "subnet-dr8hq3013o",
				SecurityGroups: []string{"sg-39a4x7nkua"},
				DeviceIndex:    1,
				//FixedIp             :""
				Ipv6AddressCount:    0,
				Ipv6Addresses:       []string{},
				DeleteOnTermination: &boolFalse,
			},
		},

		RootVolume: &api.CloudDiskSpec{
			VolumeId:            rootVolumeId,
			FsType:              "ext4",
			DeleteOnTermination: &boolFalse,
		},

		DataVolumes: []*api.DataVolumeSpec{
			{
				MountPath:           "/mnt/1",
				ReadOnly:            false,
				VolumeId:            ncVolume1,
				FsType:              "xfs",
				DiskFormat:          true,
				DeleteOnTermination: &boolFalse,
			},

			{
				MountPath:           "/mnt/2",
				ReadOnly:            false,
				VolumeId:            ncVolume2,
				FsType:              "ext4",
				DiskFormat:          true,
				DeleteOnTermination: &boolFalse,
			},
		},

		Placement: &api.SchedulerPolicySpec{
			IncludeHosts: []string{},
			ExcludeHosts: []string{},
		},
		InstanceType: "g.n2.medium",
		ServiceCode:  "normal",
		Az:           "az2",
		RuntimeType:  "xagent",
		VpcId:        "vpc-8dgcoequ4t",
	}

	util.FormatJSonOutput(casp)
}

func showRebuildNCJson() {
	req := &api.RebuildNativeContainerRequest{
		ContainerId: "c-12345678",
		Image:       "busybox:latest",
		//SecretName: "hami_secret",
		Command:    []string{"/bin/sh", "-c"},
		Args:       []string{"i=1; while true; do let i+=1; echo $i; sleep 2; done"},
		TTY:        true,
		WorkingDir: "/home/cli",
		Envs: []*api.EnvSpec{
			{
				Name:  "path",
				Value: "/usr/bin",
			},
		},
	}

	util.FormatJSonOutput(req)
}

func showRebuildNCYaml() {
	req := &api.RebuildNativeContainerRequest{
		ContainerId: "c-12345678",
		Image:       "busybox:latest",
		//SecretName: "hami_secret",
		Command:    []string{"/bin/sh", "-c"},
		Args:       []string{"i=1; while true; do let i+=1; echo $i; sleep 2; done"},
		TTY:        true,
		WorkingDir: "/home/cli",
		Envs: []*api.EnvSpec{
			{
				Name:  "path",
				Value: "/usr/bin",
			},
		},
	}

	util.FormatYamlOutput(req)
}

func showCreateNCYaml() {

	boolFalse := false
	casp := &api.CreateNativeContainerRequest{
		Name:        "cli-test",
		Description: "nc about cli test",
		Hostname:    "hostname",

		Image: "busybox:latest",
		//SecretName: "hami_secret",

		Command: []string{"/bin/sh", "-c"},
		Args:    []string{"i=1; while true; do let i+=1; echo $i; sleep 2; done"},

		TTY:        true,
		WorkingDir: "/home/cli",

		Envs: []*api.EnvSpec{
			{
				Name:  "path",
				Value: "/usr/bin",
			},
		},

		HostAliases: []*api.HostAliasSpec{
			{
				IP:        "127.0.0.1",
				Hostnames: []string{"localhost", "localhost.localdomain"},
			},
		},

		Networks: []*api.NetworkPortSpec{
			{
				VpcId:          "vpc-8dgcoequ4t",
				SubnetId:       "subnet-dr8hq3013o",
				SecurityGroups: []string{"sg-39a4x7nkua"},
				DeviceIndex:    1,
				//FixedIp             :""
				Ipv6AddressCount:    0,
				Ipv6Addresses:       []string{},
				DeleteOnTermination: &boolFalse,
			},
		},

		RootVolume: &api.CloudDiskSpec{
			VolumeId:            rootVolumeId,
			FsType:              "ext4",
			DeleteOnTermination: &boolFalse,
		},

		DataVolumes: []*api.DataVolumeSpec{
			{
				MountPath:           "/mnt/1",
				ReadOnly:            false,
				VolumeId:            ncVolume1,
				FsType:              "xfs",
				DiskFormat:          true,
				DeleteOnTermination: &boolFalse,
			},

			{
				MountPath:           "/mnt/2",
				ReadOnly:            false,
				VolumeId:            ncVolume2,
				FsType:              "ext4",
				DiskFormat:          true,
				DeleteOnTermination: &boolFalse,
			},
		},

		Placement: &api.SchedulerPolicySpec{
			IncludeHosts: []string{},
			ExcludeHosts: []string{},
		},

		InstanceType: "g.n2.medium",
		ServiceCode:  "normal",
		RuntimeType:  "xagent",
		Az:           "az2",
		VpcId:        "vpc-8dgcoequ4t",
	}

	util.FormatYamlOutput(casp)
}

func CreateNcCommand() *cobra.Command {
	var (
		jsonFile    string
		jsonExample bool
		yamlFile    string
		yamlExample bool
	)

	cmd := &cobra.Command{
		Use:   "nc-create [OPTIONS]",
		Short: "create native-container from file json or yaml",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {
			params := new(api.CreateNativeContainerRequest)
			if jsonExample {
				showCreateNCJson()
				return
			}

			if jsonFile != "" {
				util.LoadJsonFile(jsonFile, params)
			}

			if yamlExample {
				showCreateNCYaml()
				return
			}

			if yamlFile != "" {
				util.LoadYamlFile(yamlFile, params)
				//showCreatePodJson()
			}

			if params == nil || params.Name == "" || params.Networks == nil {
				cmd.Help()
				return
			}

			if params.Networks[0].VpcId == "" {
				params.Networks[0].VpcId = params.VpcId
			}

			res, err := JksApiClient.CreateNativeContainer(CommonHeader, params)
			if err != nil {
				util.FormatJErrorOutput(err)
				return
			}

			if res == nil {
				util.FormatErrorOutput(fmt.Errorf(">> return nc is nil"))
				return
			}

			result := api.NativeContainerView{
				ContainerId: res.ContainerId,
			}
			util.FormatViewOutput(result)
		},
	}

	cmd.Flags().StringVar(&jsonFile, "json-file", "", "create nc json file path")
	cmd.Flags().BoolVar(&jsonExample, "json-file-example", false, "a json file example about create nc, (type:bool, default false)")

	cmd.Flags().StringVar(&yamlFile, "yaml-file", "", "create nc yaml file path")
	cmd.Flags().BoolVar(&yamlExample, "yaml-file-example", false, "a yaml file example about create nc, (type:bool, default false)")

	return cmd
}

func RebuildNcCommand() *cobra.Command {
	var (
		jsonFile    string
		jsonExample bool
		yamlFile    string
		yamlExample bool
	)

	cmd := &cobra.Command{
		Use:   "nc-rebuild [OPTIONS]",
		Short: "rebuild native-container from file json or yaml",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {
			var params *api.RebuildNativeContainerRequest

			if jsonExample {
				showRebuildNCJson()
				return
			}

			if !jsonExample && yamlExample {
				showRebuildNCYaml()
				return
			}

			if jsonFile != "" {
				params = new(api.RebuildNativeContainerRequest)
				util.LoadJsonFile(jsonFile, params)
			}

			if jsonFile == "" && yamlFile != "" {
				params = new(api.RebuildNativeContainerRequest)
				util.LoadYamlFile(yamlFile, params)
			}

			if params == nil {
				cmd.Help()
				return
			}

			if err := JksApiClient.RebuildNativeContainer(CommonHeader, params); err != nil {
				util.FormatJErrorOutput(err)
				return
			}
			util.FormatMessageOutput(">> rebuild native-container success!")
		},
	}

	cmd.Flags().StringVar(&jsonFile, "json-file", "", "use json file rebuild nc")
	cmd.Flags().BoolVar(&jsonExample, "json-file-example", false, "a json file example about rebuild nc")
	cmd.Flags().StringVar(&yamlFile, "yaml-file", "", "yse yaml file rebuild nc")
	cmd.Flags().BoolVar(&yamlExample, "yaml-file-example", false, "a yaml file example about rebuild nc")

	return cmd
}

func StartNcCommand() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "nc-start [OPTIONS] NC_ID",
		Short: "start native-container",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {
			if len(args) != 1 {
				cmd.Help()
				return
			}

			params := &api.StartNativeContainerRequest{
				ContainerId: args[0],
			}

			if err := JksApiClient.StartNativeContainer(CommonHeader, params); err != nil {
				util.FormatJErrorOutput(err)
				return
			}
			util.FormatMessageOutput(">> start native-container success!")
		},
	}

	return cmd
}

func StopNcCommand() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "nc-stop [OPTIONS] NC_ID",
		Short: "stop native-container",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {
			if len(args) != 1 {
				cmd.Help()
				return
			}

			params := &api.StopNativeContainerRequest{
				ContainerId: args[0],
			}

			if err := JksApiClient.StopNativeContainer(CommonHeader, params); err != nil {
				util.FormatJErrorOutput(err)
				return
			}
			util.FormatMessageOutput(">> stop native-container success!")
		},
	}

	return cmd
}

func UpdateNcCommand() *cobra.Command {
	name := new(string)
	description := new(string)

	cmd := &cobra.Command{
		Use:   "nc-update [OPTIONS] NC_ID",
		Short: "modify native-container info",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {
			if len(args) != 1 {
				cmd.Help()
				return
			}

			params := &api.UpdateNativeContainerRequest{
				ContainerId: args[0],
			}
			if name != nil && *name != "" {
				params.Name = name
			}
			if description != nil && *description != "" {
				params.Description = description
			}

			if err := JksApiClient.UpdateNativeContainer(CommonHeader, params); err != nil {
				util.FormatJErrorOutput(err)
				return
			}
			util.FormatMessageOutput(">> update native-container success!")
		},
	}

	cmd.Flags().StringVar(name, "name", "", "modify native-container name")
	cmd.Flags().StringVar(description, "description", "", "modify native-container description info")

	return cmd
}

func DeleteNcCommand() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "nc-delete [OPTIONS] NC_ID",
		Short: "delete native-container",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {
			if len(args) != 1 {
				cmd.Help()
				return
			}

			params := &api.DeleteNativeContainerRequest{
				ContainerId: args[0],
			}

			if err := JksApiClient.DeleteNativeContainer(CommonHeader, params); err != nil {
				util.FormatJErrorOutput(err)
				return
			}
			util.FormatMessageOutput(">> delete native-container success!")
		},
	}

	return cmd
}

func MigrateNcCommand() *cobra.Command {
	var (
		includeHosts  []string
		excludeHosts  []string
		resourceHints []string
	)

	cmd := &cobra.Command{
		Use:   "nc-migrate [OPTIONS] NC_ID",
		Short: "migrate native-container from source host to target host, must be admin permissions",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {
			if len(args) != 1 {
				cmd.Help()
				return
			}

			if !IsAdmin {
				util.FormatMessageOutput("nc-migrate must be admin permissions")
				return
			}

			params := &api.MigrateNativeContainerRequest{
				ContainerId: args[0],
				SchedulerPolicy: &api.SchedulerPolicySpec{
					IncludeHosts:  includeHosts,
					ExcludeHosts:  excludeHosts,
					ResourceHints: resourceHints,
				},
			}

			if err := JksApiClient.MigrateNativeContainer(CommonHeader, params); err != nil {
				util.FormatJErrorOutput(err)
				return
			}
			util.FormatMessageOutput(">> migrate native-container success!")
		},
	}
	cmd.Flags().StringArrayVar(&includeHosts, "include-hosts", nil, "include hosts")
	cmd.Flags().StringArrayVar(&excludeHosts, "exclude-hosts", nil, "exclude hosts")
	cmd.Flags().StringArrayVar(&resourceHints, "tags", nil, "host tag")

	return cmd
}

func ListNCsCommand() *cobra.Command {
	var (
		page           int
		pageSize       int
		name           string
		userPin        string
		fixIp          string
		ncIds          []string
		ncStatus       []string
		azs            []string
		hostIps        []string
		vpcIds         []string
		subnetIds      []string
		portIds        []string
		serviceCodes   []string
		securityGroups []string
	)

	cmd := &cobra.Command{
		Use:   "nc-list [OPTIONS]",
		Short: "list native containers simple info",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {

			filters := &api.DescribeNativeContainerFilterSpec{
				ContainerId:     ncIds,
				ContainerStatus: ncStatus,
				Az:              azs,
				UserPin:         userPin,
				HostIp:          hostIps,
				VpcId:           vpcIds,
				SubnetId:        subnetIds,
				PortId:          portIds,
				ServiceCode:     serviceCodes,
				SecurityGroups:  securityGroups,
			}
			if name != "" {
				filters.Name = []string{name}
			}
			if fixIp != "" {
				filters.FixIp = []string{fixIp}
			}

			params := &api.DescribeNativeContainersRequest{
				Filters:    filters,
				DescOffset: page,
				DescLimit:  pageSize,
			}
			resp, err := JksApiClient.DescribeNativeContainers(CommonHeader, params)
			if err != nil {
				util.FormatJErrorOutput(err)
				return
			}
			if resp == nil || resp.Containers == nil {
				return
			}

			label := []string{"ContainerId", "Status", "Name", "Az", "HostIp", "InstanceType", "Image", "LaunchTime"}
			util.FormatListOutput(label, resp.Containers)
			total := Total{TotalCount: resp.TotalCount, RealCount: len(resp.Containers)}
			util.FormatViewOutput(total)
		},
	}
	cmd.Flags().IntVar(&page, "page", 0, "page")
	cmd.Flags().IntVar(&pageSize, "page-size", 100, "page size")

	cmd.Flags().StringVar(&name, "name", "", "nc name, fuzzy query")
	cmd.Flags().StringVar(&userPin, "pin", "", "user pin, fuzzy query")
	cmd.Flags().StringVar(&fixIp, "fix-ip", "", "nc fixip, fuzzy query")
	cmd.Flags().StringArrayVar(&ncIds, "nc-id", nil, "nc id")
	cmd.Flags().StringArrayVar(&ncStatus, "status", nil, "nc status")
	cmd.Flags().StringArrayVar(&azs, "az", nil, "availability zone ")
	cmd.Flags().StringArrayVar(&hostIps, "host-ip", nil, "host ip")
	cmd.Flags().StringArrayVar(&vpcIds, "vpc-id", nil, "vpc id")
	cmd.Flags().StringArrayVar(&subnetIds, "subnet-id", nil, "subnet id")
	cmd.Flags().StringArrayVar(&portIds, "port-id", nil, "port id")
	cmd.Flags().StringArrayVar(&serviceCodes, "service-code", nil, "service code")
	cmd.Flags().StringArrayVar(&securityGroups, "security-groups", nil, "security groups")

	return cmd
}

func DescribeNCCommand() *cobra.Command {

	cmd := &cobra.Command{
		Use:   "nc-show [OPTIONS] NC_ID",
		Short: "show native-container detail info",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {
			if len(args) != 1 {
				cmd.Help()
				return
			}

			filters := &api.DescribeNativeContainerFilterSpec{
				ContainerId: []string{args[0]},
			}

			params := &api.DescribeNativeContainersRequest{
				Filters: filters,
			}
			resp, err := JksApiClient.DescribeNativeContainers(CommonHeader, params)
			if err != nil {
				util.FormatJErrorOutput(err)
				return
			}

			if resp == nil || len(resp.Containers) == 0 {
				util.FormatMessageOutput(">> native-container not found!")
				return
			}

			util.FormatJSonOutput(resp.Containers[0])
		},
	}

	return cmd
}

func GetLogsCommand() *cobra.Command {
	var (
		tailLines    int
		sinceSeconds int
		limitBytes   int
		startTime    string
		endTime      string
	)
	cmd := &cobra.Command{
		Use:   "nc-logs [OPTIONS] NC_ID",
		Short: "get native-container log info",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {
			if len(args) < 1 {
				cmd.Help()
				return
			}

			params := &api.GetNativeContainerLogsRequest{
				ContainerId:  args[0],
				TailLines:    tailLines,
				SinceSeconds: sinceSeconds,
				LimitBytes:   limitBytes,
				StartTime:    startTime,
				EndTime:      endTime,
			}

			resp, err := JksApiClient.GetNativeContainerLogs(CommonHeader, params)
			if err != nil {
				util.FormatJErrorOutput(err)
				return
			}

			if resp == "" {
				return
			}
			util.FormatMessageOutput(resp)
		},
	}

	cmd.Flags().IntVar(&tailLines, "tail-lines", 0, "Number of lines to show from the end of the logs")
	cmd.Flags().IntVar(&sinceSeconds, "since-seconds", 0, "Show logs of latest timestamp seconds")
	cmd.Flags().IntVar(&limitBytes, "limit-bytes", 4096, "Number of bytes to show from the end of the logs")
	cmd.Flags().StringVar(&startTime, "start-time", "", "Show logs of Start timestamp, format: RFC3339(2006-01-02T15:04:05Z) or RFC3339Nano(2006-01-02T15:04:05.999999999Z)")
	cmd.Flags().StringVar(&endTime, "end-time", "", "Show logs of End timestamp, format: RFC3339(2006-01-02T15:04:05Z) or RFC3339Nano(2006-01-02T15:04:05.999999999Z)")

	return cmd
}

func ResizeNCCommand() *cobra.Command {
	var (
		instanceType  string
		includeHosts  []string
		excludeHosts  []string
		resourceHints []string
	)

	params := &api.ResizeNativeContainerRequest{}
	cmd := &cobra.Command{
		Use:   "nc-resize [OPTIONS] NC_ID",
		Short: "resize native-container instance-type",
		Long:  "resize native-container instance-type",
		Run: func(cmd *cobra.Command, args []string) {
			if len(args) < 1 {
				cmd.Help()
				return
			}

			params = &api.ResizeNativeContainerRequest{
				ContainerId:  args[0],
				InstanceType: instanceType,
				SchedulerPolicy: &api.SchedulerPolicySpec{
					IncludeHosts:  includeHosts,
					ExcludeHosts:  excludeHosts,
					ResourceHints: resourceHints,
				},
			}

			if err := JksApiClient.ResizeNativeContainer(CommonHeader, params); err != nil {
				util.FormatJErrorOutput(err)
				return
			}
			util.FormatMessageOutput(">> migrate native-container success!")
		},
	}

	cmd.Flags().StringVar(&instanceType, "instance-type", "", "instance type")
	cmd.Flags().StringArrayVar(&includeHosts, "include-hosts", nil, "include hosts")
	cmd.Flags().StringArrayVar(&excludeHosts, "exclude-hosts", nil, "exclude hosts")
	cmd.Flags().StringArrayVar(&resourceHints, "tags", nil, "host tag")

	return cmd
}

func NewNativeContainerCommand(cmd *cobra.Command) {
	cmd.AddCommand(CreateNcCommand())
	cmd.AddCommand(RebuildNcCommand())
	cmd.AddCommand(MigrateNcCommand())
	cmd.AddCommand(ListNCsCommand())
	cmd.AddCommand(DescribeNCCommand())
	cmd.AddCommand(StartNcCommand())
	cmd.AddCommand(StopNcCommand())
	cmd.AddCommand(DeleteNcCommand())
	cmd.AddCommand(UpdateNcCommand())
	cmd.AddCommand(GetLogsCommand())
	cmd.AddCommand(ResizeNCCommand())
}
