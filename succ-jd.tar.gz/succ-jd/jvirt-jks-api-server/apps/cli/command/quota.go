package command

import (
	"errors"
	"strconv"

	"github.com/spf13/cobra"
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	"jd.com/jvirt/jvirt-jks-api-server/apps/cli/util"
)

func DescribeQuotaCommand() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "quota-show [OPTIONS] RESOURCE_TYPE",
		Short: "show resource quota of user, resource_type: pod, container, secret",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {
			if len(args) != 1 {
				cmd.Help()
				return
			}

			params := &api.DescribeQuotaRequest{
				ResourceType: args[0],
			}

			resp, err := JksApiClient.DescribeQuota(CommonHeader, params)
			if err != nil {
				util.FormatJErrorOutput(err)
				return
			}

			if resp == nil {
				util.FormatMessageOutput(">> quota not found!")
				return
			}
			util.FormatViewOutput(resp)
		},
	}

	return cmd
}

func UpdateQuotaCommand() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "quota-update [OPTIONS] LIMIT RESOURCE_TYPE",
		Short: "modify resource quota limit of user",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {
			if len(args) != 2 {
				cmd.Help()
				return
			}

			//if !IsAdmin {
			//	util.FormatMessageOutput("quota-update must be admin permissions")
			//	return
			//}

			limit, err := strconv.Atoi(args[0])
			if err != nil {
				util.FormatErrorOutput(errors.New("invalid quota limit"))
				return
			}
			if limit <= 0 {
				util.FormatErrorOutput(errors.New("quota limit must be gt 0"))
				return
			}

			resourceType := args[1]
			params := &api.UpdateQuotaRequest{
				ResourceType: resourceType,
				Limit:        limit,
			}

			if err := JksApiClient.UpdateQuota(CommonHeader, params); err != nil {
				util.FormatJErrorOutput(err)
				return
			}
			util.FormatMessageOutput(">> update quota success!")
		},
	}

	return cmd
}

func NewQuotaCommand(cmd *cobra.Command) {
	cmd.AddCommand(DescribeQuotaCommand())
	cmd.AddCommand(UpdateQuotaCommand())
}
