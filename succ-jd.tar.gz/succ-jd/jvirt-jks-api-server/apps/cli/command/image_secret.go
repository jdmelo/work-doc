package command

import (
	"github.com/spf13/cobra"
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	"jd.com/jvirt/jvirt-jks-api-server/apps/cli/util"
)

func CreateImageSecretCommand() *cobra.Command {
	data := &api.DockerRegistryDataSpec{}

	cmd := &cobra.Command{
		Use:   "image-secret-create [OPTIONS] SECRET_NAME",
		Short: "create image secret for user, access internet docker registry",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {
			if len(args) != 1 {
				cmd.Help()
				return
			}

			params := &api.CreateImageSecretRequest{
				Name:               args[0],
				Type:               "docker-registry",
				DockerRegistryData: data,
			}

			if err := JksApiClient.CreateImageSecret(CommonHeader, params); err != nil {
				util.FormatJErrorOutput(err)
				return
			}
			util.FormatMessageOutput(">> create image secret success!")
		},
	}

	cmd.Flags().StringVar(&data.Server, "registry-url", "", "docker registry server url")
	cmd.Flags().StringVar(&data.UserName, "registry-username", "", "docker registry server username")
	cmd.Flags().StringVar(&data.Password, "registry-password", "", "docker registry server password")
	cmd.Flags().StringVar(&data.Email, "registry-email", "", "login docker registry server email")

	return cmd
}

func DeleteImageSecretCommand() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "image-secret-delete [OPTIONS] SECRET_NAME",
		Short: "delete image secret for user",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {
			if len(args) != 1 {
				cmd.Help()
				return
			}

			params := &api.DeleteImageSecretRequest{
				Name: args[0],
			}
			if err := JksApiClient.DeleteImageSecret(CommonHeader, params); err != nil {
				util.FormatJErrorOutput(err)
				return
			}
			util.FormatMessageOutput(">> delete image secret success!")
		},
	}

	return cmd
}

func DescribeImageSecretCommand() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "image-secret-show [OPTIONS] SECRET_NAME",
		Short: "show image secret detail info",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {
			if len(args) != 1 {
				cmd.Help()
				return
			}

			params := &api.DescribeImageSecretRequest{
				Name: args[0],
			}
			resp, err := JksApiClient.DescribeImageSecret(CommonHeader, params)
			if err != nil {
				util.FormatJErrorOutput(err)
				return
			}

			if resp == nil || resp.DockerRegistryData == nil {
				util.FormatMessageOutput(">> image-secret not found!")
				return
			}
			util.FormatViewOutput(resp)
		},
	}

	return cmd
}

func DescribeImageSecretsCommand() *cobra.Command {
	filters := &api.DescribeImageSecretFilterSpec{}
	if len(filters.SecretType) < 1 {
		filters.SecretType = []string{"docker-registry"}
	}

	cmd := &cobra.Command{
		Use:   "image-secret-list [OPTIONS]",
		Short: "list image secrets detail info",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {
			params := &api.DescribeImageSecretsRequest{
				Filters: filters,
			}
			resp, err := JksApiClient.DescribeImageSecrets(CommonHeader, params)
			if err != nil {
				util.FormatErrorOutput(err)
				return
			}

			if resp == nil && len(resp.Secrets) == 0 {
				return
			}

			type imageSecret struct {
				Name        string `json:"name"`
				Type        string `json:"type"`
				UserId      string `json:"user_id"`
				Server      string `json:"server"`
				UserName    string `json:"user_name"`
				Password    string `json:"password"`
				Email       string `json:"email"`
				CreatedTime string `json:"created_time"`
			}

			showList := make([]*imageSecret, 0)
			for _, secret := range resp.Secrets {
				secretInfo := &imageSecret{
					Name:        secret.Name,
					Type:        secret.Type,
					UserId:      secret.UserId,
					Server:      secret.DockerRegistryData.Server,
					UserName:    secret.DockerRegistryData.UserName,
					Password:    secret.DockerRegistryData.Password,
					Email:       secret.DockerRegistryData.Email,
					CreatedTime: secret.CreatedTime,
				}
				showList = append(showList, secretInfo)
			}

			//显示
			label := []string{
				"Name",
				"Type",
				"Server",
				"UserName",
				"CreatedTime",
			}

			util.FormatListOutput(label, showList)
			total := Total{TotalCount: resp.TotalCount, RealCount: len(showList)}
			util.FormatViewOutput(total)
		},
	}
	cmd.Flags().StringArrayVar(&filters.Name, "name", nil, "image secret name")
	cmd.Flags().StringArrayVar(&filters.SecretType, "type", nil, "image secret type")

	return cmd
}

func NewImageSecretCommand(cmd *cobra.Command) {
	cmd.AddCommand(CreateImageSecretCommand())
	cmd.AddCommand(DeleteImageSecretCommand())
	cmd.AddCommand(DescribeImageSecretCommand())
	cmd.AddCommand(DescribeImageSecretsCommand())
}
