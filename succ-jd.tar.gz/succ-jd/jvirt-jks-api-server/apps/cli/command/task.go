package command

import (
	"errors"
	"strconv"

	"github.com/spf13/cobra"
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	"jd.com/jvirt/jvirt-jks-api-server/apps/cli/util"
)

func ListTaskCommand() *cobra.Command {
	var pageSize int
	var page int
	filters := &api.DescribeTasksFilterSpec{}

	cmd := &cobra.Command{
		Use:   "task-list [OPTIONS]",
		Short: "list native-container or pod tasks according to the condition",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {
			params := &api.DescribeTasksRequest{
				Filters:    filters,
				DescOffset: page,
				DescLimit:  pageSize,
			}

			resp, err := JksApiClient.DescribeTasks(CommonHeader, params)
			if err != nil {
				util.FormatJErrorOutput(err)
				return
			}

			if resp == nil || resp.Items == nil {
				return
			}

			label := []string{
				"task_id",
				"refer_id",
				"task_type",
				"task_state",
				"request_id",
				"host_ip",
				"task_before",
				"task_after",
				"created_time",
				"elapsed_time",
			}
			util.FormatListOutput(label, resp.Items)
			total := Total{TotalCount: resp.TotalCount, RealCount: len(resp.Items)}
			util.FormatViewOutput(total)
		},
	}

	cmd.Flags().IntVar(&page, "page", 0, "describe offset, query start index")
	cmd.Flags().IntVar(&pageSize, "page-size", 100, "describe limit,max list number, 0: not limit")

	cmd.Flags().Int64Var(&filters.TaskId, "task-id", 0, "task id")
	cmd.Flags().StringVar(&filters.InstanceId, "instance-id", "", "the id of nc or pod")
	cmd.Flags().StringVar(&filters.TaskState, "task-state", "", "pending, running, finished, failed")
	cmd.Flags().StringVar(&filters.TaskType, "task-type", "", "PodCreateTask, PodDeleteTask, PodStartTask, PodStopTask, PodMigrateTask")
	cmd.Flags().StringVar(&filters.HostIp, "host-ip", "", "the host ip of task")
	return cmd
}

func TaskShowCommand() *cobra.Command {
	var pageSize int
	var page int

	cmd := &cobra.Command{
		Use:   "task-show [OPTIONS] INSTANCE_ID",
		Short: "show all task list of a instance (nc or pod)",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {
			if len(args) != 1 {
				cmd.Help()
				return
			}

			params := &api.DescribeTasksRequest{
				Filters: &api.DescribeTasksFilterSpec{
					InstanceId: args[0],
				},
				DescOffset: page,
				DescLimit:  pageSize,
			}

			resp, err := JksApiClient.DescribeTasks(CommonHeader, params)
			if err != nil {
				util.FormatJErrorOutput(err)
				return
			}

			if resp == nil || resp.Items == nil {
				return
			}

			label := []string{
				"task_id",
				"refer_id",
				"task_type",
				"task_state",
				"request_id",
				"host_ip",
				"task_before",
				"task_after",
				"created_time",
				"elapsed_time",
			}
			util.FormatListOutput(label, resp.Items)
			total := Total{TotalCount: resp.TotalCount, RealCount: len(resp.Items)}
			util.FormatViewOutput(total)
		},
	}

	cmd.Flags().IntVar(&page, "page", 0, "describe offset, query start index")
	cmd.Flags().IntVar(&pageSize, "page-size", 100, "describe limit,max list number, 0: not limit")

	return cmd
}

func ResetTaskCommand() *cobra.Command {
	var (
		taskState  string
		taskBefore int
		taskAfter  int
	)

	cmd := &cobra.Command{
		Use:   "task-reset [OPTIONS] TASK_ID",
		Short: "reset task state, must be admin permissions",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {
			if len(args) != 1 {
				cmd.Help()
				return
			}

			if !IsAdmin {
				util.FormatMessageOutput("reset-task must be admin permissions")
				return
			}

			taskId, err := strconv.Atoi(args[0])
			if err != nil {
				util.FormatErrorOutput(errors.New("invalid task id"))
				return
			}
			if taskId == 0 {
				util.FormatErrorOutput(errors.New("task id is not 0"))
				return
			}

			params := &api.ResetTaskRequest{
				TaskId:    int64(taskId),
				TaskState: taskState,
			}
			if taskBefore == -1 {
				params.TaskBefore = nil
			} else {
				params.TaskBefore = &taskBefore
			}
			if taskBefore == -1 {
				params.TaskAfter = nil
			} else {
				params.TaskAfter = &taskAfter
			}

			if err := JksApiClient.ResetTask(CommonHeader, params); err != nil {
				util.FormatJErrorOutput(err)
				return
			}
			util.FormatMessageOutput(">> reset task success!")
		},
	}

	cmd.Flags().IntVar(&taskBefore, "task-before", -1, "\"1\" represent undo, \"2\" represent done")
	cmd.Flags().IntVar(&taskAfter, "task-after", -1, "\"1\" represent undo, \"2\" represent done")
	cmd.Flags().StringVar(&taskState, "task-state", "", "Force reset status. Be careful to use. eg: failed, finished, running, pending")
	return cmd
}

func NewTaskCommand(cmd *cobra.Command) {
	cmd.AddCommand(ListTaskCommand())
	cmd.AddCommand(TaskShowCommand())
	cmd.AddCommand(ResetTaskCommand())
}
