package command

import (
	"os"
	"strings"

	"github.com/spf13/cobra"
	"jd.com/jvirt/jvirt-common/inner/jks/api"
)

var (
	JksApiUrl    string
	UserId       string
	IsAdmin      bool
	IsDebug      bool
	IsHelp       bool
	JksApiClient *api.JksOutApiClient
)

var CommonHeader = map[string]string{}

//func CopyCommonHeader() map[string]string {
//	ret := make(map[string]string)
//	for k, v := range CommonHeader {
//		ret[k] = v
//	}
//
//	return ret
//}

func NewJvirtCli() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "jvirt-jks [OPTIONS] COMMAND [arg...]",
		Short: "A self-sufficient runtime for jks system",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {
			if len(args) < 1 {
				cmd.Help()
				return
			}
		},
	}
	cmd.PersistentFlags().StringVar(&JksApiUrl, "jks-api-url", "", "URL of jvirt-jks-api")
	cmd.PersistentFlags().StringVar(&UserId, "user-id", "", "jvirt user id")
	cmd.PersistentFlags().BoolVarP(&IsHelp, "help", "h", false, "Print help info")
	cmd.PersistentFlags().BoolVarP(&IsDebug, "debug", "v", false, "Print request detailed info")
	cmd.PersistentFlags().BoolVarP(&IsAdmin, "admin", "a", false, "Whether to enable Admin Permissions")

	al := len(os.Args)
	for i := 0; i < al; i++ {
		switch os.Args[i] {
		case "--help", "-h":
			IsHelp = true
		case "--debug", "-v":
			IsDebug = true
		case "--admin", "-a":
			IsAdmin = true
		}

		if strings.HasPrefix(os.Args[i], "--jks-api-url") {
			strs := strings.SplitN(os.Args[i], "=", 2)
			if len(strs) == 2 {
				JksApiUrl = strs[1]
			} else {
				if i < al-1 {
					JksApiUrl = os.Args[i+1]
					i++
				}
			}
		}

		if strings.HasPrefix(os.Args[i], "--user-id") {
			strs := strings.SplitN(os.Args[i], "=", 2)
			if len(strs) == 2 {
				UserId = strs[1]
			} else {
				if i < al-1 {
					UserId = os.Args[i+1]
					i++
				}
			}
		}
	}

	NewTaskCommand(cmd)
	NewQuotaCommand(cmd)
	NewImageSecretCommand(cmd)
	NewPodContainerCommand(cmd)
	NewPodCommand(cmd)
	NewNativeContainerCommand(cmd)
	NewToolsCommand(cmd)

	return cmd
}
