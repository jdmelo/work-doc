package command

import (
	"fmt"
	"github.com/spf13/cobra"
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	"jd.com/jvirt/jvirt-jks-api-server/apps/cli/util"
)

func CheckImageCmd() *cobra.Command {
	var secret string
	cmd := &cobra.Command{
		Use:   "check-image [OPTIONS] image",
		Short: "Check the image format and whether the image exists in the image registry",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {
			if len(args) < 1 {
				cmd.Help()
				return
			}

			param := &api.CheckImageRequest{
				Image:  args[0],
				Secret: secret,
			}
			if err := JksApiClient.CheckImage(CommonHeader, param); err != nil {
				util.FormatJErrorOutput(err)
				return
			}

			util.FormatMessageOutput(fmt.Sprintf(">> check image pass! %s", args[0]))
		},
	}
	cmd.Flags().StringVar(&secret, "secret", "", "the secret of image")

	return cmd
}

func NewToolsCommand(cmd *cobra.Command) {
	cmd.AddCommand(CheckImageCmd())
}
