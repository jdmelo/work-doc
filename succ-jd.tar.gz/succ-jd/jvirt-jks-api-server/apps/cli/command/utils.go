package command

type Total struct {
	TotalCount int
	RealCount  int
}
