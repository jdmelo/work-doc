package command

import (
	"fmt"

	"github.com/spf13/cobra"
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	"jd.com/jvirt/jvirt-common/utils"
	"jd.com/jvirt/jvirt-jks-api-server/apps/cli/util"
)

const (
	podVolume1          = "vol-mdifcimi0o"
	podVolume2          = "vol-ajdj7m6s8g"
	Container1SysVolume = "vol-o3u6lzifnl"
	Container2SysVolume = "vol-7juthcawru"
)

func showCreatePodJson() {

	defaultInt3 := 3
	defaultInt10 := 10
	defaultInt300 := 300
	defaultTrue := true
	defaultFalse := false
	cpu200 := 200
	cpu100 := 100
	mem128 := 128
	mem64 := 64

	container1 := &api.ContainerSpec{
		Name:    "container1",
		Command: []string{"/bin/sh", "-c"},
		Args:    []string{"i=1; while true; do echo`date` >> /tmp/logs; sleep 2; done"},
		Env: []*api.EnvSpec{
			{
				Name:  "sbin",
				Value: "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
			},
		},

		Image: "http://pod-test-cn-ite-1.jcr.service.jdcloud.com/pod-test:latest",
		//Secret:"",
		TTY:        &defaultTrue,
		WorkingDir: "/home/cli/container1",
		LivenessProbe: &api.ProbeSpec{
			InitialDelaySeconds: &defaultInt3,
			FailureThreshold:    &defaultInt3,
			SuccessThreshold:    &defaultInt3,
			PeriodSeconds:       &defaultInt10,
			TimeoutSeconds:      &defaultInt300,
			Exec: &api.ExecActionSpec{
				Command: []string{"ls", "/"},
			},
		},

		ReadinessProbe: &api.ProbeSpec{
			InitialDelaySeconds: &defaultInt3,
			FailureThreshold:    &defaultInt3,
			SuccessThreshold:    &defaultInt3,
			PeriodSeconds:       &defaultInt10,
			TimeoutSeconds:      &defaultInt300,
			Exec: &api.ExecActionSpec{
				Command: []string{"ls", "/root"},
			},
		},

		Resources: &api.ResourceRequestsSpec{
			Limits: &api.ResourceSpec{
				CPU:      &cpu200,
				MemoryMB: &mem128,
			},

			Requests: &api.ResourceSpec{
				CPU:      &cpu100,
				MemoryMB: &mem64,
			},
		},

		SystemDisk: &api.CloudDiskSpec{
			VolumeId:            Container1SysVolume,
			FsType:              "xfs",
			DeleteOnTermination: &defaultFalse,
		},

		VolumeMounts: []*api.VolumeMountSpec{
			{
				Name:      "v-volume1",
				MountPath: "/mnt/1",
				ReadOnly:  &defaultFalse,
			},
			{
				Name:      "v-volume1",
				MountPath: "/mnt/2",
				ReadOnly:  &defaultFalse,
			},
			{
				Name:      "v-volume2",
				MountPath: "/mnt/3",
				ReadOnly:  &defaultFalse,
			},
		},
	}

	container2 := &api.ContainerSpec{
		Name:    "container2",
		Command: []string{"/bin/sh", "-c"},
		Args:    []string{"i=1; while true; do let i+=1; echo $i; sleep 2; done"},

		Env: []*api.EnvSpec{
			{
				Name:  "sbin",
				Value: "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
			},
		},

		Image: "httpd:latest",
		//Secret:     "hami_secret",
		TTY:        &defaultFalse,
		WorkingDir: "/home/cli/container2",

		LivenessProbe: &api.ProbeSpec{
			InitialDelaySeconds: &defaultInt3,
			FailureThreshold:    &defaultInt10,
			SuccessThreshold:    &defaultInt10,
			PeriodSeconds:       &defaultInt10,
			TimeoutSeconds:      &defaultInt300,

			Exec: &api.ExecActionSpec{
				Command: []string{"ls", "/root"},
			},

			//TCPSocket    :&api.TCPSocketActionSpec{
			//	            Port :1,
			//},

			//HTTPGet: &api.HTTPGetActionSpec{
			//	Scheme: "https",
			//	Host:   "127.0.0.1",
			//	Port:   65535,
			//	Path:   "http://fanyi.baidu.com/?aldtype=16047#en/zh/abort",
			//	HTTPHeaders: []*api.HTTPHeaderSpec{
			//		{Name: "debug", Value: "169.254.0.0"},
			//		{Name: "debug", Value: "169.254.0.0"},
			//	},
			//},
		},

		ReadinessProbe: &api.ProbeSpec{
			InitialDelaySeconds: &defaultInt3,
			FailureThreshold:    &defaultInt10,
			SuccessThreshold:    &defaultInt10,
			PeriodSeconds:       &defaultInt10,
			TimeoutSeconds:      &defaultInt300,

			//Exec: &api.ExecActionSpec{
			//	Command: []string{"ls", "/root"},
			//},

			//TCPSocket: &api.TCPSocketActionSpec{
			//	Port: 1,
			//},

			HTTPGet: &api.HTTPGetActionSpec{
				Scheme: "http",
				Host:   "127.0.0.1",
				Port:   80,
				Path:   "/",
				HTTPHeaders: []*api.HTTPHeaderSpec{
					{Name: "cache-control", Value: "no-cache"},
					{Name: "Content-Type", Value: "application/json"},
				},
			},
		},

		Resources: &api.ResourceRequestsSpec{
			Limits: &api.ResourceSpec{
				CPU:      &cpu100,
				MemoryMB: &mem64,
			},

			Requests: &api.ResourceSpec{
				CPU:      &cpu100,
				MemoryMB: &mem64,
			},
		},

		SystemDisk: &api.CloudDiskSpec{
			VolumeId:            Container2SysVolume,
			FsType:              "xfs",
			DeleteOnTermination: &defaultFalse,
		},

		VolumeMounts: []*api.VolumeMountSpec{
			{
				Name:      "v-volume1",
				MountPath: "/mnt/1",
				ReadOnly:  &defaultFalse,
			},
			{
				Name:      "v-volume1",
				MountPath: "/mnt/2",
				ReadOnly:  &defaultFalse,
			},
			{
				Name:      "v-volume2",
				MountPath: "/mnt/3",
				ReadOnly:  &defaultFalse,
			},
		},
	}

	containerList := make([]*api.ContainerSpec, 0)
	containerList = append(containerList, container1)
	containerList = append(containerList, container2)

	casp := api.CreatePodRequest{
		Name:                          utils.GenerateUuid("cli"),
		Description:                   "cli-test",
		Hostname:                      "hostname",
		RestartPolicy:                 "Never",
		TerminationGracePeriodSeconds: &defaultInt10,
		InstanceType:                  "g.n2.medium",
		Az:                            "az2",
		ServiceCode:                   "normal",
		RuntimeType:                   "xagent",
		DNSConfig: &api.DNSConfigSpec{
			Nameservers: []string{"8.8.8.8", "4.4.4.4"},

			Searches: []string{
				"JCLOUD.COM"},

			Options: []*api.DNSConfigOptionSpec{
				{Name: "timeout", Value: "300"},
				{Name: "debug", Value: ""},
				{Name: "edns0", Value: ""}},
		},

		LogConfig: &api.LogConfigSpec{
			LogDriver: "default",
		},

		PrimaryInterface: &api.NetworkPortSpec{
			VpcId:               "vpc-8dgcoequ4t",
			SubnetId:            "subnet-dr8hq3013o",
			SecurityGroups:      []string{"sg-39a4x7nkua"},
			Ipv6AddressCount:    0,
			Ipv6Addresses:       []string{},
			DeviceIndex:         1,
			DeleteOnTermination: &defaultFalse,
		},

		HostAliases: []*api.HostAliasSpec{
			{
				IP:        "127.0.0.1",
				Hostnames: []string{"localhost", "localhost.localdomain"},
			},
		},

		Volumes: []*api.VolumeSpec{
			{
				Name: "v-volume1",
				JDCloudDisk: &api.JDCloudVolumeSourceSpec{
					VolumeId:            podVolume1,
					FsType:              "xfs",
					FormatVolume:        &defaultTrue,
					DeleteOnTermination: &defaultFalse,
				},
			},

			{
				Name: "v-volume2",
				JDCloudDisk: &api.JDCloudVolumeSourceSpec{
					VolumeId:            podVolume2,
					FsType:              "ext4",
					FormatVolume:        &defaultTrue,
					DeleteOnTermination: &defaultFalse,
				},
			},
		},

		Containers: containerList,
		SchedulerPolicy: &api.SchedulerPolicySpec{
			IncludeHosts:  []string{},
			ExcludeHosts:  []string{},
			ResourceHints: []string{},
		},
	}

	util.FormatJSonOutput(casp)
}

func showRebuildPodJson() {
	defaultInt3 := 3
	defaultInt10 := 10
	defaultInt300 := 300
	defaultTrue := true
	defaultFalse := false

	container1 := &api.RebuildContainerSpec{
		Name:    "container1",
		Command: []string{"/bin/sh", "-c"},
		Args:    []string{"i=1; while true; do echo`date` >> /tmp/logs; sleep 2; done"},
		Env: []*api.EnvSpec{
			{
				Name:  "sbin",
				Value: "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
			},
		},

		Image: "http://pod-test-cn-ite-1.jcr.service.jdcloud.com/pod-test:latest",
		//Secret:"",
		TTY:        &defaultTrue,
		WorkingDir: "/home/cli/container1",
		LivenessProbe: &api.ProbeSpec{
			InitialDelaySeconds: &defaultInt3,
			FailureThreshold:    &defaultInt3,
			SuccessThreshold:    &defaultInt3,
			PeriodSeconds:       &defaultInt10,
			TimeoutSeconds:      &defaultInt300,
			Exec: &api.ExecActionSpec{
				Command: []string{"ls", "/"},
			},
		},
		ReadinessProbe: &api.ProbeSpec{
			InitialDelaySeconds: &defaultInt3,
			FailureThreshold:    &defaultInt3,
			SuccessThreshold:    &defaultInt3,
			PeriodSeconds:       &defaultInt10,
			TimeoutSeconds:      &defaultInt300,
			Exec: &api.ExecActionSpec{
				Command: []string{"ls", "/root"},
			},
		},
		VolumeMounts: []*api.VolumeMountSpec{
			{
				Name:      "v-volume1",
				MountPath: "/mnt/1",
				ReadOnly:  &defaultFalse,
			},
			{
				Name:      "v-volume1",
				MountPath: "/mnt/2",
				ReadOnly:  &defaultFalse,
			},
			{
				Name:      "v-volume2",
				MountPath: "/mnt/3",
				ReadOnly:  &defaultFalse,
			},
		},
	}

	containerList := make([]*api.RebuildContainerSpec, 0)
	containerList = append(containerList, container1)

	req := api.RebuildPodRequest{
		PodId:      "pod-12345678",
		Containers: containerList,
	}

	util.FormatJSonOutput(req)
}

func showResizePodJson() {
	limitCpu := 200
	limitMem := 256
	requestCpu := 100
	requestMem := 128
	instanceType := "g.s1.micro"

	req := &api.ResizePodRequest{
		PodId:        "pod-1s7bdv8xj5",
		InstanceType: &instanceType,
		Resources: []*api.ResizeContainerSpec{
			{
				Name: "container1",
				Resources: &api.ResourceRequestsSpec{
					Limits: &api.ResourceSpec{
						CPU:      &limitCpu,
						MemoryMB: &limitMem,
					},
					Requests: &api.ResourceSpec{
						CPU:      &requestCpu,
						MemoryMB: &requestMem,
					},
				},
			},
		},

		SchedulerPolicy: &api.SchedulerPolicySpec{
			IncludeHosts:  []string{},
			ExcludeHosts:  []string{},
			ResourceHints: []string{},
		},
	}

	util.FormatJSonOutput(req)
}

func showResizePodYaml() {
	limitCpu := 200
	limitMem := 256
	requestCpu := 100
	requestMem := 128
	instanceType := "g.s1.micro"

	req := &api.ResizePodRequest{
		PodId:        "pod-1s7bdv8xj5",
		InstanceType: &instanceType,
		Resources: []*api.ResizeContainerSpec{
			{
				Name: "container1",
				Resources: &api.ResourceRequestsSpec{
					Limits: &api.ResourceSpec{
						CPU:      &limitCpu,
						MemoryMB: &limitMem,
					},
					Requests: &api.ResourceSpec{
						CPU:      &requestCpu,
						MemoryMB: &requestMem,
					},
				},
			},
		},

		SchedulerPolicy: &api.SchedulerPolicySpec{
			IncludeHosts:  []string{},
			ExcludeHosts:  []string{},
			ResourceHints: []string{},
		},
	}

	util.FormatYamlOutput(req)
}

func showRebuildPodYaml() {
	defaultInt3 := 3
	defaultInt10 := 10
	defaultInt300 := 300
	defaultTrue := true
	defaultFalse := false

	container1 := &api.RebuildContainerSpec{
		Name:    "container1",
		Command: []string{"/bin/sh", "-c"},
		Args:    []string{"i=1; while true; do echo`date` >> /tmp/logs; sleep 2; done"},
		Env: []*api.EnvSpec{
			{
				Name:  "sbin",
				Value: "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
			},
		},

		Image: "http://pod-test-cn-ite-1.jcr.service.jdcloud.com/pod-test:latest",
		//Secret:"",
		TTY:        &defaultTrue,
		WorkingDir: "/home/cli/container1",
		LivenessProbe: &api.ProbeSpec{
			InitialDelaySeconds: &defaultInt3,
			FailureThreshold:    &defaultInt3,
			SuccessThreshold:    &defaultInt3,
			PeriodSeconds:       &defaultInt10,
			TimeoutSeconds:      &defaultInt300,
			Exec: &api.ExecActionSpec{
				Command: []string{"ls", "/"},
			},
		},
		ReadinessProbe: &api.ProbeSpec{
			InitialDelaySeconds: &defaultInt3,
			FailureThreshold:    &defaultInt3,
			SuccessThreshold:    &defaultInt3,
			PeriodSeconds:       &defaultInt10,
			TimeoutSeconds:      &defaultInt300,
			Exec: &api.ExecActionSpec{
				Command: []string{"ls", "/root"},
			},
		},
		VolumeMounts: []*api.VolumeMountSpec{
			{
				Name:      "v-volume1",
				MountPath: "/mnt/1",
				ReadOnly:  &defaultFalse,
			},
			{
				Name:      "v-volume1",
				MountPath: "/mnt/2",
				ReadOnly:  &defaultFalse,
			},
			{
				Name:      "v-volume2",
				MountPath: "/mnt/3",
				ReadOnly:  &defaultFalse,
			},
		},
	}

	containerList := make([]*api.RebuildContainerSpec, 0)
	containerList = append(containerList, container1)

	req := api.RebuildPodRequest{
		PodId:      "pod-12345678",
		Containers: containerList,
	}

	util.FormatYamlOutput(req)
}

func showCreatePodYaml() {
	defaultInt3 := 3
	defaultInt10 := 10
	defaultInt300 := 300
	defaultTrue := true
	defaultFalse := false
	cpu200 := 200
	cpu100 := 100
	mem128 := 128
	mem64 := 64

	container1 := &api.ContainerSpec{
		Name:    "container1",
		Command: []string{"/bin/sh", "-c"},
		Args:    []string{"i=1; while true; do echo`date` >> /tmp/logs; sleep 2; done"},
		Env: []*api.EnvSpec{
			{
				Name:  "sbin",
				Value: "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
			},
		},

		Image: "http://pod-test-cn-ite-1.jcr.service.jdcloud.com/pod-test:latest",
		//Secret:"",
		TTY:        &defaultTrue,
		WorkingDir: "/home/cli/container1",
		LivenessProbe: &api.ProbeSpec{
			InitialDelaySeconds: &defaultInt3,
			FailureThreshold:    &defaultInt3,
			SuccessThreshold:    &defaultInt3,
			PeriodSeconds:       &defaultInt10,
			TimeoutSeconds:      &defaultInt300,
			Exec: &api.ExecActionSpec{
				Command: []string{"ls", "/"},
			},
		},

		ReadinessProbe: &api.ProbeSpec{
			InitialDelaySeconds: &defaultInt3,
			FailureThreshold:    &defaultInt3,
			SuccessThreshold:    &defaultInt3,
			PeriodSeconds:       &defaultInt10,
			TimeoutSeconds:      &defaultInt300,
			Exec: &api.ExecActionSpec{
				Command: []string{"ls", "/root"},
			},
		},

		Resources: &api.ResourceRequestsSpec{
			Limits: &api.ResourceSpec{
				CPU:      &cpu200,
				MemoryMB: &mem128,
			},

			Requests: &api.ResourceSpec{
				CPU:      &cpu100,
				MemoryMB: &mem64,
			},
		},

		SystemDisk: &api.CloudDiskSpec{
			VolumeId:            Container1SysVolume,
			FsType:              "xfs",
			DeleteOnTermination: &defaultFalse,
		},

		VolumeMounts: []*api.VolumeMountSpec{
			{
				Name:      "v-volume1",
				MountPath: "/mnt/1",
				ReadOnly:  &defaultFalse,
			},
			{
				Name:      "v-volume1",
				MountPath: "/mnt/2",
				ReadOnly:  &defaultFalse,
			},
			{
				Name:      "v-volume2",
				MountPath: "/mnt/3",
				ReadOnly:  &defaultFalse,
			},
		},
	}

	container2 := &api.ContainerSpec{
		Name:    "container2",
		Command: []string{"/bin/sh", "-c"},
		Args:    []string{"i=1; while true; do let i+=1; echo $i; sleep 2; done"},

		Env: []*api.EnvSpec{
			{
				Name:  "sbin",
				Value: "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
			},
			{
				Name:  "path1",
				Value: "",
			},
		},

		Image: "httpd:latest",
		//Secret:     "hami_secret",
		TTY:        &defaultFalse,
		WorkingDir: "/home/cli/container2",

		LivenessProbe: &api.ProbeSpec{
			InitialDelaySeconds: &defaultInt3,
			FailureThreshold:    &defaultInt10,
			SuccessThreshold:    &defaultInt10,
			PeriodSeconds:       &defaultInt10,
			TimeoutSeconds:      &defaultInt300,

			Exec: &api.ExecActionSpec{
				Command: []string{"ls", "/root"},
			},

			//TCPSocket    :&api.TCPSocketActionSpec{
			//	            Port :1,
			//},

			//HTTPGet: &api.HTTPGetActionSpec{
			//	Scheme: "https",
			//	Host:   "127.0.0.1",
			//	Port:   65535,
			//	Path:   "http://fanyi.baidu.com/?aldtype=16047#en/zh/abort",
			//	HTTPHeaders: []*api.HTTPHeaderSpec{
			//		{Name: "debug", Value: "169.254.0.0"},
			//		{Name: "debug", Value: "169.254.0.0"},
			//	},
			//},
		},

		ReadinessProbe: &api.ProbeSpec{
			InitialDelaySeconds: &defaultInt3,
			FailureThreshold:    &defaultInt10,
			SuccessThreshold:    &defaultInt10,
			PeriodSeconds:       &defaultInt10,
			TimeoutSeconds:      &defaultInt300,

			//Exec: &api.ExecActionSpec{
			//	Command: []string{"ls", "/root"},
			//},

			//TCPSocket: &api.TCPSocketActionSpec{
			//	Port: 1,
			//},

			HTTPGet: &api.HTTPGetActionSpec{
				Scheme: "http",
				Host:   "127.0.0.1",
				Port:   80,
				Path:   "/",
				HTTPHeaders: []*api.HTTPHeaderSpec{
					{Name: "cache-control", Value: "no-cache"},
					{Name: "Content-Type", Value: "application/json"},
				},
			},
		},

		Resources: &api.ResourceRequestsSpec{
			Limits: &api.ResourceSpec{
				CPU:      &cpu100,
				MemoryMB: &mem64,
			},

			Requests: &api.ResourceSpec{
				CPU:      &cpu100,
				MemoryMB: &mem64,
			},
		},

		SystemDisk: &api.CloudDiskSpec{
			VolumeId:            Container2SysVolume,
			FsType:              "xfs",
			DeleteOnTermination: &defaultFalse,
		},

		VolumeMounts: []*api.VolumeMountSpec{
			{
				Name:      "v-volume1",
				MountPath: "/mnt/1",
				ReadOnly:  &defaultFalse,
			},
			{
				Name:      "v-volume1",
				MountPath: "/mnt/2",
				ReadOnly:  &defaultFalse,
			},
			{
				Name:      "v-volume2",
				MountPath: "/mnt/3",
				ReadOnly:  &defaultFalse,
			},
		},
	}

	containerList := make([]*api.ContainerSpec, 0)
	containerList = append(containerList, container1)
	containerList = append(containerList, container2)

	casp := api.CreatePodRequest{
		Name:                          utils.GenerateUuid("cli"),
		Description:                   "cli-test",
		Hostname:                      "hostname",
		RestartPolicy:                 "Never",
		TerminationGracePeriodSeconds: &defaultInt10,
		InstanceType:                  "g.n2.medium",
		Az:                            "az2",
		ServiceCode:                   "normal",
		RuntimeType:                   "xagent",
		DNSConfig: &api.DNSConfigSpec{
			Nameservers: []string{"8.8.8.8", "4.4.4.4"},

			Searches: []string{
				"JCLOUD.COM"},

			Options: []*api.DNSConfigOptionSpec{
				{Name: "timeout", Value: "300"},
				{Name: "debug", Value: ""},
				{Name: "edns0", Value: ""}},
		},

		LogConfig: &api.LogConfigSpec{
			LogDriver: "default",
		},

		PrimaryInterface: &api.NetworkPortSpec{
			VpcId:               "vpc-8dgcoequ4t",
			SubnetId:            "subnet-dr8hq3013o",
			SecurityGroups:      []string{"sg-39a4x7nkua"},
			Ipv6AddressCount:    0,
			Ipv6Addresses:       []string{},
			DeviceIndex:         1,
			DeleteOnTermination: &defaultFalse,
		},

		HostAliases: []*api.HostAliasSpec{
			{
				IP:        "127.0.0.1",
				Hostnames: []string{"localhost", "localhost.localdomain"},
			},
		},

		Volumes: []*api.VolumeSpec{
			{
				Name: "v-volume1",
				JDCloudDisk: &api.JDCloudVolumeSourceSpec{
					VolumeId:            podVolume1,
					FsType:              "xfs",
					FormatVolume:        &defaultTrue,
					DeleteOnTermination: &defaultFalse,
				},
			},

			{
				Name: "v-volume2",
				JDCloudDisk: &api.JDCloudVolumeSourceSpec{
					VolumeId:            podVolume2,
					FsType:              "ext4",
					FormatVolume:        &defaultTrue,
					DeleteOnTermination: &defaultFalse,
				},
			},
		},

		Containers: containerList,
		SchedulerPolicy: &api.SchedulerPolicySpec{
			IncludeHosts:  []string{},
			ExcludeHosts:  []string{},
			ResourceHints: []string{},
		},
	}

	util.FormatYamlOutput(casp)
}

func CreatePodCmd() *cobra.Command {
	var (
		jsonFile    string
		jsonExample bool
		yamlFile    string
		yamlExample bool
	)

	cmd := &cobra.Command{
		Use:   "pod-create [OPTIONS]",
		Short: "create pod from file json or yaml",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {
			params := new(api.CreatePodRequest)
			if jsonExample {
				showCreatePodJson()
				return
			}

			if jsonFile != "" {
				util.LoadJsonFile(jsonFile, params)
			}

			if yamlExample {
				showCreatePodYaml()
				return
			}

			if yamlFile != "" {
				util.LoadYamlFile(yamlFile, params)
				//showCreatePodJson()
			}

			if params == nil || params.Name == "" || params.PrimaryInterface == nil {
				cmd.Help()
				return
			}

			if params.SchedulerPolicy.AvailabilityZone == "" {
				params.SchedulerPolicy.AvailabilityZone = params.Az
			}

			res, err := JksApiClient.CreatePod(CommonHeader, params)
			if err != nil {
				util.FormatJErrorOutput(err)
				return
			}

			if res == nil {
				util.FormatErrorOutput(fmt.Errorf("return pod is nil"))
			}
			util.FormatViewOutput(res)
		},
	}

	cmd.Flags().StringVar(&jsonFile, "json-file", "", "create pod json file path")
	cmd.Flags().BoolVar(&jsonExample, "json-file-example", false, "a json file example about create pod, (type:bool, default false)")

	cmd.Flags().StringVar(&yamlFile, "yaml-file", "", "create pod yaml file path,【optional】")
	cmd.Flags().BoolVar(&yamlExample, "yaml-file-example", false, "a yaml file example about create pod, (type:bool, default false)")

	return cmd
}

func RebuildPodCmd() *cobra.Command {
	var (
		jsonFile    string
		jsonExample bool
		yamlFile    string
		yamlExample bool
	)

	cmd := &cobra.Command{
		Use:   "pod-rebuild [OPTIONS]",
		Short: "rebuild pod from file json or yaml",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {
			var params *api.RebuildPodRequest

			if jsonExample {
				showRebuildPodJson()
				return
			}

			if !jsonExample && yamlExample {
				showRebuildPodYaml()
				return
			}

			if jsonFile != "" {
				fmt.Println("JsonFile")
				params = new(api.RebuildPodRequest)
				util.LoadJsonFile(jsonFile, params)
			}

			if jsonFile == "" && yamlFile != "" {
				fmt.Println("YamlFile")
				params = new(api.RebuildPodRequest)
				util.LoadYamlFile(yamlFile, params)
			}

			if params == nil {
				cmd.Help()
				return
			}

			if err := JksApiClient.RebuildPod(CommonHeader, params); err != nil {
				util.FormatJErrorOutput(err)
				return
			}
			util.FormatMessageOutput(">> rebuild pod success!")
		},
	}

	cmd.Flags().StringVar(&jsonFile, "json-file", "", "use json file rebuild pod")
	cmd.Flags().BoolVar(&jsonExample, "json-file-example", false, "a json file example about rebuild pod")

	cmd.Flags().StringVar(&yamlFile, "yaml-file", "", "use yaml file rebuild pod")
	cmd.Flags().BoolVar(&yamlExample, "yaml-file-example", false, "a yaml file example about rebuild pod")

	return cmd
}

func PodStartCmd() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "pod-start [OPTIONS] PodId",
		Short: "start pod",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {
			// 执行的方法
			if len(args) < 1 {
				cmd.Help()
				return
			}

			param := &api.StartPodRequest{PodId: args[0]}
			if err := JksApiClient.StartPod(CommonHeader, param); err != nil {
				util.FormatJErrorOutput(err)
				return
			}

			util.FormatMessageOutput(">> start pod success!")
		},
	}
	return cmd
}

func PodStopCmd() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "pod-stop [OPTIONS] PodId",
		Short: "stop pod",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {
			// 执行的方法
			if len(args) < 1 {
				cmd.Help()
				return
			}

			param := &api.StopPodRequest{PodId: args[0]}
			if err := JksApiClient.StopPod(CommonHeader, param); err != nil {
				util.FormatJErrorOutput(err)
				return
			}

			util.FormatMessageOutput(">> stop pod success!")
		},
	}
	return cmd
}

func PodDeleteCmd() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "pod-delete [OPTIONS] PodId",
		Short: "delete pod",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {
			// 执行的方法
			if len(args) < 1 {
				cmd.Help()
				return
			}
			param := &api.DeletePodRequest{PodId: args[0]}
			if err := JksApiClient.DeletePod(CommonHeader, param); err != nil {
				util.FormatJErrorOutput(err)
				return
			}

			util.FormatMessageOutput(">> delete pod success!")
		},
	}
	return cmd
}

func PodUpdateCmd() *cobra.Command {
	desc := new(string)

	cmd := &cobra.Command{
		Use:   "pod-update [OPTIONS] PodId",
		Short: "update pod",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {
			// 执行的方法
			if len(args) < 1 {
				cmd.Help()
				return
			}
			param := &api.UpdatePodRequest{
				PodId:       args[0],
				Description: desc,
			}

			if err := JksApiClient.UpdatePod(CommonHeader, param); err != nil {
				util.FormatJErrorOutput(err)
				return
			}

			util.FormatMessageOutput(">> update pod success!")
		},
	}

	cmd.Flags().StringVar(desc, "description", "", "pod description")

	return cmd
}

func PodListCmd() *cobra.Command {
	var (
		page     int
		pageSize int
		order    string
		sort     string
	)
	filter := new(api.DescribePodsFilterSpec)

	//封装请求
	cmd := &cobra.Command{
		Use:   "pod-list",
		Short: "pod list by userId",
		Long:  "Effect: pod list by userId",
		Run: func(cmd *cobra.Command, args []string) {

			//参数
			params := &api.DescribePodsRequest{
				Filters:    filter,
				DescOffset: page,
				DescLimit:  pageSize,
				Sort:       sort,
				Order:      order,
			}

			//请求
			resp, err := JksApiClient.DescribePods(CommonHeader, params)
			if err != nil {
				util.FormatJErrorOutput(err)
				return
			}
			if resp == nil || resp.Items == nil || resp.Items[0].PodStatus == nil {
				return
			}

			type podInfo struct {
				PodId        string
				Name         string
				UserId       string
				UserPin      string
				PodStatus    string
				TaskId       int64
				HostIP       string
				Az           string
				InstanceType string
				CreateTime   string
				UpdateTime   string
			}

			showList := make([]*podInfo, 0)
			for _, podMsg := range resp.Items {
				pod := &podInfo{
					PodId:        podMsg.PodId,
					Name:         podMsg.Name,
					UserId:       podMsg.UserId,
					UserPin:      podMsg.UserPin,
					TaskId:       podMsg.TaskId,
					Az:           podMsg.Az,
					HostIP:       podMsg.HostIP,
					InstanceType: podMsg.InstanceType,
					PodStatus:    podMsg.PodStatus.Phase,
					CreateTime:   podMsg.CreateTime,
					UpdateTime:   podMsg.UpdateTime,
				}
				showList = append(showList, pod)
			}

			//显示
			label := []string{
				"PodId",
				"PodStatus",
				"Name",
				//"UserId",
				//"UserPin",
				"TaskId",
				"Az",
				"HostIP",
				"InstanceType",
				"CreateTime",
				//"UpdateTime",
			}

			util.FormatListOutput(label, showList)
			total := Total{TotalCount: resp.TotalCount, RealCount: len(showList)}
			util.FormatViewOutput(total)
		},
	}

	cmd.Flags().IntVar(&page, "page", 0, "describe offset, query start index")
	cmd.Flags().IntVar(&pageSize, "page-size", 100, "describe limit,max list number, 0: not limit")
	cmd.Flags().StringVar(&order, "order", "created_time", "order by basis this")
	cmd.Flags().StringVar(&sort, "sort", "desc", "sort way, asc or desc")

	cmd.Flags().StringVar(&filter.Name, "name", "", "name of pod")
	cmd.Flags().StringVar(&filter.UserPin, "pin", "", "user pin of pod")
	cmd.Flags().StringVar(&filter.FixedIp, "fixed-ip", "", "fix ip of pod")
	cmd.Flags().StringArrayVar(&filter.HostIp, "host-ip", nil, "host ip of pod")
	cmd.Flags().StringArrayVar(&filter.PodId, "pod-id", nil, "pod id")
	cmd.Flags().StringArrayVar(&filter.Az, "az", nil, "az of pod")
	cmd.Flags().StringArrayVar(&filter.VpcId, "vpc-id", nil, "vpc id of pod")
	cmd.Flags().StringArrayVar(&filter.SubnetId, "subnet-id", nil, "subnet id of pod")
	cmd.Flags().StringArrayVar(&filter.Phase, "phase", nil, "pod phase")
	cmd.Flags().StringArrayVar(&filter.ServiceCode, "service-code", nil, "service code")
	cmd.Flags().StringArrayVar(&filter.SecurityGroups, "security-groups", nil, "security groups")

	return cmd
}

func PodShowCmd() *cobra.Command {
	//封装请求
	cmd := &cobra.Command{
		Use:   "pod-show PodId",
		Short: "show one pod to json",
		Run: func(cmd *cobra.Command, args []string) {
			if len(args) < 1 {
				cmd.Help()
				return
			}
			params := &api.DescribePodsRequest{
				Filters: &api.DescribePodsFilterSpec{
					PodId: []string{args[0]},
				},
			}

			//请求
			resp, err := JksApiClient.DescribePods(CommonHeader, params)
			if err != nil {
				util.FormatJErrorOutput(err)
				return
			}
			if resp == nil || len(resp.Items) == 0 {
				util.FormatMessageOutput(">> pod not found!")
				return
			}

			util.FormatJSonOutput(resp.Items[0])
		},
	}

	return cmd
}

func PodStatusCmd() *cobra.Command {
	//封装请求
	cmd := &cobra.Command{
		Use:   "pod-status PodId",
		Short: "show one pod status to json",
		Run: func(cmd *cobra.Command, args []string) {

			//参数
			if len(args) < 1 {
				cmd.Help()
				return
			}
			params := &api.DescribePodStatusRequest{PodId: args[0]}
			//请求
			resp, err := JksApiClient.DescribePodStatus(CommonHeader, params)
			if err != nil {
				util.FormatJErrorOutput(err)
				return
			}
			if resp == nil || resp.PodStatus == nil {
				util.FormatMessageOutput(">> pod status not found!")
				return
			}

			util.FormatJSonOutput(resp)
		},
	}

	return cmd
}

func MigratePodCmd() *cobra.Command {
	var (
		includeHosts  []string
		excludeHosts  []string
		resourceHints []string
	)

	cmd := &cobra.Command{
		Use:   "pod-migrate [OPTIONS] POD_ID",
		Short: "migrate pod from source host to target host, must be admin permissions",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {
			if len(args) != 1 {
				cmd.Help()
				return
			}

			if !IsAdmin {
				util.FormatMessageOutput("pod-migrate must be admin permissions")
				return
			}

			params := &api.MigratePodRequest{
				PodId: args[0],
				SchedulerPolicy: &api.SchedulerPolicySpec{
					IncludeHosts:  includeHosts,
					ExcludeHosts:  excludeHosts,
					ResourceHints: resourceHints,
				},
			}

			if err := JksApiClient.MigratePod(CommonHeader, params); err != nil {
				util.FormatJErrorOutput(err)
				return
			}

			util.FormatMessageOutput(">> migrate pod success!")
		},
	}

	cmd.Flags().StringArrayVar(&includeHosts, "include-hosts", nil, "include hosts")
	cmd.Flags().StringArrayVar(&excludeHosts, "exclude-hosts", nil, "exclude hosts")
	cmd.Flags().StringArrayVar(&resourceHints, "tags", nil, "host tag")

	return cmd
}

func RecoverPodCmd() *cobra.Command {
	var (
		includeHosts  []string
		excludeHosts  []string
		resourceHints []string
	)

	cmd := &cobra.Command{
		Use:   "pod-recover [OPTIONS] POD_ID",
		Short: "recover pod from source host to target host when compute node fault, must be admin permissions",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {
			if len(args) != 1 {
				cmd.Help()
				return
			}

			if !IsAdmin {
				util.FormatMessageOutput("pod-recover must be admin permissions")
				return
			}

			params := &api.RecoverPodRequest{
				PodId: args[0],
				SchedulerPolicy: &api.SchedulerPolicySpec{
					IncludeHosts:  includeHosts,
					ExcludeHosts:  excludeHosts,
					ResourceHints: resourceHints,
				},
			}

			if err := JksApiClient.RecoverPod(CommonHeader, params); err != nil {
				util.FormatJErrorOutput(err)
				return
			}

			util.FormatMessageOutput(">> recover pod success!")
		},
	}

	cmd.Flags().StringArrayVar(&includeHosts, "include-hosts", nil, "include hosts")
	cmd.Flags().StringArrayVar(&excludeHosts, "exclude-hosts", nil, "exclude hosts")
	cmd.Flags().StringArrayVar(&resourceHints, "tags", nil, "host tag")

	return cmd
}

func ResetPodStatusCmd() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "reset-status [OPTIONS] POD_ID|NC_ID",
		Short: "reset status to stopped, when the status of resource is error, must be admin permissions",
		Long:  "",
		Run: func(cmd *cobra.Command, args []string) {
			if len(args) != 1 {
				cmd.Help()
				return
			}

			if !IsAdmin {
				util.FormatMessageOutput("reset-status must be admin permissions")
				return
			}

			params := &api.ResetPodStatusRequest{
				PodId: args[0],
			}

			if err := JksApiClient.ResetPodStatus(CommonHeader, params); err != nil {
				util.FormatJErrorOutput(err)
				return
			}

			util.FormatMessageOutput(">> reset pod status success!")
		},
	}

	return cmd
}

func ResizePodCmd() *cobra.Command {
	var (
		jsonFile    string
		jsonExample bool
		yamlFile    string
		yamlExample bool
	)
	params := &api.ResizePodRequest{}
	cmd := &cobra.Command{
		Use:   "pod-resize [OPTIONS]",
		Short: "resize pod InstanceType or cpu memery config",
		Long:  "resize pod InstanceType or cpu memery config",
		Run: func(cmd *cobra.Command, args []string) {
			if jsonExample {
				showResizePodJson()
				return
			}

			if jsonFile != "" {
				util.LoadJsonFile(jsonFile, params)
			}

			if yamlExample {
				showResizePodYaml()
				return
			}

			if yamlFile != "" {
				util.LoadYamlFile(yamlFile, params)
				//showCreatePodJson()
			}

			if params == nil {
				cmd.Help()
				return
			}

			if err := JksApiClient.ResizePod(CommonHeader, params); err != nil {
				util.FormatJErrorOutput(err)
				return
			}
			util.FormatMessageOutput(">> resize pod success!")
		},
	}

	cmd.Flags().StringVar(&jsonFile, "json-file", "", "resize pod json file path")
	cmd.Flags().BoolVar(&jsonExample, "json-file-example", false, "a json file example about resize pod, (type:bool, default false)")

	cmd.Flags().StringVar(&yamlFile, "yaml-file", "", "resize pod yaml file path")
	cmd.Flags().BoolVar(&yamlExample, "yaml-file-example", false, "a yaml file example about resize pod, (type:bool, default false)")

	return cmd
}

func NewPodCommand(cmd *cobra.Command) {
	cmd.AddCommand(CreatePodCmd())
	cmd.AddCommand(RebuildPodCmd())
	cmd.AddCommand(PodStartCmd())
	cmd.AddCommand(PodStopCmd())
	cmd.AddCommand(PodDeleteCmd())
	cmd.AddCommand(PodListCmd())
	cmd.AddCommand(PodShowCmd())
	cmd.AddCommand(PodUpdateCmd())
	cmd.AddCommand(PodStatusCmd())
	cmd.AddCommand(MigratePodCmd())
	cmd.AddCommand(RecoverPodCmd())
	cmd.AddCommand(ResizePodCmd())
	cmd.AddCommand(ResetPodStatusCmd())
}
