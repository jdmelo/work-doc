package task

import (
	"encoding/json"
	"errors"
	"fmt"
	"time"

	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	rmsApi "jd.com/jvirt/jvirt-common/inner/rms/api-server"
	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/golocal"
	"jd.com/jvirt/jvirt-common/utils/url"
	"jd.com/jvirt/jvirt-jks-api-server/bean"
	"jd.com/jvirt/jvirt-jks-api-server/constant"
	"jd.com/jvirt/jvirt-jks-api-server/dao"
)

func (p *TaskService) taskCompleteUpdateDB(params *api.UpdateTaskRequest, dbTask *bean.Task) error {
	taskState := params.TaskState
	taskAfter := dbTask.TaskAfter
	taskType := dbTask.TaskType
	podId := dbTask.ReferId
	hostIp := dbTask.HostIp

	podStatusMap, err := p.DescribePodStatusByIds([]string{podId})
	if err != nil {
		p.Logger.Error("[taskCompleteUpdateDB] DescribePodStatusByIds failed. PodId: %s, Error: %s", podId, err.Error())
		return err
	}

	podStatus, ok := podStatusMap[podId]
	if !ok {
		p.Logger.Error("pod status not found in the db. PodId: %s", podId)
		return errors.New("pod status not found in the db")
	}

	p.Logger.Info("[taskCompleteUpdateDB] HostIp: %s, PodId: %s, TaskId: %v, TaskType: %s TaskState: %s, TaskAfter: %v.",
		hostIp, podId, params.TaskId, taskType, taskState, taskAfter)

	dbTask.TaskState = taskState
	podObject := &bean.Pod{
		PodId:  podId,
		TaskId: 0,
	}

	taskUpdateFields := []string{"task_state", "task_after"}
	podUpdateFields := []string{"task_id"}

	txs := make([]db.FuncT, 0)
	switch taskType {
	case jks.PodCreateTask:
		if taskState == jks.TaskFinished {
			podStatus.Phase = jks.PodPhaseRunning
			podStatus.Reason = jks.PodStatusReasonPodCreateSuccess
			podStatus.Message = ""
			for _, item := range podStatus.ContainerStatuses {
				item.Phase = jks.ContainerPhaseRunning
				item.RestartCount = 0
				item.Ready = false
				item.State = &jks.ContainerState{
					Running: &jks.ContainerStateRunning{
						StartedAt: time.Now().UTC().Format(time.RFC3339),
					},
					Waiting:    nil,
					Terminated: nil,
				}
			}
		} else {
			podStatus.Phase = jks.PodPhaseError
			podStatus.Reason = params.FailReason
			podStatus.Message = params.FailMessage
			for _, item := range podStatus.ContainerStatuses {
				item.Phase = jks.ContainerPhaseError
			}
		}
	case jks.PodDeleteTask:
		if taskState == jks.TaskFinished {
			podStatus.Phase = jks.PodPhaseDeleted
			podStatus.Reason = jks.PodStatusReasonPodDeleteSuccess
			podStatus.Message = ""
			for _, item := range podStatus.ContainerStatuses {
				item.Phase = jks.ContainerPhaseTerminated
				item.State = &jks.ContainerState{
					Running:    nil,
					Waiting:    nil,
					Terminated: &jks.ContainerStateTerminated{},
				}
			}
		} else {
			podStatus.Phase = jks.PodPhaseError
			podStatus.Reason = params.FailReason
			podStatus.Message = params.FailMessage
			for _, item := range podStatus.ContainerStatuses {
				item.Phase = jks.ContainerPhaseError
			}
		}
	case jks.PodMigrateTask:
		if taskState == jks.TaskFinished {
			extends, err := dbTask.GetExtends()
			if err != nil {
				p.Logger.Error("Unmarshal task.extends failed, TaskId: %v, Error: %s.", dbTask.Id, err.Error())
				return err
			}
			podObject.AllocId = extends.NewAllocId
			podObject.HostIp = hostIp
			podUpdateFields = []string{"task_id", "host_ip", "alloc_id"}

			podStatus.Phase = jks.PodPhaseStopped
			podStatus.Reason = jks.PodStatusReasonPodMigrateSuccess
			podStatus.Message = ""
			for _, item := range podStatus.ContainerStatuses {
				item.Phase = jks.ContainerPhaseStopped
			}
		} else {
			podStatus.Phase = jks.PodPhaseStopped
			podStatus.Reason = jks.PodStatusReasonPodMigrateFailed
			podStatus.Message = "migrate failed"
			for _, item := range podStatus.ContainerStatuses {
				item.Phase = jks.ContainerPhaseStopped
			}
		}

		taskUpdateFields = []string{"task_state", "task_after", "extends"}
	case jks.PodResizeTask:
		taskContent := &api.ResizePodResources{}
		if err := json.Unmarshal([]byte(dbTask.Content), taskContent); err != nil {
			return err
		}
		if taskState == jks.TaskFinished {
			extends, err := dbTask.GetExtends()
			if err != nil {
				p.Logger.Error("Unmarshal task.extends failed, TaskId: %v, Error: %s.", dbTask.Id, err.Error())
				return err
			}

			podObject.HostIp = hostIp
			podObject.AllocId = extends.NewAllocId
			podObject.InstanceType = taskContent.InstanceType
			podUpdateFields = []string{"task_id", "host_ip", "instance_type", "alloc_id"}
			podStatus.Phase = jks.PodPhaseStopped
			podStatus.Reason = jks.PodStatusReasonPodResizeSuccess
			podStatus.Message = ""
			for _, item := range podStatus.ContainerStatuses {
				item.Phase = jks.ContainerPhaseStopped
			}

			txsFunc, err := p.updateContainer(podId, taskContent.Resources)
			if err != nil {
				p.Logger.Error("[PodResizeTask] updateContainer failed. podId: %s, err: %v", podId, err)
				return err
			}
			txs = append(txs, txsFunc...)
		} else {
			if taskContent.ResizeType == jks.ResizePodDiffNode || taskAfter == jks.TaskDone {
				// resize失败, 设置成Stopped状态
				podStatus.Phase = jks.PodPhaseStopped
				podStatus.Reason = jks.PodStatusReasonPodResizeFailed
				podStatus.Message = "resize failed"
				for _, item := range podStatus.ContainerStatuses {
					item.Phase = jks.ContainerPhaseStopped
				}
			} else {
				// resize失败, 回滚失败, 设置成Error状态
				podStatus.Phase = jks.PodPhaseError
				podStatus.Reason = jks.PodStatusReasonPodResizeFailed
				podStatus.Message = "resize failed and rollback failed"
				for _, item := range podStatus.ContainerStatuses {
					item.Phase = jks.ContainerPhaseError
				}
			}
		}

		taskUpdateFields = []string{"task_state", "task_after", "extends"}
	case jks.PodStartTask:
		if taskState == jks.TaskFinished {
			podStatus.Phase = jks.PodPhaseRunning
			podStatus.Reason = jks.PodStatusReasonPodStartSuccess
			podStatus.Message = ""
			for _, item := range podStatus.ContainerStatuses {
				item.Phase = jks.ContainerPhaseRunning
				item.RestartCount += 1
				item.State = &jks.ContainerState{
					Running: &jks.ContainerStateRunning{
						StartedAt: time.Now().UTC().Format(time.RFC3339),
					},
					Waiting:    nil,
					Terminated: nil,
				}
			}
		} else {
			podStatus.Phase = jks.PodPhaseStopped
			podStatus.Reason = params.FailReason
			podStatus.Message = params.FailMessage
			for _, item := range podStatus.ContainerStatuses {
				item.Phase = jks.ContainerPhaseStopped
			}
		}
	case jks.PodRebuildTask:
		if taskState == jks.TaskFinished {
			podStatus.Phase = jks.PodPhaseStopped
			podStatus.Reason = jks.PodStatusReasonPodRebuildSuccess
			podStatus.Message = ""
			for _, item := range podStatus.ContainerStatuses {
				item.Phase = jks.ContainerPhaseStopped
				item.Ready = false
				item.State = &jks.ContainerState{
					Running:    nil,
					Waiting:    nil,
					Terminated: &jks.ContainerStateTerminated{},
				}
			}
		} else {
			podStatus.Phase = jks.PodPhaseError
			podStatus.Reason = jks.PodStatusReasonPodRebuildFailed
			podStatus.Message = "rebuild failed and rollback failed"
			for _, item := range podStatus.ContainerStatuses {
				item.Phase = jks.ContainerPhaseError
			}
		}
	case jks.PodStopTask:
		if taskState == jks.TaskFinished {
			podStatus.Phase = jks.PodPhaseStopped
			podStatus.Reason = jks.PodStatusReasonPodStopSuccess
			podStatus.Message = ""
			for _, item := range podStatus.ContainerStatuses {
				item.Phase = jks.ContainerPhaseStopped
				item.Ready = false
				item.State = &jks.ContainerState{
					Running:    nil,
					Waiting:    nil,
					Terminated: &jks.ContainerStateTerminated{},
				}
			}
		} else {
			// TODO: 关机失败状态回退有不准确情况
			podStatus.Phase = jks.PodPhaseRunning
			podStatus.Reason = params.FailReason
			podStatus.Message = params.FailMessage
			for _, item := range podStatus.ContainerStatuses {
				item.Phase = jks.ContainerPhaseRunning
			}
		}
	}

	// 更新Task
	txs = append(txs, func(tx *db.Tx) error {
		whereCond := &bean.Task{Id: dbTask.Id, TaskState: jks.TaskRunning}
		return p.TaskDao.UpdateByWhere(tx, dbTask, taskUpdateFields, whereCond, []string{"id", "task_state"})
	})

	// 更新ContainerStatus, PodCondition, PodStatus
	tx, err := p.UpdatePodStatusTxs(podId, podStatus)
	if err != nil {
		p.Logger.Error("[taskCompleteUpdateDB] UpdatePodStatusTxs failed. PodId: %s, Error: %s.", podId, err.Error())
		return err
	}

	if tx != nil {
		txs = append(txs, tx...)
	}

	//添加事件
	event, err := p.GetEvent(podId, jks.EventTypeTask, podStatus)
	if err != nil {
		p.Logger.Error("UpdateTaskStatus GetEvent failed. PodId: %s", podId)
		return common.NewSysErr(err)
	}
	if event != nil {
		event.TaskId = dbTask.Id
		event.TaskType = taskType
		event.TaskState = taskState
		txs = append(txs, func(tx *db.Tx) error {
			return p.EventDao.Create(tx, event)
		})
	}

	// 更新Pod
	txs = append(txs, func(tx *db.Tx) error {
		return p.PodDao.Update(tx, podObject, podUpdateFields, []string{"pod_id"})
	})

	if err := p.DBOperator.Exec(txs...); err != nil {
		p.Logger.Error("[taskCompleteUpdateDB] Exec transaction failed. PodId: %s, Error: %s.", podId, err.Error())
		return err
	}

	return nil
}

func (p *TaskService) updateContainer(podId string, resources []*api.ResizeContainerSpec) ([]db.FuncT, error) {
	argsJson, err := json.Marshal(resources)
	if err == nil {
		p.Logger.Debug("[updateContainer] request dbConrtainers params: %s", argsJson)
	}

	dbPod, err := p.PodDao.Query(p.DBOperator, podId)
	if err != nil {
		p.Logger.Error("PodDao.Query failed. PodId: %s, Error: %s.", podId, err.Error())
		return nil, err
	}

	dbContainers, err := p.ContainerDao.QueryRecordByPodId(p.DBOperator, podId)
	if err != nil {
		p.Logger.Error("[updateContainer] QueryRecordByPodId failed. podId: %s, err: %v", podId, err)
		return nil, err
	}

	txs := make([]db.FuncT, 0)
	resourceMap := make(map[string]*api.ResourceRequestsSpec)
	if dbPod.ResourceType == jks.ResourceTypeNativeContainer {
		if len(dbContainers) != 1 || len(resources) != 1 {
			return nil, fmt.Errorf("resize nc get dbConrtainers or taskContent.Resources len not one, ncId: %s", podId)
		}
		resources := resources[0].Resources
		dbContainers[0].CpuLimit = *resources.Limits.CPU
		dbContainers[0].CpuLimit = *resources.Limits.MemoryMB
		resourceMap[dbContainers[0].Name] = &api.ResourceRequestsSpec{}
	}

	if dbPod.ResourceType == jks.ResourceTypePod {
		for _, resource := range resources {
			resourceMap[resource.Name] = resource.Resources
		}

		for _, container := range dbContainers {
			if resource, ok := resourceMap[container.Name]; ok {
				if resource.Limits != nil {
					if resource.Limits.CPU != nil {
						container.CpuLimit = *resource.Limits.CPU
					}
					if resource.Limits.MemoryMB != nil {
						container.MemLimit = *resource.Limits.MemoryMB
					}
				}
				if resource.Requests != nil {
					if resource.Requests.CPU != nil {
						container.CpuRequest = *resource.Requests.CPU
					}
					if resource.Requests.MemoryMB != nil {
						container.MemRequest = *resource.Requests.MemoryMB
					}
				}
				p.Logger.Debug("update container name: %s", container.Name)
			}
		}
	}

	whereFields := []string{"id"}
	updateFields := []string{"cpu_request", "cpu_limit", "mem_request", "mem_limit"}
	for _, container := range dbContainers {
		if _, ok := resourceMap[container.Name]; ok {
			tmp := container
			p.Logger.Debug("updateContainer container info: %v", *tmp)
			txs = append(txs, func(tx *db.Tx) error {
				return p.ContainerDao.Update(tx, tmp, updateFields, whereFields)
			})
		}
	}

	argsJson, err = json.Marshal(dbContainers)
	if err == nil {
		p.Logger.Debug("[updateContainer] dbConrtainers result: %s", argsJson)
	}
	return txs, nil
}

func (p *TaskService) handleStopTask(req *url.Request, params *api.UpdateTaskRequest, task *bean.Task) common.JvirtError {
	taskState := params.TaskState
	podId := params.PodId

	switch taskState {
	case jks.TaskFinished:
		task.TaskState = jks.TaskFinished
	case jks.TaskFailed:
		task.TaskState = jks.TaskFailed
	default:
		msg := fmt.Sprintf("invalid task state %s, task_id: %v", taskState, params.TaskId)
		p.Logger.Error(msg)
		return common.NewError(common.RErrTask, common.TErrInvalid, common.PErrState, msg)
	}

	if err := p.taskCompleteUpdateDB(params, task); err != nil {
		p.Logger.Error("[handleStopTask] taskCompleteUpdateDB failed. PodId: %s, Error: %s", podId, err.Error())
		return common.NewSysErr(err)
	}

	return nil
}

func (p *TaskService) handleStartTask(req *url.Request, params *api.UpdateTaskRequest, task *bean.Task) common.JvirtError {
	taskState := params.TaskState
	podId := params.PodId

	switch taskState {
	case jks.TaskFinished:
		task.TaskState = jks.TaskFinished
	case jks.TaskFailed:
		task.TaskState = jks.TaskFailed
	default:
		msg := fmt.Sprintf("invalid task state %s, task_id: %v", taskState, params.TaskId)
		p.Logger.Error(msg)
		return common.NewError(common.RErrTask, common.TErrInvalid, common.PErrState, msg)
	}

	if err := p.taskCompleteUpdateDB(params, task); err != nil {
		p.Logger.Error("[handleStartTask] taskCompleteUpdateDB failed. PodId: %s, Error: %s", podId, err.Error())
		return common.NewSysErr(err)
	}

	return nil
}

func (p *TaskService) handleRebuildTask(req *url.Request, params *api.UpdateTaskRequest, task *bean.Task) common.JvirtError {
	taskState := params.TaskState
	podId := params.PodId

	switch taskState {
	case jks.TaskFinished:
		task.TaskState = jks.TaskFinished
	case jks.TaskFailed:
		task.TaskState = jks.TaskFailed
	default:
		msg := fmt.Sprintf("invalid task state %s, task_id: %v", taskState, params.TaskId)
		p.Logger.Error(msg)
		return common.NewError(common.RErrTask, common.TErrInvalid, common.PErrState, msg)
	}

	if err := p.taskCompleteUpdateDB(params, task); err != nil {
		p.Logger.Error("[handleRebuildTask] taskCompleteUpdateDB failed. PodId: %s, Error: %s", podId, err.Error())
		return common.NewSysErr(err)
	}

	return nil
}

func (p *TaskService) handleDeleteTask(req *url.Request, params *api.UpdateTaskRequest, task *bean.Task) common.JvirtError {
	taskState := params.TaskState
	podId := params.PodId
	taskId := params.TaskId

	switch taskState {
	case jks.TaskFinished:
		dbPod, err := p.PodDao.Query(p.DBOperator, podId)
		if err != nil {
			return common.NewSysErr(err)
		}

		task.TaskState = jks.TaskFinished
		if jErr := p.DeletePodFromDB(task, dbPod); jErr != nil {
			p.Logger.Error("[handleDeleteTask] DeletePodFromDB failed. PodId: %s, TaskId: %v, Error: %s, Detail: %s.",
				podId, taskId, jErr.Error(), jErr.Detail())
			return jErr
		}
	case jks.TaskFailed:
		task.TaskState = jks.TaskFailed
		task.TaskAfter = jks.TaskDone
		if err := p.taskCompleteUpdateDB(params, task); err != nil {
			p.Logger.Error("[handleDeleteTask] taskCompleteUpdateDB failed. PodId: %s, Error: %s", podId, err.Error())
			return common.NewSysErr(err)
		}
	default:
		msg := fmt.Sprintf("invalid task state %s, task_id: %v", taskState, params.TaskId)
		p.Logger.Error(msg)
		return common.NewError(common.RErrTask, common.TErrInvalid, common.PErrState, msg)
	}

	return nil
}

func (p *TaskService) handleCreateFailed(params *api.UpdateTaskRequest, dbTask *bean.Task) common.JvirtError {
	podId := dbTask.ReferId
	requestId := dbTask.RequestId
	dbTask.RetryTime--

	if !params.Rollback || dbTask.RetryTime == 0 {
		p.Logger.Error("PodId: %s, Rollback: %v, Task.RetryTime: %v.", podId, params.Rollback, dbTask.RetryTime)
		dbTask.TaskState = jks.TaskFailed
		if err := p.taskCompleteUpdateDB(params, dbTask); err != nil {
			p.Logger.Error("handleRealFailed failed. PodId: %s Error: %s.", podId, err.Error())
			return common.NewSysErr(err)
		}

		return nil
	}

	dbPod, err := p.PodDao.Query(p.DBOperator, podId)
	if err != nil {
		p.Logger.Error("[handleCreateFailed] PodDao.Query failed. PodId: %s, Error: %s.", podId, err.Error())
		return common.NewSysErr(err)
	}

	if dbPod.HostIp != params.HostIp {
		msg := fmt.Sprintf("hostIp of pod is invalid,  dbPod.host_ip: %s, jksAgent.host_ip: %s.", dbPod.HostIp, params.HostIp)
		p.Logger.Error(msg)
		return common.NewError(common.TErrIdempotence, common.RErrInstance, common.PErrHost, msg)
	}

	// 资源必须释放掉，才能重新调度。
	if jErr := p.ClearResource(requestId, podId, rmsApi.TypicalEffectNormal); jErr != nil {
		p.Logger.Error("Invoke rms FreeResource failed. PodId: %s, Error: %s, Detail: %s.", podId, jErr.Error(), jErr.Detail())
		return jErr
	}

	extends := &bean.Extends{}
	if err := json.Unmarshal([]byte(dbTask.Extends), extends); err != nil {
		p.Logger.Error("Unmarshal task extends failed. PodId: %s, Error: %s", podId, err.Error())
		return common.NewSysErr(err)
	}
	extends.ExcludeHosts = append(extends.ExcludeHosts, params.HostIp)
	newTask := &bean.Task{
		UserId:      dbTask.UserId,
		ClientToken: dbTask.ClientToken,
		RequestId:   dbTask.RequestId,
		TaskType:    jks.PodCreateTask,
		TaskState:   jks.TaskPending,
		Timeout:     dbTask.Timeout,
		TaskBefore:  jks.TaskUndo,
		TaskAfter:   jks.TaskDisable,
		ReferId:     dbTask.ReferId,
		RetryTime:   dbTask.RetryTime,
		Extends:     extends.ToString(),
		Content:     dbTask.Content,
	}

	txs := make([]db.FuncT, 0)
	txs = append(txs, func(tx *db.Tx) error {
		// 将任务设置成失败状态。
		dbTask.TaskState = jks.TaskFailed
		dbTask.TaskBefore = jks.TaskDone
		whereCond := &bean.Task{Id: dbTask.Id, TaskState: jks.TaskRunning}
		return p.TaskDao.UpdateByWhere(tx, dbTask, []string{"task_state", "task_before"}, whereCond, []string{"id", "task_state"})
	})
	txs = append(txs, func(tx *db.Tx) error {
		// 重新创建任务。
		return p.TaskDao.Create(tx, newTask)
	})
	txs = append(txs, func(tx *db.Tx) error {
		// 更新Pod。
		dbPod.HostIp = ""
		dbPod.AllocId = ""
		dbPod.TaskId = newTask.Id
		return p.PodDao.Update(tx, dbPod, []string{"alloc_id", "host_ip", "task_id"}, []string{"pod_id"})
	})
	if err := p.DBOperator.Exec(txs...); err != nil {
		p.Logger.Error("update db for task or instance failed, err: %s", err.Error())
		return common.NewSysErr(err)
	}

	goValue := golocal.GoContext.Get()
	go func() {
		defer func() {
			golocal.GoContext.Remove()
		}()
		golocal.GoContext.Put(goValue)

		dbPod, err := p.PodDao.Query(p.DBOperator, podId)
		if err != nil {
			p.Logger.Error("PodDao.Query failed. PodId: %s, Error: %s.", podId, err.Error())
			return
		}
		if jErr := p.AllocResourceAndSendTask(podId, dbPod.TaskId); jErr != nil {
			p.Logger.Error("[handleCreateFailed] AllocResourceAndSendTask failed. PodId: %s, Error: %s, Detail: %s",
				podId, jErr.Error(), jErr.Detail())
		}
	}()

	return nil
}

func (p *TaskService) handleCreateTask(req *url.Request, params *api.UpdateTaskRequest, task *bean.Task) common.JvirtError {
	taskState := params.TaskState
	podId := params.PodId

	switch taskState {
	case jks.TaskFinished:
		task.TaskState = jks.TaskFinished
		if err := p.taskCompleteUpdateDB(params, task); err != nil {
			p.Logger.Error("[handleCreateTask] taskCompleteUpdateDB failed. PodId: %s, Error: %s", podId, err.Error())
			return common.NewSysErr(err)
		}
	case jks.TaskFailed:
		if jErr := p.handleCreateFailed(params, task); jErr != nil {
			p.Logger.Error("[handleCreateTask] handleCreateFailed failed. PodId: %s, Error: %s", podId, jErr.Error())
			return jErr
		}
	default:
		msg := fmt.Sprintf("invalid task state %s, task_id: %v", taskState, params.TaskId)
		p.Logger.Error(msg)
		return common.NewError(common.RErrTask, common.TErrInvalid, common.PErrState, msg)
	}

	return nil
}

func (p *TaskService) handleMigrateFinished(req *url.Request, params *api.UpdateTaskRequest, task *bean.Task) common.JvirtError {
	extend, err := task.GetExtends()
	if err != nil {
		p.Logger.Error("Unmarshal task.extends failed, TaskId: %v, Error: %s.", params.TaskId, err.Error())
		return common.NewSysErr(errors.New("unmarshal task.Extends failed"))
	}
	srcHostIp := extend.SrcHostIp
	podId := params.PodId
	if jErr := p.MigrateFinishCleanSrc(req.RequestId, srcHostIp, podId); jErr != nil {
		p.Logger.Error("[handleMigrateFinished] MigrateFinishCleanSrc failed. PodId: %s, Error: %s, Detail: %s",
			podId, jErr.Error(), jErr.Detail())
		extend.AgentFreed = false
	} else {
		extend.AgentFreed = true
	}

	if jErr := p.FreeOldAlloc(req.RequestId, extend.OldAllocId, rmsApi.TypicalEffectNormal); jErr != nil {
		p.Logger.Error("[handleMigrateFinished] RmsFreeReAllocResource failed. PodId: %s, Error: %s, Detail: %s",
			podId, jErr.Error(), jErr.Detail())
		extend.RmsFreed = false
	} else {
		extend.RmsFreed = true
	}

	if extend.AgentFreed && extend.RmsFreed {
		task.TaskAfter = jks.TaskDone
	}
	task.TaskState = jks.TaskFinished
	task.Extends = extend.ToString()

	p.Logger.Debug("[handleMigrateFinished] podId: %s, agentFreed: %t, rmsFreed: %t", podId, extend.AgentFreed, extend.RmsFreed)
	if err := p.taskCompleteUpdateDB(params, task); err != nil {
		p.Logger.Error("[handleMigrateFinished] taskCompleteUpdateDB failed. PodId: %s, Error: %s", podId, err.Error())
		return common.NewSysErr(err)
	}

	newTask := &bean.Task{
		RequestId:  task.RequestId,
		UserId:     task.UserId,
		HostIp:     task.HostIp,
		TaskState:  jks.TaskRunning,
		TaskBefore: jks.TaskDisable,
		TaskAfter:  jks.TaskDisable,
		ReferId:    podId,
	}
	switch task.Content {
	case constant.RecoverStartingPod, constant.RecoverRunningPod:
		newTask.TaskType = jks.PodStartTask

	case constant.RecoverRebuildingPod:
		lastRebuildTask, err := p.TaskDao.Query(p.DBOperator, extend.PostTask.TaskId)
		if err != nil {
			return common.NewSysErr(err)
		}
		newTask.TaskType = jks.PodRebuildTask
		newTask.Content = lastRebuildTask.Content
		newTask.ClientToken = lastRebuildTask.ClientToken
		newTask.Timeout = lastRebuildTask.Timeout

	default:
		p.Logger.Debug("Recover not support %s", task.Content)
		return nil
	}

	pod, err := p.PodDao.Query(p.DBOperator, podId)
	if err != nil {
		return common.NewSysErr(err)
	}

	if jErr := p.CreateTaskAndUpdatePodStatus(newTask, pod, nil); jErr != nil {
		p.Logger.Error("CreateTaskAndUpdatePodStatus failed. PodId: %s, Error: %s, Detail: %s.", jErr.Error(), jErr.Detail())
		return jErr
	}

	go p.SendRequestToAgent(newTask)

	return nil
}

func (p *TaskService) handleResizeFinished(req *url.Request, params *api.UpdateTaskRequest, task *bean.Task) common.JvirtError {
	extend, err := task.GetExtends()
	if err != nil {
		p.Logger.Error("Unmarshal task.extends failed, TaskId: %v, Error: %s.", params.TaskId, err.Error())
		return common.NewSysErr(errors.New("unmarshal task.Extends failed"))
	}

	podId := params.PodId
	extend.AgentFreed = true //xagnet reAlloc为增量，没有资源释放的问题
	if jErr := p.FreeOldAlloc(req.RequestId, extend.OldAllocId, rmsApi.TypicalEffectNormal); jErr != nil {
		p.Logger.Error("[handleResizeFinished] RmsFreeReAllocResource failed. PodId: %s, Error: %s, Detail: %s",
			podId, jErr.Error(), jErr.Detail())
		extend.RmsFreed = false //失败补偿
	} else {
		extend.RmsFreed = true
	}

	if extend.AgentFreed && extend.RmsFreed {
		task.TaskAfter = jks.TaskDone
	}
	task.TaskState = jks.TaskFinished
	task.Extends = extend.ToString()

	p.Logger.Debug("[handleResizeFinished] podId: %s, agentFreed: %t, rmsFreed: %t", podId, extend.AgentFreed, extend.RmsFreed)
	if err := p.taskCompleteUpdateDB(params, task); err != nil {
		p.Logger.Error("[handleMigrateFinished] taskCompleteUpdateDB failed. PodId: %s, Error: %s", podId, err.Error())
		return common.NewSysErr(err)
	}
	return nil
}

func (p *TaskService) handleMigrateFailed(req *url.Request, params *api.UpdateTaskRequest, task *bean.Task) common.JvirtError {
	extend, err := task.GetExtends()
	if err != nil {
		p.Logger.Error("Unmarshal task.extends failed, TaskId: %v, Error: %s.", params.TaskId, err.Error())
		return common.NewSysErr(errors.New("unmarshal task.Extends failed"))
	}
	dstHostIp := params.HostIp
	podId := params.PodId

	extend.AgentFreed = true
	if !params.Rollback {
		if jErr := p.MigrateFailedCleanDst(req.RequestId, dstHostIp, podId); jErr != nil {
			p.Logger.Error("[handleMigrateFailed] MigrateFailedCleanDst failed. PodId: %s, Error: %s, Detail: %s",
				podId, jErr.Error(), jErr.Detail())
			extend.AgentFreed = false
		}
	}

	extend.RmsFreed = true
	if jErr := p.RollbackReAlloc(req.RequestId, podId); jErr != nil {
		p.Logger.Error("[handleMigrateFailed] RmsRollbackReAlloc failed. PodId: %s, Error: %s, Detail: %s",
			podId, jErr.Error(), jErr.Detail())
		extend.RmsFreed = false
	}

	if extend.AgentFreed && extend.RmsFreed {
		task.TaskAfter = jks.TaskDone
	}
	task.TaskState = jks.TaskFailed
	task.Extends = extend.ToString()

	p.Logger.Debug("[ handleMigrateFailed] podId: %s, agentFreed: %t, rmsFreed: %t", podId, extend.AgentFreed, extend.RmsFreed)
	if err := p.taskCompleteUpdateDB(params, task); err != nil {
		p.Logger.Error("[handleMigrateFinished] taskCompleteUpdateDB failed. PodId: %s, Error: %s", podId, err.Error())
		return common.NewSysErr(err)
	}

	return nil
}

func (p *TaskService) handleResizeFailed(req *url.Request, params *api.UpdateTaskRequest, task *bean.Task) common.JvirtError {
	extend, err := task.GetExtends()
	if err != nil {
		p.Logger.Error("Unmarshal task.extends failed, TaskId: %v, Error: %s.", params.TaskId, err.Error())
		return common.NewSysErr(errors.New("unmarshal task.Extends failed"))
	}
	hostIp := params.HostIp
	podId := params.PodId

	extend.AgentFreed = true
	p.Logger.Debug("[handleResizeFailed] resize failed clean cgroup resource. PodId: %s, hostIp: %s", podId, hostIp)
	if jErr := p.ResizePodRollBack(req.RequestId, hostIp, podId); jErr != nil {
		p.Logger.Error("[handleResizeFailed] ResizePodRollBack failed. PodId: %s, Error: %s, Detail: %s",
			podId, jErr.Error(), jErr.Detail())
		extend.AgentFreed = false
	}

	extend.RmsFreed = true
	if jErr := p.RollbackReAlloc(req.RequestId, podId); jErr != nil {
		p.Logger.Error("[handleResizeFailed] RmsRollbackReAlloc failed. PodId: %s, Error: %s, Detail: %s",
			podId, jErr.Error(), jErr.Detail())
		extend.RmsFreed = false
	}

	if extend.AgentFreed && extend.RmsFreed {
		task.TaskAfter = jks.TaskDone
	}
	task.TaskState = jks.TaskFailed
	task.Extends = extend.ToString()

	if err := p.taskCompleteUpdateDB(params, task); err != nil {
		p.Logger.Error("[handleMigrateFinished] taskCompleteUpdateDB failed. PodId: %s, Error: %s", podId, err.Error())
		return common.NewSysErr(err)
	}

	return nil
}

func (p *TaskService) handleMigrateTask(req *url.Request, params *api.UpdateTaskRequest, task *bean.Task) common.JvirtError {
	taskState := params.TaskState
	podId := params.PodId

	switch taskState {
	case jks.TaskFinished:
		if jErr := p.handleMigrateFinished(req, params, task); jErr != nil {
			p.Logger.Error("[handleMigrateTask] handleMigrateFinished failed. PodId: %s, Error: %s", podId, jErr.Error())
			return jErr
		}
	case jks.TaskFailed:
		if jErr := p.handleMigrateFailed(req, params, task); jErr != nil {
			p.Logger.Error("[handleMigrateTask] handleMigrateFailed failed. PodId: %s, Error: %s", podId, jErr.Error())
			return jErr
		}
	default:
		msg := fmt.Sprintf("invalid task state %s, task_id: %v", taskState, params.TaskId)
		p.Logger.Error(msg)
		return common.NewError(common.RErrTask, common.TErrInvalid, common.PErrState, msg)
	}

	return nil
}

func (p *TaskService) handleResizeTask(req *url.Request, params *api.UpdateTaskRequest, task *bean.Task) common.JvirtError {
	taskState := params.TaskState
	podId := params.PodId

	taskContent := &api.ResizePodResources{}
	if err := json.Unmarshal([]byte(task.Content), taskContent); err != nil {
		return common.NewError(common.RErrJson, common.TErrError, common.PErrType, err.Error())
	}
	p.Logger.Debug("[handleResizeTask] start podId: %s, fault: %s, taskState: %s", podId, task.Fault, params.TaskState)
	if taskContent.ResizeType == jks.ResizePodSameNode {
		switch taskState {
		case jks.TaskFinished:
			if jErr := p.handleResizeFinished(req, params, task); jErr != nil {
				p.Logger.Error("[handleResizeTask] handleResizeFinished failed. PodId: %s, Error: %s", podId, jErr.Error())
				return jErr
			}
		case jks.TaskFailed:
			if jErr := p.handleResizeFailed(req, params, task); jErr != nil { //todo 状态什么设置
				p.Logger.Error("[handleResizeTask] handleResizeFailed failed. PodId: %s, Error: %s", podId, jErr.Error())
				return jErr
			}
		default:
			msg := fmt.Sprintf("invalid task state %s, task_id: %v", taskState, params.TaskId)
			p.Logger.Error(msg)
			return common.NewError(common.RErrTask, common.TErrInvalid, common.PErrState, msg)
		}

	}

	if taskContent.ResizeType == jks.ResizePodDiffNode {
		switch taskState {
		case jks.TaskFinished:
			if jErr := p.handleMigrateFinished(req, params, task); jErr != nil {
				p.Logger.Error("[handleMigrateTask] handleMigrateFinished failed. PodId: %s, Error: %s", podId, jErr.Error())
				return jErr
			}
		case jks.TaskFailed:
			if jErr := p.handleMigrateFailed(req, params, task); jErr != nil {
				p.Logger.Error("[handleMigrateTask] handleMigrateFailed failed. PodId: %s, Error: %s", podId, jErr.Error())
				return jErr
			}
		default:
			msg := fmt.Sprintf("invalid task state %s, task_id: %v", taskState, params.TaskId)
			p.Logger.Error(msg)
			return common.NewError(common.RErrTask, common.TErrInvalid, common.PErrState, msg)
		}
	}

	return nil
}

func (p *TaskService) UpdateTask(req *url.Request, params *api.UpdateTaskRequest) common.JvirtError {
	var jErr common.JvirtError

	taskId := params.TaskId
	podId := params.PodId

	p.Logger.Info("[UpdateTask] Start PodId: %s, TaskId: %v, Params :%v.", podId, taskId, params)

	task, err := p.TaskDao.Query(p.DBOperator, taskId)
	if err != nil {
		p.Logger.Error("[UpdateTask] TaskDao.Query failed. TaskId: %v, Error: %s", taskId, err.Error())
		if dao.IsDataNotFound(err) {
			return common.NewError(common.RErrTask, common.PErrDB, common.TErrNotFound, err.Error())
		}

		return common.NewSysErr(err)
	}

	taskType := task.TaskType

	if task.TaskState == jks.TaskFailed || task.TaskState == jks.TaskFinished {
		p.Logger.Info("Task has completed, ignore it. TaskId: %v, TaskState: %s, TaskType: %s.",
			taskId, task.TaskState, task.TaskType)
		return nil
	}

	switch taskType {
	case jks.PodCreateTask:
		jErr = p.handleCreateTask(req, params, task)
	case jks.PodDeleteTask:
		jErr = p.handleDeleteTask(req, params, task)
	case jks.PodStopTask:
		jErr = p.handleStopTask(req, params, task)
	case jks.PodStartTask:
		jErr = p.handleStartTask(req, params, task)
	case jks.PodRebuildTask:
		jErr = p.handleRebuildTask(req, params, task)
	case jks.PodMigrateTask:
		jErr = p.handleMigrateTask(req, params, task)
	case jks.PodResizeTask:
		jErr = p.handleResizeTask(req, params, task)
	default:
		msg := fmt.Sprintf("unsupported task type %s for pod %s", taskType, podId)
		jErr = common.NewError(common.RErrTask, common.TErrUnsupported, common.PErrType, msg)
	}

	p.Logger.Info("[UpdateTask] End PodId: %s, TaskId: %v.", podId, taskId)

	return jErr
}
