package task

import (
	"jd.com/jvirt/jvirt-jks-api-server/service/base"
)

type TaskService struct {
	*base.PodCommonService `inject:""`
}
