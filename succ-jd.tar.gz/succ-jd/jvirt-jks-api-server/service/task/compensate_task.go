package task

import (
	"encoding/json"
	"errors"
	"fmt"
	"time"

	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	rmsApi "jd.com/jvirt/jvirt-common/inner/rms/api-server"
	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/golocal"
	"jd.com/jvirt/jvirt-common/utils/url"
	"jd.com/jvirt/jvirt-jks-api-server/bean"
	"jd.com/jvirt/jvirt-jks-api-server/dao"
	"jd.com/jvirt/jvirt-jks-api-server/utils"
)

func (p *TaskService) compensatePendingTask(req *url.Request, task *bean.Task) common.JvirtError {
	taskState := task.TaskState
	taskBefore := task.TaskBefore
	taskId := task.Id
	podId := task.ReferId

	// TaskState == pending && TaskBefore == TaskUndo
	if taskState != jks.TaskPending || taskBefore != jks.TaskUndo {
		msg := fmt.Sprintf("Compensate PendingTask, TaskState must be pending, TaskBefore must be undo. CurrentTaskState: %s, CurrentTaskBefore: %v",
			taskState, taskBefore)
		p.Logger.Error(msg)
		return common.NewError(common.RErrTask, common.TErrForbidden, common.PErrState, msg)
	}

	p.Logger.Info("[compensatePendingTask] PodId: %s, TaskId: %v, TaskType: %s, TaskState: %s, TaskBefore: %s", podId, taskId, task.TaskType, task.TaskState, taskBefore)

	dbPod, err := p.PodDao.Query(p.DBOperator, podId)
	if err != nil {
		p.Logger.Error("PodDao.Query failed. PodId: %s, TaskId: %s, Error: %s.", podId, taskId, err.Error())
		return common.NewSysErr(err)
	}

	queryNow, err := p.TaskDao.QueryNow(p.DBOperator)
	if err != nil {
		p.Logger.Error("TaskDao.QueryNow failed. PodId: %s, TaskId: %s, Error: %s.", podId, taskId, err.Error())
		return common.NewSysErr(errors.New("query now from db failed"))
	}

	if queryNow.Now.After(task.CreatedTime.Add(time.Duration(task.Timeout) * time.Second)) {
		p.Logger.Error("Task %v timeout. CreatedTime: %s, CurrentTime: %s, Timeout: %v", taskId, task.CreatedTime.String(), queryNow.Now.String(), task.Timeout)

		if err := p.AllocFailedAndNoCompensate(dbPod, task); err != nil {
			p.Logger.Error("AllocFailedAndNoCompensate failed. PodId: %s, TaskId: %s, Error: %s.", podId, taskId, err.Error())
			return common.NewSysErr(err)
		}

		return nil
	}

	goValue := golocal.GoContext.Get()
	p.Logger.Debug("[compensatePendingTask] goValue:%v", goValue)
	go func() {
		defer func() {
			golocal.GoContext.Remove()
		}()
		golocal.GoContext.Put(goValue)
		p.Logger.Debug("[compensatePendingTask] start AllocResourceAndSendTask")
		if jErr := p.AllocResourceAndSendTask(podId, taskId); jErr != nil {
			p.Logger.Error("[compensatePendingTask] AllocResourceAndSendTask failed. PodId: %s, Error: %s, Detail: %s",
				podId, jErr.Error(), jErr.Detail())
		}
	}()

	return nil
}

func (p *TaskService) compensateDeleteTask(req *url.Request, task *bean.Task) common.JvirtError {
	instanceId := task.ReferId
	taskAfter := task.TaskAfter
	taskState := task.TaskState

	// TaskState == finished && TaskAfter == TaskUndo
	if taskState != jks.TaskFinished || taskAfter != jks.TaskUndo {
		msg := fmt.Sprintf("Compensate DeleteTask, TaskState must be finished, TaskAfter must be undo. CurrentTaskState: %s, CurrentTaskAfter: %v",
			taskState, taskAfter)
		p.Logger.Error(msg)
		return common.NewError(common.RErrTask, common.TErrForbidden, common.PErrState, msg)
	}

	// 调用RMS接口释放资源，同时将TaskAfter设置成TaskDone
	if jErr := p.ClearResource(req.RequestId, instanceId, rmsApi.TypicalEffectNormal); jErr != nil {
		p.Logger.Error("ClearResource failed. PodId: %s, AllocId: %v, Error: %s, Detail: %s.", instanceId, jErr.Error(), jErr.Detail())
		return jErr
	}

	task.TaskAfter = jks.TaskDone
	if err := p.TaskDao.UpdateByWhere(p.DBOperator, task, []string{"task_after"}, task, []string{"id"}); err != nil {
		p.Logger.Error("TaskDao.UpdateById failed. PodId: %s, TaskId: %s, Error: %s", instanceId, task.Id, err.Error())
		return common.NewSysErr(err)
	}

	return nil
}

func (p *TaskService) handleMigrateFinishedTask(req *url.Request, task *bean.Task) common.JvirtError {
	taskId := task.Id
	taskAfter := task.TaskAfter
	podId := task.ReferId

	if taskAfter != jks.TaskUndo {
		detail := fmt.Sprintf("TaskState is finished, TaskAfter must be undo for MigratePodCompensate, CurrentTaskAfter: %v", taskAfter)
		p.Logger.Error(detail)
		return common.NewError(common.RErrTask, common.TErrInvalid, common.PErrState, detail)
	}

	queryNow, err := p.TaskDao.QueryNow(p.DBOperator)
	if err != nil {
		p.Logger.Error("TaskDao.QueryNow failed. PodId: %s, TaskId: %s, Error: %s.", podId, taskId, err.Error())
		return common.NewSysErr(errors.New("query now from db failed"))
	}

	if queryNow.Now.After(task.CreatedTime.Add(time.Duration(utils.GetTaskClearResourceTimeout()) * time.Second)) {
		p.Logger.Error("Task %v timeout. TaskType: %s, CreatedTime: %s, CurrentTime: %s, Timeout: %v",
			taskId, task.TaskType, task.CreatedTime.String(), queryNow.Now.String(), task.Timeout)

		task.TaskAfter = jks.TaskDisable
		if err := p.TaskDao.UpdateById(p.DBOperator, task, []string{"task_after"}); err != nil {
			p.Logger.Error("TaskDao.UpdateById failed. PodId: %s, TaskId: %s, Error: %s.", podId, taskId, err.Error())
			return common.NewSysErr(err)
		}

		return nil
	}

	extend, err := task.GetExtends()
	if err != nil {
		p.Logger.Error("Unmarshal task.extends failed, TaskId: %v, Error: %s.", taskId, err.Error())
		return common.NewSysErr(errors.New("unmarshal task.Extends failed"))
	}
	srcHostIp := extend.SrcHostIp
	oldAllocId := extend.OldAllocId

	if !extend.AgentFreed {
		if jErr := p.MigrateFinishCleanSrc(req.RequestId, srcHostIp, podId); jErr != nil {
			p.Logger.Error("[handleMigrateFinishedTask] MigrateFinishCleanSrc failed. PodId: %s, Error: %s, Detail: %s",
				podId, jErr.Error(), jErr.Detail())
		} else {
			extend.AgentFreed = true
		}
	}

	if !extend.RmsFreed {
		if jErr := p.FreeOldAlloc(req.RequestId, oldAllocId, rmsApi.TypicalEffectNormal); jErr != nil {
			p.Logger.Error("[handleMigrateFinishedTask] FreeOldAlloc failed. PodId: %s, Error: %s, Detail: %s",
				podId, jErr.Error(), jErr.Detail())
		} else {
			extend.RmsFreed = true
		}
	}

	if extend.AgentFreed && extend.RmsFreed {
		task.TaskAfter = jks.TaskDone
	}
	task.Extends = extend.ToString()

	if err := p.TaskDao.UpdateByWhere(p.DBOperator, task, []string{"extends", "task_after"}, task, []string{"id"}); err != nil {
		p.Logger.Error("[handleMigrateFinishedTask] TaskDao.UpdateById failed. TaskId: %s, PodId: %s, Error: %s",
			taskId, podId, err.Error())
		return common.NewSysErr(err)
	}

	return nil
}

func (p *TaskService) handleResizeFinishedTask(req *url.Request, task *bean.Task) common.JvirtError {
	taskId := task.Id
	taskAfter := task.TaskAfter
	podId := task.ReferId

	p.Logger.Info("[handleResizeFinishedTask] PodId: %s, TaskId: %s, TaskAfter: %s", podId, taskId, taskAfter)
	if taskAfter != jks.TaskUndo {
		detail := fmt.Sprintf("TaskState is finished, TaskAfter must be undo for ResizePodCompensate, CurrentTaskAfter: %v", taskAfter)
		p.Logger.Error(detail)
		return common.NewError(common.RErrTask, common.TErrInvalid, common.PErrState, detail)
	}

	queryNow, err := p.TaskDao.QueryNow(p.DBOperator)
	if err != nil {
		p.Logger.Error("TaskDao.QueryNow failed. PodId: %s, TaskId: %s, Error: %s.", podId, taskId, err.Error())
		return common.NewSysErr(errors.New("query now from db failed"))
	}

	if queryNow.Now.After(task.CreatedTime.Add(time.Duration(utils.GetTaskClearResourceTimeout()) * time.Second)) {
		p.Logger.Error("Task %v timeout. TaskType: %s, CreatedTime: %s, CurrentTime: %s, Timeout: %v",
			taskId, task.TaskType, task.CreatedTime.String(), queryNow.Now.String(), task.Timeout)

		task.TaskAfter = jks.TaskDisable
		if err := p.TaskDao.UpdateById(p.DBOperator, task, []string{"task_after"}); err != nil {
			p.Logger.Error("TaskDao.UpdateById failed. PodId: %s, TaskId: %s, Error: %s.", podId, taskId, err.Error())
			return common.NewSysErr(err)
		}

		return nil
	}

	extend, err := task.GetExtends()
	if err != nil {
		p.Logger.Error("Unmarshal task.extends failed, TaskId: %v, Error: %s.", taskId, err.Error())
		return common.NewSysErr(errors.New("unmarshal task.Extends failed"))
	}
	oldAllocId := extend.OldAllocId

	if !extend.RmsFreed {
		if jErr := p.FreeOldAlloc(req.RequestId, oldAllocId, rmsApi.TypicalEffectNormal); jErr != nil {
			p.Logger.Error("[handleMigrateFinishedTask] FreeOldAlloc failed. PodId: %s, Error: %s, Detail: %s",
				podId, jErr.Error(), jErr.Detail())
		} else {
			extend.RmsFreed = true
		}
	}

	if extend.AgentFreed && extend.RmsFreed {
		task.TaskAfter = jks.TaskDone
	}
	task.Extends = extend.ToString()
	p.Logger.Debug("[handleResizeFinishedTask] PodId: %s, TaskId: %s, TaskAfter: %s", podId, taskId, task.TaskAfter)

	if err := p.TaskDao.UpdateByWhere(p.DBOperator, task, []string{"extends", "task_after"}, task, []string{"id"}); err != nil {
		p.Logger.Error("[handleResizeFinishedTask] TaskDao.UpdateById failed. TaskId: %s, PodId: %s, Error: %s",
			taskId, podId, err.Error())
		return common.NewSysErr(err)
	}

	return nil
}

func (p *TaskService) handleResizeFailedTask(req *url.Request, task *bean.Task) common.JvirtError {
	taskId := task.Id
	taskAfter := task.TaskAfter
	podId := task.ReferId

	if taskAfter != jks.TaskUndo {
		detail := fmt.Sprintf("TaskState is failed, TaskAfter must be undo for ResizePodCompensate, CurrentTaskAfter: %v", taskAfter)
		p.Logger.Error(detail)
		return common.NewError(common.RErrTask, common.TErrInvalid, common.PErrState, detail)
	}

	extend, err := task.GetExtends()
	if err != nil {
		p.Logger.Error("Unmarshal task.extends failed, TaskId: %v, Error: %s.", taskId, err.Error())
		return common.NewSysErr(errors.New("unmarshal task.Extends failed"))
	}
	hostIp := task.HostIp

	if !extend.AgentFreed {
		if jErr := p.ResizePodRollBack(req.RequestId, hostIp, podId); jErr != nil {
			p.Logger.Error("[handleResizeFailed] ResizePodRollBack failed. PodId: %s, Error: %s, Detail: %s",
				podId, jErr.Error(), jErr.Detail())
		} else {
			extend.AgentFreed = true
		}
	}

	if !extend.RmsFreed {
		if jErr := p.RollbackReAlloc(req.RequestId, podId); jErr != nil {
			p.Logger.Error("[handleResizeFailedTask] RollbackReAlloc failed. PodId: %s, Error: %s, Detail: %s",
				podId, jErr.Error(), jErr.Detail())
		} else {
			extend.RmsFreed = true
		}
	}

	if extend.AgentFreed && extend.RmsFreed {
		task.TaskAfter = jks.TaskDone
	}
	task.Extends = extend.ToString()

	p.Logger.Debug("[handleResizePodFailedTask] resizePod failed compensate clear resource. PodId: %s, TaskAfter: %d", podId, task.TaskAfter)
	if err := p.TaskDao.UpdateByWhere(p.DBOperator, task, []string{"extends", "task_after"}, task, []string{"id"}); err != nil {
		p.Logger.Error("[handleResizePodFailedTask] TaskDao.UpdateById failed. TaskId: %s, PodId: %s, Error: %s",
			taskId, podId, err.Error())
		return common.NewSysErr(err)
	}

	return nil
}

func (p *TaskService) handleMigrateFailedTask(req *url.Request, task *bean.Task) common.JvirtError {

	taskId := task.Id
	taskAfter := task.TaskAfter
	podId := task.ReferId

	if taskAfter != jks.TaskUndo {
		detail := fmt.Sprintf("TaskState is failed, TaskAfter must be undo for MigratePodCompensate, CurrentTaskAfter: %v", taskAfter)
		p.Logger.Error(detail)
		return common.NewError(common.RErrTask, common.TErrInvalid, common.PErrState, detail)
	}

	queryNow, err := p.TaskDao.QueryNow(p.DBOperator)
	if err != nil {
		p.Logger.Error("TaskDao.QueryNow failed. PodId: %s, TaskId: %s, Error: %s.", podId, taskId, err.Error())
		return common.NewSysErr(errors.New("query now from db failed"))
	}

	if queryNow.Now.After(task.CreatedTime.Add(time.Duration(utils.GetTaskClearResourceTimeout()) * time.Second)) {
		p.Logger.Error("Task %v timeout. TaskType: %s, CreatedTime: %s, CurrentTime: %s, Timeout: %v",
			taskId, task.TaskType, task.CreatedTime.String(), queryNow.Now.String(), task.Timeout)

		task.TaskAfter = jks.TaskDisable
		if err := p.TaskDao.UpdateById(p.DBOperator, task, []string{"task_after"}); err != nil {
			p.Logger.Error("TaskDao.UpdateById failed. PodId: %s, TaskId: %s, Error: %s.", podId, taskId, err.Error())
			return common.NewSysErr(err)
		}
		return nil
	}

	extend, err := task.GetExtends()
	if err != nil {
		p.Logger.Error("Unmarshal task.extends failed, TaskId: %v, Error: %s.", taskId, err.Error())
		return common.NewSysErr(errors.New("unmarshal task.Extends failed"))
	}
	dstHostIp := task.HostIp

	if !extend.AgentFreed {
		if jErr := p.MigrateFailedCleanDst(req.RequestId, dstHostIp, podId); jErr != nil {
			p.Logger.Error("[handleMigrateFailedTask] MigrateFailedCleanDst failed. PodId: %s, Error: %s, Detail: %s",
				podId, jErr.Error(), jErr.Detail())
		} else {
			extend.AgentFreed = true
		}
	}

	if !extend.RmsFreed {
		if jErr := p.RollbackReAlloc(req.RequestId, podId); jErr != nil {
			p.Logger.Error("[handleMigrateFailedTask] RollbackReAlloc failed. PodId: %s, Error: %s, Detail: %s",
				podId, jErr.Error(), jErr.Detail())
		} else {
			extend.RmsFreed = true
		}
	}

	if extend.AgentFreed && extend.RmsFreed {
		task.TaskAfter = jks.TaskDone
	}
	task.Extends = extend.ToString()

	if err := p.TaskDao.UpdateByWhere(p.DBOperator, task, []string{"extends", "task_after"}, task, []string{"id"}); err != nil {
		p.Logger.Error("[handleMigrateFailedTask] TaskDao.UpdateById failed. TaskId: %s, PodId: %s, Error: %s",
			taskId, podId, err.Error())
		return common.NewSysErr(err)
	}

	return nil
}

func (p *TaskService) compensateMigrateTask(req *url.Request, task *bean.Task) common.JvirtError {
	var jErr common.JvirtError

	taskState := task.TaskState

	// (TaskState == finished && TaskAfter = TaskUndo) || (TaskState == pending && TaskBefore = TaskUndo)
	switch taskState {
	case jks.TaskPending:
		jErr = p.compensatePendingTask(req, task)
	case jks.TaskFinished:
		jErr = p.handleMigrateFinishedTask(req, task)
	case jks.TaskFailed:
		p.Logger.Warn("MigrateFinishedTask can not compensate. TaskId: %v, ReferId: %s", task.Id, task.ReferId)
		jErr = p.handleMigrateFailedTask(req, task)
	default:
		msg := fmt.Sprintf("[compensateMigrateTask] invalid task state: %s", taskState)
		p.Logger.Error(msg)
		return common.NewError(common.RErrTask, common.TErrInvalid, common.PErrState, msg)
	}

	return jErr
}

func (p *TaskService) compensatePodResizeTask(req *url.Request, task *bean.Task) common.JvirtError {
	var jErr common.JvirtError
	taskState := task.TaskState

	taskContent := &api.ResizePodResources{}
	if err := json.Unmarshal([]byte(task.Content), taskContent); err != nil {
		return common.NewError(common.RErrJson, common.TErrError, common.PErrType, err.Error())
	}
	p.Logger.Info("[compensatePodResizeTask] ResizeRype: %s, TaskState: %s", taskContent.ResizeType, taskState)
	if taskContent.ResizeType == jks.ResizePodSameNode {
		switch taskState {
		case jks.TaskPending:
			jErr = p.compensatePendingTask(req, task)
		case jks.TaskFinished:
			jErr = p.handleResizeFinishedTask(req, task)
		case jks.TaskFailed:
			/*
				TODO: resize失败不能补偿, 会影响下次resize
			*/
			queryNow, err := p.TaskDao.QueryNow(p.DBOperator)
			if err != nil {
				p.Logger.Error("TaskDao.QueryNow failed. PodId: %s, TaskId: %s, Error: %s.", task.ReferId, task.Id, err.Error())
				return common.NewSysErr(errors.New("query now from db failed"))
			} //在清理时间范围内打日志，之后不在打印
			if queryNow.Now.After(task.CreatedTime.Add(time.Duration(utils.GetTaskClearResourceTimeout()/10) * time.Second)) {
				p.Logger.Warn("ResizePod same node can not compensate. TaskId: %v, ReferId: %s", task.Id, task.ReferId)
				//jErr = p.handleResizeFailedTask(req, task)
			}
		default:
			msg := fmt.Sprintf("[compensatePodResizeTask] invalid task state: %s", taskState)
			p.Logger.Error(msg)
			return common.NewError(common.RErrTask, common.TErrInvalid, common.PErrState, msg)
		}
	}

	if taskContent.ResizeType == jks.ResizePodDiffNode {
		switch taskState {
		case jks.TaskPending:
			jErr = p.compensatePendingTask(req, task)
		case jks.TaskFinished:
			jErr = p.handleMigrateFinishedTask(req, task)
		case jks.TaskFailed:
			p.Logger.Warn("ResizePod diff node can not compensate. TaskId: %v, ReferId: %s", task.Id, task.ReferId)
			jErr = p.handleMigrateFailedTask(req, task)
		default:
			msg := fmt.Sprintf("[compensatePodResizeTask] invalid task state: %s", taskState)
			p.Logger.Error(msg)
			return common.NewError(common.RErrTask, common.TErrInvalid, common.PErrState, msg)
		}
	}

	return jErr
}

func (p *TaskService) CompensateTask(req *url.Request, params *api.CompenstateTaskRequest) common.JvirtError {
	taskId := params.TaskId

	task, err := p.TaskDao.Query(p.DBOperator, taskId)
	if err != nil {
		p.Logger.Error("[CompensateTask] TaskDao.Query failed. TaskId: %v, Error: %s", taskId, err.Error())
		if dao.IsDataNotFound(err) {
			return common.NewError(common.RErrTask, common.PErrDB, common.TErrNotFound, err.Error())
		}

		return common.NewSysErr(err)
	}

	taskType := task.TaskType
	taskState := task.TaskState
	instanceId := task.ReferId
	p.Logger.Debug("[CompensateTask] TaskId: %v, TaskType: %s, TaskState: %s, InstanceId: %s.", taskId, taskType, taskState, instanceId)

	var jErr common.JvirtError
	switch taskType {
	case jks.PodCreateTask:
		jErr = p.compensatePendingTask(req, task)
	case jks.PodDeleteTask:
		jErr = p.compensateDeleteTask(req, task)
	case jks.PodMigrateTask:
		jErr = p.compensateMigrateTask(req, task)
	case jks.PodResizeTask:
		jErr = p.compensatePodResizeTask(req, task)
	default:
		msg := fmt.Sprintf("unsupported task type %s for pod %s", taskType, instanceId)
		jErr = common.NewError(common.RErrTask, common.TErrUnsupported, common.PErrType, msg)
	}

	p.Logger.Info("[CompensateTask] success. TaskId: %v, TaskType: %s, PodId: %s.", taskId, taskType, instanceId)

	return jErr
}
