package task

import (
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/url"
	"jd.com/jvirt/jvirt-jks-api-server/bean"
	"jd.com/jvirt/jvirt-jks-api-server/dao"
)

func (p *TaskService) ResetTask(req *url.Request, params *api.ResetTaskRequest) common.JvirtError {
	taskId := params.TaskId
	_, err := p.TaskDao.Query(p.DBOperator, taskId)
	if err != nil {
		p.Logger.Error("[ResetTask] TaskDao.Query failed. TaskId: %v, Error: %s.", taskId, err.Error())
		if dao.IsDataNotFound(err) {
			return common.NewError(common.RErrTask, common.PErrDB, common.TErrNotFound, err.Error())
		}
		return common.NewSysErr(err)
	}

	updateTask := &bean.Task{Id: params.TaskId, TaskState: params.TaskState}
	updateFields := []string{"id", "task_state"}
	if params.TaskAfter != nil {
		updateTask.TaskAfter = *params.TaskAfter
		updateFields = append(updateFields, "task_after")
	}
	if params.TaskBefore != nil {
		updateTask.TaskBefore = *params.TaskBefore
		updateFields = append(updateFields, "task_before")
	}

	if err := p.TaskDao.UpdateByWhere(p.DBOperator, updateTask, updateFields, updateTask, []string{"id"}); err != nil {
		p.Logger.Error("[ResetTask] TaskDao.UpdateById failed. TaskId: %v, Error: %s.", taskId, err.Error())
		return common.NewError(common.RErrTask, common.TErrMaintaining, common.PErrId, err.Error())
	}

	return nil
}
