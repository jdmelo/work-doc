package task

import (
	"strings"

	"jd.com/jvirt/jvirt-common/inner/jks/api"
	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/url"
	"jd.com/jvirt/jvirt-jks-api-server/dao"
)

func (p *TaskService) genFilterMap(req *url.Request, params *api.DescribeTasksFilterSpec) map[string]interface{} {
	conditions := make(map[string]interface{})

	if req.Admin == "" {
		conditions["user_id"] = req.UserId
	}

	conditions["status"] = 1

	if params == nil {
		return conditions
	}

	if params.TaskId != 0 {
		conditions["id"] = params.TaskId
	}

	if params.InstanceId != "" {
		conditions["refer_id"] = strings.TrimSpace(params.InstanceId)
	}

	if params.TaskState != "" {
		conditions["task_state"] = strings.TrimSpace(params.TaskState)
	}

	if params.TaskType != "" {
		conditions["task_type"] = strings.TrimSpace(params.TaskType)
	}

	if params.HostIp != "" {
		conditions["host_ip"] = strings.TrimSpace(params.HostIp)
	}

	return conditions
}

func (p *TaskService) genQuerySqlByFilters(params *api.DescribeTasksRequest, conditions map[string]interface{}, fields string, hasPage bool) string {

	operators := make(map[string]string, 0)
	whereSql := db.GenerateFilterSql(conditions, operators)
	if strings.TrimSpace(whereSql) == "" {
		whereSql = "1"
	}
	if hasPage {
		order := "created_time"
		sort := "desc"
		page := db.NewPage(order, sort, params.DescOffset, params.DescLimit)
		whereSql += page.GeneratePageSql()
	}

	table := dao.TableTask
	queryFields := "id"
	if fields != "" {
		queryFields = fields
	}

	querySql := db.GenerateQuerySql(queryFields, table, whereSql)

	p.Logger.Info("genQuerySqlByFilters: %s.", querySql)

	return querySql
}

func (p *TaskService) DescribeTasks(req *url.Request, params *api.DescribeTasksRequest) (*api.DescribeTasksResp, common.JvirtError) {
	resp := &api.DescribeTasksResp{}

	conditions := p.genFilterMap(req, params.Filters)

	// 根据Filters查询返回total count.
	queryCountSql := p.genQuerySqlByFilters(params, conditions, "id", false)
	objects, err := p.TaskDao.QueryByFilters(p.DBOperator, conditions, queryCountSql)
	if err != nil {
		p.Logger.Error("TaskDao.QueryByFilters failed. Filters: %v.", *params)
		return nil, common.NewSysErr(err)
	}
	totalCount := len(objects)
	resp.TotalCount = totalCount
	if totalCount == 0 {
		return resp, nil
	}

	// 根据Page和Filters查询列表
	querySql := p.genQuerySqlByFilters(params, conditions, dao.SelectTaskColumn, true)
	objects, err = p.TaskDao.QueryByFilters(p.DBOperator, conditions, querySql)
	if err != nil {
		p.Logger.Error("TaskDao.QueryByFilters failed. Filters: %v.", *params)
		return nil, common.NewSysErr(err)
	}

	for _, obj := range objects {
		view := obj.ToView()
		resp.Items = append(resp.Items, view)
	}

	return resp, nil
}
