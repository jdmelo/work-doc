package pod

import (
	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/url"
	"jd.com/jvirt/jvirt-jks-api-server/bean"
	"jd.com/jvirt/jvirt-jks-api-server/dao"
)

func (p *PodService) QueryPodCount(params map[string]interface{}, sqlStatement string) (int, common.JvirtError) {
	podIds, err := p.PodDao.QueryIdByFilters(p.DBOperator, params, sqlStatement)
	if err != nil {
		p.Logger.Error("PodDao.QueryIdByFilters failed. SQL: %s, Error: %s", sqlStatement, err.Error())
		return 0, common.NewSysErr(err)
	}

	return len(podIds), nil
}

func (p *PodService) DescribePods(req *url.Request, params map[string]interface{}, sqlStatement string) ([]*jks.Pod, common.JvirtError) {
	podIds, err := p.PodDao.QueryIdByFilters(p.DBOperator, params, sqlStatement)
	if err != nil {
		p.Logger.Error("PodDao.QueryIdByFilters failed. SQL: %s, Error: %s", sqlStatement, err.Error())
		return nil, common.NewSysErr(err)
	}

	if len(podIds) == 0 {
		p.Logger.Info("[DescribePods] pod not found")
		return nil, nil
	}

	pods, err := p.DescribePodByIds(podIds)
	if err != nil {
		p.Logger.Error("[DescribePods] DescribePodByIds failed. Error: %s", err.Error())
		return nil, common.NewError(common.RErrPod, common.TErrError, common.PErrBody, err.Error())
	}

	return pods, nil
}

func (p *PodService) GetPods(req *url.Request, params *api.GetPodsRequest) (*api.DescribePodsResp, common.JvirtError) {
	if params.PodId == "" && params.HostIP == "" {
		p.Logger.Error("[GetPods] PodId or HostIP must be set.")
		return nil, common.NewError(common.RErrRequest, common.TErrMiss, common.PErrParams, "PodId or HostIP miss")
	}
	resPod := &bean.Pod{
		PodId:  params.PodId,
		HostIp: params.HostIP,
	}

	podIds, err := p.PodDao.QueryIdByCond(p.DBOperator, resPod)
	if err != nil {
		p.Logger.Error("[GetPods] PodDao.QueryIdByCond failed. Error: %s", err.Error())
		return nil, common.NewError(common.RErrPod, common.TErrNotFound, common.PErrBody, err.Error())
	}
	podNum := len(podIds)
	if podNum == 0 {
		p.Logger.Info("Pod not found. Query Filters: %+v.", *resPod)
		return nil, nil
	}

	pods, err := p.DescribePodByIds(podIds)
	if err != nil {
		p.Logger.Error("[GetPods] DescribePodByIds failed. Error: %s", err.Error())
		return nil, common.NewError(common.RErrPod, common.TErrError, common.PErrBody, err.Error())
	}

	res := &api.DescribePodsResp{
		TotalCount: podNum,
		Items:      pods,
	}

	return res, nil
}

// 获取任意pod的详细信息， 即使已经删除了。
func (p *PodService) GetRecordPod(req *url.Request, params *api.GetRecordPodRequest) (*jks.Pod, common.JvirtError) {
	podId := params.PodId
	if podId == "" {
		p.Logger.Error("[GetRecordPod] PodId must be set.")
		return nil, common.NewError(common.RErrRequest, common.TErrMiss, common.PErrParams, "PodId miss")
	}

	pod, err := p.DescribeRecordPodById(podId)
	if err != nil {
		p.Logger.Error("[GetRecordPod] DescribeRecordPodById failed. PodId: %s, Error: %s", podId, err.Error())
		if dao.IsDataNotFound(err) {
			return nil, common.NewError(common.RErrPod, common.PErrDB, common.TErrNotFound, err.Error())
		}
		return nil, common.NewSysErr(err)
	}

	return pod, nil
}
