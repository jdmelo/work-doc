package pod

import (
	"context"
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
	"time"

	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils"
	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/golocal"
	"jd.com/jvirt/jvirt-common/utils/sets"
	"jd.com/jvirt/jvirt-common/utils/url"
	"jd.com/jvirt/jvirt-jks-api-server/bean"
	"jd.com/jvirt/jvirt-jks-api-server/constant"
	apiUtils "jd.com/jvirt/jvirt-jks-api-server/utils"
)

type ContainerObjects struct {
	container    *bean.Container
	status       *bean.ContainerStatus
	sysDisk      *bean.ContainerSystemDisk
	image        *bean.ContainerImage
	lProbe       *bean.ContainerProbe
	rProbe       *bean.ContainerProbe
	envs         []*bean.ContainerEnv
	volumeMounts []*bean.ContainerVolumeMount
}

type PodObjects struct {
	task           *bean.Task
	pod            *bean.Pod
	podNetwork     *bean.PodNetwork
	podStatus      *bean.PodStatus
	podCondition   *bean.PodCondition
	podVolumes     []*bean.PodVolume
	podHostAliases []*bean.PodHostAlias
	containers     []*ContainerObjects
}

func (p *PodService) genContainerVolumeMount(req *url.Request, ctx context.Context, cName string, params *api.VolumeMountSpec) (*bean.ContainerVolumeMount, common.JvirtError) {
	podId := ctx.Value(constant.CtxPodId).(string)
	mountPath := params.MountPath

	dbObject := &bean.ContainerVolumeMount{
		PodId:         podId,
		ContainerName: cName,
		PodVolumeName: params.Name,
		MountPath:     mountPath,
	}

	if params.ReadOnly == nil {
		dbObject.ReadOnly = 0
	} else {
		dbObject.ReadOnly = utils.BoolToInt(*params.ReadOnly)
	}

	return dbObject, nil
}

func (p *PodService) genContainerSystemDisk(req *url.Request, ctx context.Context, cName string, params *api.CloudDiskSpec) (*bean.ContainerSystemDisk, common.JvirtError) {
	podId := ctx.Value(constant.CtxPodId).(string)
	az := ctx.Value(constant.CtxAz).(string)
	volId := params.VolumeId
	userId := req.UserId

	resp, jErr := p.CheckVolumeAvailable(userId, az, volId)
	if jErr != nil {
		p.Logger.Error("CheckVolumeAvailable failed. VolumeId: %s, Error: %s, Detail: %s.", volId, jErr.Error(), jErr.Detail())
		return nil, jErr
	}
	volumeView := resp.Data

	dbObject := &bean.ContainerSystemDisk{
		PodId:         podId,
		ContainerName: cName,
		VolumeId:      volId,
		VolumeType:    volumeView.VolumeType,
	}

	if params.FsType == "" {
		dbObject.FsType = "xfs"
	} else {
		dbObject.FsType = params.FsType
	}
	if params.DeleteOnTermination == nil {
		dbObject.DeleteOnTermination = 1
	} else {
		dbObject.DeleteOnTermination = utils.BoolToInt(*params.DeleteOnTermination)
	}

	return dbObject, nil
}

func (p *PodService) genContainerProbe(req *url.Request, ctx context.Context, cName, probeType string, params *api.ProbeSpec) (*bean.ContainerProbe, common.JvirtError) {
	var err error
	podId := ctx.Value(constant.CtxPodId).(string)

	execAction := params.Exec
	httpGetAction := params.HTTPGet
	tcpSocketAction := params.TCPSocket

	actionNum := 0
	probeAction := jks.ProbeActionExec
	probeContent := ""

	if execAction != nil {
		actionNum += 1
		probeAction = jks.ProbeActionExec
		probeContent, err = apiUtils.Marshal(params.Exec)
		if err != nil {
			p.Logger.Error("Marshal ExecSpec failed. Error: %s.", err.Error())
			return nil, common.NewSysErr(err)
		}
	}
	if httpGetAction != nil {
		if actionNum > 0 {
			msg := "probe may not specify more than 1 action type"
			p.Logger.Error(msg)
			return nil, common.NewError(common.RErrRequest, common.TErrInvalid, common.PErrParams, msg)
		}
		actionNum += 1
		probeAction = jks.ProbeActionHttpGet
		probeContent, err = apiUtils.Marshal(params.HTTPGet)
		if err != nil {
			p.Logger.Error("Marshal HTTPGetSpec failed. Error: %s.", err.Error())
			return nil, common.NewSysErr(err)
		}
	}
	if tcpSocketAction != nil {
		if actionNum > 0 {
			msg := "probe may not specify more than 1 action type"
			p.Logger.Error(msg)
			return nil, common.NewError(common.RErrRequest, common.TErrInvalid, common.PErrParams, msg)
		}
		actionNum += 1
		probeAction = jks.ProbeActionTcpSocket
		probeContent, err = apiUtils.Marshal(params.TCPSocket)
		if err != nil {
			p.Logger.Error("Marshal TCPSocketSpec failed. Error: %s.", err.Error())
			return nil, common.NewSysErr(err)
		}
	}

	if actionNum != 1 {
		msg := "only one of exec, httpGet and tcpSocket should be specified"
		p.Logger.Error(msg)
		return nil, common.NewError(common.RErrRequest, common.TErrInvalid, common.PErrParams, msg)
	}

	dbObject := &bean.ContainerProbe{
		PodId:         podId,
		ContainerName: cName,
		ProbeType:     probeType,
		ProbeAction:   probeAction,
		Content:       probeContent,
	}

	if params.InitialDelaySeconds == nil {
		dbObject.InitialDelaySeconds = 10
	} else {
		dbObject.InitialDelaySeconds = *params.InitialDelaySeconds
	}
	if params.PeriodSeconds == nil {
		dbObject.PeriodSeconds = 10
	} else {
		dbObject.PeriodSeconds = *params.PeriodSeconds
	}
	if params.TimeoutSeconds == nil {
		dbObject.TimeoutSeconds = 1
	} else {
		dbObject.TimeoutSeconds = *params.TimeoutSeconds
	}
	if params.FailureThreshold == nil {
		dbObject.FailureThreshold = 3
	} else {
		dbObject.FailureThreshold = *params.FailureThreshold
	}
	if params.SuccessThreshold == nil {
		dbObject.SuccessThreshold = 1
	} else {
		dbObject.SuccessThreshold = *params.SuccessThreshold
	}

	return dbObject, nil
}

func (p *PodService) genContainer(req *url.Request, ctx context.Context, params *api.ContainerSpec) (*bean.Container, common.JvirtError) {
	podId := ctx.Value(constant.CtxPodId).(string)
	instTypeCpu := ctx.Value(constant.CtxInstTypeCpu).(int)
	instTypeMem := ctx.Value(constant.CtxInstTypeMem).(int)
	dbObject := &bean.Container{
		PodId:      podId,
		Name:       params.Name,
		Image:      params.Image,
		Secret:     params.Secret,
		WorkingDir: params.WorkingDir,
		CpuLimit:   instTypeCpu,
		MemLimit:   instTypeMem,
		CpuRequest: 0,
		MemRequest: 0,
	}
	if len(params.Command) != 0 {
		dbObject.Command = strings.Join(params.Command, ",")
	}
	if len(params.Args) != 0 {
		dbObject.Args = strings.Join(params.Args, ",")
	}

	if params.TTY == nil {
		dbObject.TTY = 0
	} else {
		dbObject.TTY = utils.BoolToInt(*params.TTY)
	}

	resources := params.Resources
	if resources != nil {
		reqResources := resources.Requests
		limitResources := resources.Limits

		if reqResources != nil {
			if reqResources.CPU != nil {
				dbObject.CpuRequest = *reqResources.CPU
			}
			if reqResources.MemoryMB != nil {
				dbObject.MemRequest = *reqResources.MemoryMB
			}
		}
		if limitResources != nil {
			if limitResources.CPU != nil {
				dbObject.CpuLimit = *limitResources.CPU
			}
			if limitResources.MemoryMB != nil {
				dbObject.MemLimit = *limitResources.MemoryMB
			}
		}
	}

	return dbObject, nil
}

func (p *PodService) genPodNetwork(req *url.Request, ctx context.Context, params *api.NetworkPortSpec) (*bean.PodNetwork, common.JvirtError) {
	podId := ctx.Value(constant.CtxPodId).(string)
	params.SecurityGroups = sets.NewString(params.SecurityGroups...).List()
	params.Ipv6Addresses = sets.NewString(params.Ipv6Addresses...).List()
	// 检查网络参数正确性.
	if jErr := p.CheckCreatePort(req.UserId, params); jErr != nil {
		p.Logger.Error("CheckCreatePort failed. Error: %s, Detail: %s.", jErr.Error(), jErr.Detail())
		return nil, jErr
	}

	dbObject := &bean.PodNetwork{
		PodId:            podId,
		BootIndex:        1, // TODO: 目前只有一块网卡。
		VpcId:            params.VpcId,
		SubnetId:         params.SubnetId,
		FixedIp:          params.FixedIp,
		Ipv6AddressCount: params.Ipv6AddressCount,
	}

	if len(params.SecurityGroups) != 0 {
		dbObject.SecurityGroups = strings.Join(params.SecurityGroups, ",")
	}
	if len(params.Ipv6Addresses) != 0 {
		dbObject.Ipv6Addresses = strings.Join(params.Ipv6Addresses, ",")
	}

	if params.DeleteOnTermination == nil {
		dbObject.DeleteOnTermination = 1
	} else {
		dbObject.DeleteOnTermination = utils.BoolToInt(*params.DeleteOnTermination)
	}

	return dbObject, nil
}

func (p *PodService) genPodVolume(req *url.Request, ctx context.Context, params *api.VolumeSpec) (*bean.PodVolume, common.JvirtError) {
	var err error
	podId := ctx.Value(constant.CtxPodId).(string)
	az := ctx.Value(constant.CtxAz).(string)

	referId := ""
	volumeContent := ""
	volumeType := jks.PodVolumeTypeJDCloudDisk

	jdcloudDisk := params.JDCloudDisk
	if jdcloudDisk != nil {
		referId = jdcloudDisk.VolumeId
		volumeType = jks.PodVolumeTypeJDCloudDisk

		// 检查Volume的状态。
		resp, jErr := p.CheckVolumeAvailable(req.UserId, az, referId)
		if jErr != nil {
			p.Logger.Error("describeVolume failed. VolId: %s, Error: %s.", referId, jErr.Detail())
			return nil, jErr
		}
		volumeView := resp.Data

		obj := &jks.JDCloudVolumeSource{
			VolumeId: referId,
			Type:     volumeView.VolumeType,
		}
		if jdcloudDisk.FsType == "" {
			obj.FsType = "xfs"
		} else {
			obj.FsType = jdcloudDisk.FsType
		}
		if jdcloudDisk.DeleteOnTermination == nil {
			obj.DeleteOnTermination = true
		} else {
			obj.DeleteOnTermination = *jdcloudDisk.DeleteOnTermination
		}
		if jdcloudDisk.FormatVolume == nil {
			obj.FormatVolume = false
		} else {
			obj.FormatVolume = *jdcloudDisk.FormatVolume
		}
		volumeContent, err = apiUtils.Marshal(obj)
		if err != nil {
			p.Logger.Error("Marshal CloudDiskSpec failed. Error: %s.", err.Error())
			return nil, common.NewSysErr(err)
		}
	}

	dbObject := &bean.PodVolume{
		PodId:      podId,
		Name:       params.Name,
		VolumeType: volumeType,
		ReferId:    referId,
		Content:    volumeContent,
	}

	return dbObject, nil
}

func (p *PodService) genPodHostAlias(req *url.Request, ctx context.Context, params *api.HostAliasSpec) (*bean.PodHostAlias, common.JvirtError) {
	podId := ctx.Value(constant.CtxPodId).(string)

	strSet := sets.NewString(params.Hostnames...)
	hostnames := strSet.List()

	dbObject := &bean.PodHostAlias{
		PodId: podId,
		Ip:    params.IP,
	}

	if len(hostnames) != 0 {
		dbObject.Hostnames = strings.Join(hostnames, ",")
	}

	return dbObject, nil
}

func (p *PodService) genPodStatus(req *url.Request, ctx context.Context) (*bean.PodStatus, common.JvirtError) {
	podId := ctx.Value(constant.CtxPodId).(string)
	dbObject := &bean.PodStatus{
		PodId:     podId,
		Phase:     jks.PodPhasePending,
		Reason:    jks.PodStatusReasonPodCreating,
		Message:   "alloc resources",
		StartTime: time.Now().UTC().Format(time.RFC3339),
	}

	return dbObject, nil
}

func (p *PodService) genPodCondition(req *url.Request, ctx context.Context) (*bean.PodCondition, common.JvirtError) {
	podId := ctx.Value(constant.CtxPodId).(string)

	dbObject := &bean.PodCondition{
		PodId:           podId,
		Reason:          jks.PodStatusReasonPodCreating,
		ConditionType:   jks.PodConditionTypeReady,
		ConditionStatus: jks.PodConditionStatusFalse,
	}

	return dbObject, nil
}

func (p *PodService) genContainerStatus(req *url.Request, ctx context.Context, cName string) (*bean.ContainerStatus, common.JvirtError) {
	podId := ctx.Value(constant.CtxPodId).(string)

	curState := jks.ContainerState{
		Waiting: &jks.ContainerStateWaiting{
			Reason: jks.ContainerReasonCreating,
		},
	}

	content, err := apiUtils.Marshal(curState)
	if err != nil {
		p.Logger.Error("Marshal ContainerState failed. Error: %s.", err.Error())
		return nil, common.NewSysErr(err)
	}

	dbObject := &bean.ContainerStatus{
		PodId:               podId,
		ContainerName:       cName,
		Phase:               jks.ContainerPhasePending,
		Ready:               0,
		RestartCount:        0,
		CurrentState:        jks.ContainerStatusWaiting,
		CurrentStateContent: content,
	}

	return dbObject, nil
}

func (p *PodService) genPodAndTask(req *url.Request, ctx context.Context, params *api.CreatePodRequest) (*bean.Pod, *bean.Task, common.JvirtError) {
	podId := ctx.Value(constant.CtxPodId).(string)

	dbObject := &bean.Pod{
		ResourceType: params.ResourceType,
		PodId:        podId,
		UserId:       req.UserId,
		UserPin:      req.UserPin,
		Name:         params.Name,
		Description:  params.Description,
		InstanceType: params.InstanceType,
		ServiceCode:  params.ServiceCode,
		Az:           params.Az,
		RuntimeType:  params.RuntimeType,
	}
	if params.ResourceType == jks.ResourceTypeNativeContainer {
		dbObject.Name = podId
		dbObject.NcName = params.Name
	}
	if params.Hostname == "" {
		dbObject.Hostname = podId // 默认是PodId。
	} else {
		dbObject.Hostname = params.Hostname
	}
	if params.RestartPolicy == "" {
		dbObject.RestartPolicy = jks.RestartPolicyAlways
	} else {
		dbObject.RestartPolicy = params.RestartPolicy
	}
	if params.TerminationGracePeriodSeconds == nil {
		dbObject.TerminationGracePeriodSeconds = 30
	} else {
		dbObject.TerminationGracePeriodSeconds = *params.TerminationGracePeriodSeconds
	}

	dnsConfig := params.DNSConfig
	if dnsConfig != nil {
		// 去重.
		if len(dnsConfig.Searches) > 0 {
			searchSet := sets.NewString(dnsConfig.Searches...)
			dnsConfig.Searches = searchSet.List()
		}
		if len(dnsConfig.Nameservers) > 0 {
			nameserversSet := sets.NewString(dnsConfig.Nameservers...)
			dnsConfig.Nameservers = nameserversSet.List()
		} else {
			dnsConfig.Nameservers = apiUtils.GetDnsServerUrls()
		}
		hasValueMap := map[string]bool{
			"ndots":    true,
			"timeout":  true,
			"attempts": true,
		}
		for _, option := range dnsConfig.Options {
			if _, ok := hasValueMap[option.Name]; ok {
				if option.Value == "" {
					msg := fmt.Sprintf("dns option %v must be set value", option.Name)
					p.Logger.Error(msg)
					return nil, nil, common.NewError(common.RErrRequest, common.TErrMiss, common.PErrValue, msg)
				}
				if _, err := strconv.ParseUint(strings.TrimSpace(option.Value), 10, 64); err != nil {
					msg := fmt.Sprintf("value of dns option %v format error", option.Name)
					p.Logger.Error(msg)
					return nil, nil, common.NewError(common.RErrRequest, common.TErrInvalid, common.PErrValue, msg)
				}
			} else {
				if option.Value != "" {
					msg := fmt.Sprintf("dns option %v can't set value", option.Name)
					p.Logger.Error(msg)
					return nil, nil, common.NewError(common.RErrRequest, common.TErrInvalid, common.PErrValue, msg)
				}
			}
		}
	} else {
		dnsConfig = &api.DNSConfigSpec{
			Nameservers: apiUtils.GetDnsServerUrls(),
		}
	}
	dnsData, err := apiUtils.Marshal(dnsConfig)
	if err != nil {
		p.Logger.Error("Marshal PodDNSConfigSpec failed. Error: %s.", err.Error())
		return nil, nil, common.NewSysErr(err)
	}
	dbObject.DnsConfig = dnsData

	if params.LogConfig == nil || params.LogConfig.LogDriver == "" {
		params.LogConfig = &api.LogConfigSpec{
			LogDriver: jks.PodLogConfigDriverDefault,
		}
	}
	logData, err := apiUtils.Marshal(params.LogConfig)
	if err != nil {
		p.Logger.Error("Marshal LogConfigSpec failed. Error: %s.", err.Error())
		return nil, nil, common.NewSysErr(err)
	}
	dbObject.LogConfig = logData
	schedulerPolicy := params.SchedulerPolicy
	extends := &bean.Extends{}
	if schedulerPolicy != nil {
		extends.ExcludeHosts = schedulerPolicy.ExcludeHosts
		extends.IncludeHosts = schedulerPolicy.IncludeHosts
		extends.ResourceHints = schedulerPolicy.ResourceHints
	}

	dbTask := &bean.Task{
		UserId:      req.UserId,
		RequestId:   req.RequestId,
		ClientToken: req.ClientToken,
		TaskType:    jks.PodCreateTask,
		ReferId:     podId,
		TaskState:   jks.TaskPending,
		Timeout:     apiUtils.GetTaskApplyResourceTimeout(),
		TaskBefore:  jks.TaskUndo,
		TaskAfter:   jks.TaskDisable,
		RetryTime:   3,
		Extends:     extends.ToString(),
	}

	return dbObject, dbTask, nil
}

func (p *PodService) InsertPodToDB(req *url.Request, podId string, object *PodObjects) common.JvirtError {
	txs := make([]db.FuncT, 0)

	txs = append(txs, func(tx *db.Tx) error {
		return p.TaskDao.Create(tx, object.task)
	})
	txs = append(txs, func(tx *db.Tx) error {
		object.pod.TaskId = object.task.Id
		return p.PodDao.Create(tx, object.pod)
	})
	txs = append(txs, func(tx *db.Tx) error {
		return p.PodNetworkDao.Create(tx, object.podNetwork)
	})
	txs = append(txs, func(tx *db.Tx) error {
		return p.PodStatusDao.Create(tx, object.podStatus)
	})
	txs = append(txs, func(tx *db.Tx) error {
		return p.PodConditionDao.Create(tx, object.podCondition)
	})
	for _, item := range object.podHostAliases {
		tmp := item
		txs = append(txs, func(tx *db.Tx) error {
			return p.PodHostAliasDao.Create(tx, tmp)
		})
	}
	for _, item := range object.podVolumes {
		tmp := item
		txs = append(txs, func(tx *db.Tx) error {
			return p.PodVolumeDao.Create(tx, tmp)
		})
	}

	for _, item := range object.containers {
		c := item

		txs = append(txs, func(tx *db.Tx) error {
			tmp := c.container
			return p.ContainerDao.Create(tx, tmp)
		})
		txs = append(txs, func(tx *db.Tx) error {
			tmp := c.image
			return p.ContainerImageDao.Create(tx, tmp)
		})
		txs = append(txs, func(tx *db.Tx) error {
			tmp := c.status
			return p.ContainerStatusDao.Create(tx, tmp)
		})
		txs = append(txs, func(tx *db.Tx) error {
			tmp := c.sysDisk
			return p.ContainerSystemDiskDao.Create(tx, tmp)
		})

		if c.lProbe != nil {
			txs = append(txs, func(tx *db.Tx) error {
				tmp := c.lProbe
				return p.ContainerProbeDao.Create(tx, tmp)
			})
		}
		if c.rProbe != nil {
			txs = append(txs, func(tx *db.Tx) error {
				tmp := c.rProbe
				return p.ContainerProbeDao.Create(tx, tmp)
			})
		}

		for _, env := range c.envs {
			tmp := env
			txs = append(txs, func(tx *db.Tx) error {
				return p.ContainerEnvDao.Create(tx, tmp)
			})
		}

		for _, vm := range c.volumeMounts {
			tmp := vm
			txs = append(txs, func(tx *db.Tx) error {
				return p.ContainerVolumeMountDao.Create(tx, tmp)
			})
		}

	}

	if err := p.DBOperator.Exec(txs...); err != nil {
		p.Logger.Error("Invoke Insert Pod transaction failed. Error: %s.", err.Error())
		if strings.Contains(err.Error(), "Duplicate entry") {
			return common.NewError(common.RErrPod, common.TErrDuplicate, common.PErrName, "pod.name have to be unique in one user")
		}

		return common.NewSysErr(err)
	}

	return nil
}

func (p *PodService) CheckContainerSpec(req *url.Request, ctx context.Context, params *api.ContainerSpec) (*ContainerObjects, common.JvirtError) {
	object := &ContainerObjects{}
	cName := params.Name
	podId := ctx.Value(constant.CtxPodId).(string)

	imageManifest, jErr := p.CheckImage(req.UserId, params.Image, params.Secret)
	if jErr != nil {
		p.Logger.Error("CheckImage failed. Error: %s, Detail: %s.", jErr.Detail(), jErr.Detail())
		return nil, jErr
	}

	dbCImage := &bean.ContainerImage{
		PodId:            podId,
		ContainerName:    cName,
		RegistryType:     imageManifest.RegistryType,
		RegistryUrl:      imageManifest.RegistryUrl,
		RegistryUsername: imageManifest.RegistryName,
		RegistryPassword: imageManifest.RegistryPassword,
		ImageName:        imageManifest.ImageName,
		ImageDigest:      imageManifest.ImageDigest,
		WorkingDir:       imageManifest.WorkingDir,
	}
	if len(imageManifest.Command) != 0 {
		dbCImage.Command = strings.Join(imageManifest.Command, ",")
	}
	if len(imageManifest.Entrypoint) != 0 {
		dbCImage.Entrypoint = strings.Join(imageManifest.Entrypoint, ",")
	}
	object.image = dbCImage

	dbContainer, jErr := p.genContainer(req, ctx, params)
	if jErr != nil {
		return nil, jErr
	}
	object.container = dbContainer

	dbSystemDisk, jErr := p.genContainerSystemDisk(req, ctx, cName, params.SystemDisk)
	if jErr != nil {
		return nil, jErr
	}
	object.sysDisk = dbSystemDisk

	dbStatus, jErr := p.genContainerStatus(req, ctx, cName)
	if jErr != nil {
		return nil, jErr
	}
	object.status = dbStatus

	lProbe := params.LivenessProbe
	rProbe := params.ReadinessProbe
	if lProbe != nil {
		dbProbe, jErr := p.genContainerProbe(req, ctx, cName, jks.ProbeTypeLiveness, lProbe)
		if jErr != nil {
			return nil, jErr
		}
		object.lProbe = dbProbe
	}
	if rProbe != nil {
		dbProbe, jErr := p.genContainerProbe(req, ctx, cName, jks.ProbeTypeReadiness, rProbe)
		if jErr != nil {
			return nil, jErr
		}
		object.rProbe = dbProbe
	}

	object.envs = make([]*bean.ContainerEnv, 0)
	for _, item := range params.Env {
		dbEnv := &bean.ContainerEnv{
			PodId:         podId,
			ContainerName: cName,
			Source:        jks.ContainerEnvSourceUser,
			Name:          item.Name,
			Value:         item.Value,
		}
		object.envs = append(object.envs, dbEnv)
	}
	for _, item := range imageManifest.Env {
		ret := strings.SplitN(item, "=", 2)
		if len(ret) != 2 {
			continue
		}

		dbEnv := &bean.ContainerEnv{
			PodId:         podId,
			ContainerName: cName,
			Source:        jks.ContainerEnvSourceImage,
			Name:          ret[0],
			Value:         ret[1],
		}
		object.envs = append(object.envs, dbEnv)
	}

	mountPaths := make([]string, 0)
	object.volumeMounts = make([]*bean.ContainerVolumeMount, 0)
	for _, item := range params.VolumeMounts {
		// volume 不能挂载到根目录.
		if strings.Trim(item.MountPath, " ") == "/" {
			msg := fmt.Sprintf("invalid mount path for data volumes, mount_path: %s", item.MountPath)
			p.Logger.Error(msg)
			return nil, common.NewError(common.RErrVolume, common.TErrInvalid, common.PErrMountPath, msg)
		}
		mountPaths = append(mountPaths, item.MountPath)

		dbVolumeMount, jErr := p.genContainerVolumeMount(req, ctx, cName, item)
		if jErr != nil {
			return nil, jErr
		}
		object.volumeMounts = append(object.volumeMounts, dbVolumeMount)
	}
	// 检查目录是否有包含关系。
	if ok := apiUtils.CheckMountPaths(mountPaths); !ok {
		msg := fmt.Sprintf("mount path invalid for data volumes, mount_paths: %s", mountPaths)
		p.Logger.Error(msg)
		return nil, common.NewError(common.RErrRequest, common.TErrInvalid, common.PErrValue, msg)
	}

	return object, nil
}

func (p *PodService) checkPodResources(req *url.Request, ctx context.Context, params *api.CreatePodRequest) common.JvirtError {

	var (
		totalRequestsCpu int
		totalRequestsMem int
	)

	instTypeCpu := ctx.Value(constant.CtxInstTypeCpu).(int)
	instTypeMem := ctx.Value(constant.CtxInstTypeMem).(int)

	for _, container := range params.Containers {
		resources := container.Resources
		if resources == nil {
			totalRequestsCpu += 2
			continue
		}

		limits := resources.Limits
		requests := resources.Requests

		limitsCpu := instTypeCpu
		limitsMem := instTypeMem
		requestsCpu := 2
		requestsMem := 0

		if limits != nil {
			if limits.CPU != nil {
				limitsCpu = *limits.CPU
				if limitsCpu > instTypeCpu {
					msg := fmt.Sprintf("limitsCpu [%v] of container [%s] is gt cpu of instance type [%v]", limitsCpu, container.Name, instTypeCpu)
					return common.NewError(common.RErrRequest, common.TErrInvalid, common.PErrValue, msg)
				}
			}

			if limits.MemoryMB != nil {
				limitsMem = *limits.MemoryMB
				if limitsMem > instTypeMem {
					msg := fmt.Sprintf("limitsMem [%v] of container [%s] is gt mem of instance type [%v]", limitsMem, container.Name, instTypeMem)
					return common.NewError(common.RErrRequest, common.TErrInvalid, common.PErrValue, msg)
				}
			}
		}

		if requests != nil {
			if requests.CPU != nil {
				requestsCpu = *requests.CPU
			}
			if requestsCpu > limitsCpu {
				msg := fmt.Sprintf("requestsCpu [%v] of container [%s] is gt limitsCpu [%v]", requestsCpu, container.Name, limitsCpu)
				return common.NewError(common.RErrRequest, common.TErrInvalid, common.PErrValue, msg)
			}

			if requests.MemoryMB != nil {
				requestsMem = *requests.MemoryMB
			}
			if requestsMem > limitsMem {
				msg := fmt.Sprintf("requestsMem [%v] of container [%s] is gt limitsMem [%v]", requestsMem, container.Name, limitsMem)
				return common.NewError(common.RErrRequest, common.TErrInvalid, common.PErrValue, msg)
			}
		}

		totalRequestsCpu += requestsCpu
		totalRequestsMem += requestsMem
	}

	if totalRequestsCpu > instTypeCpu {
		msg := fmt.Sprintf("totalRequestsCpu [%v] of containers is gt cpu of instance type [%v]", totalRequestsCpu, instTypeCpu)
		return common.NewError(common.RErrRequest, common.TErrInvalid, common.PErrValue, msg)
	}

	if totalRequestsMem > instTypeMem {
		msg := fmt.Sprintf("totalRequestsMem [%v] of containers is gt mem of instance type [%v]", totalRequestsMem, instTypeMem)
		return common.NewError(common.RErrRequest, common.TErrInvalid, common.PErrValue, msg)
	}

	return nil
}

func (p *PodService) CheckPodSpec(req *url.Request, podId string, params *api.CreatePodRequest) (*PodObjects, common.JvirtError) {
	object := &PodObjects{}
	volNum := len(params.Volumes)
	containerNum := len(params.Containers)
	podVolumeNames := make(map[string]interface{})
	jdcloudDiskIds := make(map[string]interface{})
	containerNames := make(map[string]interface{})

	if params.Az == "" {
		defaultAz := apiUtils.GetDefaultAz()
		if defaultAz == "" {
			msg := fmt.Sprintf("default az not set in config_info")
			p.Logger.Error(msg)
			return nil, common.NewError(common.RErrConfigInfo, common.TErrMiss, common.ErrNull, msg)
		}
		params.Az = defaultAz
	}

	if params.ServiceCode == "" {
		params.ServiceCode = jks.ServiceCodeNormal
	}

	if params.RuntimeType == "" {
		params.RuntimeType = jks.RuntimeXagent
	}

	// 由于xagent限制,检查磁盘总数是否超过8个。
	if volNum+containerNum > jks.PodVolumeContainerSum {
		msg := fmt.Sprintf("count of volume is %d, the num of container is %d. sum over %v.", volNum, containerNum, jks.PodVolumeContainerSum)
		p.Logger.Error(msg)
		return nil, common.NewError(common.RErrRequest, common.TErrLimit, common.PErrValue, msg)
	}

	az := params.Az
	//ServiceCode := params.ServiceCode
	instanceType := params.InstanceType
	// 检查instanceType是否存在.
	flavorView, jErr := p.GetFlavorById(instanceType)
	if jErr != nil {
		p.Logger.Error("Check InstanceType failed. InstanceType: %s, Error: %s.", instanceType, jErr.Error())
		return nil, jErr
	}

	ctx := context.WithValue(context.TODO(), constant.CtxPodId, podId)
	ctx = context.WithValue(ctx, constant.CtxAz, az)
	ctx = context.WithValue(ctx, constant.CtxInstTypeCpu, flavorView.Cpu*1000)
	ctx = context.WithValue(ctx, constant.CtxInstTypeMem, flavorView.Memory)

	if jErr := p.checkPodResources(req, ctx, params); jErr != nil {
		p.Logger.Error("checkPodResources failed. Error: %s, Detail: %s.", jErr.Error(), jErr.Detail())
		return nil, jErr
	}

	// 生成pod和task对象.
	dbPod, dbTask, jErr := p.genPodAndTask(req, ctx, params)
	if jErr != nil {
		p.Logger.Error("genPodAndTask failed. Error: %s, Detail: %s.", jErr.Error(), jErr.Detail())
		return nil, jErr
	}
	object.pod = dbPod
	object.task = dbTask

	dbPodNetwork, jErr := p.genPodNetwork(req, ctx, params.PrimaryInterface)
	if jErr != nil {
		p.Logger.Error("genPodNetwork failed. Error: %s, Detail: %s.", jErr.Error(), jErr.Detail())
		return nil, jErr
	}
	object.podNetwork = dbPodNetwork

	dbPodStatus, jErr := p.genPodStatus(req, ctx)
	if jErr != nil {
		p.Logger.Error("genPodStatus failed. Error: %s, Detail: %s.", jErr.Error(), jErr.Detail())
		return nil, jErr
	}
	object.podStatus = dbPodStatus

	dbPodCondition, jErr := p.genPodCondition(req, ctx)
	if jErr != nil {
		p.Logger.Error("genPodCondition failed. Error: %s, Detail: %s.", jErr.Error(), jErr.Detail())
		return nil, jErr
	}
	object.podCondition = dbPodCondition

	object.podHostAliases = make([]*bean.PodHostAlias, 0)
	for _, item := range params.HostAliases {
		dbPodHost, jErr := p.genPodHostAlias(req, ctx, item)
		if jErr != nil {
			p.Logger.Error("genPodHostAlias failed. Error: %s, Detail: %s.", jErr.Error(), jErr.Detail())
			return nil, jErr
		}
		object.podHostAliases = append(object.podHostAliases, dbPodHost)
	}

	object.podVolumes = make([]*bean.PodVolume, 0)
	for _, item := range params.Volumes {
		// 检查pod volume name在pod内是否唯一.
		if _, ok := podVolumeNames[item.Name]; ok {
			msg := fmt.Sprintf("name [%s] of pod volumes is repeated", item.Name)
			p.Logger.Error(msg)
			return nil, common.NewError(common.RErrRequest, common.TErrConflict, common.PErrValue, msg)
		}
		podVolumeNames[item.Name] = nil

		jdcloudDisk := item.JDCloudDisk
		if jdcloudDisk != nil {
			// 如果pod volume是jdcloudDisk记录volumeId, 检查volumeId是否有重复.
			if _, ok := jdcloudDiskIds[jdcloudDisk.VolumeId]; ok {
				msg := fmt.Sprintf("JDCloudDisk id [%s] of pod volumes is repeated", item.JDCloudDisk.VolumeId)
				p.Logger.Error(msg)
				return nil, common.NewError(common.RErrRequest, common.TErrConflict, common.PErrValue, msg)
			}
			jdcloudDiskIds[jdcloudDisk.VolumeId] = nil
		}

		dbPodVolume, jErr := p.genPodVolume(req, ctx, item)
		if jErr != nil {
			p.Logger.Error("genPodVolume failed. Error: %s, Detail: %s.", jErr.Error(), jErr.Detail())
			return nil, jErr
		}
		object.podVolumes = append(object.podVolumes, dbPodVolume)
	}

	for _, item := range params.Containers {
		// 在一个Pod内容器的名称唯一.
		if _, ok := containerNames[item.Name]; ok {
			msg := fmt.Sprintf("name [%s] of pod container is repeated", item.Name)
			p.Logger.Error(msg)
			return nil, common.NewError(common.RErrRequest, common.TErrConflict, common.PErrValue, msg)
		}
		containerNames[item.Name] = nil

		// 检查 container.SystemDisk.VolumeId 与 pod.Volumes.JDCloudDisk.VolumeId是否存在重复.
		sysDisk := item.SystemDisk
		if _, ok := jdcloudDiskIds[sysDisk.VolumeId]; ok {
			msg := fmt.Sprintf("JDCloudDisk id [%s] of pod volumes is repeated", sysDisk.VolumeId)
			p.Logger.Error(msg)
			return nil, common.NewError(common.RErrRequest, common.TErrConflict, common.PErrValue, msg)
		}
		jdcloudDiskIds[sysDisk.VolumeId] = nil

		// container.VolumeMounts.Name in podVolumeNames
		for _, vm := range item.VolumeMounts {
			if _, ok := podVolumeNames[vm.Name]; !ok {
				msg := fmt.Sprintf("container.VolumeMount.Name %s do not belong to pod.Volumes.Name", vm.Name)
				p.Logger.Error(msg)
				return nil, common.NewError(common.RErrRequest, common.TErrConflict, common.PErrValue, msg)
			}
		}
	}

	var (
		completeNum int
		retErr      common.JvirtError
		errC        = make(chan common.JvirtError)
		retC        = make(chan *ContainerObjects)
	)
	object.containers = make([]*ContainerObjects, 0)

	goValue := golocal.GoContext.Get()
	for _, item := range params.Containers {
		go func(c *api.ContainerSpec, rc chan *ContainerObjects, ec chan common.JvirtError) {
			defer func() {
				golocal.GoContext.Remove()
			}()
			golocal.GoContext.Put(goValue)

			p.Logger.Info("Start Check Container: %s", c.Name)
			objects, jErr := p.CheckContainerSpec(req, ctx, c)
			if jErr != nil {
				p.Logger.Error("CheckContainerSpec failed. ContainerName: %s, Error: %s, Detail: %s.", c.Name, jErr.Error(), jErr.Detail())
				ec <- jErr
				return
			}
			retC <- objects
		}(item, retC, errC)
	}

	for {
		select {
		case err := <-errC:
			p.Logger.Error("[CheckPodSpec] CheckContainerSpec failed. Error: %s.", err.Error())
			retErr = err
		case ret := <-retC:
			object.containers = append(object.containers, ret)
		}
		completeNum += 1
		p.Logger.Info("[CheckPodSpec] ContainerNum: %v, CompleteNum: %v.", containerNum, completeNum)
		if completeNum == containerNum {
			p.Logger.Info("CheckContainerSpec finished.")
			break
		}
	}

	if retErr != nil {
		return nil, retErr
	}

	podInsertDB, err := json.Marshal(object)
	if err == nil {
		p.Logger.Debug("[CreatePod] podInsertDB: %s", podInsertDB)
	}

	return object, nil
}

func (p *PodService) CreatePod(req *url.Request, params *api.CreatePodRequest) (string, common.JvirtError) {

	argsJson, err := json.Marshal(params)
	if err == nil {
		p.Logger.Debug("[CreatePod] CreatePod params: %s", argsJson)
	}

	podId := params.PodId

	podObject, jErr := p.CheckPodSpec(req, podId, params)
	if jErr != nil {
		p.Logger.Error("CheckPodSpec failed. Error: %s, Detail: %s.", jErr.Error(), jErr.Detail())
		return "", jErr
	}

	if jErr := p.InsertPodToDB(req, podId, podObject); jErr != nil {
		p.Logger.Error("InsertPodToDB failed. Error: %s, Detail: %s.", jErr.Error(), jErr.Detail())
		return "", jErr
	}

	goValue := golocal.GoContext.Get()
	go func() {
		defer func() {
			golocal.GoContext.Remove()
		}()
		golocal.GoContext.Put(goValue)

		dbPod, err := p.PodDao.Query(p.DBOperator, podId)
		if err != nil {
			p.Logger.Error("PodDao.Query failed. PodId: %s, Error: %s.", podId, err.Error())
			return
		}
		if jErr := p.AllocResourceAndSendTask(podId, dbPod.TaskId); jErr != nil {
			p.Logger.Error("[CreatePod] AllocResourceAndSendTask failed. PodId: %s, Error: %s, Detail: %s",
				podId, jErr.Error(), jErr.Detail())
		}
	}()

	return podId, nil
}
