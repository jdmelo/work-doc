package imagesecret

import (
	"errors"

	"jd.com/jvirt/jvirt-common/inner/jks/api"
	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils"
	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/url"
	"jd.com/jvirt/jvirt-jks-api-server/bean"
)

func (p *ImageSecretService) CreateImageSecret(req *url.Request, params *api.CreateImageSecretRequest) common.JvirtError {
	name := params.Name
	userId := req.UserId

	if params.DockerRegistryData == nil {
		params.DockerRegistryData = &api.DockerRegistryDataSpec{}
	}

	txs := make([]db.FuncT, 0)

	txs = append(txs, func(tx *db.Tx) error {
		// 保证一个User下Secret Name是唯一的。
		objects, err := p.ImageSecretDao.QueryByCond(tx, &bean.ImageSecret{Name: name, UserId: userId})
		if err != nil {
			p.Logger.Error("ImageSecretDao.QueryByCond failed. Error: %s.", err.Error())
			return err
		}
		if len(objects) > 0 {
			p.Logger.Error("name of secret conflict in the user, UserId: %s, Name: %s.", userId, name)
			return errors.New("name of secret conflict in the user")
		}

		return nil
	})

	txs = append(txs, func(tx *db.Tx) error {
		obj := &bean.ImageSecret{
			Id:             utils.GenerateUuid(utils.RSecret),
			UserId:         userId,
			Name:           name,
			CredentialType: params.Type,
			ImageServer:    params.DockerRegistryData.Server,
			UserName:       params.DockerRegistryData.UserName,
			Password:       params.DockerRegistryData.Password,
			Email:          params.DockerRegistryData.Email,
		}
		return p.ImageSecretDao.Create(tx, obj)
	})

	if err := p.DBOperator.Exec(txs...); err != nil {
		p.Logger.Error("Invoke Insert Secret transaction failed. Error: %s.", err.Error())
		return common.NewSysErr(err)
	}

	return nil
}
