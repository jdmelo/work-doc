package imagesecret

import (
	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jks-api-server/dao"
)

type ImageSecretService struct {
	Logger         log.Logger          `inject:""`
	DBOperator     *db.ExtendDB        `inject:""`
	ImageSecretDao *dao.ImageSecretDao `inject:""`
	QuotaDao       *dao.QuotaDao       `inject:""`
}
