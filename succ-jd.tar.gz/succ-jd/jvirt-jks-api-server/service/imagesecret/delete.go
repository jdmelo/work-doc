package imagesecret

import (
	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/url"
	"jd.com/jvirt/jvirt-jks-api-server/dao"
)

func (p *ImageSecretService) DeleteImageSecret(req *url.Request, params *api.DeleteImageSecretRequest) common.JvirtError {
	userId := req.UserId
	name := params.Name

	imageSecret, err := p.ImageSecretDao.Query(p.DBOperator, userId, name)
	if err != nil {
		p.Logger.Error("[DeleteImageSecret] ImageSecretDao.Query failed. UserId: %s, SecretName: %s, Error: %s.",
			userId, name, err.Error())

		if dao.IsDataNotFound(err) {
			return common.NewError(common.RErrImageSecret, common.TErrNotFound, common.PErrDB, err.Error())
		}

		return common.NewSysErr(err)
	}

	secretId := imageSecret.Id

	txs := make([]db.FuncT, 0)
	txs = append(txs, func(tx *db.Tx) error {
		return p.ImageSecretDao.Delete(tx, secretId)
	})
	txs = append(txs, func(tx *db.Tx) error {
		return p.QuotaDao.ReleaseQuota(tx, req.UserId, jks.QuotaTypeSecret, 1)
	})

	if err := p.DBOperator.Exec(txs...); err != nil {
		p.Logger.Error("Exec delete secret transaction failed. SecretId: %s, Error: %s.", secretId, err.Error())
		return common.NewError(common.RErrImageSecret, common.TErrDeleteFailed, common.PErrId, err.Error())
	}

	return nil
}
