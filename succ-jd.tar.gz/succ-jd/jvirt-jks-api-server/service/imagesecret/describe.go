package imagesecret

import (
	"strconv"
	"strings"

	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/url"
	"jd.com/jvirt/jvirt-jks-api-server/dao"
)

func (p *ImageSecretService) genFilterMap(req *url.Request, params *api.DescribeImageSecretFilterSpec) map[string]interface{} {

	conditions := make(map[string]interface{})
	if req.Admin == "" {
		conditions["user_id"] = req.UserId
	}
	conditions["status"] = 1

	if params == nil {
		return conditions
	}

	if len(params.Name) > 0 {
		if strings.TrimSpace(params.Name[0]) != "" {
			conditions["name"] = strings.TrimSpace(params.Name[0])
		}
	}

	if len(params.SecretType) > 0 {
		for index, item := range params.SecretType {
			conditions["credential_type_"+strconv.Itoa(index)] = strings.TrimSpace(item)
		}
	}

	return conditions
}

func (p *ImageSecretService) genQuerySqlByFilters(params *api.DescribeImageSecretsRequest, conditions map[string]interface{}, fields string, hasPage bool) string {
	var (
		nameStr interface{}
	)
	if name, ok := conditions["name"]; ok {
		nameStr = name
		delete(conditions, "name")
	}

	operators := make(map[string]string, 0)
	whereSql := db.GenerateFilterSql(conditions, operators)
	if nameStr != nil {
		whereSql = whereSql + " and instr(name, :name) > 0"
		conditions["name"] = nameStr
	}
	if strings.TrimSpace(whereSql) == "" {
		whereSql = "1"
	}
	if hasPage {
		orderSort := []*db.OrderSort{
			{
				Order: "created_time",
				Sort:  "desc",
			},
			{
				Order: "id",
				Sort:  "desc",
			},
		}
		page := db.NewPageSize(orderSort, params.DescOffset, params.DescLimit)
		whereSql += page.GeneratePageSizeSql()
	}

	table := dao.TableImageSecret
	queryFields := "id"
	if fields != "" {
		queryFields = fields
	}

	querySql := db.GenerateQuerySql(queryFields, table, whereSql)

	p.Logger.Info("genQuerySqlByFilters: %s.", querySql)

	return querySql
}

func (p *ImageSecretService) DescribeImageSecrets(req *url.Request, params *api.DescribeImageSecretsRequest) (*api.DescribeImageSecretsResp, common.JvirtError) {

	resp := &api.DescribeImageSecretsResp{}

	conditions := p.genFilterMap(req, params.Filters)

	// 根据Filters查询返回total count.
	queryCountSql := p.genQuerySqlByFilters(params, conditions, "id", false)
	objects, err := p.ImageSecretDao.QueryByFilters(p.DBOperator, conditions, queryCountSql)
	if err != nil {
		p.Logger.Error("ImageSecretDao.QueryByFilters failed. Filters: %v.", *params)
		return nil, common.NewSysErr(err)
	}
	totalCount := len(objects)
	resp.TotalCount = totalCount
	if totalCount == 0 {
		return resp, nil
	}

	// 根据Page和Filters查询列表
	querySql := p.genQuerySqlByFilters(params, conditions, dao.SelectImageSecretColumn, true)
	objects, err = p.ImageSecretDao.QueryByFilters(p.DBOperator, conditions, querySql)
	if err != nil {
		p.Logger.Error("ImageSecretDao.QueryByFilters failed. Filters: %v.", *params)
		return nil, common.NewSysErr(err)
	}

	for _, obj := range objects {
		view := obj.ToView()
		resp.Secrets = append(resp.Secrets, view)
	}

	return resp, nil
}

func (p *ImageSecretService) DescribeImageSecret(req *url.Request, params *api.DescribeImageSecretRequest) (*jks.ImageSecret, common.JvirtError) {
	userId := req.UserId
	name := params.Name
	object, err := p.ImageSecretDao.Query(p.DBOperator, userId, name)
	if err != nil {
		p.Logger.Error("ImageSecretDao.Query failed. UserId: %s, Name: %s, Error: %s", userId, name, err.Error())

		if dao.IsDataNotFound(err) {
			return nil, common.NewError(common.RErrImageSecret, common.PErrDB, common.TErrNotFound, err.Error())
		}

		return nil, common.NewSysErr(err)
	}

	return object.ToView(), nil
}
