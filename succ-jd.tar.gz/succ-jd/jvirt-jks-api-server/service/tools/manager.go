package tools

import (
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jks-api-server/service/base"
)

type ToolsService struct {
	Logger log.Logger         `inject:""`
	Tools  *base.ImageService `inject:""`
}
