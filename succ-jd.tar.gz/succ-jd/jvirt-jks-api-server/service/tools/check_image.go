package tools

import (
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	"jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/url"
)

func (p *ToolsService) CheckImage(req *url.Request, params *api.CheckImageRequest) model.JvirtError {
	_, jErr := p.Tools.CheckImage(req.UserId, params.Image, params.Secret)
	if jErr != nil {
		p.Logger.Error("[CheckImage] failed. Error: %s, Detail: %s", jErr.Error(), jErr.Detail())
		return jErr
	}

	return nil
}
