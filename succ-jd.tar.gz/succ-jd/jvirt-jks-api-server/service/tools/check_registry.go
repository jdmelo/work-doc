package tools

import (
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	"jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/url"
)

func (p *ToolsService) CheckRegistry(req *url.Request, params *api.CheckRegistryRequest) model.JvirtError {
	regUrl := params.ServerAddress
	regUsername := params.Username
	regPassword := params.Password
	if err := p.Tools.CheckRegistry(regUrl, regUsername, regPassword); err != nil {
		return err
	}

	return nil
}
