package quota

import (
	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jks-api-server/dao"
)

type QuotaService struct {
	Logger     log.Logger    `inject:""`
	DBOperator *db.ExtendDB  `inject:""`
	QuotaDao   *dao.QuotaDao `inject:""`
}
