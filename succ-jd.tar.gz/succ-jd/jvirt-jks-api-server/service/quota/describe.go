package quota

import (
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/url"
	"jd.com/jvirt/jvirt-jks-api-server/bean"
	"jd.com/jvirt/jvirt-jks-api-server/dao"
	"jd.com/jvirt/jvirt-jks-api-server/utils"
)

func (p *QuotaService) DescribeQuota(req *url.Request, params *api.DescribeQuotaRequest) (*api.DescribeQuotaResp, common.JvirtError) {
	var resourceType string

	userId := req.UserId

	if params.ResourceType != "" {
		resourceType = params.ResourceType
	} else if params.Type != "" {
		resourceType = params.Type
	} else {
		return nil, common.NewError(common.RErrQuota, common.TErrNotFound, common.PErrPType, "Quota type not support")
	}

	dbQuota, err := p.QuotaDao.QueryByUserId(p.DBOperator, userId, resourceType)
	if err != nil {
		p.Logger.Error("[DescribeQuota] QueryByUserId failed. UserId: %s, ResourceType: %s, Error: %s.", userId, resourceType, err.Error())
		if !dao.IsDataNotFound(err) {
			return nil, common.NewSysErr(err)
		}

		dbQuota = &bean.Quota{
			UserId:    userId,
			Quota:     utils.GetQuotaLimit(),
			QuotaType: resourceType,
		}
		if err := p.QuotaDao.Create(p.DBOperator, dbQuota); err != nil {
			p.Logger.Error("[DescribeQuota] QuotaDao.Create failed. Error: %s.", err.Error())
			return nil, common.NewError(common.RErrSystem, common.TErrMaintaining, common.ErrNull, err.Error())
		}

		p.Logger.Debug("[DescribeQuota] Create default quota for user %s succeed", userId)
	}

	resp := &api.DescribeQuotaResp{
		UserId:       dbQuota.UserId,
		ResourceType: dbQuota.QuotaType,
		Type:         dbQuota.QuotaType,
		Limit:        dbQuota.Quota,
		Used:         dbQuota.Used,
	}

	return resp, nil
}
