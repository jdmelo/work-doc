package quota

import (
	"fmt"

	"jd.com/jvirt/jvirt-common/inner/jks/api"
	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/url"
	"jd.com/jvirt/jvirt-jks-api-server/dao"
)

func (p *QuotaService) UpdateQuota(req *url.Request, params *api.UpdateQuotaRequest) common.JvirtError {
	var resourceType string

	userId := req.UserId
	newLimit := params.Limit

	if params.ResourceType != "" {
		resourceType = params.ResourceType
	} else if params.Type != "" {
		resourceType = params.Type
	} else {
		return common.NewError(common.RErrQuota, common.TErrNotFound, common.PErrPType, "Quota type not support")
	}

	dbQuota, err := p.QuotaDao.QueryByUserId(p.DBOperator, userId, resourceType)
	if err != nil {
		p.Logger.Error("[UpdateQuota] QueryByUserId failed. UserId: %s, ResourceType: %s, Error: %s.", userId, resourceType, err.Error())
		if dao.IsDataNotFound(err) {
			msg := fmt.Sprintf("Quota not found, userId: %s, resourceType: %s", userId, resourceType)
			p.Logger.Error(msg)
			return common.NewError(common.RErrQuota, common.TErrNotFound, common.PErrId, msg)
		}

		return common.NewSysErr(err)
	}

	dbQuota.Quota = newLimit
	if err := p.QuotaDao.Update(p.DBOperator, dbQuota, []string{"quota"}, []string{"id"}); err != nil {
		p.Logger.Error("[UpdateQuota] QuotaDao.Update failed. UserId: %s, ResourceType: %s, Error: %s.", userId, resourceType, err.Error())
		return common.NewError(common.RErrSystem, common.TErrMaintaining, common.ErrNull, err.Error())
	}

	return nil
}
