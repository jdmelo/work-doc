package base

import (
	"fmt"
	"strings"

	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	"jd.com/jvirt/jvirt-common/integration/network"
	netModel "jd.com/jvirt/jvirt-common/integration/network/model"
	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jks-api-server/bean"
	"jd.com/jvirt/jvirt-jks-api-server/em"
)

type NetworkService struct {
	Logger       log.Logger              `inject:""`
	NetworkCli   network.INetWorkClient  `inject:""`
	EventManager *em.EventManagerService `inject:""`
}

const (
	PortTypeNativeContainer = 9
	PortTypePod             = 10
)

func (p *NetworkService) getHostId(hostname string) (string, common.JvirtError) {
	filter := make(map[string]interface{})
	filter["type"] = 0
	filter["name"] = hostname
	params := &netModel.ListOptions{
		Filter: filter,
		Offset: 0,
		Limit:  -1,
	}
	_, hostView, err := p.NetworkCli.DescribeAdminHostByFilter(params)
	msg := ""
	if err != nil {
		msg = fmt.Sprintf("decribe host failed. Hostname: %s, Error: %s", hostname, err.Error())
	}
	if len(hostView) == 0 {
		msg = fmt.Sprintf("describe host [%s] not found", hostname)
	}
	if msg != "" {
		p.Logger.Error(msg)
		return "", common.NewError(common.RErrNetwork, common.TErrError, common.ErrNull, msg)
	}

	return hostView[0].Id, nil
}

func (p *NetworkService) CheckCreatePort(userId string, params *api.NetworkPortSpec) common.JvirtError {
	vpcId := params.VpcId
	subnetId := params.SubnetId
	fixedIp := params.FixedIp

	//判断是否支持ipv6
	if len(params.Ipv6Addresses) > 0 || params.Ipv6AddressCount > 0 {
		if params.Ipv6AddressCount > 0 && len(params.Ipv6Addresses) > 0 {
			return common.NewError(common.RErrRequest, common.TErrInvalid, common.PErrParams, "port only support one ipv6 address")
		}

		subnetReq := &netModel.DescribeSubnetOptions{TenantId: userId, Id: subnetId}
		subnetView, err := p.NetworkCli.DescribeSubnetById(subnetReq)
		if err != nil {
			p.Logger.Error("[DescribeSubnetById] failed. Error: %s.", err.Error())
			return common.NewError(common.RErrNetwork, common.TErrInvalid, common.ErrNull, err.Error())
		}

		if subnetView.Ipv6Cidr == "" { //不支持ipv6
			p.Logger.Error("subnetId:%s not support ipv6", subnetId)
			return common.NewError(common.RErrNetwork, common.TErrUnsupported, common.ErrNull, fmt.Sprintf("subnetId:%s not support ipv6", subnetId))
		}
	}

	sgMap := make(map[string]int)
	for _, sgId := range params.SecurityGroups {
		if _, ok := sgMap[sgId]; !ok {
			sgMap[sgId] = 1
		}
	}

	reqNetwork := make([]map[string]string, 0)
	reqNetwork = append(reqNetwork, map[string]string{
		"subnet_id":      subnetId,
		"fixed_ip":       fixedIp,
		"ipv6_addresses": strings.Join(params.Ipv6Addresses, ","),
	})

	if err := p.NetworkCli.ValidateNetwork(userId, vpcId, 1, reqNetwork, sgMap); err != nil {
		p.Logger.Error("ValidateNetwork failed. Error: %s.", err.Error())
		return common.NewError(common.RErrNetwork, common.TErrInvalid, common.ErrNull, err.Error())
	}

	return nil
}

// TODO: CreatePort目前不支持幂等。
func (p *NetworkService) CreatePodNetwork(hostname string, dbPod *bean.Pod, dbNetwork *bean.PodNetwork) (*netModel.PortView, common.JvirtError) {
	devId := dbPod.PodId
	hostId, jErr := p.getHostId(hostname)
	if jErr != nil {
		p.Logger.Error("getHostId failed. Hostname: %s, Error: %s.", hostname, jErr.Error())
		return nil, jErr
	}

	params := &netModel.CreatePortOptions{
		TenantId:         dbPod.UserId,
		SubnetId:         dbNetwork.SubnetId,
		FixedIp:          dbNetwork.FixedIp,
		DeviceId:         devId,
		HostId:           hostId,
		Zones:            []string{dbPod.Az},
		DeviceIndex:      dbNetwork.BootIndex,
		Ipv6AddressCount: dbNetwork.Ipv6AddressCount,
	}
	if dbNetwork.SecurityGroups != "" {
		params.SecuritygroupIds = strings.Split(dbNetwork.SecurityGroups, ",")
	}
	if dbNetwork.Ipv6Addresses != "" {
		params.Ipv6Addresses = strings.Split(dbNetwork.Ipv6Addresses, ",")
	}

	if dbPod.ResourceType == jks.ResourceTypeNativeContainer {
		params.Type = PortTypeNativeContainer
	} else {
		params.Type = PortTypePod
	}
	portView, err := p.NetworkCli.CreatePort(params)
	if err != nil {
		msg := fmt.Sprintf("create port failed. PodId: %s, Error: %s", devId, err.Error())
		p.Logger.Error(msg)
		return nil, common.NewError(common.RErrNetwork, common.TErrAllocFailed, common.ErrNull, msg)
	}
	if portView == nil {
		msg := fmt.Sprintf("create port failed. response is nil. PodId: %s", devId)
		p.Logger.Error(msg)
		return nil, common.NewError(common.RErrNetwork, common.TErrAllocFailed, common.ErrNull, msg)
	}

	if len(portView.FixedIps) < 1 {
		msg := fmt.Sprintf("create port failed. FixedIps not exist. PodId: %s", devId)
		p.Logger.Error(msg)
		return nil, common.NewError(common.RErrNetwork, common.TErrAllocFailed, common.ErrNull, msg)
	}

	return portView, nil
}

func (p *NetworkService) DeletePortByPortId(userId, portId string) common.JvirtError {
	params := &netModel.BaseOptions{
		TenantId: userId,
		Id:       portId,
	}
	if err := p.NetworkCli.DeletePort(params); err != nil {
		if strings.Compare(err.Error(), "port.notfound") == 0 {
			p.Logger.Info("[DeletePortByPortId] port has deleted. UserId: %s, PortId: %s", userId, portId)
			return nil
		}

		p.Logger.Error("[DeletePortByPortId] failed. UserId: %s, PortId: %s, Error: %s.", userId, portId, err.Error())
		return common.NewSysErr(err)
	}

	return nil
}
