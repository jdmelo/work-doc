package base

import (
	"fmt"
	"os"
	"testing"

	"jd.com/jvirt/jvirt-common/integration/network"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/url"

	"jd.com/jvirt/jvirt-jks-api-server/bean"
)

const (
	//networkServer = "http://192.168.240.5:19698/cc-server"
	networkServer = "http://10.226.137.197:9698/cc-server"
	networkLog    = "D:/workplace/goproject/src/jd.com/jvirt/jvirt-jks-api-server/service/base/test.log"
)

var net NetworkService

func init() {
	logger := log.New()
	file, err := os.OpenFile(networkLog, os.O_WRONLY|os.O_APPEND|os.O_CREATE, 0755)
	if err == nil {
		logger.SetOutput(file)
	}
	logger.SetLevel("debug")

	domain := networkServer
	cc := network.CcClient{
		HttpClient: url.NewDefaultClient(logger),
		Domain:     domain,
		Logger:     logger,
	}
	cm := &network.CcManager{Client: &cc}

	net = NetworkService{
		Logger:     logger,
		NetworkCli: cm,
	}
}

func TestCheckCreatePort(t *testing.T) {
	userId := "68c6421f3071403a9ef67ad03b999809"
	vpcId := "vpc-8dgcoequ4t"
	subnetId := "subnet-dr8hq3013o"
	fixedIp := "192.168.1.14" //todo 给个已经使用的过的fixedIp 目前不会报错，ipv6分支做处理
	sgs := []string{"sg-39a4x7nkua"}

	err := net.CheckCreatePort(userId, vpcId, subnetId, fixedIp, sgs)
	if err != nil {
		fmt.Println("=============>>>result:", err.Error(), err.Detail())
	}
}

func TestCreatePodNetwork(t *testing.T) {
	hostname := "A04-R08-I137-I207-6001461.JCLOUD.COM"

	dbPod := &bean.Pod{
		PodId:  "pod-hami",
		UserId: "68c6421f3071403a9ef67ad03b999809",
		Az:     "az2",
		HostIp: "10.226.137.207",
	}

	dbNetwork := &bean.PodNetwork{
		PodId:     "pod-hami",
		BootIndex: 0,
		//PortId: "",
		//VpcId: "",
		SubnetId: "subnet-dr8hq3013o",
		//FixedIp: "",
		SecurityGroups: "sg-39a4x7nkua",
	}

	portView, err := net.CreatePodNetwork(hostname, dbPod, dbNetwork)
	if err != nil {
		fmt.Println("=============>>>result:", err.Error(), err.Detail())
		return
	}

	if portView != nil {
		fmt.Println(*portView)
	}
}

func TestDeletePortByPortId(t *testing.T) {
	userId := "68c6421f3071403a9ef67ad03b999809"
	portId := "port-i6bls87jjz"

	err := net.DeletePortByPortId(userId, portId)
	if err != nil {
		fmt.Println("=============>>>result:", err.Error(), err.Detail())
	}
}
