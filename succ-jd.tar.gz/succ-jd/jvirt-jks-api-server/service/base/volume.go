package base

import (
	"fmt"

	"jd.com/jvirt/jvirt-common/integration/volume"
	volModel "jd.com/jvirt/jvirt-common/integration/volume/model"
	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jks-api-server/em"
)

type VolumeService struct {
	Logger       log.Logger              `inject:""`
	VolumeCli    volume.IVolumeManager   `inject:""`
	EventManager *em.EventManagerService `inject:""`
}

func (p *VolumeService) describeVolume(userId, volumeId string) (*volModel.VolumeView, common.JvirtError) {
	params := &volModel.DescribeVolumeParams{
		TenantId: userId,
		Id:       volumeId,
	}
	volView, err := p.VolumeCli.DescribeVolume(params)
	if err != nil {
		p.Logger.Error("VolumeCli.describeVolume failed. UserId: %s, VolumeId: %s, Error: %s", userId, volumeId, err.Error())
		return nil, common.NewError(common.RErrVolume, common.TErrInvalid, common.ErrNull, err.Error())
	}

	return volView, nil
}

func (p *VolumeService) CheckVolumeAvailable(userId, az, volumeId string) (*volModel.VolumeView, common.JvirtError) {
	volView, jErr := p.describeVolume(userId, volumeId)
	if jErr != nil {
		p.Logger.Error("describeVolume failed. UserId: %s, VolumeId: %s.", userId, volumeId)
		return nil, jErr
	}
	if volView == nil || volView.Data == nil {
		msg := "describe volume failed"
		p.Logger.Error("VolumeView is nil. UserId: %s, VolumeId: %s.", userId, volumeId)
		return nil, common.NewError(common.RErrVolume, common.TErrInvalid, common.ErrNull, msg)
	}

	multiAttachable := volView.Data.MultiAttachable
	volStatus := volView.Data.Status
	volAz := volView.Data.AzName
	volUserId := volView.Data.TenantId

	if userId != volUserId {
		msg := fmt.Sprintf("volume [%s] is not found, in the tenant [%s]", volumeId, userId)
		p.Logger.Error(msg)
		return volView, common.NewError(common.RErrVolume, common.TErrNotFound, common.PErrUser, msg)
	}

	if volAz != az {
		msg := fmt.Sprintf("volume [%s] is %s, but pod is %s.", volumeId, volAz, az)
		p.Logger.Error(msg)
		return volView, common.NewError(common.RErrVolume, common.TErrConflict, common.PErrAz, msg)
	}

	if multiAttachable {
		msg := fmt.Sprintf("volume is multi attachable, can't use. id: %s.", volumeId)
		p.Logger.Error(msg)
		return volView, common.NewError(common.RErrVolumeStatus, common.TErrInvalid, common.ErrNull, msg)
	}

	if volStatus != volume.VOLUME_AVAILABLE && volStatus != volume.VOLUME_CREATING {
		msg := fmt.Sprintf("volume status is not available. id: %s, status: %s", volumeId, volStatus)
		p.Logger.Error(msg)
		return volView, common.NewError(common.RErrVolumeStatus, common.TErrInvalid, common.ErrNull, msg)
	}

	return volView, nil
}
