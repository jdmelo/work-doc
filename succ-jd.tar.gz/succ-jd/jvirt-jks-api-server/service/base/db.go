package base

import (
	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jks-api-server/dao"
)

type DBService struct {
	Logger                  log.Logger                   `inject:""`
	DBOperator              *db.ExtendDB                 `inject:""`
	TaskDao                 *dao.TaskDao                 `inject:""`
	ConfigInfoDao           *dao.ConfigInfoDao           `inject:""`
	QuotaDao                *dao.QuotaDao                `inject:""`
	EventDao                *dao.EventDao                `inject:""`
	ImageSecretDao          *dao.ImageSecretDao          `inject:""`
	ContainerDao            *dao.ContainerDao            `inject:""`
	ContainerEnvDao         *dao.ContainerEnvDao         `inject:""`
	ContainerProbeDao       *dao.ContainerProbeDao       `inject:""`
	ContainerStatusDao      *dao.ContainerStatusDao      `inject:""`
	ContainerSystemDiskDao  *dao.ContainerSystemDiskDao  `inject:""`
	ContainerVolumeMountDao *dao.ContainerVolumeMountDao `inject:""`
	ContainerImageDao       *dao.ContainerImageDao       `inject:""`
	PodDao                  *dao.PodDao                  `inject:""`
	PodConditionDao         *dao.PodConditionDao         `inject:""`
	PodHostAliasDao         *dao.PodHostAliasDao         `inject:""`
	PodNetworkDao           *dao.PodNetworkDao           `inject:""`
	PodStatusDao            *dao.PodStatusDao            `inject:""`
	PodVolumeDao            *dao.PodVolumeDao            `inject:""`
}
