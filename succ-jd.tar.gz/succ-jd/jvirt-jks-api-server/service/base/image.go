package base

import (
	"fmt"
	"strings"

	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/integration/registry"
	v2 "jd.com/jvirt/jvirt-common/integration/registry/v2"
	"jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/pac"
	"jd.com/jvirt/jvirt-jks-api-server/constant"
	"jd.com/jvirt/jvirt-jks-api-server/dao"
	"jd.com/jvirt/jvirt-jks-api-server/em"
	"jd.com/jvirt/jvirt-jks-api-server/utils"
)

type ImageService struct {
	Logger           log.Logger              `inject:""`
	ImageCli         *v2.RegClientV2         `inject:""`
	EventManager     *em.EventManagerService `inject:""`
	ExtendDBOperator *db.ExtendDB            `inject:""`
	SecretDao        *dao.ImageSecretDao     `inject:""`
}

type ImageManifest struct {
	SchemaVersion    int
	RegistryType     string
	RegistryUrl      string
	RegistryName     string
	RegistryPassword string
	ImageName        string
	ImageDigest      string
	WorkingDir       string
	Command          []string
	Entrypoint       []string
	Env              []string
}

func (p *ImageService) CheckImage(userId, image, secret string) (*ImageManifest, model.JvirtError) {
	var (
		regType     string
		regUsername string
		regPassword string
	)
	jksDockerHubs := utils.GetDockerHubs()
	jcrHubDomainSuffix := utils.GetJcrHubDomainSuffix()

	regUrl, imageName, err := utils.CheckImageNameFormat(image)
	if err != nil {
		p.Logger.Error("[CheckImage] CheckImageNameFormat failed. ImageName: %s, Error: %s.", image, err.Error())
		return nil, model.NewError(model.RErrImage, model.TErrInvalid, model.PErrName, err.Error())
	}

	if secret != "" {
		imageSecret, err := p.SecretDao.Query(p.ExtendDBOperator, userId, secret)
		if err != nil {
			p.Logger.Error("[CheckImage] SecretDao.Query failed. UserId: %s, Secret: %s, Error: %s.", userId, imageSecret, err.Error())
			if dao.IsDataNotFound(err) {
				return nil, model.NewError(model.RErrImageSecret, model.PErrDB, model.TErrNotFound, err.Error())
			}

			return nil, model.NewSysErr(err)
		}
		regUrl = imageSecret.ImageServer
		regUsername = imageSecret.UserName
		regPassword = imageSecret.Password
		regType = jks.ImageSourceSelfHub
	} else {

		for _, item := range jksDockerHubs {
			if strings.Compare(regUrl, item) == 0 {
				if !strings.ContainsRune(imageName, '/') {
					imageName = "library" + "/" + imageName
				}
				regType = jks.ImageSourceDockerHub
				break
			}
		}

		if regType == "" {
			if strings.HasSuffix(regUrl, jcrHubDomainSuffix) {
				regType = jks.ImageSourceJcrHub
				regUsername = userId
				regPassword = utils.GetJcrHubPassword()
			} else {
				msg := fmt.Sprintf("The registry url %s not support.", regUrl)
				p.Logger.Error(msg)
				return nil, model.NewError(model.RErrImage, model.TErrInvalid, model.PErrUrl, msg)
			}
		}
	}

	imageTag := "latest"
	images := strings.Split(imageName, ":")
	if len(images) > 2 || len(images) == 0 {
		p.Logger.Error("[CheckImage] Format of image name invalid. ImageName: %s.", imageName)
		return nil, model.NewError(model.RErrImage, model.TErrInvalid, model.PErrName, "format of image name invalid")
	}
	if len(images) == 2 {
		imageName = images[0]
		imageTag = images[1]
	}

	imageRegistryTimeout := utils.GetImageRegistryTimeout()
	proxyPac := utils.GetProxyPac()
	httpProxy := utils.GetHttpProxy()
	realProxy, err := pac.ProxyParse(proxyPac, regUrl, httpProxy)
	if err != nil {
		p.Logger.Error("[CheckImage] parse proxyPac failed. RegUrl: %s, ProxyPac: %s, HttpProxy: %s.", regUrl, proxyPac, httpProxy)
		return nil, model.NewError(model.RErrProxy, model.TErrInvalid, model.PErrValue, "parse image http proxy pac failed")
	}

	params := &registry.RegistryConfig{
		Server:    regUrl,
		User:      regUsername,
		Password:  regPassword,
		HttpProxy: realProxy,
		Timeout:   imageRegistryTimeout,
	}
	if strings.HasSuffix(regUrl, jcrHubDomainSuffix) {
		realProxy = ""
		params.Server = strings.Replace(regUrl, constant.DefaultJcrHubDomainSuffix, constant.InnerJcrHubDomainSuffix, -1)
	}
	p.Logger.Info("[CheckImage] ImageName: %s, ImageTag：%s, Params: %+v.", imageName, imageTag, *params)

	// 校验registry是否存在, 以及验证用户名和密码是否正确.
	if err := p.ImageCli.CheckRegistry(params); err != nil {
		p.Logger.Error("[CheckImage] CheckRegistry failed. Params: %+v, Error: %s", *params, err.Error())

		if regType == jks.ImageSourceDockerHub {
			for _, dockerHubAddr := range jksDockerHubs {
				if strings.Compare(params.Server, dockerHubAddr) == 0 {
					continue
				}
				params.Server = dockerHubAddr
				regUrl = dockerHubAddr
				err = p.ImageCli.CheckRegistry(params)
				if err != nil {
					p.Logger.Error("[CheckImage] CheckRegistry failed. Params: %+v, Error: %s", *params, err.Error())
					continue
				}
				break
			}
		}

		if err != nil {
			if strings.Contains(err.Error(), "unauthorized 401") {
				return nil, model.NewError(model.RErrRegistry, "unauthorized", "user", "wrong username/password")
			}
			return nil, model.NewError(model.RErrImage, model.TErrInvalid, model.PErrUrl, err.Error())
		}
		p.Logger.Info("[CheckImage] CheckRegistry success. ImageName: %s, ImageTag：%s, Params: %+v", imageName, imageTag, *params)
	}

	manifest, err := p.ImageCli.GetImageManifest(imageName, imageTag, params)
	if err != nil {
		p.Logger.Error("[CheckImage] GetImageManifest failed. ImageName: %s, ImageTag：%s, Params: %+v, Error: %s",
			imageName, imageTag, *params, err.Error())
		return nil, model.NewError(model.RErrImage, model.TErrNotFound, model.PErrName, "get image manifest failed from registry")
	}

	if manifest.ImageInfo == nil || manifest.ImageInfo.Config == nil {
		p.Logger.Error("[CheckImage] GetImageManifest return nil. ImageName: %s, ImageTag：%s, Params: %+v",
			imageName, imageTag, *params)
		return nil, model.NewError(model.RErrImage, model.TErrNotFound, model.PErrName, "check image from registry failed, manifest is nil")
	}

	configInfo := manifest.ImageInfo.Config

	ret := &ImageManifest{
		SchemaVersion:    manifest.SchemaVersion,
		RegistryType:     regType,
		RegistryUrl:      regUrl,
		RegistryName:     regUsername,
		RegistryPassword: regPassword,
		ImageName:        imageName,
		ImageDigest:      string(manifest.Digest),
		WorkingDir:       configInfo.WorkingDir,
		Command:          configInfo.Cmd,
		Entrypoint:       configInfo.Entrypoint,
		Env:              configInfo.Env,
	}

	return ret, nil
}

func (p *ImageService) CheckRegistry(url, username, password string) model.JvirtError {
	proxyPac := utils.GetProxyPac()
	httpProxy := utils.GetHttpProxy()
	imageRegistryTimeout := utils.GetImageRegistryTimeout()
	realProxy, err := pac.ProxyParse(proxyPac, url, httpProxy)
	if err != nil {
		p.Logger.Error("parse proxyPac failed. RegUrl: %s, ProxyPac: %s, HttpProxy: %s.", url, proxyPac, realProxy)
		return model.NewError(model.RErrProxy, model.TErrInvalid, model.PErrValue, "parse image http proxy pac failed")
	}

	params := &registry.RegistryConfig{
		Server:    url,
		User:      username,
		Password:  password,
		HttpProxy: realProxy,
		Timeout:   imageRegistryTimeout,
	}
	if err := p.ImageCli.CheckRegistry(params); err != nil {
		p.Logger.Error("check registry failed. server: %s, username: %s, error: %s", url, username, err.Error())
		if strings.Contains(err.Error(), "unauthorized 401") {
			return model.NewError(model.RErrRegistry, "unauthorized", "user", "wrong username/password")
		}
		return model.NewError(model.RErrImage, model.TErrInvalid, model.PErrUrl, err.Error())
	}

	return nil
}
