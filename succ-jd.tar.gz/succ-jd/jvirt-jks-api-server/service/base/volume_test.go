package base

import (
	"fmt"
	"os"
	"testing"

	"jd.com/jvirt/jvirt-common/integration/volume"
	"jd.com/jvirt/jvirt-common/utils/config"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/url"
)

const (
	volServer = "http://10.226.134.2:80"
	volLog    = "D:/workplace/goproject/src/jd.com/jvirt/jvirt-jks-api-server/service/base/test.log"
)

var vols VolumeService

func init() {
	logger := log.New()
	file, err := os.OpenFile(volLog, os.O_WRONLY|os.O_APPEND|os.O_CREATE, 0755)
	if err == nil {
		logger.SetOutput(file)
	}
	logger.SetLevel("debug")

	newVol := volume.NewDefaultVolumeManager(url.NewDefaultClient(logger), &config.Volume{Url: volServer}, logger)
	vols = VolumeService{
		Logger:    logger,
		VolumeCli: newVol,
	}
}

func TestCheckVolumeAvailable(t *testing.T) {
	userId := "68c6421f3071403a9ef67ad03b999809"
	az := "az2"
	volumeId := "vol-ajdj7m6s8g"

	volumeView, err := vols.CheckVolumeAvailable(userId, az, volumeId)
	fmt.Println("=============>>>result:", err)
	if volumeView != nil {
		fmt.Println("=============>>>result:", *volumeView.Data)
	}
}
