package base

import (
	"fmt"

	"jd.com/jvirt/jvirt-common/inner/jks"
	rmsApi "jd.com/jvirt/jvirt-common/inner/rms/api-server"
	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jks-api-server/em"
)

const (
	FreeRequestId         = "free-request-id"
	AllocStateAlloted     = "alloted"     // newAlloc
	AllocStatePrepareFree = "prepareFree" // oldAlloc
)

type RmsService struct {
	Logger       log.Logger              `inject:""`
	RmsClient    rmsApi.ResourceManager  `inject:""`
	EventManager *em.EventManagerService `inject:""`
}

func (p *RmsService) GetFlavorById(flavorId string) (*rmsApi.FlavorDescription, common.JvirtError) {
	if flavorId == "" {
		msg := fmt.Sprintf("flavorId must be set")
		p.Logger.Error(msg)
		return nil, common.NewError(common.RErrResource, common.PErrParams, common.TErrMiss, msg)
	}

	params := rmsApi.DescribeFlavorRequest{
		FlavorIds:    []string{flavorId},
		OnLineStatus: rmsApi.FlavorAllStatus,
	}
	flavors, jErr := p.RmsClient.DescribeFlavorByFlavorId(params)
	if jErr != nil {
		msg := fmt.Sprintf("DescribeFlavorByUser failed. Params: %+v, Error: %s, Detail: %s", params, jErr.Error(), jErr.Detail())
		p.Logger.Error(msg)
		return nil, jErr
	}
	if len(flavors) == 0 {
		msg := fmt.Sprintf("flavor not found. FlavorId: %s.", flavorId)
		p.Logger.Error(msg)
		return nil, common.NewError(common.RErrResource, common.PErrFlavorId, common.TErrNotFound, msg)
	}
	if len(flavors) > 1 {
		msg := fmt.Sprintf("flavor repeat. FlavorId: %s.", flavorId)
		p.Logger.Error(msg)
		return nil, common.NewError(common.RErrResource, common.PErrFlavorId, common.TErrDuplicate, msg)
	}
	flavor := flavors[0]

	return flavor, nil
}

func (p *RmsService) GetSoldFlavor(userId, az, serviceCode, flavorId string) (*rmsApi.FlavorDescription, common.JvirtError) {

	if flavorId == "" {
		msg := fmt.Sprintf("flavorId must be set")
		p.Logger.Error(msg)
		return nil, common.NewError(common.RErrResource, common.PErrParams, common.TErrMiss, msg)
	}

	if userId == "" {
		msg := fmt.Sprintf("userId must be set")
		p.Logger.Error(msg)
		return nil, common.NewError(common.RErrResource, common.PErrParams, common.TErrMiss, msg)
	}

	if serviceCode == "" {
		msg := fmt.Sprintf("serviceCode id must be set")
		p.Logger.Error(msg)
		return nil, common.NewError(common.RErrResource, common.PErrParams, common.TErrMiss, msg)
	}

	if az == "" {
		msg := fmt.Sprintf("az id must be set")
		p.Logger.Error(msg)
		return nil, common.NewError(common.RErrResource, common.PErrParams, common.TErrMiss, msg)
	}

	params := rmsApi.DescribeFlavorRequest{
		FlavorIds:     []string{flavorId}, // 唯一确定一条flavor信息
		AppId:         jks.AppIdJks,
		UserId:        userId,
		Azs:           []string{az},
		Service:       serviceCode,
		SoldOutStatus: rmsApi.OnSaleStatus,
		OnLineStatus:  rmsApi.FlavorOnlineStatus,
	}
	flavors, jErr := p.RmsClient.DescribeFlavorByUser(params)
	if jErr != nil {
		msg := fmt.Sprintf("DescribeFlavorByUser failed. Params: %+v, Error: %s, Detail: %s", params, jErr.Error(), jErr.Detail())
		p.Logger.Error(msg)
		return nil, jErr
	}
	if len(flavors) == 0 {
		msg := fmt.Sprintf("flavor not found. UserId: %s, FlavorId: %s, Az: %s, ServiceCode: %s.", userId, flavorId, az, serviceCode)
		p.Logger.Error(msg)
		return nil, common.NewError(common.RErrResource, common.PErrFlavorId, common.TErrNotFound, msg)
	}
	if len(flavors) > 1 {
		msg := fmt.Sprintf("flavor repeat. UserId: %s, FlavorId: %s, Az: %s, ServiceCode: %s.", userId, flavorId, az, serviceCode)
		p.Logger.Error(msg)
		return nil, common.NewError(common.RErrResource, common.PErrFlavorId, common.TErrDuplicate, msg)
	}
	flavorView := flavors[0]

	isSoldOut := true // 表示是否下线或者售罄
	onSaleStatuses := flavorView.SoldFlavorDescription
	for _, item := range onSaleStatuses {
		if item.OnlineStatus == rmsApi.FlavorOnlineStatus && item.SoldOutStatus == rmsApi.OnSaleStatus {
			isSoldOut = false
			break
		}
	}

	if isSoldOut {
		msg := fmt.Sprintf("flavor is offline or sold out. UserId: %s, FlavorId: %s, Az: %s, ServiceCode: %s.", userId, flavorId, az, serviceCode)
		p.Logger.Error(msg)
		return nil, common.NewError(common.RErrResource, common.PErrFlavorId, common.TErrNotEnough, msg)
	}

	return flavorView, nil
}

func (p *RmsService) freeResource(requestId, allocId, freeEffect, freeType string) common.JvirtError {
	params := &rmsApi.FreeResourceRequest{
		AllocId:    allocId,
		RequestId:  requestId,
		FreeType:   freeType,
		FreeEffect: freeEffect, // 由于什么原因请求释放, 例如: 计算节点故障创建instance失败.
	}

	if jErr := p.RmsClient.FreeResource(params); jErr != nil {
		msg := fmt.Sprintf("[freeResource] failed. AllocId: %s, FreeEffect: %s, FreeType: %s, Error: %s, Detail: %s",
			allocId, freeEffect, freeType, jErr.Error(), jErr.Detail())
		p.Logger.Error(msg)
		event := &em.DependenceEvent{
			Type:   em.RMS,
			Action: em.FreeResource,
			Result: em.Fail,
			Detail: msg,
		}
		p.EventManager.NotifyDependenceEvent(event, requestId)

		return jErr
	}

	p.Logger.Info("[freeResource] success. AllocId: %v, FreeEffect: %s, FreeType: %s.", allocId, freeEffect, freeType)

	return nil
}

/*
在迁移完成后,需要释放以前的资源.
*/
func (p *RmsService) FreeOldAlloc(requestId, oldAllocId, freeEffect string) common.JvirtError {
	if jErr := p.freeResource(requestId, oldAllocId, freeEffect, rmsApi.TypicalFreeReAlloc); jErr != nil {
		p.Logger.Error("[FreeOldAlloc] failed. Error: %s", jErr.Error())
		return jErr
	}

	return nil
}

/*
迁移失败后,需要释放新申请的资源.
*/
func (p *RmsService) RollbackReAlloc(requestId, resourceId string) common.JvirtError {
	params := &rmsApi.RollbackReAllocRequest{
		ResourceId: resourceId,
		RequestId:  requestId,
	}

	if jErr := p.RmsClient.RollbackReAlloc(params); jErr != nil {
		p.Logger.Error("[RollbackReAlloc] RMS rollback realloc failed. ResourceId: %s, Error: %s, Detail: %s",
			resourceId, jErr.Error(), jErr.Detail())
		return jErr
	}

	return nil
}

/*
释放instance对应的alloc, 针对allocId没有保存数据库的情况.
*/
func (p *RmsService) ClearResource(reqId, resId, freeEffect string) common.JvirtError {

	if reqId == "" {
		reqId = FreeRequestId
	}

	allocs, jErr := p.RmsClient.GetAllocByResourceId(&rmsApi.QueryAllocByResource{ResourceId: resId})
	if jErr != nil {
		p.Logger.Error("[ClearResource] GetAllocByResourceId failed. ResourceId: %s, Error: %s, Detail: %s", resId, jErr.Error(), jErr.Detail())
		return jErr
	}

	allocNum := len(allocs)
	if allocNum == 0 {
		p.Logger.Info("[ClearResource] The rms resource of instance has free. InstanceId: %s", resId)
		return nil
	}

	if allocNum == 1 {
		allocId := allocs[0].AllocId
		if jErr := p.freeResource(reqId, allocId, freeEffect, rmsApi.TypicalFreeAlloc); jErr != nil {
			p.Logger.Error("FreeResource failed. ResourceId: %s, AllocId: %v.", resId, allocId)
			return jErr
		}
		return nil
	}

	oldAllocId := ""
	newAllocId := ""

	for _, alloc := range allocs {
		allocId := alloc.AllocId
		allocState := alloc.AllocState

		switch allocState {
		case AllocStatePrepareFree:
			oldAllocId = allocId
		case AllocStateAlloted:
			newAllocId = allocId

		default:
			p.Logger.Error("[ClearResource] The rms alloc state is %s, not support. InstanceId: %s, AllocId: %s", allocState, resId, allocId)
			return common.NewError(common.RErrResource, common.TErrDeleteFailed, common.PErrValue, "rms alloc state not support, free resource failed")
		}
	}

	if jErr := p.FreeOldAlloc(reqId, oldAllocId, freeEffect); jErr != nil {
		p.Logger.Error("[ClearResource] FreeOldAlloc failed. InstanceId: %s, AllocId: %s", resId, oldAllocId)
		return jErr
	}

	if jErr := p.freeResource(reqId, newAllocId, freeEffect, rmsApi.TypicalFreeAlloc); jErr != nil {
		p.Logger.Error("FreeResource failed. ResourceId: %s, AllocId: %v.", resId, newAllocId)
		return jErr
	}

	/*
			if jErr := p.RollbackReAlloc(reqId, resId); jErr != nil {
			p.Logger.Error("[ClearResource] RollbackReAlloc failed. InstanceId: %s, AllocId: %s", resId, oldAllocId)
			return jErr
		}

		if jErr := p.freeResource(reqId, oldAllocId, freeEffect, rmsApi.TypicalFreeAlloc); jErr != nil {
			p.Logger.Error("FreeResource failed. ResourceId: %s, AllocId: %v.", resId, newAllocId)
			return jErr
		}
	*/

	return nil
}
