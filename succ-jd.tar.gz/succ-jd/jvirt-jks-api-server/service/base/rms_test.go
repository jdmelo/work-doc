package base

import (
	"fmt"
	"jd.com/jvirt/jvirt-common/inner"
	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/inner/rms"
	rmsApi "jd.com/jvirt/jvirt-common/inner/rms/api-server"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/url"
	"jd.com/jvirt/jvirt-jks-api-server/em"
	"os"
	"testing"
)

const (
	rmsUrl = "http://10.226.137.205:8790/rms-api-server"
	rmsLog = "D:/workplace/goproject/src/jd.com/jvirt/jvirt-jks-api-server/service/base/test.log"
)

var rmsServer *RmsService
var rmsClient *rmsApi.RmsClient

func init() {
	logger := log.New()
	file, err := os.OpenFile(rmsLog, os.O_WRONLY|os.O_APPEND|os.O_CREATE, 0755)
	if err == nil {
		logger.SetOutput(file)
	}
	logger.SetLevel("debug")

	rmsClient = &rmsApi.RmsClient{
		HttpCommonClient: inner.HttpCommonClient{
			HttpClient: url.NewDefaultClient(logger),
			Logger:     logger,
		},
		Url: rmsUrl,
	}

	rmsServer = &RmsService{
		Logger:       logger,
		RmsClient:    rmsClient,
		EventManager: em.NewEventManager(logger),
	}
}

/*
  jks 用到的rms 接口测试
*/

func TestAllocResource(t *testing.T) {
	properties := make([]*rms.Properties, 0)
	properties = append(properties, &rms.Properties{Key: rms.PropertiesHyperDriver, Value: rms.PropertiesDriverAlive, Must: true})

	rmsRequest := &rmsApi.AllocResourceRequest{
		Resource: &rmsApi.Resource{
			Cpu:    uint(2),
			Memory: uint(4096),
			Disk:   uint(0),
		},
		RequestId:   "req-hami-old999",
		Machine:     "general",
		AppId:       jks.AppIdJks,
		ServiceType: rms.ServiceTypeHyper,
		ServiceCode: "normal",
		Az:          "az1",
		UserId:      "68c6421f3071403a9ef67ad03b999809",
		ResourceIds: []string{"pod-hami-666999"},
		Properties:  properties,
		Include:     []string{"10.226.137.206", "10.226.137.207"},
	}

	allocResources, jErr := rmsClient.AllocResource(rmsRequest)
	if jErr != nil {
		fmt.Println(jErr.Detail(), jErr.Detail())
	}
	if allocResources != nil {
		fmt.Println(allocResources[0])
	}
}

func TestReAllocRequest(t *testing.T) {
	properties := make([]*rms.Properties, 0)
	properties = append(properties, &rms.Properties{Key: rms.PropertiesHyperDriver, Value: rms.PropertiesDriverAlive, Must: true})

	rmsRequest := &rmsApi.ReAllocRequest{
		RequestId:  "req-hami-new",
		Az:         "az2",
		UserId:     "68c6421f3071403a9ef67ad03b999809",
		ResourceId: "pod-hami-7777", //todo 只有AllocResource 资源资源存在的情况下才会申请成功，否则返回nil
		//AllocToSameHost :true,
		Resource: &rmsApi.Resource{
			Cpu:    uint(1),
			Memory: uint(1024),
			Disk:   uint(0),
		},
		Machine:     "general",
		ReAllocType: rms.ServiceTypeHyper,
		//Include         :[]string{},
		//Exclude         :[]string{},
	}

	reAllocResource, jErr := rmsClient.ReAlloc(rmsRequest)
	if jErr != nil {
		fmt.Println(jErr.Detail(), jErr.Detail())
	}
	if reAllocResource != nil {
		fmt.Println(reAllocResource)
	}
}

func TestDescribeFlavor(t *testing.T) {
	params := rmsApi.DescribeFlavorRequest{
		FlavorIds: []string{"c.n1.medium"},
	}
	flavors, jErr := rmsClient.DescribeFlavorByFlavorId(params)
	if jErr != nil {
		fmt.Println(jErr)
		return
	}

	fmt.Println(len(flavors))
	if len(flavors) > 0 {
		fmt.Println(*flavors[0])
	}
}

func TestDescribeFlavorByUser(t *testing.T) {
	params := rmsApi.DescribeFlavorRequest{
		AppId:         jks.AppIdJks,
		FlavorIds:     []string{"g.s1.micro"},
		UserId:        "68c6421f3071403a9ef67ad03b999809",
		Azs:           []string{"az2"},
		Service:       "normal",
		SoldOutStatus: 1,
		//Type: 1,
	}

	flavors, jErr := rmsClient.DescribeFlavorByUser(params)
	if jErr != nil {
		fmt.Println(jErr)
		return
	}

	fmt.Println(len(flavors))
	if len(flavors) > 0 {
		fmt.Println(flavors[0])
	}
}

func TestGetAllocByResourceId(t *testing.T) {
	resource := &rmsApi.QueryAllocByResource{
		ResourceId: "c-hmb9hm5ldw",
	}

	resources, jErr := rmsClient.GetAllocByResourceId(resource)
	if jErr != nil {
		fmt.Println(jErr)
		return
	}

	fmt.Println(len(resources))
	if len(resources) > 0 {
		fmt.Println(resources[0])
	}
}

func TestFreeResource(t *testing.T) {
	params := &rmsApi.FreeResourceRequest{
		AllocId:    "alloc-ifuh6kd5bo",
		RequestId:  "req-99999",
		FreeEffect: "lllllllll",
		FreeType:   "FreeAlloc",
		UserId:     "68c6421f3071403a9ef67ad03b999809",
	}

	jErr := rmsClient.FreeResource(params)
	if jErr != nil {
		fmt.Println(jErr)
		return
	}
}

func TestRollbackReAlloc(t *testing.T) {
	params := &rmsApi.RollbackReAllocRequest{
		ResourceId: "pod-hami-666",
		RequestId:  "req-hami",
	}

	jErr := rmsClient.RollbackReAlloc(params)
	if jErr != nil {
		fmt.Println(jErr)
		return
	}
}

/*
  jks 封装的rms 接口测试
*/

func TestGetFlavorById(t *testing.T) {
	flavorId := "c.n1.medium"

	flavor, jErr := rmsServer.GetFlavorById(flavorId)
	if jErr != nil {
		fmt.Println(jErr.Error(), jErr.Detail())
		return
	}

	fmt.Println(*flavor)
}

func TestGetSoldFlavor(t *testing.T) {
	flavorId := "g.s1.micro"
	userId := "68c6421f3071403a9ef67ad03b999809"
	az := "az2"
	sourceType := "normal"

	flavor, jErr := rmsServer.GetSoldFlavor(userId, az, sourceType, flavorId)
	if jErr != nil {
		fmt.Println(jErr.Error(), jErr.Detail())
		return
	}

	fmt.Println(*flavor, flavor.SoldFlavorDescription[0])
}

func TestFreeOldAlloc(t *testing.T) {
	oldAllocId := "alloc-c70w824p9y"
	requestId := "req-hami-000"
	freeEffect := "normal"

	jErr := rmsServer.FreeOldAlloc(requestId, oldAllocId, freeEffect)
	if jErr != nil {
		fmt.Println(jErr.Error(), jErr.Detail())
		return
	}
}

func TestRmsRollbackReAlloc(t *testing.T) {
	resourceId := "pod-hami-666"
	requestId := "req-hami"

	jErr := rmsServer.RollbackReAlloc(requestId, resourceId)
	if jErr != nil {
		fmt.Println(jErr.Error(), jErr.Detail())
		return
	}
}

func TestClearResource(t *testing.T) {
	resId := "pod-hami-666"
	reqId := "req-hami123"
	freeEffect := "freeEffect"

	jErr := rmsServer.ClearResource(reqId, resId, freeEffect)
	if jErr != nil {
		fmt.Println(jErr.Error(), jErr.Detail())
		return
	}
}
