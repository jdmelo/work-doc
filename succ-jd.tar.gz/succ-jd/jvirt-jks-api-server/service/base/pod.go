package base

import (
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"time"

	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	"jd.com/jvirt/jvirt-common/inner/rms"
	rmsApi "jd.com/jvirt/jvirt-common/inner/rms/api-server"
	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils"
	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/retry"
	"jd.com/jvirt/jvirt-jks-api-server/bean"
	"jd.com/jvirt/jvirt-jks-api-server/dao"
	apiUtils "jd.com/jvirt/jvirt-jks-api-server/utils"
)

type PodCommonService struct {
	Logger          log.Logger `inject:""`
	*RmsService     `inject:""`
	*AgentService   `inject:""`
	*NetworkService `inject:""`
	*VolumeService  `inject:""`
	*ImageService   `inject:""`
	*DBService      `inject:""`
}

func (p *PodCommonService) canDeletePod(resourceType, phase string) bool {
	if resourceType == jks.ResourceTypePod {
		switch phase {
		case jks.PodPhaseSucceeded, jks.PodPhaseStopped, jks.PodPhaseRunning, jks.PodPhaseFailed, jks.PodPhaseError:
			return true
		}
	} else {
		switch phase {
		case jks.ContainerPhaseError, jks.ContainerPhaseRunning, jks.ContainerPhaseStopped, jks.ContainerPhaseCreated:
			return true
		}
	}

	return false
}

func (p *PodCommonService) canMigratePod(resourceType, phase string) bool {
	if resourceType == jks.ResourceTypePod {
		switch phase {
		case jks.PodPhaseStopped:
			return true
		}
	} else {
		switch phase {
		case jks.ContainerPhaseStopped:
			return true
		}
	}

	return false
}

func (p *PodCommonService) canResizePod(resourceType, phase string) bool {
	if resourceType == jks.ResourceTypePod {
		switch phase {
		case jks.PodPhaseStopped:
			return true
		}
	} else {
		switch phase {
		case jks.ContainerPhaseStopped:
			return true
		}
	}

	return false
}

func (p *PodCommonService) canStartPod(resourceType, phase string) bool {
	if resourceType == jks.ResourceTypePod {
		switch phase {
		case jks.PodPhaseStopped:
			return true
		}
	} else {
		switch phase {
		case jks.ContainerPhaseStopped:
			return true
		}
	}

	return false
}

func (p *PodCommonService) canRebuildPod(resourceType, phase string) bool {
	if resourceType == jks.ResourceTypePod {
		switch phase {
		case jks.PodPhaseStopped, jks.PodPhaseError:
			return true
		}
	} else {
		switch phase {
		case jks.ContainerPhaseStopped, jks.ContainerPhaseError:
			return true
		}
	}

	return false
}

func (p *PodCommonService) canStopPod(resourceType, phase string) bool {
	if resourceType == jks.ResourceTypePod {
		switch phase {
		case jks.PodPhaseRunning, jks.PodPhaseSucceeded, jks.PodPhaseFailed:
			return true
		}
	} else {
		switch phase {
		case jks.ContainerPhaseRunning:
			return true
		}
	}

	return false
}

func (p *PodCommonService) canUpdatePod(resourceType, phase string) bool {
	if resourceType == jks.ResourceTypePod {
		switch phase {
		case jks.PodPhaseDeleted, jks.PodPhasePending:
			return false
		}
	} else {
		switch phase {
		case jks.ContainerPhaseTerminated, jks.ContainerPhaseCreating:
			return false
		}
	}

	return true
}

func (p *PodCommonService) canGetContainerLogs(resourceType, phase string) bool {
	if resourceType == jks.ResourceTypePod {
		switch phase {
		case jks.PodPhaseRunning, jks.PodPhaseStopped, jks.PodPhaseSucceeded,
			jks.PodPhaseFailed, jks.PodPhaseStopping, jks.PodPhaseStarting, jks.PodPhaseError:
			return true
		}
	} else {
		switch phase {
		case jks.ContainerPhaseStarting, jks.ContainerPhaseStopping,
			jks.ContainerPhaseRunning, jks.ContainerPhaseStopped, jks.ContainerPhaseError:
			return true
		}
	}

	return false
}

func (p *PodCommonService) CheckTaskAndStatus(action, podId string) (*bean.Pod, common.JvirtError) {
	pod, err := p.PodDao.CheckPodExist(p.DBOperator, "", podId)
	if err != nil {
		p.Logger.Error("[checkTaskAndStatus] PodDao.CheckPodExist failed. PodId: %s, Error: %s.", podId, err.Error())
		if dao.IsDataNotFound(err) {
			return nil, common.NewError(common.RErrPod, common.PErrDB, common.TErrNotFound, err.Error())
		}

		return nil, common.NewSysErr(err)
	}

	if pod.TaskId != 0 {
		msg := fmt.Sprintf("pod %s is running other task %v.", podId, pod.TaskId)
		p.Logger.Error(msg)
		return nil, common.NewError(common.RErrPod, common.TErrConflict, common.PErrTask, msg)
	}

	var podPhase string
	resourceType := pod.ResourceType

	if resourceType == jks.ResourceTypePod {
		podStatus, err := p.PodStatusDao.Query(p.DBOperator, podId)
		if err != nil {
			p.Logger.Error("PodStatusDao.Query failed. PodId: %s, Error: %s.", podId, err.Error())
			if dao.IsDataNotFound(err) {
				return nil, common.NewError(common.RErrResource, common.PErrDB, common.TErrNotFound, err.Error())
			}
			return nil, common.NewSysErr(err)
		}

		podPhase = podStatus.Phase
	} else {
		containerStatus, err := p.ContainerStatusDao.Query(p.DBOperator, podId, "")
		if err != nil {
			p.Logger.Error("ContainerStatusDao.Query failed. PodId: %s, Error: %s.", podId, err.Error())
			if dao.IsDataNotFound(err) {
				return nil, common.NewError(common.RErrResource, common.PErrDB, common.TErrNotFound, err.Error())
			}
			return nil, common.NewSysErr(err)
		}

		podPhase = containerStatus.Phase
	}

	switch action {
	case api.ActionDeletePod:
		if !p.canDeletePod(resourceType, podPhase) {
			msg := fmt.Sprintf("The status of pod %s is %s, not allowed to delete", podId, podPhase)
			p.Logger.Error(msg)
			return nil, common.NewError(common.RErrPod, common.TErrConflict, common.PErrStatus, msg)
		}
	case api.ActionMigratePod:
		if !p.canMigratePod(resourceType, podPhase) {
			msg := fmt.Sprintf("The status of pod %s is %s, not allowed to migrate", podId, podPhase)
			p.Logger.Error(msg)
			return nil, common.NewError(common.RErrPod, common.TErrConflict, common.PErrStatus, msg)
		}
	case api.ActionStartPod:
		if !p.canStartPod(resourceType, podPhase) {
			msg := fmt.Sprintf("The status of pod %s is %s, not allowed to start", podId, podPhase)
			p.Logger.Error(msg)
			return nil, common.NewError(common.RErrPod, common.TErrConflict, common.PErrStatus, msg)
		}
	case api.ActionRebuildPod:
		if !p.canRebuildPod(resourceType, podPhase) {
			msg := fmt.Sprintf("The status of pod %s is %s, not allowed to rebuild", podId, podPhase)
			p.Logger.Error(msg)
			return nil, common.NewError(common.RErrPod, common.TErrConflict, common.PErrStatus, msg)
		}
	case api.ActionStopPod:
		if !p.canStopPod(resourceType, podPhase) {
			msg := fmt.Sprintf("The status of pod %s is %s, not allowed to stop", podId, podPhase)
			p.Logger.Error(msg)
			return nil, common.NewError(common.RErrPod, common.TErrConflict, common.PErrStatus, msg)
		}
	case api.ActionUpdatePod:
		if !p.canUpdatePod(resourceType, podPhase) {
			msg := fmt.Sprintf("The status of pod %s is %s, not allowed to update", podId, podPhase)
			p.Logger.Error(msg)
			return nil, common.NewError(common.RErrPod, common.TErrConflict, common.PErrStatus, msg)
		}
	case api.ActionGetContainerLogs:
		if !p.canGetContainerLogs(resourceType, podPhase) {
			msg := fmt.Sprintf("The status of pod %s is %s, not allowed to getContainerLogs", podId, podPhase)
			p.Logger.Error(msg)
			return nil, common.NewError(common.RErrPod, common.TErrConflict, common.PErrStatus, msg)
		}
	case api.ActionResizePod:
		if !p.canResizePod(resourceType, podPhase) {
			msg := fmt.Sprintf("The status of pod %s is %s, not allowed to resize", podId, podPhase)
			p.Logger.Error(msg)
			return nil, common.NewError(common.RErrPod, common.TErrConflict, common.PErrStatus, msg)
		}
	default:
		msg := fmt.Sprintf("CheckTaskAndStatus not support %s", action)
		return nil, common.NewError(common.RErrRequest, common.TErrInvalid, common.PErrParams, msg)
	}

	return pod, nil
}

// 幂等接口。
func (p *PodCommonService) AllocResourceAndSendTask(podId string, taskId int64) common.JvirtError {
	dbPod, err := p.PodDao.Query(p.DBOperator, podId)
	if err != nil {
		p.Logger.Error("PodDao.Query failed. PodId: %s, Error: %s, Detail: %s.", podId, err.Error())
		return common.NewSysErr(err)
	}

	dbTask, err := p.TaskDao.Query(p.DBOperator, taskId)
	if err != nil {
		p.Logger.Error("TaskDao.Query failed. TaskId: %s, Error: %s, Detail: %s.", taskId, err.Error())
		return common.NewSysErr(err)
	}

	var f func(dbPod *bean.Pod, dbTask *bean.Task) (bool, common.JvirtError)

	switch dbTask.TaskType {
	case jks.PodCreateTask:
		f = p.IdempotentAllocResource
	case jks.PodMigrateTask, jks.PodResizeTask:
		f = p.IdempotentReAllocResource
	default:
		return common.NewSysErr(fmt.Errorf("TaskType: %s not support! \n", dbTask.TaskType))
	}

	if isCompensate, jErr := f(dbPod, dbTask); jErr != nil {
		if !isCompensate {
			p.AllocFailedAndNoCompensate(dbPod, dbTask)
		}
		p.Logger.Error("IdempotentAllocResource failed. PodId: %s, Error: %s, Detail: %s.", podId, jErr.Error(), jErr.Detail())

		return jErr
	}

	p.SendRequestToAgent(dbTask)

	return nil
}

// 幂等接口。
func (p *PodCommonService) IdempotentAllocResource(dbPod *bean.Pod, dbTask *bean.Task) (bool, common.JvirtError) {
	podId := dbPod.PodId
	userId := dbPod.UserId
	az := dbPod.Az
	serviceCode := dbPod.ServiceCode
	flavorId := dbPod.InstanceType

	flavorView, jErr := p.GetFlavorById(flavorId)
	if jErr != nil {
		p.Logger.Error("GetSoldFlavor failed. Error: %s", jErr.Error())
		return false, jErr
	}

	extends, err := dbTask.GetExtends()
	if err != nil {
		p.Logger.Error("Unmarshal task.extends failed, TaskId: %v, Error: %s.", dbTask.Id, err.Error())
		return false, common.NewSysErr(errors.New("unmarshal task.Extends failed"))
	}

	properties := make([]*rms.Properties, 0)
	properties = append(properties, &rms.Properties{Key: rms.PropertiesHyperDriver, Value: rms.PropertiesDriverAlive, Must: true})
	rmsRequest := &rmsApi.AllocResourceRequest{
		Resource: &rmsApi.Resource{
			Cpu:    uint(flavorView.Cpu),
			Memory: uint(flavorView.Memory),
			Disk:   uint(flavorView.Disk),
		},
		RequestId:   dbTask.RequestId,
		Machine:     flavorView.Machine,
		AppId:       jks.AppIdJks,
		ServiceType: rms.ServiceTypeHyper,
		ServiceCode: serviceCode,
		Az:          az,
		UserId:      userId,
		ResourceIds: []string{podId},
		Properties:  properties,
		Exclude:     extends.ExcludeHosts,
		Include:     extends.IncludeHosts,
	}
	if len(extends.ResourceHints) != 0 {
		rmsRequest.Tags = strings.Join(extends.ResourceHints, ",")
	}
	allocResources, jErr := p.RmsClient.AllocResource(rmsRequest)
	if jErr != nil {
		p.Logger.Error("[PodAllocResource] Alloc resource failed. PodID: %s, Error: %s, Detail: %s.", podId, jErr.Error(), jErr.Detail())
		if strings.Contains(jErr.Detail(), common.TErrNoNeedCompensate) {
			p.Logger.Debug("alloc resource failed, not need compensate. PodId: %s, Error: %s, Detail: %s.", podId, jErr.Error(), jErr.Detail())
			// 资源申请失败，不可以补偿。
			return false, jErr
		}

		// 资源申请失败，可以补偿。
		return true, jErr
	}
	if len(allocResources) != 1 {
		p.Logger.Error("alloc resource failed. Alloc Count: %v.", len(allocResources))
		// 资源申请失败，可以触发补偿。
		return true, common.NewError(common.RErrResource, common.TErrAllocFailed, common.PErrPod, "alloc resource failed")
	}
	alloc := allocResources[0]

	dbPodNetwork, err := p.PodNetworkDao.Query(p.DBOperator, podId)
	if err != nil {
		p.Logger.Error("PodNetworkDao.Query failed. PodId: %s, Error: %s.", podId, err.Error())
		if dao.IsDataNotFound(err) {
			return false, common.NewError(common.RErrNetwork, common.TErrNotFound, common.PErrDB, err.Error())
		}
		return true, common.NewSysErr(err)
	}
	if dbPodNetwork.PortId == "" {
		portView, jErr := p.CreatePodNetwork(alloc.Hostname, dbPod, dbPodNetwork)
		if jErr != nil {
			p.Logger.Error("CreatePodNetwork failed. PodId: %s, Error: %s.", podId, jErr.Error())
			return true, jErr
		}
		dbPodNetwork.PortId = portView.Id
		dbPodNetwork.FixedIp = portView.FixedIps[0]
		if len(portView.Ipv6Addresses) > 0 {
			dbPodNetwork.Ipv6Addresses = strings.Join(portView.Ipv6Addresses, ",")
		}
	}

	txs := make([]db.FuncT, 0)

	// 更新task
	txs = append(txs, func(tx *db.Tx) error {
		dbTask.TaskState = jks.TaskRunning
		dbTask.TaskBefore = jks.TaskDone
		dbTask.HostIp = alloc.HostIp
		return p.TaskDao.UpdateByWhere(tx, dbTask, []string{"task_before", "host_ip", "task_state"}, dbTask, []string{"id"})
	})

	// 更新PodNetwork
	txs = append(txs, func(tx *db.Tx) error {
		return p.PodNetworkDao.Update(tx, dbPodNetwork, []string{"port_id", "fixed_ip", "ipv6_addresses"}, []string{"id"})
	})

	// 更新Pod
	txs = append(txs, func(tx *db.Tx) error {
		dbPod.AllocId = alloc.AllocId
		dbPod.HostIp = alloc.HostIp
		return p.PodDao.Update(tx, dbPod, []string{"host_ip", "alloc_id"}, []string{"pod_id"})
	})

	if err := p.DBOperator.Exec(txs...); err != nil {
		p.Logger.Error("Exec update Pod, PodStatus and Task transaction failed. PodId: %s, Error: %s.", podId, err.Error())
		return true, common.NewSysErr(err)
	}

	return true, nil
}

func (p *PodCommonService) IdempotentReAllocResource(dbPod *bean.Pod, dbTask *bean.Task) (bool, common.JvirtError) {
	podId := dbPod.PodId
	flavorId := dbPod.InstanceType

	extends, err := dbTask.GetExtends()
	if err != nil {
		p.Logger.Error("Unmarshal task.extends failed, TaskId: %v, Error: %s.", dbTask.Id, err.Error())
		return false, common.NewSysErr(errors.New("unmarshal task.Extends failed"))
	}

	excludeHosts, err := p.GetExcludeHostIps(podId)
	if err != nil {
		p.Logger.Error("[IdempotentReAllocResource] GetExcludeHostIps failed, PodId: %s, Error: %s.", podId, err.Error())
		return false, common.NewSysErr(errors.New(err.Error()))
	}
	extends.ExcludeHosts = append(extends.ExcludeHosts, excludeHosts...)

	properties := make([]*rms.Properties, 0)
	properties = append(properties, &rms.Properties{
		Key:   rms.PropertiesHyperDriver,
		Value: rms.PropertiesDriverAlive,
		Must:  true})

	var allocToSameHost bool
	var taskContent = &api.ResizePodResources{}
	if dbTask.TaskType == jks.PodResizeTask {
		if err := json.Unmarshal([]byte(dbTask.Content), taskContent); err != nil {
			p.Logger.Error("Unmarshal task.Content failed, TaskId: %v, Error: %s.", dbTask.Id, err.Error())
			return false, common.NewSysErr(errors.New("unmarshal task.Content failed"))
		}
		flavorId = taskContent.InstanceType

		allocToSameHost = true //优先同结点
		for _, hosIp := range extends.IncludeHosts {
			allocToSameHost = false //按用户指定
			if hosIp == dbPod.HostIp {
				allocToSameHost = true //用户指定的含有同结点
				break
			}
		}

		for _, hosIp := range extends.ExcludeHosts {
			if hosIp == dbPod.HostIp {
				allocToSameHost = false //用户指定不有同结点
				break
			}
		}
	}

	flavorView, jErr := p.GetFlavorById(flavorId)
	if jErr != nil {
		p.Logger.Error("GetFlavorById failed. FlavorId: %s, Error: %s, Detail: %s", flavorId, jErr.Error(), jErr.Detail())
		return false, jErr
	}

	rmsRequest := &rmsApi.ReAllocRequest{
		Resource: &rmsApi.Resource{
			Cpu:    uint(flavorView.Cpu),
			Memory: uint(flavorView.Memory),
			Disk:   uint(flavorView.Disk),
		},
		Machine:         flavorView.Machine,
		RequestId:       dbTask.RequestId,
		Az:              dbPod.Az,
		ResourceId:      podId,
		UserId:          dbPod.UserId,
		AllocToSameHost: allocToSameHost,
		Exclude:         extends.ExcludeHosts,
		Include:         extends.IncludeHosts,
		Properties:      properties,
	}
	if len(extends.ResourceHints) != 0 {
		rmsRequest.Tags = strings.Join(extends.ResourceHints, ",")
	}
	alloc, jErr := p.RmsClient.ReAlloc(rmsRequest)
	if jErr != nil {
		p.Logger.Error("ReAlloc resource failed, error: %s, detail: %s", jErr.Error(), jErr.Detail())
		if strings.Contains(jErr.Detail(), common.TErrNoNeedCompensate) {
			p.Logger.Debug("error not need compensate: %s", jErr.Detail())
			return false, jErr
		}
		return true, jErr
	}

	if alloc == nil {
		msg := fmt.Sprintf("Realloc resource return is nil, PodId: %s, Error: %s, Detail: %s", podId, jErr.Error(), jErr.Detail())
		p.Logger.Error(msg)
		return true, common.NewError(common.RErrResource, common.TErrAllocFailed, common.PErrPod, msg)
	}
	if alloc.AllocId == extends.OldAllocId {
		return false, common.NewError(common.RErrResource, common.TErrAllocFailed, common.PErrPod, "exist rms resource not free")
	}

	extends.NewAllocId = alloc.AllocId
	dbTask.HostIp = alloc.HostIp
	dbTask.TaskBefore = jks.TaskDone
	dbTask.TaskState = jks.TaskRunning
	dbTask.Extends = extends.ToString()

	if dbTask.TaskType == jks.PodResizeTask {
		if alloc.HostIp == dbPod.HostIp {
			taskContent.ResizeType = jks.ResizePodSameNode
		} else {
			taskContent.ResizeType = jks.ResizePodDiffNode
		}

		resizePodBytes, err := json.Marshal(taskContent)
		if err != nil {
			return false, common.NewError(common.RErrJson, common.TErrInvalid, common.PErrJson, err.Error())
		}
		dbTask.Content = string(resizePodBytes)
	}

	// 更新Task
	txs := make([]db.FuncT, 0)
	txs = append(txs, func(tx *db.Tx) error {
		updateFields := []string{"task_before", "host_ip", "task_state", "content", "extends"}
		return p.TaskDao.UpdateByWhere(tx, dbTask, updateFields, dbTask, []string{"id"})
	})

	if err := p.DBOperator.Exec(txs...); err != nil {
		p.Logger.Error("Exec update PodStatus and Task transaction failed. PodId: %s, Error: %s.", podId, err.Error())
		return true, common.NewSysErr(err)
	}
	return true, nil
}

func (p *PodCommonService) AllocFailedAndNoCompensate(dbPod *bean.Pod, dbTask *bean.Task) error {
	var (
		podPhase  string
		podReason string
		podMsg    string
	)
	podId := dbPod.PodId

	p.Logger.Error("[AllocFailedAndNoCompensate] Update task_state: failed, task_before: done, task_after: done")
	txs := make([]db.FuncT, 0)

	// 更新Task
	taskUpdateField := []string{"task_state"}
	if dbTask.TaskBefore == jks.TaskUndo {
		dbTask.TaskBefore = jks.TaskDone
		taskUpdateField = append(taskUpdateField, "task_before")
	}
	if dbTask.TaskAfter == jks.TaskUndo {
		dbTask.TaskAfter = jks.TaskDone
		taskUpdateField = append(taskUpdateField, "task_after")
	}
	txs = append(txs, func(tx *db.Tx) error {
		dbTask.TaskState = jks.TaskFailed
		return p.TaskDao.UpdateByWhere(tx, dbTask, taskUpdateField, dbTask, []string{"id"})
	})

	// 更新ContainerStatus
	if dbTask.TaskType == jks.PodCreateTask {
		txs = append(txs, func(tx *db.Tx) error {
			curContent, err := apiUtils.Marshal(&jks.ContainerState{})
			if err != nil {
				p.Logger.Error("Unmarshal ContainerState failed. PodId: %s, Error: %s.", podId, err.Error())
				return err
			}
			cond := &bean.ContainerStatus{
				PodId:               podId,
				Phase:               jks.ContainerPhaseError,
				Ready:               utils.BoolToInt(false),
				CurrentState:        "",
				CurrentStateContent: curContent,
				LastState:           "",
				LastStateContent:    curContent,
			}
			return p.ContainerStatusDao.Update(tx, cond, []string{"phase", "ready", "current_state", "current_state_content", "last_state", "last_state_content"}, []string{"pod_id"})
		})

		podPhase = jks.PodPhaseError
		podReason = jks.PodStatusReasonPodCreateFailed
		podMsg = "alloc resources failed, no need compensate"

	} else if dbTask.TaskType == jks.PodResizeTask {
		txs = append(txs, func(tx *db.Tx) error {
			cond := &bean.ContainerStatus{
				PodId: podId,
				Phase: jks.ContainerPhaseStopped,
			}
			return p.ContainerStatusDao.Update(tx, cond, []string{"phase"}, []string{"pod_id"})
		})
		podPhase = jks.PodPhaseStopped
		podReason = jks.PodStatusReasonPodResizeFailed
		podMsg = "resize realloc resources failed, no need compensate"

	} else {
		txs = append(txs, func(tx *db.Tx) error {
			cond := &bean.ContainerStatus{
				PodId: podId,
				Phase: jks.ContainerPhaseStopped,
			}
			return p.ContainerStatusDao.Update(tx, cond, []string{"phase"}, []string{"pod_id"})
		})

		podPhase = jks.PodPhaseStopped
		podReason = jks.PodStatusReasonPodMigrateFailed
		podMsg = "realloc resources failed, no need compensate"
	}

	// 更新PodStatus
	txs = append(txs, func(tx *db.Tx) error {
		dbPodStatus := &bean.PodStatus{
			PodId:   podId,
			Phase:   podPhase,
			Reason:  podReason,
			Message: podMsg,
		}
		return p.PodStatusDao.Update(tx, dbPodStatus, []string{"phase", "reason", "message"}, []string{"pod_id"})
	})

	// 更新Pod
	txs = append(txs, func(tx *db.Tx) error {
		dbPod.TaskId = 0
		return p.PodDao.Update(tx, dbPod, []string{"task_id"}, []string{"pod_id"})
	})

	if err := p.DBOperator.Exec(txs...); err != nil {
		p.Logger.Error("Exec update Pod, PodStatus and Task transaction failed. PodId: %s, Error: %s.", podId, err.Error())
		return err
	}

	return nil
}

func (p *PodCommonService) CreateTaskAndUpdatePodStatus(dbTask *bean.Task, dbPod *bean.Pod, txs []db.FuncT) common.JvirtError {
	podId := dbTask.ReferId
	taskType := dbTask.TaskType

	if txs == nil {
		txs = make([]db.FuncT, 0)
	}

	// 创建Task
	txs = append(txs, func(tx *db.Tx) error {
		return p.TaskDao.Create(tx, dbTask)
	})

	dbPodStatus := &bean.PodStatus{
		PodId: podId,
	}
	dbContainerStatus := &bean.ContainerStatus{
		PodId: podId,
	}

	switch taskType {
	case jks.PodStartTask:
		dbPodStatus.Phase = jks.PodPhaseStarting
		dbPodStatus.Reason = jks.PodStatusReasonPodStarting

		dbContainerStatus.Phase = jks.ContainerPhaseStarting
	case jks.PodRebuildTask:
		dbPodStatus.Phase = jks.PodPhaseRebuilding
		dbPodStatus.Reason = jks.PodStatusReasonPodRebuilding

		dbContainerStatus.Phase = jks.ContainerPhaseRebuilding
	case jks.PodStopTask:
		dbPodStatus.Phase = jks.PodPhaseStopping
		dbPodStatus.Reason = jks.PodStatusReasonPodStopping

		dbContainerStatus.Phase = jks.ContainerPhaseStopping
	case jks.PodDeleteTask:
		dbPodStatus.Phase = jks.PodPhaseDeleting
		dbPodStatus.Reason = jks.PodStatusReasonPodDeleting

		dbContainerStatus.Phase = jks.ContainerPhaseDeleting
	case jks.PodMigrateTask:
		dbPodStatus.Phase = jks.PodPhaseMigrating
		dbPodStatus.Reason = jks.PodStatusReasonPodMigrating

		dbContainerStatus.Phase = jks.ContainerPhaseMigrating

	case jks.PodResizeTask:
		dbPodStatus.Phase = jks.PodPhaseResizing
		dbPodStatus.Reason = jks.PodStatusReasonPodResizing

		dbContainerStatus.Phase = jks.ContainerPhaseResizing
	default:
		p.Logger.Error("CreateTaskAndUpdatePodStatus The taskType %s not support, podId: %s.", taskType, podId)
		return common.NewError(common.RErrPod, common.TErrUnsupported, common.PErrPType, "taskType not support")
	}

	// 更新ContainerStatus
	txs = append(txs, func(tx *db.Tx) error { // jks.PodDeleteTask
		return p.ContainerStatusDao.Update(tx, dbContainerStatus, []string{"phase"}, []string{"pod_id"})
	})

	// 更新PodStatus
	txs = append(txs, func(tx *db.Tx) error { // jks.PodDeleteTask
		return p.PodStatusDao.Update(tx, dbPodStatus, []string{"phase", "reason", "message"}, []string{"pod_id"})
	})

	// 更新Pod
	txs = append(txs, func(tx *db.Tx) error {
		dbPod.TaskId = dbTask.Id
		whPod := &bean.Pod{
			Id:     dbPod.Id,
			TaskId: 0,
		}
		return p.PodDao.UpdateByWhere(tx, dbPod, []string{"task_id"}, whPod, []string{"id"})
	})

	f := func() error {
		if err := p.DBOperator.Exec(txs...); err != nil {
			p.Logger.Warn("Update Pod, PodStatus, ContainerStatus and create Task failed. PodId: %s. Error: %s.", podId, err.Error())
			return err
		}

		return nil
	}
	if err := retry.Retry(f, 3, 1*time.Second); err != nil {
		p.Logger.Error("[CreateTaskAndUpdatePodStatus] %s", err.Error())
		return common.NewSysErr(err)
	}

	return nil
}

func (p *PodCommonService) DeletePodFromDB(dbTask *bean.Task, dbPod *bean.Pod) common.JvirtError {
	podId := dbPod.PodId
	userId := dbPod.UserId
	quotaType := jks.QuotaTypePod
	if dbPod.ResourceType == jks.ResourceTypeNativeContainer {
		quotaType = jks.QuotaTypeContainer
	}

	// 1: 清理资源
	// 删除Pod的网卡资源
	podNetwork, err := p.PodNetworkDao.Query(p.DBOperator, podId)
	if err != nil {
		p.Logger.Error("PodNetworkDao.Query failed. PodId: %s, Error: %s.", podId, err.Error())
		if !dao.IsDataNotFound(err) {
			return common.NewSysErr(err)
		}
	} else {
		if podNetwork.DeleteOnTermination != 0 && podNetwork.PortId != "" {
			if jErr := p.DeletePortByPortId(dbPod.UserId, podNetwork.PortId); jErr != nil {
				p.Logger.Error("DeletePortByPortId failed. PodId: %s, Error: %s, Detail: %s.", podId, jErr.Error(), jErr.Detail())
				return jErr
			}
		}
	}

	txs := make([]db.FuncT, 0)

	txs = append(txs, func(tx *db.Tx) error {
		event := &bean.Event{
			ResourceId:       podId,
			ResourceType:     dbPod.ResourceType,
			OldResourceState: jks.PodPhaseDeleting,
			NewResourceState: jks.PodPhaseDeleted,
			TaskId:           dbTask.Id,
			TaskState:        jks.TaskFinished,
			TaskType:         dbTask.TaskType,
			EventType:        jks.EventTypeTask,
			EventState:       jks.EventStatePending,
		}
		return p.EventDao.Create(tx, event)
	})
	txs = append(txs, func(tx *db.Tx) error {
		return p.TaskDao.UpdateByWhere(p.DBOperator, dbTask, []string{"task_state"}, dbTask, []string{"id"})
	})

	txs = append(txs, func(tx *db.Tx) error {
		return p.ContainerEnvDao.DeleteByPodId(tx, podId)
	})
	txs = append(txs, func(tx *db.Tx) error {
		return p.ContainerSystemDiskDao.DeleteByPodId(tx, podId)
	})
	txs = append(txs, func(tx *db.Tx) error {
		return p.ContainerVolumeMountDao.DeleteByPodId(tx, podId)
	})
	txs = append(txs, func(tx *db.Tx) error {
		return p.ContainerProbeDao.DeleteByPodId(tx, podId)
	})
	txs = append(txs, func(tx *db.Tx) error {
		return p.ContainerImageDao.DeleteByPodId(tx, podId)
	})
	txs = append(txs, func(tx *db.Tx) error {
		curContent, err := apiUtils.Marshal(&jks.ContainerState{})
		if err != nil {
			p.Logger.Error("Unmarshal ContainerState failed. PodId: %s, Error: %s.", podId, err.Error())
			return err
		}
		cond := &bean.ContainerStatus{
			PodId:               podId,
			Phase:               jks.ContainerPhaseTerminated,
			Ready:               utils.BoolToInt(false),
			CurrentState:        "",
			CurrentStateContent: curContent,
			Status:              common.DBStatusDelete,
		}
		return p.ContainerStatusDao.Update(tx, cond, []string{"phase", "ready", "current_state", "current_state_content", "status"}, []string{"pod_id"})
	})
	txs = append(txs, func(tx *db.Tx) error {
		return p.ContainerDao.DeleteByPodId(tx, podId)
	})

	txs = append(txs, func(tx *db.Tx) error {
		return p.PodNetworkDao.DeleteByPodId(tx, podId)
	})
	txs = append(txs, func(tx *db.Tx) error {
		return p.PodVolumeDao.DeleteByPodId(tx, podId)
	})
	txs = append(txs, func(tx *db.Tx) error {
		return p.PodHostAliasDao.DeleteByPodId(tx, podId)
	})
	txs = append(txs, func(tx *db.Tx) error {
		return p.PodConditionDao.DeleteByPodId(tx, podId)
	})
	txs = append(txs, func(tx *db.Tx) error {
		cond := &bean.PodStatus{
			PodId:  podId,
			Phase:  jks.PodPhaseDeleted,
			Reason: jks.PodStatusReasonPodDeleteSuccess,
			Status: common.DBStatusDelete,
		}
		return p.PodStatusDao.Update(tx, cond, []string{"phase", "reason", "status"}, []string{"pod_id"})
	})
	txs = append(txs, func(tx *db.Tx) error {
		dbPod.TaskId = 0
		dbPod.Deleted = podId
		dbPod.Status = common.DBStatusDelete
		return p.PodDao.Update(tx, dbPod, []string{"task_id", "deleted", "status"}, []string{"id"})
	})
	if dbPod.ServiceCode == jks.ServiceCodeNormal {
		txs = append(txs, func(tx *db.Tx) error {
			return p.QuotaDao.ReleaseQuota(p.DBOperator, userId, quotaType, 1)
		})
	}

	if err := p.DBOperator.Exec(txs...); err != nil {
		p.Logger.Error("Exec delete pod transaction failed. PodId: %s, Error: %s.", podId, err.Error())
		return common.NewSysErr(err)
	}

	// 释放RMS申请的资源。
	if jErr := p.ClearResource(dbTask.RequestId, podId, rmsApi.TypicalEffectNormal); jErr != nil {
		p.Logger.Warn("ClearResource failed, trigger compensate. PodId: %s, Error: %s, Detail: %s.", podId, jErr.Error(), jErr.Detail())
		dbTask.TaskAfter = jks.TaskUndo
	} else {
		dbTask.TaskAfter = jks.TaskDone
	}

	if err := p.TaskDao.UpdateByWhere(p.DBOperator, dbTask, []string{"task_after"}, dbTask, []string{"id"}); err != nil {
		p.Logger.Error("Update PodDeleteTask failed. TaskId: %s, Error: %s.", dbTask.Id, err)
		return common.NewSysErr(err)
	}

	return nil
}

func (p *PodCommonService) UpdateContainerStatusTxs(podId string, curStatus *jks.ContainerStatus) ([]db.FuncT, error) {
	cName := curStatus.Name
	p.Logger.Info("UpdateContainerStatus start PodId: %s, ContainerName: %s.", podId, cName)

	dbObject, err := p.ContainerStatusDao.Query(p.DBOperator, podId, cName)
	if err != nil {
		p.Logger.Error("ContainerStatusDao.Query failed. PodId: %s, ContainerName: %s, Error: %s.", podId, cName, err.Error())
		return nil, err
	}

	txs := make([]db.FuncT, 0)

	updateFields := make([]string, 0)

	containerPhase := jks.ContainerPhaseIntegration(curStatus.Phase)
	if containerPhase != "" && strings.Compare(dbObject.Phase, containerPhase) != 0 {
		updateFields = append(updateFields, "phase")
		dbObject.Phase = containerPhase
	}

	if utils.IntToBool(dbObject.Ready) != curStatus.Ready {
		updateFields = append(updateFields, "ready")
		dbObject.Ready = utils.BoolToInt(curStatus.Ready)
	}

	if dbObject.RestartCount != curStatus.RestartCount {
		updateFields = append(updateFields, "restart_count")
		dbObject.RestartCount = curStatus.RestartCount
	}

	if curStatus.State != nil {
		curState := curStatus.State.GetState()
		updateFields = append(updateFields, "current_state")
		updateFields = append(updateFields, "current_state_content")
		dbObject.CurrentState = curState
		v, err := apiUtils.Marshal(curStatus.State)
		if err != nil {
			p.Logger.Error("Invoke utils.Marshal failed. Error: %s.", err.Error())
			return nil, err
		}
		dbObject.CurrentStateContent = v
	}

	if curStatus.LastState != nil {
		lastState := curStatus.LastState.GetState()
		updateFields = append(updateFields, "last_state")
		updateFields = append(updateFields, "last_state_content")
		dbObject.LastState = lastState
		v, err := apiUtils.Marshal(curStatus.LastState)
		if err != nil {
			p.Logger.Error("Invoke utils.Marshal failed. Error: %s.", err.Error())
			return nil, err
		}
		dbObject.LastStateContent = v
	}

	if len(updateFields) == 0 {
		p.Logger.Info("ContainerStatus no update. PodId: %s, ContainerName: %s.", podId, cName)
		return nil, nil
	}

	txs = append(txs, func(tx *db.Tx) error {
		if err := p.ContainerStatusDao.Update(tx, dbObject, updateFields, []string{"id"}); err != nil {
			p.Logger.Error("ContainerStatusDao.Update failed. PodId: %s, ContainerName: %s, Error: %s.", podId, cName, err.Error())
			return err
		}
		return nil
	})

	p.Logger.Info("UpdateContainerStatus finished PodId: %s, ContainerName: %s.", podId, cName)

	return txs, nil
}

func (p *PodCommonService) UpdatePodConditionTxs(podId string, curPodCond *jks.PodCondition) (db.FuncT, error) {
	conditionType := curPodCond.Type

	p.Logger.Info("UpdatePodCondition start. PodId: %s, ContainerType: %s.", podId, conditionType)

	dbObject, err := p.PodConditionDao.Query(p.DBOperator, podId, conditionType)
	if err != nil {
		p.Logger.Error("PodConditionDao.Query failed. PodId: %s, ContainerType: %s, Error: %s.", podId, conditionType, err.Error())
		return nil, err
	}

	updateFields := make([]string, 0)

	if strings.Compare(dbObject.Reason, curPodCond.Reason) != 0 {
		updateFields = append(updateFields, "reason")
		dbObject.Reason = curPodCond.Reason
	}

	if strings.Compare(dbObject.Message, curPodCond.Message) != 0 {
		updateFields = append(updateFields, "message")
		dbObject.Message = curPodCond.Message
	}

	if strings.Compare(dbObject.ConditionStatus, curPodCond.Status) != 0 {
		updateFields = append(updateFields, "condition_status")
		dbObject.ConditionStatus = curPodCond.Status
	}

	//if strings.Compare(dbObject.LastProbeTime, curPodCond.LastProbeTime) != 0 {
	//	updateFields = append(updateFields, "last_probe_time")
	//	dbObject.LastProbeTime = curPodCond.LastProbeTime
	//}

	if strings.Compare(dbObject.LastTransitionTime, curPodCond.LastTransitionTime) != 0 {
		updateFields = append(updateFields, "last_transition_time")
		dbObject.LastTransitionTime = curPodCond.LastTransitionTime
	}

	if len(updateFields) == 0 {
		p.Logger.Info("PodCondition no update. PodId: %s, ContainerType: %s.", podId, conditionType)
		return nil, nil
	}

	updatePodConditionTx := func(tx *db.Tx) error {
		if err := p.PodConditionDao.Update(tx, dbObject, updateFields, []string{"id"}); err != nil {
			p.Logger.Error("PodConditionDao.Update failed. PodId: %s, ContainerType: %s, Error: %s.", podId, conditionType, err.Error())
			return err
		}
		return nil
	}

	p.Logger.Info("UpdatePodCondition finished. PodId: %s, ContainerType: %s.", podId, conditionType)

	return updatePodConditionTx, nil
}

/*
triggerType: agent | task
*/
func (p *PodCommonService) UpdatePodStatusTxs(podId string, curPodStatus *jks.PodStatus) ([]db.FuncT, error) {
	p.Logger.Info("UpdatePodStatus start. PodId: %s.", podId)
	curPodConditions := curPodStatus.Conditions
	curContainerStatuses := curPodStatus.ContainerStatuses

	dbObject, err := p.PodStatusDao.Query(p.DBOperator, podId)
	if err != nil {
		p.Logger.Error("PodStatusDao.Query failed. PodId: %s, Error: %s.", podId, err.Error())
		return nil, err
	}

	txs := make([]db.FuncT, 0)
	updateFields := make([]string, 0)

	if curPodStatus.Phase != "" && strings.Compare(dbObject.Phase, curPodStatus.Phase) != 0 {
		updateFields = append(updateFields, "phase")
		dbObject.Phase = curPodStatus.Phase
	}

	if strings.Compare(dbObject.Reason, curPodStatus.Reason) != 0 {
		updateFields = append(updateFields, "reason")
		dbObject.Reason = curPodStatus.Reason
	}

	if strings.Compare(dbObject.Message, curPodStatus.Message) != 0 {
		updateFields = append(updateFields, "message")
		dbObject.Message = curPodStatus.Message
	}

	// 更新ContainerStatus
	for _, cStatus := range curContainerStatuses {
		containerStatusTx, err := p.UpdateContainerStatusTxs(podId, cStatus)
		if err != nil {
			return nil, err
		}

		if containerStatusTx != nil {
			txs = append(txs, containerStatusTx...)
		}
	}

	// 更新PodCondition
	for _, pCondition := range curPodConditions {
		podConditionTx, err := p.UpdatePodConditionTxs(podId, pCondition)
		if err != nil {
			return nil, err
		}

		if podConditionTx != nil {
			txs = append(txs, podConditionTx)
		}
	}

	// 更新PodStatus
	if len(updateFields) != 0 {
		txs = append(txs, func(tx *db.Tx) error {
			if err := p.PodStatusDao.Update(tx, dbObject, updateFields, []string{"id"}); err != nil {
				p.Logger.Error("PodStatusDao.Update failed. PodId: %s, Error: %s.", podId, err.Error())
				return err
			}
			return nil
		})
	}

	return txs, nil
}

func (p *PodCommonService) GetEvent(podId, eventType string, curPodStatus *jks.PodStatus) (*bean.Event, error) {
	var event *bean.Event
	dbPod, err := p.PodDao.Query(p.DBOperator, podId)
	if err != nil {
		p.Logger.Error("PodStatusDao.Query failed. PodId: %s, Error: %s.", podId, err.Error())
		return nil, err
	}
	resourceType := dbPod.ResourceType

	if resourceType == jks.ResourceTypePod {
		dbObject, err := p.PodStatusDao.Query(p.DBOperator, podId)
		if err != nil {
			p.Logger.Error("PodStatusDao.Query failed. PodId: %s, Error: %s.", podId, err.Error())
			return nil, err
		}

		if curPodStatus.Phase != "" && strings.Compare(dbObject.Phase, curPodStatus.Phase) != 0 {
			event = &bean.Event{
				ResourceId:       podId,
				ResourceType:     jks.ResourceTypePod,
				OldResourceState: dbObject.Phase,
				NewResourceState: curPodStatus.Phase,
				EventState:       jks.EventStatePending,
				EventType:        eventType,
			}
		}
	}

	if resourceType == jks.ResourceTypeNativeContainer {
		for _, cStatus := range curPodStatus.ContainerStatuses {
			event, err = p.ContainerEventTxs(podId, cStatus.Phase, eventType)
			if err != nil {
				return nil, err
			}
		}
	}

	return event, nil
}

func (p *PodCommonService) ContainerEventTxs(podId, curStatus, eventType string) (*bean.Event, error) {
	var event *bean.Event
	dbObject, err := p.ContainerStatusDao.Query(p.DBOperator, podId, "")
	if err != nil {
		p.Logger.Error("ContainerStatusDao.QueryRecordByPodId failed. PodId: %s, Error: %s.", podId, err.Error())
		return nil, err
	}

	containerPhase := jks.ContainerPhaseIntegration(curStatus)
	if containerPhase != "" && strings.Compare(dbObject.Phase, containerPhase) != 0 {
		event = &bean.Event{
			ResourceId:       podId,
			ResourceType:     jks.ResourceTypeNativeContainer,
			OldResourceState: dbObject.Phase,
			NewResourceState: containerPhase,
			EventState:       jks.EventStatePending,
			EventType:        eventType,
		}
	}
	return event, nil
}

func (p *PodCommonService) GetVolumeMounts(podId, cName string) ([]*jks.VolumeMount, error) {
	var volumeMounts []*jks.VolumeMount

	params := &bean.ContainerVolumeMount{
		PodId:         podId,
		ContainerName: cName,
	}
	objects, err := p.ContainerVolumeMountDao.QueryByCond(p.DBOperator, params)
	if err != nil {
		p.Logger.Error("ContainerVolumeMountDao.QueryByCond failed. PodId: %s, ContainerName: %s, Error: %s.", podId, cName, err.Error())
		return nil, err
	}

	if len(objects) != 0 {
		volumeMounts = make([]*jks.VolumeMount, 0)
		for _, val := range objects {
			volumeMounts = append(volumeMounts, val.ToView())
		}
	}

	return volumeMounts, nil
}

func (p *PodCommonService) GetSysDisk(podId, cName string) (*jks.CloudDisk, error) {
	object, err := p.ContainerSystemDiskDao.Query(p.DBOperator, podId, cName)
	if err != nil {
		p.Logger.Error("ContainerSystemDiskDao.QueryByCond failed. PodId: %s, ContainerName: %s, Error: %s.", podId, cName, err.Error())
		return nil, err
	}

	return object.ToView(), nil
}

func (p *PodCommonService) GetProbe(podId, cName, probeType string) (*jks.Probe, error) {
	object, err := p.ContainerProbeDao.Query(p.DBOperator, podId, cName, probeType)
	if err != nil {
		if dao.IsDataNotFound(err) {
			return nil, nil
		}
		p.Logger.Error("ContainerProbeDao.QueryByCond failed. PodId: %s, ContainerName: %s, Error: %s.", podId, cName, err.Error())

		return nil, err
	}

	probe, err := object.ToView()
	if err != nil {
		p.Logger.Error("[GetProbe] ToView failed. PodId: %s, ContainerName: %s, Error: %s.", podId, cName, err.Error())
		return nil, err
	}

	return probe, nil
}

func (p *PodCommonService) GetContainerEnvs(podId, cName, source string) ([]*jks.Env, error) {
	var envs []*jks.Env

	params := &bean.ContainerEnv{
		PodId:         podId,
		ContainerName: cName,
		Source:        source,
	}
	objects, err := p.ContainerEnvDao.QueryByCond(p.DBOperator, params)
	if err != nil {
		p.Logger.Error("ContainerEnvDao.QueryByCond failed. PodId: %s, ContainerName: %s, Error: %s.", podId, cName, err.Error())

		return nil, err
	}

	if len(objects) != 0 {
		envs = make([]*jks.Env, 0)
		for _, val := range objects {
			envs = append(envs, val.ToView())
		}
	}

	return envs, nil
}

func (p *PodCommonService) GetContainerStatus(podId, cName string) (*jks.ContainerStatus, error) {
	dbObject, err := p.ContainerStatusDao.Query(p.DBOperator, podId, cName)
	if err != nil {
		p.Logger.Error("ContainerStatusDao.Query failed. PodId: %s, ContainerName: %s.", podId, cName)
		return nil, err
	}

	return dbObject.ToView()
}

func (p *PodCommonService) GetContainer(podId, cName string) (*jks.Container, error) {
	container, err := p.ContainerDao.Query(p.DBOperator, podId, cName)
	if err != nil {
		return nil, err
	}

	envs, err := p.GetContainerEnvs(podId, cName, jks.ContainerEnvSourceUser)
	if err != nil {
		return nil, err
	}

	lProbe, err := p.GetProbe(podId, cName, jks.ProbeTypeLiveness)
	if err != nil {
		return nil, err
	}
	rProbe, err := p.GetProbe(podId, cName, jks.ProbeTypeReadiness)
	if err != nil {
		return nil, err
	}

	resources := &jks.ResourceRequests{
		Limits: &jks.Resource{
			MemoryMB: container.MemLimit,
			CPU:      container.CpuLimit,
		},
		Requests: &jks.Resource{
			MemoryMB: container.MemRequest,
			CPU:      container.CpuRequest,
		},
	}

	sysDisk, err := p.GetSysDisk(podId, cName)
	if err != nil {
		return nil, err
	}

	volumeMounts, err := p.GetVolumeMounts(podId, cName)
	if err != nil {
		return nil, err
	}

	ret := &jks.Container{
		Name:           container.Name,
		Env:            envs,
		Image:          container.Image,
		Secret:         container.Secret,
		WorkingDir:     container.WorkingDir,
		TTY:            utils.IntToBool(container.TTY),
		LivenessProbe:  lProbe,
		ReadinessProbe: rProbe,
		Resources:      resources,
		SystemDisk:     sysDisk,
		VolumeMounts:   volumeMounts,
	}
	if container.Command != "" {
		ret.Command = strings.Split(container.Command, ",")
	}
	if container.Args != "" {
		ret.Args = strings.Split(container.Args, ",")
	}

	return ret, nil
}

func (p *PodCommonService) describePodConditionByPodIds(podIds []string) (map[string][]*jks.PodCondition, error) {
	conditions := make(map[string]interface{})
	db.BatchFields("pod_id", podIds, conditions)

	objects, err := p.PodConditionDao.BatchQuery(p.DBOperator, conditions)
	if err != nil {
		p.Logger.Error("PodConditionDao.BatchQuery failed. Error: %s.", err.Error())
		return nil, err
	}
	if len(objects) == 0 {
		return nil, nil
	}

	ret := make(map[string][]*jks.PodCondition, 0)
	for _, item := range objects {
		podId := item.PodId
		items, ok := ret[podId]
		if !ok {
			items = make([]*jks.PodCondition, 0)
		}
		items = append(items, item.ToView())
		ret[podId] = items
	}

	return ret, nil
}

func (p *PodCommonService) describeContainerStatusByPodIds(podIds []string) (map[string][]*jks.ContainerStatus, error) {
	conditions := make(map[string]interface{})
	db.BatchFields("pod_id", podIds, conditions)

	objects, err := p.ContainerStatusDao.BatchQuery(p.DBOperator, conditions)
	if err != nil {
		p.Logger.Error("ContainerStatusDao.BatchQuery failed. Error: %s.", err.Error())
		return nil, err
	}
	if len(objects) == 0 {
		return nil, nil
	}

	ret := make(map[string][]*jks.ContainerStatus, 0)
	for _, item := range objects {
		podId := item.PodId
		ctnStatus, err := item.ToView()
		if err != nil {
			p.Logger.Error("ContainerStatus.ToView failed. PodId: %s, Error: %s", podId, err.Error())
			return nil, err
		}

		items, ok := ret[podId]
		if !ok {
			items = make([]*jks.ContainerStatus, 0)
		}
		items = append(items, ctnStatus)
		ret[podId] = items
	}

	return ret, nil
}

func (p *PodCommonService) DescribePodStatusByIds(podIds []string) (map[string]*jks.PodStatus, error) {
	conditions := make(map[string]interface{})
	db.BatchFields("pod_id", podIds, conditions)

	objects, err := p.PodStatusDao.BatchQuery(p.DBOperator, conditions)
	if err != nil {
		p.Logger.Error("PodStatusDao.BatchQuery failed. Error: %s.", err.Error())
		return nil, err
	}
	if len(objects) == 0 {
		return nil, nil
	}

	podNetworkMap, err := p.describePrimaryInterfaceByPodIds(podIds)
	if err != nil {
		return nil, err
	}

	podConditionMap, err := p.describePodConditionByPodIds(podIds)
	if err != nil {
		return nil, err
	}

	ctnStatusMap, err := p.describeContainerStatusByPodIds(podIds)
	if err != nil {
		return nil, err
	}

	ret := make(map[string]*jks.PodStatus)
	for _, item := range objects {
		podId := item.PodId
		primaryInterface, ok := podNetworkMap[podId]
		if !ok {
			p.Logger.Error("[DescribePodStatusByIds] primary interface of pod [%s] not found", podId)
			return nil, errors.New("primary interface of pod not found")
		}
		obj := &jks.PodStatus{
			PodIP:     primaryInterface.FixedIP,
			Phase:     item.Phase,
			Reason:    item.Reason,
			Message:   item.Message,
			StartTime: item.StartTime,
		}
		if podConds, ok := podConditionMap[podId]; ok {
			obj.Conditions = podConds
		} else {
			obj.Conditions = []*jks.PodCondition{}
		}
		if ctnStatuses, ok := ctnStatusMap[podId]; ok {
			obj.ContainerStatuses = ctnStatuses
		} else {
			obj.ContainerStatuses = []*jks.ContainerStatus{}
		}
		ret[podId] = obj
	}

	return ret, nil
}

func (p *PodCommonService) describeContainerEnvByPodIds(podIds []string) (map[string][]*jks.Env, error) {
	conditions := make(map[string]interface{})
	conditions["source"] = jks.ContainerEnvSourceUser
	db.BatchFields("pod_id", podIds, conditions)

	objects, err := p.ContainerEnvDao.BatchQuery(p.DBOperator, conditions)
	if err != nil {
		p.Logger.Error("ContainerEnvDao.BatchQuery failed. Error: %s", err.Error())
		return nil, err
	}
	if len(objects) == 0 {
		return nil, nil
	}

	ret := make(map[string][]*jks.Env)
	for _, item := range objects {
		// PodId + ContainerName
		index := jks.JoinPodContainerUQ(item.PodId, item.ContainerName)
		items, ok := ret[index]
		if !ok {
			items = make([]*jks.Env, 0)
		}
		items = append(items, item.ToView())
		ret[index] = items
	}

	return ret, nil
}

func (p *PodCommonService) describeContainerVolumeMountByPodIds(podIds []string) (map[string][]*jks.VolumeMount, error) {
	conditions := make(map[string]interface{})
	db.BatchFields("pod_id", podIds, conditions)

	objects, err := p.ContainerVolumeMountDao.BatchQuery(p.DBOperator, conditions)
	if err != nil {
		p.Logger.Error("ContainerVolumeMountDao.BatchQuery failed. Error: %s", err.Error())
		return nil, err
	}
	if len(objects) == 0 {
		return nil, nil
	}

	ret := make(map[string][]*jks.VolumeMount)
	for _, item := range objects {
		// PodId + ContainerName
		index := jks.JoinPodContainerUQ(item.PodId, item.ContainerName)
		items, ok := ret[index]
		if !ok {
			items = make([]*jks.VolumeMount, 0)
		}
		items = append(items, item.ToView())
		ret[index] = items
	}

	return ret, nil
}

func (p *PodCommonService) describeContainerSysDiskByPodIds(podIds []string) (map[string]*jks.CloudDisk, error) {
	conditions := make(map[string]interface{})
	db.BatchFields("pod_id", podIds, conditions)

	objects, err := p.ContainerSystemDiskDao.BatchQuery(p.DBOperator, conditions)
	if err != nil {
		p.Logger.Error("ContainerSystemDiskDao.BatchQuery failed. Error: %s", err.Error())
		return nil, err
	}
	if len(objects) == 0 {
		return nil, nil
	}

	ret := make(map[string]*jks.CloudDisk)
	for _, item := range objects {
		// PodId + ContainerName
		index := jks.JoinPodContainerUQ(item.PodId, item.ContainerName)
		ret[index] = item.ToView()
	}

	return ret, nil
}

func (p *PodCommonService) describeContainerProbeByPodIds(podIds []string) (map[string][]*bean.ContainerProbe, error) {
	conditions := make(map[string]interface{})
	db.BatchFields("pod_id", podIds, conditions)

	objects, err := p.ContainerProbeDao.BatchQuery(p.DBOperator, conditions)
	if err != nil {
		p.Logger.Error("ContainerProbeDao.BatchQuery failed. Error: %s", err.Error())
		return nil, err
	}
	if len(objects) == 0 {
		return nil, nil
	}

	ret := make(map[string][]*bean.ContainerProbe)
	for _, item := range objects {
		// PodId + ContainerName
		index := jks.JoinPodContainerUQ(item.PodId, item.ContainerName)
		items, ok := ret[index]
		if !ok {
			items = make([]*bean.ContainerProbe, 0)
		}
		items = append(items, item)
		ret[index] = items
	}

	return ret, nil
}

func (p *PodCommonService) describePodContainerByPodIds(podIds []string) (map[string][]*jks.Container, error) {
	conditions := make(map[string]interface{})
	db.BatchFields("pod_id", podIds, conditions)

	objects, err := p.ContainerDao.BatchQuery(p.DBOperator, conditions)
	if err != nil {
		p.Logger.Error("ContainerDao.BatchQuery failed. Error: %s", err.Error())
		return nil, err
	}
	if len(objects) == 0 {
		return nil, nil
	}

	sysDiskMap, err := p.describeContainerSysDiskByPodIds(podIds)
	if err != nil {
		return nil, err
	}
	probeMap, err := p.describeContainerProbeByPodIds(podIds)
	if err != nil {
		return nil, err
	}
	envMap, err := p.describeContainerEnvByPodIds(podIds)
	if err != nil {
		return nil, err
	}
	volMountMap, err := p.describeContainerVolumeMountByPodIds(podIds)
	if err != nil {
		return nil, err
	}

	ret := make(map[string][]*jks.Container)
	for _, item := range objects {
		// PodId + ContainerName
		podId := item.PodId
		ctnName := item.Name
		ctnIndex := jks.JoinPodContainerUQ(podId, ctnName)
		items, ok := ret[podId]
		if !ok {
			items = make([]*jks.Container, 0)
		}

		sysDisk, ok := sysDiskMap[ctnIndex]
		if !ok {
			p.Logger.Error("System disk not found in the db. PodId: %s, ContainerName: %s", podId, ctnName)
			return nil, errors.New("system disk not found in the db")
		}

		ctn := &jks.Container{
			Name:       item.Name,
			Image:      item.Image,
			Secret:     item.Secret,
			WorkingDir: item.WorkingDir,
			TTY:        utils.IntToBool(item.TTY),
			Resources: &jks.ResourceRequests{
				Limits: &jks.Resource{
					MemoryMB: item.MemLimit,
					CPU:      item.CpuLimit,
				},
				Requests: &jks.Resource{
					MemoryMB: item.MemRequest,
					CPU:      item.CpuRequest,
				},
			},
			SystemDisk: sysDisk,
		}
		if item.Command != "" {
			ctn.Command = strings.Split(item.Command, ",")
		} else {
			ctn.Command = []string{}
		}
		if item.Args != "" {
			ctn.Args = strings.Split(item.Args, ",")
		} else {
			ctn.Args = []string{}
		}
		if envs, ok := envMap[ctnIndex]; ok {
			ctn.Env = envs
		} else {
			ctn.Env = []*jks.Env{}
		}
		if volMounts, ok := volMountMap[ctnIndex]; ok {
			ctn.VolumeMounts = volMounts
		} else {
			ctn.VolumeMounts = []*jks.VolumeMount{}
		}
		for _, probe := range probeMap[ctnIndex] {
			v, err := probe.ToView()
			if err != nil {
				p.Logger.Error("ContainerProbe.ToView failed. PodId: %s, ContainerName: %s", podId, ctnName)
				return nil, err
			}
			if probe.ProbeType == jks.ProbeTypeLiveness {
				ctn.LivenessProbe = v
			} else {
				ctn.ReadinessProbe = v
			}
		}

		items = append(items, ctn)
		ret[podId] = items
	}

	return ret, nil
}

func (p *PodCommonService) describePodVolumeByPodIds(podIds []string) (map[string][]*jks.Volume, error) {
	conditions := make(map[string]interface{})
	db.BatchFields("pod_id", podIds, conditions)

	objects, err := p.PodVolumeDao.BatchQuery(p.DBOperator, conditions)
	if err != nil {
		p.Logger.Error("PodVolumeDao.BatchQuery failed. Error: %s", err.Error())
		return nil, err
	}
	if len(objects) == 0 {
		return nil, nil
	}

	ret := make(map[string][]*jks.Volume)
	for _, item := range objects {
		podId := item.PodId
		vol, err := item.ToView()
		if err != nil {
			p.Logger.Error("PodVolume.ToView failed. PodId: %s, Error: %s", podId, err.Error())
			return nil, err
		}

		items, ok := ret[podId]
		if !ok {
			items = make([]*jks.Volume, 0)
		}
		items = append(items, vol)
		ret[podId] = items
	}

	return ret, nil
}

func (p *PodCommonService) describePodHostAliasByPodIds(podIds []string) (map[string][]*jks.HostAlias, error) {
	conditions := make(map[string]interface{})
	db.BatchFields("pod_id", podIds, conditions)

	objects, err := p.PodHostAliasDao.BatchQuery(p.DBOperator, conditions)
	if err != nil {
		p.Logger.Error("PodHostAliasDao.BatchQuery failed. Error: %s", err.Error())
		return nil, err
	}
	if len(objects) == 0 {
		return nil, nil
	}

	ret := make(map[string][]*jks.HostAlias)
	for _, item := range objects {
		podId := item.PodId
		items, ok := ret[podId]
		if !ok {
			items = make([]*jks.HostAlias, 0)
		}
		items = append(items, item.ToView())
		ret[podId] = items
	}

	return ret, nil
}

func (p *PodCommonService) describePrimaryInterfaceByPodIds(podIds []string) (map[string]*jks.NetworkPort, error) {
	conditions := make(map[string]interface{})
	conditions["boot_index"] = 1
	db.BatchFields("pod_id", podIds, conditions)

	objects, err := p.PodNetworkDao.BatchQuery(p.DBOperator, conditions)
	if err != nil {
		p.Logger.Error("PodNetworkDao.BatchQuery failed. Error: %s", err.Error())
		return nil, err
	}
	if len(objects) == 0 {
		return nil, nil
	}

	ret := make(map[string]*jks.NetworkPort)
	for _, item := range objects {
		podId := item.PodId
		ret[podId] = item.ToView()
	}

	return ret, nil
}

func (p *PodCommonService) describePodByPodIds(podIds []string) (map[string]*bean.Pod, error) {
	conditions := make(map[string]interface{})
	db.BatchFields("pod_id", podIds, conditions)

	objects, err := p.PodDao.BatchQuery(p.DBOperator, conditions)
	if err != nil {
		p.Logger.Error("PodDao.BatchQuery failed. Error: %s", err.Error())
		return nil, err
	}
	if len(objects) == 0 {
		return nil, nil
	}

	ret := make(map[string]*bean.Pod)
	for _, item := range objects {
		podId := item.PodId
		ret[podId] = item
	}

	return ret, nil
}

func (p *PodCommonService) DescribePodByIds(podIds []string) ([]*jks.Pod, error) {
	if len(podIds) == 0 {
		return nil, nil
	}

	// 查询Pod和PodStatus的顺序不能变
	podStatusMap, err := p.DescribePodStatusByIds(podIds)
	if err != nil {
		return nil, err
	}
	podMap, err := p.describePodByPodIds(podIds)
	if err != nil {
		return nil, err
	}

	hostAliasMap, err := p.describePodHostAliasByPodIds(podIds)
	if err != nil {
		return nil, err
	}

	volumeMap, err := p.describePodVolumeByPodIds(podIds)
	if err != nil {
		return nil, err
	}

	portMap, err := p.describePrimaryInterfaceByPodIds(podIds)
	if err != nil {
		return nil, err
	}

	containerMap, err := p.describePodContainerByPodIds(podIds)
	if err != nil {
		return nil, err
	}

	ret := make([]*jks.Pod, 0)
	for _, podId := range podIds {
		var (
			dnsConfig *jks.PodDNSConfig
			logConfig *jks.LogConfig
		)
		pod := podMap[podId]

		if pod.DnsConfig != "" {
			dnsConfig = &jks.PodDNSConfig{}
			if err := apiUtils.Unmarshal(pod.DnsConfig, dnsConfig); err != nil {
				return nil, err
			}
		}
		if len(dnsConfig.Options) == 0 {
			dnsConfig.Options = []*jks.PodDNSConfigOption{}
		}
		if len(dnsConfig.Nameservers) == 0 {
			dnsConfig.Nameservers = []string{}
		}
		if len(dnsConfig.Searches) == 0 {
			dnsConfig.Searches = []string{}
		}

		if pod.LogConfig != "" {
			logConfig = &jks.LogConfig{}
			if err := apiUtils.Unmarshal(pod.LogConfig, logConfig); err != nil {
				return nil, err
			}
		}

		podStatus, ok := podStatusMap[podId]
		if !ok {
			p.Logger.Error("[DescribePodByIds] pod status of pod [%s] not found", podId)
			return nil, errors.New("pod status of pod not found")
		}

		primaryInterface, ok := portMap[podId]
		if !ok {
			p.Logger.Error("[DescribePodByIds] primary interface of pod [%s] not found", podId)
			return nil, errors.New("primary interface of pod not found")
		}

		containers := containerMap[podId]
		if len(containers) == 0 {
			p.Logger.Error("[DescribePodByIds] containers of pod [%s] not found", podId)
			return nil, errors.New("containers of pod not found")
		}

		podObj := &jks.Pod{
			PodId:                         podId,
			ResourceType:                  pod.ResourceType,
			Name:                          pod.Name,
			UserId:                        pod.UserId,
			UserPin:                       pod.UserPin,
			Description:                   pod.Description,
			TaskId:                        pod.TaskId,
			Az:                            pod.Az,
			Hostname:                      pod.Hostname,
			HostIP:                        pod.HostIp,
			InstanceType:                  pod.InstanceType,
			RestartPolicy:                 pod.RestartPolicy,
			ServiceCode:                   pod.ServiceCode,
			RuntimeType:                   pod.RuntimeType,
			TerminationGracePeriodSeconds: pod.TerminationGracePeriodSeconds,
			DNSConfig:                     dnsConfig,
			LogConfig:                     logConfig,
			Containers:                    containers,
			PrimaryInterface:              primaryInterface,
			PodStatus:                     podStatus,
			CreateTime:                    pod.CreatedTime.UTC().Format(time.RFC3339),
			UpdateTime:                    pod.UpdateTime.UTC().Format(time.RFC3339),
		}
		if hostAliases, ok := hostAliasMap[podId]; ok {
			podObj.HostAliases = hostAliases
		} else {
			podObj.HostAliases = []*jks.HostAlias{}
		}
		if volumes, ok := volumeMap[podId]; ok {
			podObj.Volumes = volumes
		} else {
			podObj.Volumes = []*jks.Volume{}
		}

		if pod.ResourceType == jks.ResourceTypeNativeContainer {
			podObj.Name = pod.NcName
		}

		ret = append(ret, podObj)
	}

	return ret, nil
}

func (p *PodCommonService) describeRecordContainerByPodId(podId string) ([]*jks.Container, error) {
	objects, err := p.ContainerDao.QueryRecordByPodId(p.DBOperator, podId)
	if err != nil {
		p.Logger.Error("ContainerDao.QueryRecordByPodId failed. PodId: %s, Error: %s", podId, err.Error())
		return nil, err
	}
	if len(objects) == 0 {
		return nil, nil
	}

	ctnSysDisks, err := p.ContainerSystemDiskDao.QueryRecordByPodId(p.DBOperator, podId)
	if err != nil {
		p.Logger.Error("ContainerSystemDiskDao.QueryRecordByPodId failed. PodId: %s, Error: %s", podId, err.Error())
		return nil, err
	}
	ctnSysDiskMap := make(map[string]*jks.CloudDisk)
	for _, item := range ctnSysDisks {
		// PodId + ContainerName
		index := jks.JoinPodContainerUQ(item.PodId, item.ContainerName)
		ctnSysDiskMap[index] = item.ToView()
	}

	ctnProbes, err := p.ContainerProbeDao.QueryRecordByPodId(p.DBOperator, podId)
	if err != nil {
		p.Logger.Error("ContainerProbeDao.QueryRecordByPodId failed. PodId: %s, Error: %s", podId, err.Error())
		return nil, err
	}
	ctnProbeMap := make(map[string][]*bean.ContainerProbe)
	for _, item := range ctnProbes {
		// PodId + ContainerName
		index := jks.JoinPodContainerUQ(item.PodId, item.ContainerName)
		items, ok := ctnProbeMap[index]
		if !ok {
			items = make([]*bean.ContainerProbe, 0)
		}
		items = append(items, item)
		ctnProbeMap[index] = items
	}

	ctnEnvs, err := p.ContainerEnvDao.QueryRecordByPodId(p.DBOperator, podId)
	if err != nil {
		p.Logger.Error("ContainerEnvDao.QueryRecordByPodId failed. PodId: %s, Error: %s", podId, err.Error())
		return nil, err
	}
	ctnEnvMap := make(map[string][]*jks.Env)
	for _, item := range ctnEnvs {
		// PodId + ContainerName
		index := jks.JoinPodContainerUQ(item.PodId, item.ContainerName)
		items, ok := ctnEnvMap[index]
		if !ok {
			items = make([]*jks.Env, 0)
		}
		items = append(items, item.ToView())
		ctnEnvMap[index] = items
	}

	ctnVolMounts, err := p.ContainerVolumeMountDao.QueryRecordByPodId(p.DBOperator, podId)
	if err != nil {
		p.Logger.Error("ContainerVolumeMountDao.QueryRecordByPodId failed. PodId: %s, Error: %s", podId, err.Error())
		return nil, err
	}
	ctnVolMountsMap := make(map[string][]*jks.VolumeMount)
	for _, item := range ctnVolMounts {
		// PodId + ContainerName
		index := jks.JoinPodContainerUQ(item.PodId, item.ContainerName)
		items, ok := ctnVolMountsMap[index]
		if !ok {
			items = make([]*jks.VolumeMount, 0)
		}
		items = append(items, item.ToView())
		ctnVolMountsMap[index] = items
	}

	ret := make([]*jks.Container, 0)
	for _, item := range objects {
		// PodId + ContainerName
		podId := item.PodId
		ctnName := item.Name
		ctnIndex := jks.JoinPodContainerUQ(podId, ctnName)

		sysDisk, ok := ctnSysDiskMap[ctnIndex]
		if !ok {
			p.Logger.Error("System disk not found in the db. PodId: %s, ContainerName: %s", podId, ctnName)
			return nil, errors.New("system disk not found in the db")
		}

		ctn := &jks.Container{
			Name:       item.Name,
			Image:      item.Image,
			Secret:     item.Secret,
			WorkingDir: item.WorkingDir,
			TTY:        utils.IntToBool(item.TTY),
			Resources: &jks.ResourceRequests{
				Limits: &jks.Resource{
					MemoryMB: item.MemLimit,
					CPU:      item.CpuLimit,
				},
				Requests: &jks.Resource{
					MemoryMB: item.MemRequest,
					CPU:      item.CpuRequest,
				},
			},
			SystemDisk: sysDisk,
		}
		if item.Command != "" {
			ctn.Command = strings.Split(item.Command, ",")
		} else {
			ctn.Command = []string{}
		}
		if item.Args != "" {
			ctn.Args = strings.Split(item.Args, ",")
		} else {
			ctn.Args = []string{}
		}
		if envs, ok := ctnEnvMap[ctnIndex]; ok {
			ctn.Env = envs
		} else {
			ctn.Env = []*jks.Env{}
		}
		if volMounts, ok := ctnVolMountsMap[ctnIndex]; ok {
			ctn.VolumeMounts = volMounts
		} else {
			ctn.VolumeMounts = []*jks.VolumeMount{}
		}
		for _, probe := range ctnProbeMap[ctnIndex] {
			v, err := probe.ToView()
			if err != nil {
				p.Logger.Error("ContainerProbe.ToView failed. PodId: %s, ContainerName: %s", podId, ctnName)
				return nil, err
			}
			if probe.ProbeType == jks.ProbeTypeLiveness {
				ctn.LivenessProbe = v
			} else {
				ctn.ReadinessProbe = v
			}
		}

		ret = append(ret, ctn)
	}

	return ret, nil
}

func (p *PodCommonService) DescribeRecordPodById(podId string) (*jks.Pod, error) {
	var (
		dnsConfig *jks.PodDNSConfig
		logConfig *jks.LogConfig
	)

	pod, err := p.PodDao.QueryRecordByPodId(p.DBOperator, podId)
	if err != nil {
		p.Logger.Error("[DescribeSomePodById] PodDao.QueryRecordByPodId failed. PodId: %s, Error: %s", podId, err.Error())
		return nil, err
	}

	podHostAliases, err := p.PodHostAliasDao.QueryRecordByPodId(p.DBOperator, podId)
	if err != nil {
		p.Logger.Error("[DescribeSomePodById] PodHostAliasDao.QueryRecordByPodId failed. PodId: %s, Error: %s", podId, err.Error())
		return nil, err
	}

	podVolumes, err := p.PodVolumeDao.QueryRecordByPodId(p.DBOperator, podId)
	if err != nil {
		p.Logger.Error("[DescribeSomePodById] PodVolumeDao.QueryRecordByPodId failed. PodId: %s, Error: %s", podId, err.Error())
		return nil, err
	}

	podPriInterface, err := p.PodNetworkDao.QueryRecordByPodId(p.DBOperator, podId)
	if err != nil {
		p.Logger.Error("[DescribeSomePodById] PodNetworkDao.QueryRecordByPodId failed. PodId: %s, Error: %s", podId, err.Error())
		return nil, err
	}

	if pod.DnsConfig != "" {
		dnsConfig = &jks.PodDNSConfig{}
		if err := apiUtils.Unmarshal(pod.DnsConfig, dnsConfig); err != nil {
			return nil, err
		}
	}
	if len(dnsConfig.Options) == 0 {
		dnsConfig.Options = []*jks.PodDNSConfigOption{}
	}
	if len(dnsConfig.Nameservers) == 0 {
		dnsConfig.Nameservers = []string{}
	}
	if len(dnsConfig.Searches) == 0 {
		dnsConfig.Searches = []string{}
	}

	if pod.LogConfig != "" {
		logConfig = &jks.LogConfig{}
		if err := apiUtils.Unmarshal(pod.LogConfig, logConfig); err != nil {
			return nil, err
		}
	}

	containers, err := p.describeRecordContainerByPodId(podId)
	if err != nil {
		p.Logger.Error("[DescribeSomePodById] describeRecordContainerByPodId failed. PodId: %s, Error: %s", podId, err.Error())
		return nil, err
	}

	podObj := &jks.Pod{
		PodId:                         podId,
		ResourceType:                  pod.ResourceType,
		Name:                          pod.Name,
		UserId:                        pod.UserId,
		UserPin:                       pod.UserPin,
		Description:                   pod.Description,
		TaskId:                        pod.TaskId,
		Az:                            pod.Az,
		Hostname:                      pod.Hostname,
		HostIP:                        pod.HostIp,
		InstanceType:                  pod.InstanceType,
		RestartPolicy:                 pod.RestartPolicy,
		ServiceCode:                   pod.ServiceCode,
		RuntimeType:                   pod.RuntimeType,
		TerminationGracePeriodSeconds: pod.TerminationGracePeriodSeconds,
		DNSConfig:                     dnsConfig,
		LogConfig:                     logConfig,
		Containers:                    containers,
		PrimaryInterface:              podPriInterface.ToView(),
		CreateTime:                    pod.CreatedTime.UTC().Format(time.RFC3339),
		UpdateTime:                    pod.UpdateTime.UTC().Format(time.RFC3339),
	}
	for _, item := range podHostAliases {
		podObj.HostAliases = append(podObj.HostAliases, item.ToView())
	}

	for _, item := range podVolumes {
		vol, err := item.ToView()
		if err != nil {
			p.Logger.Error("PodVolume.ToView failed. PodId: %s, Error: %s", podId, err.Error())
			return nil, err
		}
		podObj.Volumes = append(podObj.Volumes, vol)
	}

	if pod.ResourceType == jks.ResourceTypeNativeContainer {
		podObj.Name = pod.NcName
	}

	return podObj, nil
}

func (p *PodCommonService) GetExcludeHostIps(podId string) ([]string, error) {
	var res []string
	notDownTasks, err := p.TaskDao.QueryNotDownTasks(p.DBOperator, podId)
	if err != nil {
		p.Logger.Error("[GetExcludeHostIps] QueryNotDownTasks failed, PodId: %s, Error: %s.", podId, err.Error())
		return res, err
	}

	for _, task := range notDownTasks {
		extends, err := task.GetExtends()
		if err != nil {
			p.Logger.Error("[GetExcludeHostIps] GetExtends failed. podId: %s, err: %v", podId, err)
			return res, err
		}

		if extends.AgentFreed == false {
			srcIp := extends.SrcHostIp
			dstIp := task.HostIp
			if task.TaskState == jks.TaskFinished && srcIp != "" {

				res = append(res, srcIp) //迁移完成清理原资源

				p.Logger.Debug("[GetExcludeHostIps] taskId: %d, TaskState: %s, taskAfter: %d, srcIp: %s",
					task.Id, task.TaskState, task.TaskAfter, srcIp)
			}
			if task.TaskState == jks.TaskFailed && dstIp != "" {

				res = append(res, dstIp) //迁移失败清理目标资源

				p.Logger.Debug("[GetExcludeHostIps] taskId: %d, TaskState: %s, taskAfter: %d, dstIp: %s",
					task.Id, task.TaskState, task.TaskAfter, dstIp)
			}
		}
	}

	p.Logger.Debug("[GetExcludeHostIps] excludeHostIp: %v", res)
	return res, nil
}
