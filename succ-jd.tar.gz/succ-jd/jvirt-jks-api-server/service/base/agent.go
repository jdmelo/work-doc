package base

import (
	"fmt"

	"jd.com/jvirt/jvirt-common/inner/jks/agent"
	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jks-api-server/bean"
	"jd.com/jvirt/jvirt-jks-api-server/em"
)

type AgentService struct {
	Logger       log.Logger              `inject:""`
	AgentClient  agent.IAgentHttpClient  `inject:""`
	EventManager *em.EventManagerService `inject:""`
}

func (p *AgentService) SendRequestToAgent(task *bean.Task) common.JvirtError {
	p.Logger.Debug("Send request to agent. HostIp: %s, TaskId: %v, TaskType: %s.", task.HostIp, task.Id, task.TaskType)

	agentRequest := &agent.LaunchTaskRequest{
		Task:   task.ToView(),
		HostIp: task.HostIp,
	}

	if jErr := p.AgentClient.LaunchTask(agentRequest); jErr != nil {
		msg := fmt.Sprintf("Send request to agent failed. HostIp: %s, TaskId: %v, TaskType: %s, Error: %s, Detail: %s.",
			task.HostIp, task.Id, task.TaskType, jErr.Error(), jErr.Detail())
		p.Logger.Error(msg)
		event := &em.DependenceEvent{
			Type:   em.Agent,
			Action: em.SendRequest,
			Result: em.Fail,
			Detail: msg,
		}
		p.EventManager.NotifyDependenceEvent(event, task.RequestId)

		return jErr
	}

	return nil
}

func (p *AgentService) MigrateFinishCleanSrc(requestId, srcHostIp, podId string) common.JvirtError {
	p.Logger.Debug("MigrateFinishCleanSrc SrcHostIp: %s, PodId: %s.", srcHostIp, podId)
	agentRequest := &agent.CleanResourceRequest{
		HostIp: srcHostIp,
		PodId:  podId,
	}
	if jErr := p.AgentClient.MigrateFinishCleanSrc(agentRequest); jErr != nil {
		msg := fmt.Sprintf("MigrateFinishCleanSrc failed. SrcHostIp: %s, PodId: %s, Error: %s, detail: %s.",
			srcHostIp, podId, jErr.Error(), jErr.Detail())
		p.Logger.Error(msg)
		event := &em.DependenceEvent{
			Type:   em.Agent,
			Action: em.SendRequest,
			Result: em.Fail,
			Detail: msg,
		}
		p.EventManager.NotifyDependenceEvent(event, requestId)
		return jErr
	}

	return nil
}

func (p *AgentService) MigrateFailedCleanDst(requestId, dstHostIp, podId string) common.JvirtError {
	p.Logger.Debug("MigrateFailedCleanDst DstHostIp: %s, PodId: %s.", dstHostIp, podId)
	agentRequest := &agent.CleanResourceRequest{
		HostIp: dstHostIp,
		PodId:  podId,
	}

	if jErr := p.AgentClient.MigrateFailedCleanDst(agentRequest); jErr != nil {
		msg := fmt.Sprintf("MigrateFailedCleanDst failed. DstHostIp: %s, PodId: %s, Error: %s, detail: %s.",
			dstHostIp, podId, jErr.Error(), jErr.Detail())
		p.Logger.Error(msg)
		event := &em.DependenceEvent{
			Type:   em.Agent,
			Action: em.SendRequest,
			Result: em.Fail,
			Detail: msg,
		}
		p.EventManager.NotifyDependenceEvent(event, requestId)
		return jErr
	}

	return nil
}

func (p *AgentService) ResizePodRollBack(requestId, hostIp, podId string) common.JvirtError {
	p.Logger.Debug("ResizePodRollBack DstHostIp: %s, PodId: %s.", hostIp, podId)
	agentRequest := &agent.ResizePodRequest{
		HostIp: hostIp,
		PodId:  podId,
	}
	if jErr := p.AgentClient.ResizePodRollBack(agentRequest); jErr != nil {
		msg := fmt.Sprintf("ResizePodRollBack failed. hostIp: %s, PodId: %s, Error: %s, detail: %s.",
			hostIp, podId, jErr.Error(), jErr.Detail())
		p.Logger.Error(msg)
		event := &em.DependenceEvent{
			Type:   em.Agent,
			Action: em.SendRequest,
			Result: em.Fail,
			Detail: msg,
		}
		p.EventManager.NotifyDependenceEvent(event, requestId)
		return jErr
	}

	return nil
}
