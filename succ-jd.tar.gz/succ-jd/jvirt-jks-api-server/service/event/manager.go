package event

import (
	"jd.com/jvirt/jvirt-common/utils/db"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jks-api-server/dao"
)

type EventService struct {
	Logger     log.Logger    `inject:""`
	DBOperator *db.ExtendDB  `inject:""`
	EventDao   *dao.EventDao `inject:""`
}
