package event

import (
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-jks-api-server/bean"
)

func (p *EventService) UpdateEvent(params *api.UpdateEventRequest) common.JvirtError {
	event := &bean.Event{
		Id:         params.Id,
		EventState: params.EventState,
	}

	if err := p.EventDao.UpdateById(p.DBOperator, event, []string{"event_state"}); err != nil {
		p.Logger.Error("update db for event failed, err: %s", err.Error())
		return common.NewSysErr(err)
	}

	return nil
}
