package container

import (
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/url"
	"jd.com/jvirt/jvirt-jks-api-server/dao"
)

func (p *ContainerService) DescribeContainer(request *url.Request, params *api.DescribeContainerRequest) (*api.DescribeContainerResp, common.JvirtError) {
	podId := params.PodId
	cName := params.ContainerName

	if request.Admin == "" {
		_, err := p.PodDao.CheckPodExist(p.DBOperator, request.UserId, podId)
		if err != nil {
			p.Logger.Error("[DescribeContainer] PodDao.CheckPodExist failed. PodId: %s, Error: %s, Detail: %s.", podId, err.Error())
			if dao.IsDataNotFound(err) {
				return nil, common.NewError(common.RErrPod, common.PErrDB, common.TErrNotFound, err.Error())
			}

			return nil, common.NewSysErr(err)
		}
	}

	container, err := p.GetContainer(podId, cName)
	if err != nil {
		p.Logger.Error("[GetContainer] fail, podId:%d, containerName: %s, error%v", podId, cName, err.Error())
		return nil, common.NewError(common.RErrPod, common.TErrNotFound, common.PErrContainer, err.Error())
	}

	containerStatus, err := p.GetContainerStatus(podId, cName)
	if err != nil {
		p.Logger.Error("GetContainerStatus failed. PodId: %s,  containerName: %s, error%v", podId, cName, err.Error())
		return nil, common.NewError(common.RErrPod, common.TErrNotFound, common.PErrStatus, err.Error())
	}

	return &api.DescribeContainerResp{PodId: podId, Container: container, ContainerStatus: containerStatus}, nil
}
