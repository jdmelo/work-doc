package container

import (
	"jd.com/jvirt/jvirt-jks-api-server/service/base"
)

type ContainerService struct {
	*base.PodCommonService `inject:""`
}
