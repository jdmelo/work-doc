package container

import (
	"strings"

	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/pac"
	"jd.com/jvirt/jvirt-common/utils/url"
	"jd.com/jvirt/jvirt-jks-api-server/constant"
	"jd.com/jvirt/jvirt-jks-api-server/dao"
	"jd.com/jvirt/jvirt-jks-api-server/utils"
)

func (p *ContainerService) GetContainerImage(req *url.Request, params *api.GetContainerImageRequest) (*api.GetContainerImageResp, common.JvirtError) {
	podId := params.PodId
	cName := params.ContainerName

	if podId == "" {
		p.Logger.Error("[GetContainerImage] PodId and ContainerName must be set.")
		return nil, common.NewError(common.RErrRequest, common.TErrMiss, common.PErrParams, "PodId or ContainerName miss")
	}

	object, err := p.ContainerImageDao.Query(p.DBOperator, podId, cName)
	if err != nil {
		p.Logger.Error("ContainerImageDao.Query failed. PodId: %s, ContainerName: %s, Error: %s.", podId, cName, err.Error())
		if dao.IsDataNotFound(err) {
			return nil, common.NewError(common.RErrImage, common.TErrNotFound, common.PErrDB, err.Error())
		}

		return nil, common.NewSysErr(err)
	}

	envs, err := p.GetContainerEnvs(podId, cName, jks.ContainerEnvSourceImage)
	if err != nil {
		p.Logger.Error("GetContainerEnvs failed. PodId: %s, ContainerName: %s, Source: %s, Error: %s.", podId, cName, jks.ContainerEnvSourceImage, err.Error())
		return nil, common.NewSysErr(err)
	}

	strEnv := make([]string, 0)
	for _, item := range envs {
		v := item.Name + "=" + item.Value
		strEnv = append(strEnv, v)
	}

	regUrl := object.RegistryUrl
	proxyPac := utils.GetProxyPac()
	httpProxy := utils.GetHttpProxy()
	realProxy, err := pac.ProxyParse(proxyPac, regUrl, httpProxy)
	if err != nil {
		p.Logger.Error("parse proxy pac failed. RegUrl: %s, ProxyPac: %s, HttpProxy: %s.", regUrl, proxyPac, httpProxy)
		return nil, common.NewError(common.RErrProxy, common.TErrInvalid, common.PErrValue, "parse proxy pac failed")
	}

	jcrHubDomainSuffix := utils.GetJcrHubDomainSuffix()
	if strings.HasSuffix(regUrl, jcrHubDomainSuffix) {
		realProxy = ""
		regUrl = strings.Replace(regUrl, constant.DefaultJcrHubDomainSuffix, constant.InnerJcrHubDomainSuffix, -1)
	}

	resp := &api.GetContainerImageResp{
		PodId:            podId,
		ContainerName:    cName,
		RegistryType:     object.RegistryType,
		RegistryUrl:      regUrl,
		RegistryUsername: object.RegistryUsername,
		RegistryPassword: object.RegistryPassword,
		ImageName:        object.ImageName,
		ImageDigest:      object.ImageDigest,
		WorkingDir:       object.WorkingDir,
		Env:              strEnv,
		HttpProxy:        realProxy,
	}
	if object.Command != "" {
		resp.Command = strings.Split(object.Command, ",")
	}
	if object.Entrypoint != "" {
		resp.Entrypoint = strings.Split(object.Entrypoint, ",")
	}

	return resp, nil
}
