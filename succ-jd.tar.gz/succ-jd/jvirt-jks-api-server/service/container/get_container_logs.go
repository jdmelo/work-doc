package container

import (
	"jd.com/jvirt/jvirt-common/inner/jks/agent"
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/url"
	"jd.com/jvirt/jvirt-jks-api-server/dao"
)

const logLimitBytes = 4194304

func (p *ContainerService) GetPodContainerLogs(request *url.Request, params *api.GetContainerLogsRequest) (string, common.JvirtError) {
	podId := params.PodId

	if request.Admin == "" {
		// 先校验pod是否存在和是否属于这个userid
		if _, err := p.PodDao.CheckPodExist(p.DBOperator, request.UserId, podId); err != nil {
			p.Logger.Error("[GetPodContainerLogs] PodDao.CheckPodExist failed. PodId: %s, Error: %s.", podId, err.Error())
			if dao.IsDataNotFound(err) {
				return "", common.NewError(common.RErrPod, common.PErrDB, common.TErrNotFound, err.Error())
			}

			return "", common.NewSysErr(err)
		}
	}

	// startTime and endTime 必须同时为空 或者 同时不为空.
	if (params.StartTime != "" && params.EndTime == "") || (params.EndTime != "" && params.StartTime == "") {
		return "", common.NewError(common.RErrRequest, common.TErrInvalid, common.PErrParams, "start_time and end_time must assign values together or not")
	}

	limitBytes := params.LimitBytes

	if limitBytes == 0 {
		limitBytes = logLimitBytes
	}

	_, err := p.ContainerDao.Query(p.DBOperator, podId, params.ContainerName)
	if err != nil {
		p.Logger.Error("[GetPodContainerLogs] ContainerDao.Query failed. PodId: %s ContainerName： %s, Error: %s",
			podId, params.ContainerName, err.Error())
		if dao.IsDataNotFound(err) {
			return "", common.NewError(common.RErrContainer, common.PErrDB, common.TErrNotFound, err.Error())
		}

		return "", common.NewSysErr(err)
	}

	pod, jErr := p.CheckTaskAndStatus(api.ActionGetContainerLogs, podId)
	if jErr != nil {
		return "", jErr
	}

	if pod.HostIp == "" {
		return "", common.NewError(common.RErrPod, common.TErrInvalid, common.PErrHost, "hostIp of pod is nil, not allow get container logs")
	}

	getLogReq := &agent.GetContainerLogsRequest{
		HostIp:        pod.HostIp,
		RuntimeType:   pod.RuntimeType,
		PodId:         podId,
		ContainerName: params.ContainerName,
		TailLines:     params.TailLines,
		LimitBytes:    limitBytes,
		SinceSeconds:  params.SinceSeconds,
		StartTime:     params.StartTime,
		EndTime:       params.EndTime,
	}

	resp, jErr := p.AgentClient.GetContainerLogs(getLogReq)
	if jErr != nil {
		p.Logger.Error("[GetPodContainerLogs] agent.GetContainerLogs failed. PodId: %s, Error: %s, Detail: %s.", podId, jErr.Error(), jErr.Detail())
		return "", common.NewError(common.RErrAgent, common.TErrError, common.PErrLog, jErr.Error())
	}

	return resp.Content, nil
}
