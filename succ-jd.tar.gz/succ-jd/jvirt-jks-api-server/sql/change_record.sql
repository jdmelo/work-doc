/*
请将每次线上修改的SQL的按日期进行添加
*/
-- 20190117
INSERT INTO `jvirt-jks`.`config_info` (`group`, `key`, `value`, `description`, created_time, update_time, status) VALUES ('jks-api', 'recover_task_compensate_timeout', '1800', 'recover task compensate timeout', now(), now(), 1);
INSERT INTO `jvirt-jks`.`config_info` (`group`, `key`, `value`, `description`, created_time, update_time, status) VALUES ('jks-api', 'default_registry_scheme', 'http', 'registry scheme', now(), now(), 1);


-- 20190329
ALTER TABLE `jvirt-jks`.`pod` CHANGE COLUMN `instance_type` `instance_type` VARCHAR(100) NOT NULL ;


-- 20190613
INSERT INTO `jvirt-jks`.`config_info` (`group`, `key`, `value`, `description`, created_time, update_time, status) VALUES ('jks-api', 'task_compensate_apply_resource_timeout', '300', 'task compensate apply resource timeout', now(), now(), 1);

INSERT INTO `jvirt-jks`.`config_info` (`group`, `key`, `value`, `description`, created_time, update_time, status) VALUES ('jks-api', 'task_compensate_clear_resource_timeout', '3600', 'task compensate clear resource timeout', now(), now(), 1);
