USE `jvirt-jks`;

ALTER TABLE `jvirt-jks`.`pod` DROP COLUMN `product_type`;

ALTER TABLE `jvirt-jks`.`network` ADD COLUMN `ipv6_addresses` VARCHAR(200) NOT NULL DEFAULT '' AFTER `fix_ips`;
ALTER TABLE `jvirt-jks`.`network` ADD COLUMN `ipv6_address_count`  TINYINT(4) UNSIGNED NOT NULL DEFAULT 0 AFTER `ipv6_addresses`;

ALTER TABLE `jvirt-jks`.`pod` ADD COLUMN `nc_name` VARCHAR(100) NOT NULL DEFAULT '' AFTER `name`;
ALTER TABLE `jvirt-jks`.`pod` ADD COLUMN `deleted` VARCHAR(20) NOT NULL DEFAULT '' AFTER `log_config`;
ALTER TABLE `jvirt-jks`.`pod` ADD COLUMN `resource_type` VARCHAR(10) NOT NULL DEFAULT 'pod' AFTER `id`;
ALTER TABLE `jvirt-jks`.`pod` ADD COLUMN `service_code` VARCHAR(20) NOT NULL DEFAULT 'normal' AFTER `instance_type`;
ALTER TABLE `jvirt-jks`.`pod` ADD COLUMN `runtime_type` VARCHAR(20) NOT NULL DEFAULT 'xagent' AFTER `service_code`;

ALTER TABLE `jvirt-jks`.`pod_network` ADD COLUMN `ipv6_addresses` VARCHAR(200) NOT NULL DEFAULT '' AFTER `fixed_ip`;
ALTER TABLE `jvirt-jks`.`pod_network` ADD COLUMN `ipv6_address_count` TINYINT(4) UNSIGNED NOT NULL DEFAULT 0 AFTER `ipv6_addresses`;

ALTER TABLE `jvirt-jks`.`container_status` ADD COLUMN `phase` VARCHAR(20) NOT NULL DEFAULT '' AFTER `container_name`;

ALTER TABLE `jvirt-jks`.`container_image` ADD COLUMN `image_digest` VARCHAR(100) NOT NULL DEFAULT '' AFTER `image_name`;

-- 添加索引, 需要先update操作将删除的pod deleted属性,设置成pod_id.
UPDATE `jvirt-jks`.`pod` dst SET deleted=dst.pod_id WHERE status=-1;
ALTER TABLE `jvirt-jks`.`pod` ADD UNIQUE INDEX `pod_name_UNIQUE` (`user_id` ASC, `name` ASC, `deleted` ASC);

-- config info 操作
DELETE FROM `jvirt-jks`.`config_info` WHERE `group`='api';
DELETE FROM `jvirt-jks`.`config_info` WHERE `group`='jks-api' and `key`='jks_docker_hub_domain';
INSERT INTO `jvirt-jks`.`config_info` (`group`, `key`, `value`, `description`, created_time, update_time, status) VALUES ('jks-api', 'jks_docker_hub_domains', 'https://registry.docker-cn.com,https://hub-mirror.c.163.com', 'docker registry list', now(), now(), 1);
-- update config_info 不同的区域配置不同

-- 华北
UPDATE `jvirt-jks`.`config_info` SET `value`='{"always_use_proxy": false,"rules": [{"proxy_url": "DIRECT","url_prefix": "-cn-north-1.jcr.service.jdcloud.com"}],"url": "http://cproxy.jks.cn-north-1.jcloud.com:2004","use_proxy": true}' WHERE `group`='jks-api' and `key`='image_registry_proxy_pac';
UPDATE `jvirt-jks`.`config_info` SET `value`='-cn-north-1.jcr.service.jdcloud.com' WHERE `group`='jks-api' and `key`='jcr_hub_domain_suffix';

-- 华东上海
UPDATE `jvirt-jks`.`config_info` SET `value`='{"always_use_proxy": false,"rules": [{"proxy_url": "DIRECT","url_prefix": "-cn-east-2.jcr.service.jdcloud.com"}],"url": "http://cproxy.jks.cn-east-2.jcloud.com:2004","use_proxy": true}' WHERE `group`='jks-api' and `key`='image_registry_proxy_pac';
UPDATE `jvirt-jks`.`config_info` SET `value`='-cn-east-2.jcr.service.jdcloud.com' WHERE `group`='jks-api' and `key`='jcr_hub_domain_suffix';

-- 华南
UPDATE `jvirt-jks`.`config_info` SET `value`='{"always_use_proxy": false,"rules": [{"proxy_url": "DIRECT","url_prefix": "-cn-south-1.jcr.service.jdcloud.com"}],"url": "http://cproxy.jks.cn-south-1.jcloud.com:2004","use_proxy": true}' WHERE `group`='jks-api' and `key`='image_registry_proxy_pac';
UPDATE `jvirt-jks`.`config_info` SET `value`='-cn-south-1.jcr.service.jdcloud.com' WHERE `group`='jks-api' and `key`='jcr_hub_domain_suffix';