USE `jvirt-jks`;

INSERT INTO `jvirt-jks`.`config_info` (`group`, `key`, `value`, `description`, created_time, update_time, status) VALUES ('jks-api', 'default_pod_dns_server', '103.224.222.222,103.224.222.223', '', now(), now(), 1);
INSERT INTO `jvirt-jks`.`config_info` (`group`, `key`, `value`, `description`, created_time, update_time, status) VALUES ('jks-api', 'default_az', 'az1', 'default az', now(), now(), 1);
INSERT INTO `jvirt-jks`.`config_info` (`group`, `key`, `value`, `description`, created_time, update_time, status) VALUES ('jks-api', 'admin_token', '07765634-933c-4cea-9f63-a586cd15cbb8', 'admin token', now(), now(), 1);
INSERT INTO `jvirt-jks`.`config_info` (`group`, `key`, `value`, `description`, created_time, update_time, status) VALUES ('jks-api', 'task_compensate_timeout', '300', 'task compensate timeout', now(), now(), 1);
INSERT INTO `jvirt-jks`.`config_info` (`group`, `key`, `value`, `description`, created_time, update_time, status) VALUES ('jks-api', 'image_registry_http_proxy', 'http://192.168.178.128:3128', 'image registry http proxy', now(), now(), 1);
INSERT INTO `jvirt-jks`.`config_info` (`group`, `key`, `value`, `description`, created_time, update_time, status) VALUES ('jks-api', 'resource_quota_limit', '20', 'resource quota limit', now(), now(), 1);
INSERT INTO `jvirt-jks`.`config_info` (`group`, `key`, `value`, `description`, created_time, update_time, status) VALUES ('jks-api', 'jcr_hub_domain_suffix', 'jcr.service.jdcloud.com', '', now(), now(), 1);
INSERT INTO `jvirt-jks`.`config_info` (`group`, `key`, `value`, `description`, created_time, update_time, status) VALUES ('jks-api', 'jcr_hub_password', 'jks-agent', '', now(), now(), 1);

INSERT INTO `jvirt-jks`.`config_info` (`group`, `key`, `value`, `description`, created_time, update_time, status) VALUES ('jks-api', 'jks_docker_hub_domains', 'https:registry.docker-cn.com,https://hub-mirror.c.163.com', 'docker registry list', now(), now(), 1);
INSERT INTO `jvirt-jks`.`config_info` (`group`, `key`, `value`, `description`, created_time, update_time, status) VALUES ('jks-api', 'image_registry_proxy_pac', '{"always_use_proxy": false,"rules": [{"proxy_url": "DIRECT","url_prefix": ".jcr.service.jdcloud.com"},{"proxy_url": "DIRECT","url_prefix": ".jcr.service.jcloud.com"},{"proxy_url": "DIRECT","url_prefix": ".JCLOUD.COM"}],"url": "http://10.10.10.10:3128","use_proxy": true}', 'image registry proxy pac', now(), now(), 1);
