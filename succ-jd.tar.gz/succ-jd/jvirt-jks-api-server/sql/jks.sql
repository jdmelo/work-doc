-- CREATE SCHEMA IF NOT EXISTS `jvirt-jks` DEFAULT CHARACTER SET utf8;

USE `jvirt-jks`;

CREATE TABLE IF NOT EXISTS `jvirt-jks`.`config_info` (
  `id` bigint(19) NOT NULL AUTO_INCREMENT,
  `group` varchar(255) NOT NULL,
  `key` varchar(100) NOT NULL,
  `value` varchar(1000) NOT NULL,
  `description` varchar(255) NOT NULL,
  `created_time` datetime NOT NULL,
  `update_time` datetime NOT NULL,
  `status` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `jvirt-jks`.`event` (
  `id` bigint(19) NOT NULL AUTO_INCREMENT,
  `resource_id` varchar(50) NOT NULL,
  `resource_type` varchar(20) NOT NULL,
  `new_resource_state` varchar(20) NOT NULL,
  `old_resource_state` varchar(20) NOT NULL,
  `task_id` bigint(19) DEFAULT '0',
  `task_type` varchar(50) DEFAULT '',
  `task_state` varchar(20) DEFAULT '',
  `event_type` varchar(20) NOT NULL,
  `event_state` varchar(20) NOT NULL,
  `created_time` datetime NOT NULL,
  `update_time` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `jvirt-jks`.`event_bak` (
  `id` bigint(19) NOT NULL AUTO_INCREMENT,
  `resource_id` varchar(50) NOT NULL,
  `resource_type` varchar(20) NOT NULL,
  `new_resource_state` varchar(20) NOT NULL,
  `old_resource_state` varchar(20) NOT NULL,
  `task_id` bigint(19) DEFAULT '0',
  `task_type` varchar(50) DEFAULT '',
  `task_state` varchar(20) DEFAULT '',
  `event_type` varchar(20) NOT NULL,
  `event_state` varchar(20) NOT NULL,
  `created_time` datetime NOT NULL,
  `update_time` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `jvirt-jks`.`idempotency` (
  `id` bigint(19) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) NOT NULL,
  `client_token` varchar(60) NOT NULL,
  `action` varchar(30) NOT NULL,
  `state` varchar(20) NOT NULL,
  `chost` varchar(50) DEFAULT '',
  `shost` varchar(50) DEFAULT '',
  `output` varchar(5000) DEFAULT '',
  `input` varchar(5000) DEFAULT '',
  `execute_time` int(10) DEFAULT '0',
  `created_time` datetime NOT NULL,
  `update_time` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_user_token` (`user_id`,`client_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `jvirt-jks`.`idempotency_bak` (
  `id` bigint(19) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) NOT NULL,
  `client_token` varchar(60) NOT NULL,
  `action` varchar(30) NOT NULL,
  `state` varchar(20) NOT NULL,
  `chost` varchar(50) DEFAULT '',
  `shost` varchar(50) DEFAULT '',
  `output` varchar(5000) DEFAULT '',
  `input` varchar(5000) DEFAULT '',
  `execute_time` int(10) DEFAULT '0',
  `created_time` datetime NOT NULL,
  `update_time` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_user_token` (`user_id`,`client_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `jvirt-jks`.`image_secret` (
  `id` varchar(20) NOT NULL,
  `name` varchar(256) DEFAULT '',
  `user_id` varchar(50) DEFAULT '',
  `credential_type` varchar(20) NOT NULL,
  `image_server` varchar(300) NOT NULL,
  `user_name` varchar(50) DEFAULT '',
  `password` varchar(100) DEFAULT '',
  `email` varchar(50) DEFAULT '',
  `created_time` datetime NOT NULL,
  `update_time` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `jvirt-jks`.`quota` (
  `id` bigint(19) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) NOT NULL,
  `quota` int(10) NOT NULL,
  `used` int(10) NOT NULL,
  `quota_type` varchar(20) NOT NULL,
  `version` bigint(19) NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL,
  `update_time` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_user_quota` (`user_id`,`quota_type`),
  KEY `index_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `jvirt-jks`.`task` (
  `id` bigint(19) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) NOT NULL,
  `request_id` varchar(60) NOT NULL,
  `client_token` varchar(60) DEFAULT '',
  `task_type` varchar(50) NOT NULL,
  `task_state` varchar(20) NOT NULL,
  `refer_id` varchar(50) NOT NULL,
  `host_ip` varchar(20) DEFAULT '',
  `content` varchar(2000) DEFAULT '',
  `extends` varchar(2000) DEFAULT '',
  `timeout` int(10) DEFAULT '0',
  `retry_time` int(10) DEFAULT '1',
  `task_after` tinyint(4) NOT NULL,
  `task_before` tinyint(4) NOT NULL,
  `fault` varchar(200) DEFAULT '',
  `created_time` datetime NOT NULL,
  `update_time` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `jvirt-jks`.`task_bak` (
  `id` bigint(19) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) NOT NULL,
  `request_id` varchar(60) NOT NULL,
  `client_token` varchar(60) DEFAULT '',
  `task_type` varchar(50) NOT NULL,
  `task_state` varchar(20) NOT NULL,
  `refer_id` varchar(50) NOT NULL,
  `host_ip` varchar(20) DEFAULT '',
  `content` varchar(2000) DEFAULT '',
  `extends` varchar(2000) DEFAULT '',
  `timeout` int(10) DEFAULT '0',
  `retry_time` int(10) DEFAULT '1',
  `task_after` tinyint(4) NOT NULL,
  `task_before` tinyint(4) NOT NULL,
  `fault` varchar(200) DEFAULT '',
  `created_time` datetime NOT NULL,
  `update_time` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `jvirt-jks`.`pod` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `resource_type` varchar(10) NOT NULL DEFAULT 'pod',
  `pod_id` varchar(20) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `user_pin` varchar(100) NOT NULL,
  `task_id` bigint(20) NOT NULL,
  `alloc_id` varchar(20) NOT NULL DEFAULT '',
  `name` varchar(253) NOT NULL,
  `nc_name` VARCHAR(100) NOT NULL DEFAULT '',
  `description` varchar(1024) NOT NULL DEFAULT '',
  `instance_type` varchar(20) NOT NULL,
  `service_code` varchar(20) NOT NULL DEFAULT 'normal',
  `runtime_type` varchar(20) NOT NULL DEFAULT 'xagent',
  `hostname` varchar(256) NOT NULL DEFAULT '',
  `az` varchar(50) NOT NULL,
  `host_ip` varchar(20) NOT NULL DEFAULT '',
  `restart_policy` varchar(20) NOT NULL DEFAULT 'Always' COMMENT 'Always | Nerver | OnFailure',
  `termination_grace_period_seconds` int(10) unsigned NOT NULL DEFAULT '30',
  `dns_config` varchar(2000) NOT NULL DEFAULT '',
  `log_config` varchar(500) NOT NULL DEFAULT '',
  `deleted` varchar(20) NOT NULL DEFAULT '',
  `created_time` datetime NOT NULL,
  `update_time` datetime NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pod_id_UNIQUE` (`pod_id`),
  UNIQUE KEY `pod_name_UNIQUE` (`user_id`, `name`, `deleted`),
  KEY `user_id_INDEX` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `jvirt-jks`.`pod_status` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `pod_id` VARCHAR(20) NOT NULL,
  `phase` VARCHAR(20) NOT NULL DEFAULT 'Pending' COMMENT '高层次Pod状态.',
  `reason` VARCHAR(100) NOT NULL DEFAULT 'PodCreating' COMMENT '一条简短的驼峰式消息，指示有关pod处于此状态的原因的详细信息； 例如：\'Evicted\'。',
  `message` VARCHAR(1024) NOT NULL DEFAULT '' COMMENT '一条可读的消息，指示有关pod处于此状态的原因的详细信息',
  `start_time` VARCHAR(100) NOT NULL DEFAULT '' COMMENT 'RFC 3339 date and time at which the object was acknowledged by the Kubelet. This is before the Kubelet pulled the container image(s) for the pod.',
  `created_time` DATETIME NOT NULL,
  `update_time` DATETIME NOT NULL,
  `status` TINYINT(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `pod_id_UNIQUE` (`pod_id` ASC)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `jvirt-jks`.`pod_condition` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `pod_id` varchar(20) NOT NULL,
  `reason` varchar(100) NOT NULL DEFAULT '',
  `message` varchar(500) NOT NULL DEFAULT '',
  `condition_type` varchar(50) NOT NULL DEFAULT 'Ready',
  `condition_status` varchar(20) NOT NULL DEFAULT 'False' COMMENT 'Status is the status of the condition. Can be True, False, Unknown.',
  `last_probe_time` varchar(100) NOT NULL DEFAULT '',
  `last_transition_time` varchar(100) NOT NULL DEFAULT '',
  `created_time` datetime NOT NULL,
  `update_time` datetime NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pod_id_type_UNIQUE` (`pod_id`,`condition_type`),
  KEY `pod_id_INDEX` (`pod_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `jvirt-jks`.`pod_host_alias` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `pod_id` VARCHAR(20) NOT NULL,
  `hostnames` VARCHAR(2000) NOT NULL,
  `ip` VARCHAR(64) NOT NULL,
  `created_time` DATETIME NOT NULL,
  `update_time` DATETIME NOT NULL,
  `status` TINYINT(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `pod_id_INDEX` (`pod_id`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `jvirt-jks`.`pod_network` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `pod_id` VARCHAR(20) NOT NULL,
  `boot_index` TINYINT(4) UNSIGNED NOT NULL DEFAULT 1,
  `port_id` VARCHAR(50) NOT NULL,
  `vpc_id` VARCHAR(50) NOT NULL,
  `subnet_id` VARCHAR(50) NOT NULL,
  `fixed_ip` VARCHAR(20) NOT NULL DEFAULT '',
  `ipv6_addresses` VARCHAR(200) NOT NULL DEFAULT '',
  `ipv6_address_count` TINYINT(4) UNSIGNED NOT NULL DEFAULT 0,
  `security_groups` VARCHAR(200) NOT NULL DEFAULT '',
  `delete_on_termination` TINYINT(4) UNSIGNED NOT NULL DEFAULT 1 COMMENT '0: 不随pod一起删除;\n1: 随pod一起删除.',
  `created_time` DATETIME NOT NULL,
  `update_time` DATETIME NOT NULL,
  `status` TINYINT(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `pod_id_INDEX` (`pod_id`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `jvirt-jks`.`pod_volume` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `pod_id` VARCHAR(20) NOT NULL,
  `name` VARCHAR(100) NOT NULL COMMENT 'name在一个pod内是唯一的',
  `volume_type` VARCHAR(50) NOT NULL DEFAULT 'JDCloudDisk' COMMENT 'JDCloudDisk| EmptyDir | GitRepo',
  `refer_id` VARCHAR(50) NOT NULL DEFAULT '' COMMENT 'volume id',
  `content` VARCHAR(500) NOT NULL DEFAULT '' COMMENT 'ssd | premium-ssd',
  `created_time` DATETIME NOT NULL,
  `update_time` DATETIME NOT NULL,
  `status` TINYINT(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `pod_id_INDEX` (`pod_id`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `jvirt-jks`.`container` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `pod_id` VARCHAR(20) NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `command` VARCHAR(1024) NOT NULL DEFAULT '',
  `args` VARCHAR(3000) NOT NULL DEFAULT '',
  `image` VARCHAR(1024) NOT NULL COMMENT 'name:tag',
  `secret` VARCHAR(256) NOT NULL DEFAULT '',
  `tty` TINYINT(4) UNSIGNED NOT NULL DEFAULT 0,
  `working_dir` VARCHAR(2048) NOT NULL DEFAULT '/',
  `cpu_request` INT(10) unsigned NOT NULL,
  `cpu_limit` INT(10) unsigned NOT NULL,
  `mem_request` INT(10) unsigned NOT NULL COMMENT 'Unit: MB',
  `mem_limit` INT(10) unsigned NOT NULL COMMENT 'Unit: MB',
  `created_time` DATETIME NOT NULL,
  `update_time` DATETIME NOT NULL,
  `status` TINYINT(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pod_id_name_UNIQUE` (`pod_id`,`name`),
  KEY `pod_id_INDEX` (`pod_id`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `jvirt-jks`.`container_env` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `pod_id` VARCHAR(20) NOT NULL,
  `container_name` VARCHAR(100) NOT NULL,
  `source` VARCHAR(20) NOT NULL DEFAULT 'user' COMMENT 'user | image',
  `name` VARCHAR(64) NOT NULL,
  `value` VARCHAR(1024) NOT NULL DEFAULT '',
  `created_time` DATETIME NOT NULL,
  `update_time` DATETIME NOT NULL,
  `status` TINYINT(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `pod_id_INDEX` (`pod_id`),
  KEY `pod_id_c_name_INDEX` (`pod_id`,`container_name`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `jvirt-jks`.`container_image` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `pod_id` VARCHAR(20) NOT NULL,
  `container_name` VARCHAR(100) NOT NULL,
  `registry_type` VARCHAR(20) NOT NULL DEFAULT 'dockerHub' COMMENT 'dockerHub | jcrHub | selfHub',
  `registry_url` VARCHAR(300) NOT NULL,
  `registry_username` VARCHAR(50) NOT NULL DEFAULT '',
  `registry_password` VARCHAR(100) NOT NULL DEFAULT '',
  `image_name` VARCHAR(500) NOT NULL,
  `image_digest` VARCHAR(100) NOT NULL DEFAULT '',
  `working_dir` VARCHAR(2048) NOT NULL DEFAULT '',
  `command` VARCHAR(1024) NOT NULL DEFAULT '',
  `entrypoint` VARCHAR(1024) NOT NULL DEFAULT '',
  `created_time` DATETIME NOT NULL,
  `update_time` DATETIME NOT NULL,
  `status` TINYINT(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pod_id_c_name_UNIQUE` (`pod_id`,`container_name`),
  KEY `pod_id_INDEX` (`pod_id`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `jvirt-jks`.`container_probe` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `pod_id` VARCHAR(20) NOT NULL,
  `container_name` VARCHAR(100) NOT NULL,
  `probe_type` VARCHAR(20) NOT NULL DEFAULT 'liveness' COMMENT 'liveness | readiness',
  `probe_action` VARCHAR(20) NOT NULL DEFAULT 'httpGet' COMMENT 'exec | httpGet | tcpSocket',
  `initial_delay_seconds` INT(10) unsigned NOT NULL DEFAULT 10 COMMENT 'Number of seconds after the container has started before liveness probes are initiated.',
  `failure_threshold` INT(10) unsigned NOT NULL DEFAULT 3 COMMENT 'Minimum consecutive failures for the probe to be considered failed after having succeeded. Defaults to 3. Minimum value is 1.',
  `success_threshold` INT(10) unsigned NOT NULL DEFAULT 1 COMMENT 'Minimum consecutive successes for the probe to be considered successful after having failed. Defaults to 1. Must be 1 for liveness. Minimum value is 1.',
  `period_seconds` INT(10) unsigned NOT NULL DEFAULT 10 COMMENT 'How often (in seconds) to perform the probe. Default to 10 seconds. Minimum value is 1.',
  `timeout_seconds` INT(10) unsigned NOT NULL DEFAULT 1 COMMENT 'Number of seconds after which the probe times out. Defaults to 1 second. Minimum value is 1. ',
  `content` VARCHAR(1024) NOT NULL DEFAULT '',
  `created_time` DATETIME NOT NULL,
  `update_time` DATETIME NOT NULL,
  `status` TINYINT(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pod_id_c_name_type_UNIQUE` (`pod_id`,`container_name`,`probe_type`),
  KEY `pod_id_INDEX` (`pod_id`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `jvirt-jks`.`container_status` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `pod_id` VARCHAR(20) NOT NULL,
  `container_name` VARCHAR(100) NOT NULL,
  `phase` VARCHAR(20) NOT NULL DEFAULT '',
  `ready` TINYINT(4) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Specifies whether the container has passed its readiness probe.',
  `restart_count` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `last_state` VARCHAR(50) NOT NULL DEFAULT 'Waiting' COMMENT 'Waiting | Terminated | Running',
  `last_state_content` VARCHAR(500) NOT NULL DEFAULT '',
  `current_state` VARCHAR(50) NOT NULL DEFAULT 'Waiting' COMMENT 'Waiting | Terminated | Running',
  `current_state_content` VARCHAR(500) NOT NULL DEFAULT '',
  `created_time` DATETIME NOT NULL,
  `update_time` DATETIME NOT NULL,
  `status` TINYINT(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pod_id_c_name_UNIQUE` (`pod_id`,`container_name`),
  KEY `pod_id_INDEX` (`pod_id`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `jvirt-jks`.`container_system_disk` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `pod_id` VARCHAR(20) NOT NULL,
  `container_name` VARCHAR(100) NOT NULL,
  `volume_id` VARCHAR(50) NOT NULL,
  `volume_type` VARCHAR(50) NOT NULL DEFAULT 'ssd',
  `fs_type` VARCHAR(20) NOT NULL DEFAULT 'xfs' COMMENT 'xfs | ext4',
  `delete_on_termination` TINYINT(4) UNSIGNED NOT NULL DEFAULT 1 COMMENT '0: 不随pod一起删除;\n1: 随pod一起删除.',
  `created_time` DATETIME NOT NULL,
  `update_time` DATETIME NOT NULL,
  `status` TINYINT(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pod_id_c_name_UNIQUE` (`pod_id`,`container_name`),
  KEY `pod_id_INDEX` (`pod_id`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `jvirt-jks`.`container_volume_mount` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `pod_id` VARCHAR(20) NOT NULL,
  `container_name` VARCHAR(100) NOT NULL,
  `pod_volume_name` VARCHAR(64) NOT NULL,
  `mount_path` VARCHAR(1024) NOT NULL,
  `read_only` TINYINT(4) UNSIGNED NOT NULL DEFAULT 0,
  `created_time` DATETIME NOT NULL,
  `update_time` DATETIME NOT NULL,
  `status` TINYINT(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `pod_id_INDEX` (`pod_id`),
  KEY `pod_id_c_name_INDEX` (`pod_id`,`container_name`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;
