package httpclient

import (
	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/inner/jks/api"

	common "jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils/config"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-jks-gw/model"
)

type JksApiClient struct {
	logger log.Logger
	client api.InnerApi
}

func NewJksApiClient(log log.Logger, c *model.JvirtJksApiConfig) (*JksApiClient, error) {
	jksCfg := &config.JksApiConfig{
		Url:                   c.Url,
		ConnectTimeout:        c.ConnectTimeout,
		MaxIdleConns:          c.MaxIdleConns,
		TimerInterval:         c.TimerInterval,
		ResponseHeaderTimeout: c.ResponseHeaderTimeout,
		RequestTotalTimeout:   c.RequestTotalTimeout,
	}
	client := api.NewJksInnerApiClient(jksCfg, log)

	return &JksApiClient{
		client: client,
		logger: log,
	}, nil
}

func (p *JksApiClient) DescribePodStatus(repId, podId string) (*jks.ApiPodStatus, error) {
	request := &api.GetPodStatusRequest{
		PodId: podId,
	}

	podStatus, err := p.client.GetPodStatus(request)
	if err != nil {
		p.logger.Error("[DescribePodStatus] get pod status from jks-api-server failed. PodId: %s, Error: %s",
			podId, err.Error())
		return nil, err
	}

	if podStatus == nil {
		p.logger.Error("[DescribePodStatus] pod status not found in jks-api-server. PodId: %s", podId)
		return nil, common.NewError(common.RErrPod, common.TErrNotFound, common.PErrStatus, "pod status not found")
	}

	return podStatus, nil
}

func (p *JksApiClient) UpdatePodStatus(req *api.UpdatePodStatusRequest) common.JvirtError {
	if err := p.client.UpdatePodStatus(req); err != nil {
		p.logger.Error("Invoke JksApi UpdatePodStatus failed. PodId: %s, Error: %s", req.PodId, err.Error())
		return err
	}

	return nil
}
