package handler

import (
	"encoding/json"
	"strconv"

	"jd.com/jvirt/jvirt-common/inner/jks"
	"jd.com/jvirt/jvirt-common/inner/jks/api"
	"jd.com/jvirt/jvirt-common/inner/jks/gw"
	"jd.com/jvirt/jvirt-common/model"
	"jd.com/jvirt/jvirt-common/utils"
	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/redis"
	"jd.com/jvirt/jvirt-common/utils/url"
	"jd.com/jvirt/jvirt-common/utils/validate"
	"jd.com/jvirt/jvirt-jks-gw/httpclient"
)

type GWHandler struct {
	Logger      log.Logger
	RedisClient redis.Redis
	JksApi      *httpclient.JksApiClient
}

func (p *GWHandler) getTaskKey(host string) string {
	return model.JksCacheTaskPrefix + host
}

func (p *GWHandler) getPodStatusKey(host string) string {
	return model.JksCachePodStatusPrefix + host
}

func (p *GWHandler) getPodConditionKey(host string) string {
	return model.JksCachePodConditionPrefix + host
}

func (p *GWHandler) getContainerStatusKey(host string) string {
	return model.JksCacheContainerStatusPrefix + host
}

func (p *GWHandler) describeTasks(params *gw.DescribeTasksRequest) ([]*jks.Task, model.JvirtError) {
	taskKey := p.getTaskKey(params.HostIp)
	p.Logger.Debug("[describeTasks] TaskKey: %s", taskKey)

	tasks, err := p.RedisClient.HashGet(taskKey)
	if err != nil {
		p.Logger.Error("[describeTasks] Invoke Redis.HashGet failed. Error: %#v.", err)
		return nil, model.NewSysErr(err)
	}

	for _, tId := range params.ExcludeTaskIds {
		delete(tasks, strconv.Itoa(int(tId)))
	}

	ret := make([]*jks.Task, 0)
	for _, value := range tasks {
		task := new(jks.Task)
		json.Unmarshal([]byte(value), task)
		if params.TaskState == "" {
			ret = append(ret, task)
		} else if task.TaskState == params.TaskState {
			ret = append(ret, task)
		}
	}

	return ret, nil
}

func (p *GWHandler) isChangePodStatus(realStatus *jks.PodStatus, dbStatus *jks.ApiPodStatus) bool {

	p.Logger.Debug("[isChangePodStatus] PodId:%s， realStatus:[%v] dbStatus:[%v]", dbStatus.PodId, *realStatus, *dbStatus)
	if realStatus.Phase != dbStatus.Phase ||
		realStatus.Reason != dbStatus.Reason ||
		realStatus.Message != dbStatus.Message {

		return true
	}

	return false
}

func (p *GWHandler) isChangePodCondition(realStatus *jks.PodCondition, dbStatus *model.CachePodCondition) bool {
	p.Logger.Debug("[isChangePodCondition] Status:[%v] dbStatus:[%v]", *realStatus, *dbStatus)
	if realStatus.Status != dbStatus.Status ||
		realStatus.Reason != dbStatus.Reason ||
		realStatus.Message != dbStatus.Message ||
		realStatus.LastTransitionTime != dbStatus.LastTransitionTime {

		return true
	}

	return false
}

func (p *GWHandler) isChangeContainerStatus(realStatus *jks.ContainerStatus, dbStatus *model.CacheContainerStatus) bool {
	p.Logger.Debug("[isChangeContainerStatus] realStatus:[%v] dbStatus:[%v]", *realStatus, *dbStatus)
	realCurState := ""

	if realStatus.State != nil {
		realCurState = realStatus.State.GetState()
	} else {
		return false
	}

	if realStatus.Phase != dbStatus.Phase ||
		realStatus.Ready != dbStatus.Ready ||
		realStatus.RestartCount != dbStatus.RestartCount ||
		realCurState != dbStatus.CurrentState {
		return true
	}

	dbObject := &jks.ContainerState{}
	if err := json.Unmarshal([]byte(dbStatus.CurrentStateContent), dbObject); err != nil {
		p.Logger.Error("json.Unmarshal CurrentStateContent failed. Error: %s.", err.Error())
		return false
	}

	// 深度判断.
	switch realCurState {
	case jks.ContainerStatusRunning:
		realRunning := realStatus.State.Running
		dbRunning := dbObject.Running

		if realRunning.StartedAt != dbRunning.StartedAt {
			return true
		}
	case jks.ContainerStatusWaiting:
		realWaiting := realStatus.State.Waiting
		dbWaiting := dbObject.Waiting

		if realWaiting.Reason != dbWaiting.Reason || realWaiting.Message != dbWaiting.Message {
			return true
		}
	case jks.ContainerStatusTerminated:
		realTerminated := realStatus.State.Terminated
		dbTerminated := dbObject.Terminated

		if realTerminated.StartedAt != dbTerminated.StartedAt {
			return true
		}
	}

	return false
}

func (p *GWHandler) updatePodStatus(params *gw.UpdatePodStatusRequest) model.JvirtError {
	var failedErr model.JvirtError

	hostIp := params.HostIp

	// 生成Redis中key。
	podStatusKey := p.getPodStatusKey(hostIp)
	p.Logger.Debug("[updatePodStatus] PodStatusKey: %s", podStatusKey)
	podCondKey := p.getPodConditionKey(hostIp)
	p.Logger.Debug("[updatePodStatus] PodConditionKey: %s", podCondKey)
	containerStatusKey := p.getContainerStatusKey(hostIp)
	p.Logger.Debug("[updatePodStatus] ContainerStatusKey: %s", containerStatusKey)

	// 根据Key请求Redis获取数据。
	//cachePodStatusMap, err := p.RedisClient.HashGet(podStatusKey)
	//if err != nil {
	//	p.Logger.Error("[updatePodStatus] Invoke Redis.HashGet failed. Error: %s.", err.Error())
	//	return model.NewSysErr(err)
	//}
	cachePodCondMap, err := p.RedisClient.HashGet(podCondKey)
	if err != nil {
		p.Logger.Error("[updatePodStatus] Invoke Redis.HashGet failed. Error: %s.", err.Error())
		return model.NewSysErr(err)
	}
	cacheContainerStatusMap, err := p.RedisClient.HashGet(containerStatusKey)
	if err != nil {
		p.Logger.Error("[updatePodStatus] Invoke Redis.HashGet failed. Error: %s.", err.Error())
		return model.NewSysErr(err)
	}

	// 检查状态更新。
	for podId, realPodStatus := range params.PodStatuses {
		p.Logger.Debug("start compare podId: %s", podId)
		reqId := utils.GenerateUuid("req")
		isUpdate := false

		jksPodStatus, err := p.JksApi.DescribePodStatus(reqId, podId)
		if err != nil {
			p.Logger.Error("[JksApi.DescribePodStatus] failed. PodId: %s, Error: %s.", podId, err.Error())
			continue
		}
		if jksPodStatus.TaskId != 0 {
			p.Logger.Info("Pod [%s] is running task [%v], no need update status.", podId, jksPodStatus.TaskId)
			continue
		}
		if jksPodStatus.HostIp != hostIp {
			p.Logger.Warn("Pod [%s] migrate failed or finished, but clear resource is no complete.", podId)
			continue
		}

		jksApiRequest := &api.UpdatePodStatusRequest{
			PodId: podId,
			PodStatus: &jks.PodStatus{
				Phase:             realPodStatus.Phase,
				Reason:            realPodStatus.Reason,
				Message:           realPodStatus.Message,
				StartTime:         realPodStatus.StartTime,
				PodIP:             realPodStatus.PodIP,
				ContainerStatuses: make([]*jks.ContainerStatus, 0),
				Conditions:        make([]*jks.PodCondition, 0),
			},
		}
		reqPodStatus := jksApiRequest.PodStatus

		//比较pod conditions
		for _, realPodCond := range realPodStatus.Conditions {
			redisField := podId + "_" + realPodCond.Type
			cacheObject, ok := cachePodCondMap[redisField]
			if !ok {
				p.Logger.Warn("[updatePodStatus] PodCondition %s not found in the Cache.", redisField)
				continue
			}

			cachePodCond := new(model.CachePodCondition)
			if err := json.Unmarshal([]byte(cacheObject), cachePodCond); err != nil {
				p.Logger.Error("[updatePodStatus] Unmarshal cachePodCondition failed. RedisField: %s, Error: %s.", redisField, err.Error())
				continue
			}

			//对比
			if p.isChangePodCondition(realPodCond, cachePodCond) {
				isUpdate = true
				podCondition := &jks.PodCondition{
					LastProbeTime:      realPodCond.LastProbeTime,
					LastTransitionTime: realPodCond.LastTransitionTime,
					Reason:             realPodCond.Reason,
					Message:            realPodCond.Message,
					Status:             realPodCond.Status,
					Type:               realPodCond.Type,
				}
				reqPodStatus.Conditions = append(reqPodStatus.Conditions, podCondition)
			}
		}

		//比较pod Container
		for _, realCStatus := range realPodStatus.ContainerStatuses {
			redisField := jks.JoinPodContainerUQ(podId, realCStatus.Name)
			cacheObject, ok := cacheContainerStatusMap[redisField]
			if !ok {
				p.Logger.Warn("[updatePodStatus] ContainerStatus %s not found in the Cache.", redisField)
				continue
			}

			cacheCStatus := new(model.CacheContainerStatus)
			if err := json.Unmarshal([]byte(cacheObject), cacheCStatus); err != nil {
				p.Logger.Error("[updatePodStatus] Unmarshal cacheCStatus failed. RedisField: %s, Error: %s.", redisField, err.Error())
				continue
			}

			if p.isChangeContainerStatus(realCStatus, cacheCStatus) {
				isUpdate = true

				reqContainerStatus := &jks.ContainerStatus{
					Phase:        realCStatus.Phase,
					Name:         realCStatus.Name,
					RestartCount: realCStatus.RestartCount,
					Ready:        realCStatus.Ready,
					State:        realCStatus.State,
					LastState:    realCStatus.LastState,
				}
				reqPodStatus.ContainerStatuses = append(reqPodStatus.ContainerStatuses, reqContainerStatus)
			}
		}

		if isUpdate == false && p.isChangePodStatus(realPodStatus, jksPodStatus) {
			isUpdate = true
		}

		if isUpdate {
			// update value state
			if err := p.JksApi.UpdatePodStatus(jksApiRequest); err != nil {
				p.Logger.Error("JksApi.UpdatePodStatus failed. Error: %s, PodId: %s.", err.Detail(), podId)
				failedErr = err
			}
		}
	}

	return failedErr
}

func (p *GWHandler) DescribeTasks(request *url.Request, response *url.Response) model.JvirtError {
	p.Logger.Debug("[DescribeTasks] request.Content %s", string(request.Content))

	params := new(gw.DescribeTasksRequest)
	if err := json.Unmarshal(request.Content, params); err != nil {
		p.Logger.Error("[DescribeTasks] Unmarshal failed. Error: %#v.", err)
		return model.NewSysErr(err)
	}

	if err := validate.JVirtValidate(params, "task"); err != nil {
		p.Logger.Error("[DescribeTasks] JVirtValidate failed. Error: %#v.", err)
		return err
	}

	data, err := p.describeTasks(params)
	if err != nil {
		p.Logger.Error("[DescribeTasks] Invoke describeTasks failed. Error: %#v.", err)
		return err
	}
	response.Response.Data = data

	return nil
}

func (p *GWHandler) UpdatePodStatus(request *url.Request, response *url.Response) model.JvirtError {
	p.Logger.Debug("[UpdatePodStatus] request.Content %s.", string(request.Content))

	params := new(gw.UpdatePodStatusRequest)
	if err := json.Unmarshal(request.Content, params); err != nil {
		p.Logger.Error("[UpdatePodStatus] Unmarshal failed. Error: %#v.", err)
		return model.NewSysErr(err)
	}

	if err := p.updatePodStatus(params); err != nil {
		p.Logger.Error("[UpdatePodStatus] updateInstanceState failed. Error: %#v.", err)
		return err
	}

	return nil
}

func (p *GWHandler) Heartbeat(request *url.Request, response *url.Response) model.JvirtError {
	p.Logger.Debug("[Heartbeat] request.Content %s.", string(request.Content))

	params := new(gw.HeartbeatRequest)
	if err := json.Unmarshal(request.Content, params); err != nil {
		p.Logger.Error("[Heartbeat] Unmarshal failed. Error: %#v.", err)
		return model.NewSysErr(err)
	}

	if err := validate.JVirtValidate(params, "heartbeat"); err != nil {
		p.Logger.Error("[Heartbeat] JVirtValidate failed. Error: %#v.", err)
		return err
	}

	if params.UpdatePodStatus != nil {
		if err := p.updatePodStatus(params.UpdatePodStatus); err != nil {
			p.Logger.Error("[Heartbeat] UpdatePodStatus failed. Error: %#v.", err)
			return err
		}
	}

	data, err := p.describeTasks(params.DescribeTasks)
	if err != nil {
		p.Logger.Error("[DescribeTasks] Invoke describeTasks failed. Error: %#v.", err)
		return err
	}
	response.Response.Data = data

	return nil
}

func (p *GWHandler) RegisterHandler(r *url.Router) {
	r.RegisterHandleFunc(gw.ActionDescribeTasks, p.DescribeTasks)
	r.RegisterHandleFunc(gw.ActionUpdatePodStatus, p.UpdatePodStatus)
	r.RegisterHandleFunc(gw.ActionHeartbeat, p.Heartbeat)
}
