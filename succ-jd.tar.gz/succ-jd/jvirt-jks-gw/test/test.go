package main

import (
	"fmt"
	"strings"
)

func main() {
	a := "pod-12345_test_qaz"
	fmt.Println(strings.SplitN(a, "_", 2))
}
