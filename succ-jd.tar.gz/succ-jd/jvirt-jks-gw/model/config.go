package model

type DefaultConfig struct {
	HttpPort     string `ini:"http_port"`
	BasePath     string `ini:"base_path"`
	RuntimeCores int    `ini:"runtime_cores"`
}

type LogConfig struct {
	Level    string `ini:"level"`
	FilePath string `ini:"file_path" validate:"nonzero"`
}

type JvirtJksApiConfig struct {
	Url                   string `ini:"url" validate:"nonzero"`
	ConnectTimeout        int    `ini:"connect_timeout" validate:"nonzero"`
	MaxIdleConns          int    `ini:"max_idle_conns" validate:"nonzero"`
	TimerInterval         int    `ini:"timer_interval" validate:"nonzero"`
	ResponseHeaderTimeout int    `ini:"response_header_timeout" validate:"nonzero"`
	RequestTotalTimeout   int    `ini:"request_total_timeout" validate:"nonzero"`
}

type VolumeConfig struct {
	Url                   string `ini:"url" validate:"nonzero"`
	ConnectTimeout        int    `ini:"connect_timeout" validate:"nonzero"`
	MaxIdleConns          int    `ini:"max_idle_conns" validate:"nonzero"`
	TimerInterval         int    `ini:"timer_interval" validate:"nonzero"`
	ResponseHeaderTimeout int    `ini:"response_header_timeout" validate:"nonzero"`
	RequestTotalTimeout   int    `ini:"request_total_timeout" validate:"nonzero"`
}

type RedisConfig struct {
	Addr        []string `ini:"addr" validate:"nonzero"` // addr 可以多个，以逗号分隔
	IdleMax     int      `ini:"idle_max" validate:"nonzero"`
	ActiveMax   int      `ini:"active_max" validate:"nonzero"`
	IdleTimeout int      `ini:"idle_timeout" validate:"nonzero"`
	Password    string   `ini:"password" validate:"nonzero"`
}
