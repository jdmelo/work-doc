package server

import (
	"context"
	"fmt"
	"net/http"
	"strings"
	"time"

	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/redis"
	"jd.com/jvirt/jvirt-common/utils/url"
	"jd.com/jvirt/jvirt-jks-gw/cfg"
	"jd.com/jvirt/jvirt-jks-gw/handler"
	"jd.com/jvirt/jvirt-jks-gw/httpclient"
)

type JksGWServer struct {
	logger     log.Logger
	httpUrl    string
	httpPort   string
	httpRouter *url.Router
	httpServer *http.Server
}

func NewJksGWServer(l log.Logger) (*JksGWServer, error) {
	httpUrl := cfg.DefaultCfg.BasePath
	if !strings.HasPrefix(httpUrl, "/") {
		httpUrl = "/" + httpUrl
	}

	config := cfg.RedisCfg
	// 修改为单机模式, 有redis proxy做ha
	redisClient, err := redis.New(config.Addr[0], config.IdleMax, config.ActiveMax, time.Duration(config.IdleTimeout)*time.Second, config.Password, true)
	if err != nil {
		l.Error("Invoke NewRedisClientByConfig failed. Error: %#v.", err)
		return nil, err
	}

	jksApiClient, err := httpclient.NewJksApiClient(l, cfg.JksApiCfg)
	if err != nil {
		l.Error("Invoke NewJksApiClient failed. Error: %#v.", err)
		return nil, err
	}

	// init httpRouter
	httpRouter := url.NewRouter()
	httpRouter.Logger = l
	httpRouter.RegisterFilters(httpRouter.InvokerFilter)
	gwHandler := &handler.GWHandler{
		Logger:      l,
		RedisClient: redisClient,
		JksApi:      jksApiClient,
	}
	gwHandler.RegisterHandler(httpRouter)

	s := &JksGWServer{
		logger:     l,
		httpUrl:    httpUrl,
		httpPort:   cfg.DefaultCfg.HttpPort,
		httpRouter: httpRouter,
		httpServer: &http.Server{Addr: fmt.Sprintf(":%s", cfg.DefaultCfg.HttpPort)},
	}

	return s, nil
}

func (s *JksGWServer) Start() error {
	s.logger.Debug("JksGWServer start ......")
	// 启动http服务,接受请求.
	http.Handle(s.httpUrl, s.httpRouter)
	if err := s.httpServer.ListenAndServe(); err != nil {
		s.logger.Error("The HttpServer service start failed. Error: %#v.", err)
		return err
	}

	return nil
}

func (s *JksGWServer) Stop() {
	if s.httpServer != nil {
		ctx := context.Background()
		s.httpServer.Shutdown(ctx)
		ctx.Done()
	}
	s.logger.Debug("JksGWServer stop ......")
}
