package main

import (
	"flag"
	"fmt"
	"os"
	"runtime"
	"time"

	"jd.com/jvirt/jvirt-common/utils/log"
	"jd.com/jvirt/jvirt-common/utils/termination"
	"jd.com/jvirt/jvirt-jks-gw/app/http/server"
	"jd.com/jvirt/jvirt-jks-gw/cfg"
	"jd.com/jvirt/jvirt-jks-gw/model"
)

const (
	defaultConfig = "/etc/jks/jks-gw.conf"
)

// 初始化log
func initLogger(c *model.LogConfig) (log.Logger, error) {
	logger := log.New()
	file, err := os.OpenFile(c.FilePath, os.O_WRONLY|os.O_APPEND|os.O_CREATE, 0755)
	if err != nil {
		return nil, err
	}
	logger.SetOutput(file)
	log.SetOutput(file)
	logger.SetLevel(c.Level)
	log.SetLevelString(c.Level)
	return logger, nil
}

func InitJksGWServer() (*server.JksGWServer, error) {
	// 1: 参数解析
	var configPath string
	flag.StringVar(&configPath, "config", defaultConfig, "configure file!")
	flag.Usage = func() {
		fmt.Fprintf(os.Stderr, "Usage: %s [-config <file_path>] \n", os.Args[0])
		flag.PrintDefaults()
	}
	flag.Parse()

	// 2：配置文件解析
	if err := cfg.ParseConfig(&configPath); err != nil {
		return nil, err
	}

	// 3. 根据配置文件，设置程序并发.
	runtime.GOMAXPROCS(cfg.DefaultCfg.RuntimeCores)

	// 4. 根据配置文件初始化日志
	logger, err := initLogger(cfg.LogCfg)
	if err != nil {
		return nil, err
	}

	// 5: start jvirt-jks-gw http server.
	return server.NewJksGWServer(logger)
}

func main() {
	jksServer, err := InitJksGWServer()
	if err != nil {
		fmt.Fprintf(os.Stderr, "%s Init jvirt-jks-gw error: %v.\n", time.Now(), err.Error())
		os.Exit(1)
	}

	startNotify := func() error {
		fmt.Fprintf(os.Stdout, "%s JvirtJksGWServer start ......\n", time.Now())
		err := jksServer.Start()
		if err != nil {
			fmt.Fprintf(os.Stderr, "%s JvirtJksGWServer start failed. Error: %v.\n", time.Now(), err.Error())
			return err
		}
		return nil
	}

	stopNotify := func() {
		fmt.Fprintf(os.Stderr, "%s JvirtJksGWServer stopped.\n", time.Now())
	}

	interrupt := termination.New(nil, jksServer.Stop, stopNotify)
	interrupt.Run(startNotify)
}
