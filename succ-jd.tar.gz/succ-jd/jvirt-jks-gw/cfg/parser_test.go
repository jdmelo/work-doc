package cfg

import "testing"

func TestParseConfig(t *testing.T) {
	cfgFile := "/home/succ/Gopath/src/jd.com/jvirt/jvirt-jks-gw/cfg/jvirt-jks-gw.conf"
	if err := ParseConfig(&cfgFile); err != nil {
		t.Errorf("ParseConfig failed. Error: %s.", err.Error())
	}
}
