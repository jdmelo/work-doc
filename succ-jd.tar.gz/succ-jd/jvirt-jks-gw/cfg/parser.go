package cfg

import (
	"errors"
	"fmt"
	"os"

	"jd.com/jvirt/jvirt-common/utils/config"
	"jd.com/jvirt/jvirt-common/utils/validate"
	"jd.com/jvirt/jvirt-jks-gw/model"
)

const (
	DefaultSession     = "default"
	LogSession         = "log"
	JvirtJksApiSession = "jvirt_jks_api"
	RedisSession       = "redis"
)

var (
	DefaultCfg *model.DefaultConfig
	LogCfg     *model.LogConfig
	JksApiCfg  *model.JvirtJksApiConfig
	RedisCfg   *config.RedisConfig
)

func init() {
	DefaultCfg = &model.DefaultConfig{
		HttpPort: "8090",
		BasePath: "jvirt-jks-gw",
	}

	LogCfg = &model.LogConfig{
		Level: "debug",
	}

	JksApiCfg = &model.JvirtJksApiConfig{}
	RedisCfg = &config.RedisConfig{}
}

func ParseConfig(configPath *string) error {
	if configPath == nil {
		return errors.New("the config path is nil")
	}

	parser, err := config.NewConfigParser(*configPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "NewConfigParser failed. Error: %v.\n", err.Error())
		return err
	}
	// default session config.
	if err := parser.ParserAppointSection(DefaultSession, DefaultCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Parser DefaultSession failed. Error: %v.\n", err.Error())
		return err
	}
	if err := validate.Validate(DefaultCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate DefaultSession failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("DefaultSession: %#v.\n", DefaultCfg)

	// log session config.
	if err := parser.ParserAppointSection(LogSession, LogCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Parser LogSession failed. Error: %v.\n", err.Error())
		return err
	}
	if err := validate.Validate(LogCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate LogSession failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("LogSession: %#v.\n", LogCfg)

	// jvirt_jks_api session config.
	if err := parser.ParserAppointSection(JvirtJksApiSession, JksApiCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Parser JvirtJksApiSession failed. Error: %v.\n", err.Error())
		return err
	}
	if err := validate.Validate(JksApiCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate JvirtJksApiSession failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("JvirtJksApiSession: %#v.\n", JksApiCfg)

	// redis session config.
	if err := parser.ParserAppointSection(RedisSession, RedisCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Parser RedisSession failed. Error: %v.\n", err.Error())
		return err
	}
	if err := validate.Validate(RedisCfg); err != nil {
		fmt.Fprintf(os.Stderr, "Validate RedisSession failed. Error: %v.\n", err.Error())
		return err
	}
	fmt.Printf("RedisSession: %#v.\n", RedisCfg)

	return nil
}
